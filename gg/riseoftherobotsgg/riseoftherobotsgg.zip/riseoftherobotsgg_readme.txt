Rise of the Robots (Game Gear)
Traducción al Español v1.0 (11/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rise of the Robots (USA, Europe).gg
MD5: ebcedb0b611788408d1b27171b77ad6b
SHA1: 9ba2f734eccf5b2ceefaa69cebdf7399bc9032d8
CRC32: 100b77b2
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --