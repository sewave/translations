Xenon 2 (Master System)
Traducci�n al Espa�ol v1.0 (27/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Xenon 2 (E) (Image Works) [!].sms
MD5: 1f1ce1d74c416f2b85cc3f24d316f9e3
SHA1: 72cb8a24f63e9e79c65c26141abdf53f96c60c0c
CRC32: 5c205ee1
262.144 bytes
o
Xenon 2 (E) (Virgin) [!].sms
MD5: 27fba4b7db989c663dda11c255cf49f3
SHA1: 860cff21eff077acd92b06a71d859bf3e81fe628
CRC32: ec726c0d
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --