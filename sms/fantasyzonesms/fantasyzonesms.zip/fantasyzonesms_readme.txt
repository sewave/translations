Fantasy Zone
Traducci�n al Espa�ol v1.0 (15/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Fantasy Zone
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Fantasy Zone
-----------------
Cl�sico shooter de Sega para Master System.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Fantasy Zone (UE) [!].sms
131.072	bytes
CRC32: 65d7e4e0
MD5: fed8690ee5fb895c09caa8e2b879ebd6
SHA1: 0278cd120dc3a7707eda9314c46c7f27f9e8fdda

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --