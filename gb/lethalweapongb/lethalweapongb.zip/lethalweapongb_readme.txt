Lethal Weapon (Game Boy)
Traducción al Español v1.0 (15/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lethal Weapon (U) [!].gb
MD5: d345b97e4b43f20a01fa2e4ea4a63a2b
SHA1: 8b4621471b376a6262fbed70c1191416ab3be915
CRC32: 1f8d207c
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --