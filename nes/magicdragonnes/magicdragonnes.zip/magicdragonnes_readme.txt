Magic Dragon (NES)
Traducción al Español v1.1 (15/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglados bailes de letras segun la pantalla

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Magic Dragon (Unl).nes
MD5: 394264b71ce6dcfea917203baff0aeb1
SHA1: 6f0747fc2a28dd2156b3109c4a6ae9bba33957c6
CRC32: 1ad30965
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --