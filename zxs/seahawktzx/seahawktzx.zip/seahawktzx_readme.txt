Sea Hawk (ZX Spectrum)
Traducción al Español v1.0 (14/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sea Hawk.tzx
MD5: b5a85dac13a61a6e6abe84e998174938
SHA1: cf2fe6dd1673a240bb611c3677aa02f9758f0103
CRC32: 25c2e927
48512 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --