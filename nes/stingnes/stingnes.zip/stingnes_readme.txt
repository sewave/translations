STING (NES)
Traducción al Español v1.0 (10/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
STING.nes
MD5: c68fcfb486e531e2efb0f348fb100920
SHA1: a6f56e46f09d87d41f48d615bc35e95a702d451a
CRC32: f0c8191b
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --