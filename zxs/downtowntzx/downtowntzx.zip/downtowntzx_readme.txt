Down Town (ZX Spectrum)
Traducción al Español v1.0 (02/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Down Town.tzx
MD5: 44f05de9058c0244e993687524d2813f
SHA1: 867f93a1d54ae26a5f8ab387fb6c92d5bd6cc75b
CRC32: d091a8f3
48252 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --