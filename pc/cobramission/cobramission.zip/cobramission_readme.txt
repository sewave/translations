Cobra Mission (PC)
Traducción al Español v1.0 (09/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Sí, Cobra Mission es un juego que nos llegó en español, bueno, la mayor parte, hay trozos que no estaban traducidos y esto es lo que traduce este parche, reutilizando en la medida de lo posible los caracteres del español, lo traducido:
-Nombre y descripción de objetos
-Menús y pantallas de estado
-Nombres de lugares y personajes con los que hablas
-Pequeños textos al usar o encontrar objetos en el mapa
-Diálogos de combate
-Créditos

Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivos utilizados:
CM.EXE
MD5: e83c173f4c7bf8595d8c901cfb744805
SHA1: 2e24d449ee18c03162ae00fc44fb3800f8376dff
CRC32: 3bdf2e14
115092 bytes
DAT.VOL
MD5: 3fd5f3e2832e90444a86f9cf7417e3ab
SHA1: 2217dcdaaac3f30df01f2a2983138af23fdc2563
CRC32: e2cbbd2e
120547 bytes
ICP.VOL
MD5: 413e65e99c8eeae398bb309d17ec82bf
SHA1: 3783baaee5ab560577bc7efe41d2a15d4c6d0ebc
CRC32: 0cf87e9a
99120 bytes
MED.VOL
MD5: cf4cce634321eaeb4996ae0531ce2535
SHA1: 1dcc0312009fe25e5115100c485a783aff0fbc3c
CRC32: 1aa936a3
148434 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --