Zero the Kamikaze Squirrel
Traducci�n al Espa�ol v1.0 (11/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Zero the Kamikaze Squirrel
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Zero the Kamikaze Squirrel
-----------------
Plataformas Spin-off de Aero the Acrobat para Super Nintendo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
La carta inicial no es texto y no est� traducida.
Si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Zero the Kamikaze Squirrel (U) [!].smc
2.097.152 bytes
CRC32: 5397d5bc
MD5: 7981be58e5eec603c585a0f1a3190840
SHA1: 622edfe3a7b2c65724c2d78fb3d692775cd1fde1

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --