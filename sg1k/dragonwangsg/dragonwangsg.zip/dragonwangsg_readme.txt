Dragon Wang (SG-1000)
Traducci�n al Espa�ol v1.0 (28/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon Wang (SG-1000) (Ver-A).sg
MD5: 64d3cc8117292f6d5af8e1aad95bcb90
SHA1: 43807c9f634b8cf85aa5c3b2459885eedbb99955
CRC32: 99c3de21
32.768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --