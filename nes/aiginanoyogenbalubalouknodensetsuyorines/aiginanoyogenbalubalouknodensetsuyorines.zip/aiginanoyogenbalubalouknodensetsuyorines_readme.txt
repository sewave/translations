Aigina no Yogen - Balubalouk no Densetsu Yori (NES)
Traducción al Español v1.0 (14/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basada en la de Psyklax.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Aigina no Yogen - Balubalouk no Densetsu Yori (Japan).nes
MD5: e2790029e75f2fb102293f4d820cb46b
SHA1: 2eb9fba7b065a01abca38c2db77cad660c767018
CRC32: 04fc4764
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
OscarXD  - Pruebas.

-- FIN --