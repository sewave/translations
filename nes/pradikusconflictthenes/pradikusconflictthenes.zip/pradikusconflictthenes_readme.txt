The P'radikus Conflict (NES)
Traducción al Español v1.0 (20/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
P'radikus Conflict, The (Color Dreams) [!].nes
MD5: a71fec5e140b034279136b1f602b4401
SHA1: 022c620fc7ee0325e959c03382b7dfc6523a5027
CRC32: 74cbadb7
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --