Flying Dragon - The Secret Scroll (NES)
Traducción al Español v1.0 (10/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Flying Dragon - The Secret Scroll (U) [!].nes
MD5: 6afc3484cc64b482aaa44ca2f91e918e
SHA1: 3193682d39be24e7e1f51d44911867c66a8f452b
CRC32: c2f70a8c
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --