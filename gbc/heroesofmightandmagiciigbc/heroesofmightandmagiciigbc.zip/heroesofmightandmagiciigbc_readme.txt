Heroes of Might and Magic II (Game Boy Color)
Traducción al Español v1.1 (10/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Arreglados caracteres especiales

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Heroes of Might and Magic II (USA) (En,Fr,De).gbc
MD5: ad37726c92f43ad7915225b7eaf94ffd
SHA1: 1d6ae18073c8b789c288039b0f579ebf15d1f03c
CRC32: 53156d4d
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --