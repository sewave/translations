Megaman II
Traducci�n al Espa�ol v1.0 (06/08/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Megaman II
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Megaman II
-----------------
Segunda parte del cl�sico de Capcom.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Megaman II (U) [!].nes
262.160	bytes
CRC32: 5e268761
MD5: 8e4bc5b03ffbd4ef91400e92e50dd294
SHA1: 2290d8d839a303219e9327ea1451c5eea430f53d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --