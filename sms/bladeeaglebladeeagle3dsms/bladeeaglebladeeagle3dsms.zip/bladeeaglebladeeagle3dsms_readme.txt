Blade Eagle ~ Blade Eagle 3-D (Master System)
Traducción al Español v1.0 (09/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blade Eagle ~ Blade Eagle 3-D (World).sms
MD5: a20798b12481284f77cee67ce5e25f2b
SHA1: b786d15b26b914c24cd1c36a8fca41b215c0a4e7
CRC32: 8ecd201c
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --