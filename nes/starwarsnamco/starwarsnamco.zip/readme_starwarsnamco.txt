Star Wars (Namco)
Traducci�n al Espa�ol v1.0 (17/12/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Star Wars (Namco)
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Star Wars (Namco)
-----------------
Adaptacion de la pelicula por namco, muy dificil hacia el final.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking esta bastado en la traduccion al ingles de Gil Galad.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Star Wars (J) (Namco) [!].nes
262.160	bytes
CRC32: cce17a0e
MD5: 86382cfada9d12b339b1db8e5bbff026
SHA1: d5047da05e3f161b97a11ca271671380635b4b8d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Original:
Credits
------------------

Honookatana - Japanese script translation.

DarkDaiz - Suggested the PPU could be incrementing some of the tiles.

sqpat - Read a Star Wars novel for Chewie sounds.

bbitmaster - Death Star map. Continue mode hack.

Sliver-X - Beta testing.

Thaddeus - Beta testing.

Cahos Rahne Veloza - Testing and suggestions.


Authors of the above stated tools and emus.

-- END OF README --