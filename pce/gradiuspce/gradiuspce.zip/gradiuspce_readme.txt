Gradius (PC Engine)
Traducción al Español v1.0 (01/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gradius (Japan).pce
MD5: 16fe78b1630a790bee6755e3c850a366
SHA1: 338f62b6d57f30b1850c32f5ae0d8c26c761974b
CRC32: 0517da65
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --