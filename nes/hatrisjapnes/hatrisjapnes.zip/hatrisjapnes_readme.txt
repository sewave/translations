Hatris (Japón) (NES)
Traducción al Español v1.0 (02/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hatris (Japan).nes
MD5: 8999823949727f884f9efd0caf4d81af
SHA1: 802aa5d7fe0a8eb87741214730268874f1352fb5
CRC32: 66d1ab95
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --