Super Mario Bros.
Traducci�n al Espa�ol v1.0 (22/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Super Mario Bros.
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Super Mario Bros.
-----------------
El primer Super Mario para la NES.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Super Mario Bros. (W) [!].nes
40.976 bytes
CRC32: 3337ec46
MD5: 811b027eaf99c2def7b933c5208636de
SHA1: ea343f4e445a9050d4b4fbac2c77d0693b1d0922

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --