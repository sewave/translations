1942 (Game Boy Color)
Traducci�n al Espa�ol v1.0 (05/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
1942 (U) [C][!].gbc
MD5: a31652b6d1e7fc647c4af7b9dfe05ff5
SHA1: d960e951b18d07e79d046313df49c18313664224
CRC32: 87431672
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --