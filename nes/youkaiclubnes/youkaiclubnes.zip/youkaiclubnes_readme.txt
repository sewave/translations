Youkai Club (NES)
Traducción al Español v1.0 (12/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Youkai Club (Japan).nes
MD5: 0cd3eed8b490c9eede01b500580f9e23
SHA1: 9cf2ebfc0caf610d80b38bdd6f41a3af7e0d4bfc
CRC32: 7fcefe0c
163856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --