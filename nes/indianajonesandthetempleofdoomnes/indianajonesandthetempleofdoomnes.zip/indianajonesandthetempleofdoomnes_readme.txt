Indiana Jones and the Temple of Doom (NES)
Traducción al Español v1.0 (06/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Indiana Jones and the Temple of Doom (U) (PRG1) [!].nes
MD5: efda1db25bbc2df2943bd9922a07ab25
SHA1: 14e0d24d816fdcba6c1ac874bd911f215956230d
CRC32: f07d31b2
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --