U.N. Squadron (Super Nintendo)
Traducción al Español v1.0 (29/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
U.N. Squadron (USA).sfc
MD5: affecaf49a6bd32188f62d9ad1f833ea
SHA1: a2dd48574b9f7a49977c91d12d5c52c17c2c82aa
CRC32: 231f0f67
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --