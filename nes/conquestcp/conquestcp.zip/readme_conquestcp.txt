Conquest of the Crystal Palace
Traducci�n al Espa�ol v1.0 (15/03/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Conquest of the Crystal Palace
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Conquest of the Crystal Palace
-----------------
Epica aventura de Asmik, menos siniestro que su version japonesa, pero con todo el encanto.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Conquest of the Crystal Palace (U) [!].nes
262.160	bytes
CRC32: 0a362909
MD5: edb710ff29cafdc131a6c26c952829d2
SHA1: 9369adbb9bdc25861877285773d14c747e48c500

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --