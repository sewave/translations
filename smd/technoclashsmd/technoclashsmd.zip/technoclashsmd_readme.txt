TechnoClash (Mega Drive)
Traducción al Español v1.0 (23/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
TechnoClash (USA, Europe).md
MD5: 4cd30f3ad42b0354659d128bdcd61a6c
SHA1: 686afbd7130fe8487d9126e690bf53800ae953ba
CRC32: 4e65e483
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --