Mortal Kombat 3 (Game Boy)
Traducción al Español v1.0 (22/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mortal Kombat 3 (U) [!].gb
MD5: c19d61e31d6aebc12abf80d628a7bd09
SHA1: b43626e2f20fa865783892ab8a012aa86e1dcee2
CRC32: bf9c65fb
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --