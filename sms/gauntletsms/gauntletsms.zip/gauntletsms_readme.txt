Gauntlet (Master System)
Traducci�n al Espa�ol v1.0 (06/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gauntlet (UE) [!].sms
MD5: fdd401983eb42200f9fec672374597af
SHA1: 4e583ce9b95e20ecddc6c1dac9941c28a3e80808
CRC32: d9190956
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --