Fantasy Zone II - The Tears of Opa-Opa (Master System)
Traducci�n al Espa�ol v1.0 (10/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fantasy Zone II - The Tears of Opa-Opa (UE) [!].sms
262.656 bytes
MD5: a5249952d12dbd0d46b651f3788b5bd4
SHA1: 406d0676232e24492c4ecf84609b262db6b69865
CRC32: a5233205

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.
Juandex - Testing

-- FIN --