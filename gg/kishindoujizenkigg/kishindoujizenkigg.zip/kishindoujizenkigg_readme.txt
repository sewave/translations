Kishin Douji Zenki (Game Gear)
Traducción al Español v1.0 (27/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de LIPEMCO! Translations.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kishin Douji Zenki (Japan).gg
MD5: ac6ed281ac8e9d71af186602951cfd7a
SHA1: 0fb3530633070551f3d5a04839fc42babc092fbd
CRC32: 7d622bdd
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --