Junction (Mega Drive)
Traducci�n al Espa�ol v1.0 (01/12/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Junction (JU) [!].bin
MD5: 6d8a871ce4b1e88aecd4d0d50a137e99
SHA1: 7981e5764458f5230184c7b2cf77469e1ed34270
CRC32: 94cdce8d
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --