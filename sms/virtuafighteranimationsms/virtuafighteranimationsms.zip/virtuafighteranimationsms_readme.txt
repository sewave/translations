Virtua Fighter Animation (Master System)
Traducción al Español v1.0 (14/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Virtua Fighter Animation (J) [!].sms
MD5: fdc90edb44d2a2236ab9c29d2f073d3c
SHA1: ee24af11f2066dc8ffbefb72a5048a2471576229
CRC32: 57f1545b
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --