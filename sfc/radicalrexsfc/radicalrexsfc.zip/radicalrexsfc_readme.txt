Radical Rex (Super Nintendo)
Traducci�n al Espa�ol v1.0 (19/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Radical Rex (U).smc
MD5: d3664d3f30be16b2586b74108f8f3914
SHA1: 2e3336721770668ddbb2687cc9da5c719fe38823
CRC32: e2b8da18
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --