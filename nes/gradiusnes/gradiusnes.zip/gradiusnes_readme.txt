Gradius (NES)
Traducci�n al Espa�ol v1.0 (13/07/2018)
(C) 2018 Wave Translations

---------
Contenido
---------

1. Notas y Fallos Conocidos
2. Instrucciones de Parcheo
3. Cr�ditos del Parche

---------------------------
1. Notas y Fallos Conocidos
---------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
2. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Gradius (U) [!].nes
65.552 bytes
CRC32: 7a269942
MD5: fcc019dc8054403fd28b8de03d7e16aa
SHA1: 17d740e1e79350e1f0a6565908767e8585606a98

----------------------
3. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --