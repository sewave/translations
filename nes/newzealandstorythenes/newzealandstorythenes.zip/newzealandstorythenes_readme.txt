The New Zealand Story (NES)
Traducci�n al Espa�ol v1.0 (23/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
New Zealand Story, The (E) [!].nes
MD5: 2bb742838ee1031c56bd931b6d4d3943
SHA1: f99541870ca6b3bb63e5cf00ecb2fbc26ba680b4
CRC32: 4cf8ed7e
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --