Rally Bike (NES)
Traducción al Español v1.0 (21/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rally Bike (U) [!].nes
MD5: 9e37094e7e57069536540eb802e45dfd
SHA1: 1d09681605e838acefcca32dcfb0d3377aa970e3
CRC32: d2cdce48
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --