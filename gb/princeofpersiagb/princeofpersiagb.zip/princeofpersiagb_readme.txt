Prince of Persia (Game Boy)
Traducción al Español v1.0 (02/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Prince of Persia (U).gb
MD5: 80034da43f35307291714ae2553d9ddf
SHA1: ef3ef15b791ceff34d7d9bb5b3af2e05842c8323
CRC32: 2bd995f1
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --