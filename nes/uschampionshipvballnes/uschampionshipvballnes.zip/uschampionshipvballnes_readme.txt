US Championship V'Ball
Traducci�n al Espa�ol v1.0 (13/08/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre US Championship V'Ball
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre US Championship V'Ball
-----------------
Versi�n japonesa del juego de voley playa, cambian algunas cosas como menus o las frases de los jugadores a elegir.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
US Championship V'Ball (J) [!].nes
262.160	bytes
CRC32: 0bafbb69
MD5: 01e48bcd611e6bd8ca6b70128e773a83
SHA1: 36d352fa06e1bacc5fb7025ce7748830f6e1f19d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --