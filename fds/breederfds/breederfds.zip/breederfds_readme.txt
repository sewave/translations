Breeder (Famicom Disk System)
Traducción al Español v1.0 (29/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Breeder (Japan) [b].fds
MD5: 774bad95592ef8c365ac7b0724f196b6
SHA1: 82a6a9ca123add14839ca71e1b74d9f7708d3ab2
CRC32: 6e103744
131000 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --