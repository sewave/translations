DuckTales (NES)
Traducción al Español v1.1 (01/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Arreglado "A PARTE" del final.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
DuckTales (USA).nes
MD5: 34fd4014afd15b562d7100f641f900ab
SHA1: 4b5720bc6e0590c9372cfbd0c418f8efd4d0c96d
CRC32: dcb94341
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --