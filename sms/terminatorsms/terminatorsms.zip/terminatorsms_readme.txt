Terminator, The
Traducci�n al Espa�ol v1.0 (24/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Terminator, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Terminator, The
-----------------
Adaptacion de la pelicula para master system.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Terminator, The (E) [!].sms
262.144	bytes
CRC32: edc5c012
MD5: f224907676a09c7f0404c95c316f1503
SHA1: eaf733d385e61526b90c1b194bf605078d43e2d3

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --