Cool Spot (Master System)
Traducci�n al Espa�ol v1.0 (16/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cool Spot (E) [!].sms
MD5: b4c33bdba2472003f87ed193e51b2c9b
SHA1: cf36c1900d1c658cbfd974464761d145af3467c8
CRC32: 13ac9023
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --