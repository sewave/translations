Super Spy Hunter (NES)
Traducción al Español v1.0 (30/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Spy Hunter (U) [!].nes
MD5: b72e063e45a785a54c8e456aa8d713c7
SHA1: de5964c4f66200b3912889f2e6f27e97436385df
CRC32: 81d24ccc
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --