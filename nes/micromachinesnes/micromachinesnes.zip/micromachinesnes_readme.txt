Micro Machines (NES)
Traducci�n al Espa�ol v1.0 (21/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Micro Machines (Camerica) [!].nes
MD5: 5bf611347d73efe17778d6ca0d0c94a4
SHA1: 844295819b30b4802c25d34860cb40e75b850f10
CRC32: f3fffc7a
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --