Vattle Giuce (Game Boy)
Traducción al Español v1.0 (17/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Vattle Giuce (J) [!].gb
MD5: 813755de3d7338c9442f072ed52f52b3
SHA1: ca41cd69249a9ee703acfad044759baa42ef2c9a
CRC32: 956b603c
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --