Booby Kids (NES)
Traducción al Español v1.0 (03/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Booby Kids (J) [!].nes
MD5: c329905a1ede73fb82cae513a4317d6e
SHA1: 0c36fcd352fac6b8ca171c92f350099437dbeb5a
CRC32: 828f23a8
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --