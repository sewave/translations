Alien 3 (NES)
Traducción al Español v1.0 (05/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alien 3 (USA).nes
MD5: f1dfb8cc6b1ee557c0435b1be01194b2
SHA1: 9f6c768850a49a4b50597d952523a927b2b6b48b
CRC32: efb4ca05
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --