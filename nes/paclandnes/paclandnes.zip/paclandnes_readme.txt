Pac-Land (NES)
Traducción al Español v1.0 (01/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pac-Land (Japan).nes
MD5: 9f71d05fb99d8fd30e7b4c08d462577f
SHA1: 23465e55a862610dbbf98b19ea03ea40246c2254
CRC32: 6ea63a46
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --