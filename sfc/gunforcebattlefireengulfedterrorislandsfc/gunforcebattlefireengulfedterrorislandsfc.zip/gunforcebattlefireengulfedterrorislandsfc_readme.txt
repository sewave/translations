Gunforce - Battle Fire Engulfed Terror Island (Super Nintendo)
Traducción al Español v1.0 (24/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gunforce - Battle Fire Engulfed Terror Island (U).smc
MD5: c77b2f22f465bcb8fd1e6c779d21f2e1
SHA1: 29c3fb9c230972735961bc328903d07df20c87b7
CRC32: 6f5c5dc0
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --