Ninja Gaiden (Game Gear)
Traducci�n al Espa�ol v1.0 (18/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Gaiden (U) [!].gg
MD5: 764388b8b5dc2e762fab9badd0eca6ba
SHA1: 1a5c44e76a0e913d76f590affae3b2e24fbd0f59
CRC32: c578756b
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --