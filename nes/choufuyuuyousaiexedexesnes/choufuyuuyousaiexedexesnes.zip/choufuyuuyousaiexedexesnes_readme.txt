Chou Fuyuu Yousai Exed Exes (NES)
Traducción al Español v1.0 (14/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chou Fuyuu Yousai Exed Exes (Japan).nes
MD5: 6aab00294fa91b2af18424fe3dba5579
SHA1: 7523fc248138986e6bb68210da64f2ddbe72aa43
CRC32: 3e8713c7
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --