Star Wars (Game Boy)
Traducción al Español v1.0 (31/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Star Wars (U) (V1.1) [!].gb
MD5: cb1dce08c78c509a876c494d6333f45c
SHA1: f6563f526fc786c8666d75dfba9e6d42d787ea89
CRC32: 5d8deb5b
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --