WWF Superstars 2 (Game Boy)
Traducción al Español v1.0 (29/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
WWF Superstars 2 (USA, Europe).gb
MD5: 07006fe2f7363d475e34fbf63e4e94d1
SHA1: f5f2a16a9ea5694e3198cb6a9a16bcbca75be12f
CRC32: 8ece1c04
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --