Link Dragon (Mega Drive)
Traducción al Español v1.0 (12/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Link Dragon (Taiwan) (En) (Unl).md
MD5: dbfa3ac3c752d83b73540c177ced0cab
SHA1: 09e4b59da3344f16ce6173c432c88ee9a12a3561
CRC32: 1b86e623
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --