Battletoads
Traducci�n al Espa�ol v1.0 (03/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Battletoads
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Battletoads
-----------------
Versi�n de Battletoads para Game Gear.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Battletoads (U) [!].gg
262.144	bytes
CRC32: 817cc0ca
MD5: 643536bfaf945e8fa8a22de8d4653d83
SHA1: f566a19d1cfd5c20d5b91b396f29323be2209911

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --