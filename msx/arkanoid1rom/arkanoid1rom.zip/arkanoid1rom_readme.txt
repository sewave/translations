Arkanoid 1 (MSX)
Traducción al Español v1.0 (15/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Arkanoid 1 (1986) (Taito) (J).rom
MD5: 9a911c98431ba82aec9907142aee3eff
SHA1: 2183f07fa3ba87360100b2fa21fda0f55c0f8814
CRC32: c9a22dfc
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --