Hit the Ice (NES)
Traducción al Español v1.0 (21/12/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hit the Ice (USA) (Proto 2).nes
MD5: 61b037805a16ce5bd4013be4c473d44b
SHA1: 4639d15d4449edd1eb2cad98a482987bd8977913
CRC32: 60b6cba0
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --