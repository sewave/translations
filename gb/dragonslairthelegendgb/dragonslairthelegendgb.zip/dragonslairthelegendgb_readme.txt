Dragon's Lair - The Legend (Game Boy)
Traducción al Español v1.0 (08/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon's Lair - The Legend (U) [!].gb
MD5: ae4fda03378a0584d45a4735c9d6290e
SHA1: 4e947908fde7ef9892c59021c6eea0607771f6d2
CRC32: 7a38b5c3
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --