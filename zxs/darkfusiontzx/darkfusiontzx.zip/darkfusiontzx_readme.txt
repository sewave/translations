Dark Fusion (ZX Spectrum)
Traducción al Español v1.0 (15/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dark Fusion.tzx
MD5: b9ed31f3c2d7a1a7cca5393f61dc15f0
SHA1: c08b8cc31f7c07ae6efb5b6713ddd0614c32b5f0
CRC32: 1fbd70d2
65961 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --