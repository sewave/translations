World of Illusion Starring Mickey Mouse & Donald Duck
Traducci�n al Espa�ol v1.1 (25/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre World of Illusion Starring Mickey Mouse & Donald Duck
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre World of Illusion Starring Mickey Mouse & Donald Duck
-----------------
Gran plataformas de Disney para la Mega Drive con juego Cooperativo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

V1.1: Reescrita parte de la intro al causar confusi�n.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
World of Illusion Starring Mickey Mouse & Donald Duck (U) [!].bin
1.048.576 bytes
CRC32: 921ebd1c
MD5: c2c5a4b990ce72f98b7b7f236e66c022
SHA1: adb0a2edebb6f978c3217075a2f29003a8b025c6

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --