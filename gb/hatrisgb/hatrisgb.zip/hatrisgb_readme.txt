Hatris (Game Boy)
Traducción al Español v1.0 (02/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hatris (Japan, USA).gb
MD5: b9d3d91d8389cc510aa8fe9063228644
SHA1: e8002f226e90ed52e1675c003d3c8ce804b56b0e
CRC32: 7635f28b
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --