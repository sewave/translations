Streets of Rage 3 (Mega Drive)
Traducción al Español v1.0 (18/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Streets of Rage 3 (U) [!].bin
MD5: 2d0b0c8f10edf76131708e874e8d1ee4
SHA1: 40a33dd6f9dab0aff26c7525c9b8f342482c7af6
CRC32: d5bb15d9
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --