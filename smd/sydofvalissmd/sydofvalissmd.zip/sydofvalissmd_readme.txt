Syd of Valis (Mega Drive)
Traducción al Español v2.0 (06/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres especiales
-Revisión de script
-Traducidos créditos

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Syd of Valis (USA).md
MD5: a81d327574d49aab69c2a6fe4cdc893a
SHA1: 36e010f16791816108d395fce39b39ab0a49268c
CRC32: 37dc0108
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --