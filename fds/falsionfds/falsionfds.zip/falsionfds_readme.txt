Falsion (Famicom Disk System)
Traducción al Español v1.0 (01/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Falsion (Japan).fds
MD5: e1c635b2a67f2e683db3d50b23d1f519
SHA1: b81fe9f10fb19aff6e5303e7b0445e4399811791
CRC32: 5442c889
131000 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --