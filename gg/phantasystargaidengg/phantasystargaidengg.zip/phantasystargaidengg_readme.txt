Phantasy Star Gaiden (Game Gear)
Traducción al Español v1.2 (20/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la traducción de Magic Translations.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglo de textos del final.
V1.2: Arreglada frase final de Cablon y repaso del script.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Phantasy Star Gaiden (J) [!].gg
MD5: 54be96ca21885145108f1c02e4d88eba
SHA1: 914f1e693f396794a37b5d99acaf5db54fe529c2
CRC32: a942514a
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

Contributor	Type of contribution	Listed credit
Faraday	Translation	
Taskforce	Hacking	Hacking + font and script work
Wildbill	Script Editing/Revision	

-- FIN --