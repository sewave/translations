Time Zone
Traducci�n al Espa�ol v1.0 (03/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Time Zone
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Time Zone
-----------------
Curioso plataformas para la 8 bits de Nintendo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking esta basado en la traducci�n al ingl�s de King Mike.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Time Zone (J) [!].nes
262.160 bytes
CRC32: c99628bc
MD5: fe0adeaf7a696da636e7b8263c8f81d1
SHA1: b8bafdd2d63747906b00dc320ddf1fe62b2803f4

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
Original:
Tomato	Translation

-- END OF README --