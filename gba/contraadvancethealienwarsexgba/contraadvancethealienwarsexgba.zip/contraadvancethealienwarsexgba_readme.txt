Contra Advance - The Alien Wars EX (Game Boy Advance)
Traducción al Español v1.0 (23/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Contra Advance - The Alien Wars EX (USA).gba
MD5: 78672ead9f35f00e467f8c7d308acdfc
SHA1: 21b593c0fbdeacfbf0f72895fba2401fd7b60b65
CRC32: 59781c54
4194304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --