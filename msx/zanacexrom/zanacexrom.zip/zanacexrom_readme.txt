Zanac-EX (MSX 2)
Traducción al Español v1.0 (15/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zanac-EX (1986) (Pony Cannon) (J).rom
MD5: 03d381a40baed2be60f09a91b52316cc
SHA1: 23e702084e3031158a50a0560746767bbc1b7bee
CRC32: d153b2f2
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --