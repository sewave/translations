Road Rash (Master System)
Traducci�n al Espa�ol v1.0 (05/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Road Rash (E) [!].sms
MD5: 325575374d2db3755f83bba728990ebe
SHA1: 7976e717125757b1900a540a68e0ef3083839f85
CRC32: b876fc74
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --