Virtua Fighter Animation (Game Gear)
Traducción al Español v1.0 (14/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Virtua Fighter Animation (U) [!].gg
MD5: db315b11c28f8be4ecdac77759e889de
SHA1: 222f3e49f595ceb4263af329c4021d64fc4772e6
CRC32: d431c452
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --