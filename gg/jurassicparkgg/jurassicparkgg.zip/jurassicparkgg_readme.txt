Jurassic Park
Traducci�n al Espa�ol v1.0 (03/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Jurassic Park
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Jurassic Park
-----------------
Adaptaci�n de la primera parte de la franquicia para Game Gear.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Jurassic Park (UE) [!].gg
524.288	bytes
CRC32: bd6f2321
MD5: a3158baab261c5ddbcd4328d01e33a94
SHA1: 0425dc09465a4b7be78ab7aa46107987ba61e82a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --