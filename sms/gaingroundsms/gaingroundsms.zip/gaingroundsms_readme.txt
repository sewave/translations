Gain Ground (Master System)
Traducci�n al Espa�ol v1.0 (20/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gain Ground (UE) [!].sms
262.144	bytes
MD5: 7d54230748fa41bb62b6f08e5dcede08
SHA1: 62c0ca61ad8f679f90f253ab6bbffd0c7737a8c0
CRC32: 3ec5e627

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --