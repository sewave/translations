Aqua Squad (ZX Spectrum)
Traducción al Español v1.0 (28/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Aqua Squad.tzx
MD5: 4c10e949a52c910786ad1bb1586a0e69
SHA1: 1d1a4c5da0f073f1c60cd47a37d1ef779e890996
CRC32: 04e5713e
55285 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --