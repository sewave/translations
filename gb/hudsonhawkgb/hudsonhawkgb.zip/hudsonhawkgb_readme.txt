Hudson Hawk (Game Boy)
Traducci�n al Espa�ol v1.0 (16/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hudson Hawk (U) [!].gb
MD5: 9c1efb1bd07fd91765f680e7e9bc44f1
SHA1: efdbb5f86d6ff3b3f248b0360ab548ac1ceb1e0e
CRC32: adff7bbd
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --