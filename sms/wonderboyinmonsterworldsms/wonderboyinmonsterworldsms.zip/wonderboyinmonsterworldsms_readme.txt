Wonder Boy in Monster World (Master System)
Traducci�n al Espa�ol v1.0 (03/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wonder Boy in Monster World (E) [!].sms
524.288 bytes
MD5: 5837764c172c8c43c8c7b21f2144cf27
SHA1: da0acdb1b9e806aa67a0216a675cb02ed24abf8b
CRC32: 7d7ce80b

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --