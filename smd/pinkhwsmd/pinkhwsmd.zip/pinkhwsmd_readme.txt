Pink Goes to Hollywood
Traducci�n al Espa�ol v1.0 (15/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Pink Goes to Hollywood
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Pink Goes to Hollywood
-----------------
Plataformas de la pantera rosa para MegaDrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Pink Goes to Hollywood (U) [!].gen
1.048.576 bytes
CRC32: b5804771
MD5: d05bb061ee9f5880bbbe330843bb4079
SHA1: fc63d2a2a723f60f2141bc50bd94acef74ba9ab3

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --