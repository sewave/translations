DEcapAttack (Mega Drive)
Traducción al Español v2.0 (12/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducida la pantalla de título.
-Traducidos "START"-"GOAL".
-Traducido "PAUSE".
-Añadida "Ñ" en los créditos.
-Traducido gráfico de "THE END".
-Añadidos Ó-Ú en los títulos de las pantallas.
-Añadidos caracteres españoles en los diálogos.
-Traducido LUCKY.
-Script retraducido.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
DEcapAttack (USA, Europe).md
MD5: 283c180cede3352dabec75fff677052e
SHA1: 9665f54a6149d71ea72db9c168755e62cb61649c
CRC32: 73dc0dd8
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --