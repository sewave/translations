Malibu Bikini Volleyball (Atari Lynx)
Traducción al Español v1.0 (20/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking contiene el cargador de Harry Dodgson.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Malibu Bikini Volleyball (USA, Europe).lnx
MD5: 280344c8b073895ecce286d1b9d87d8b
SHA1: 9c3d8037d347c0ff23d941eff8b575a4f2f051da
CRC32: aba6da3d
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --