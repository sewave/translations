Exo Squad (Mega Drive)
Traducción al Español v1.0 (25/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Exo Squad (USA).md
MD5: 3297aed1b8bb83cca67bc2e24f84414a
SHA1: d958c3f2365162cb2ffa37fcea36695a1d4ab287
CRC32: 10ec03f3
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --