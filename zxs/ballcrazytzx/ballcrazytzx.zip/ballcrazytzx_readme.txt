Ball Crazy (ZX Spectrum)
Traducción al Español v1.0 (01/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ball Crazy.tzx
MD5: bc4ce91e5b8b29aada39c7f72982bad5
SHA1: ccb6eaa338520bbd0bee4fdba7c959f5bced8b8e
CRC32: 82d830a3
41304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --