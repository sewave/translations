The Simpsons - Bart Vs. the Space Mutants (NES)
Traducción al Español v1.0 (19/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Simpsons, The - Bart Vs. the Space Mutants (E) [!].nes
MD5: ccd36aef8b65b3e64c7a7189e004ad43
SHA1: 6e00647579904835b8f237875b81cc6d19839d51
CRC32: b3cd6707
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --