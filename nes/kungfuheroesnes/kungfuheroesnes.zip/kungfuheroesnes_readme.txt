Kung-Fu Heroes (NES)
Traducción al Español v1.0 (29/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kung-Fu Heroes (U) [!].nes
MD5: bd3c10bdbef581759295ae16c9626859
SHA1: c1500248a260d6084dff86b232f1231c62913af5
CRC32: 736bd189
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --