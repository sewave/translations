Star Force (NES)
Traducción al Español v1.0 (30/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Star Force (U) [!].nes
MD5: f9faebd9c835619b6df05c03c32b5e46
SHA1: 881bd152f6ee107495961abb9fd0fdffbd3ad1a4
CRC32: b3cf12b8
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --