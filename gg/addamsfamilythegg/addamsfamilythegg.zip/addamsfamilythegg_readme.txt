The Addams Family (Game Gear)
Traducción al Español v2.0 (17/09/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducida licencia
-Guion retraducido
-Mejorado inventario

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Addams Family, The (World).gg
MD5: f4f3211738002369b9ada7a099e33a45
SHA1: 3231d574e5eb0ac3a77b1d65d74f3a581819a9c7
CRC32: 1d01f999
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --