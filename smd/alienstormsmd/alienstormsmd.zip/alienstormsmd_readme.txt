Alien Storm
Traducci�n al Espa�ol v1.0 (23/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Alien Storm
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alien Storm
-----------------
Port del arcade beat em up de Sega para la 16 bits.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alien Storm (W) [!].gen
524.288	bytes
CRC32: f5ac8de5
MD5: b63052973d5d550087d6b36ce8487fb1
SHA1: e4f8774c5f96db76a781c31476d06203ec16811a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --