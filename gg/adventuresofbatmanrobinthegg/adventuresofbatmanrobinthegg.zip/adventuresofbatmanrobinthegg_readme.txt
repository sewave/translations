Adventures of Batman & Robin, The
Traducci�n al Espa�ol v1.0 (10/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Adventures of Batman & Robin, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Adventures of Batman & Robin, The
-----------------
Adaptaci�n de la animaci�n de Batman & Robin para Game Gear.
Nota: para usar los ascensores, hay que pulsar ataque y luego arriba sin soltarlo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Adventures of Batman & Robin, The (U) [!].gg
524.288	bytes
CRC32: bb4f23ff
MD5: a684cba5f11c4e4e3e6cb71a0d73c702
SHA1: 50e8726be1b26d066ea9e2e2b5cd7407c356187e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --