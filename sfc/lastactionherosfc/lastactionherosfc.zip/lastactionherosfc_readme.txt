Last Action Hero (Super Nintendo)
Traducción al Español v1.0 (29/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Last Action Hero (U).smc
MD5: 2c22830019d300eef94e52a31f7b9a4a
SHA1: 099bf2ea5dd17c52621c4558d89a4da0593cf5de
CRC32: 88017df9
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --