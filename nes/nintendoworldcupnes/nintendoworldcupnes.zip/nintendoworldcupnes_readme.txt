Nintendo World Cup (NES)
Traducción al Español v1.0 (27/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nintendo World Cup (USA).nes
MD5: fc0cd7c1b00d73d18e1f8af142c98fb8
SHA1: 75a2abb0d34be656ee98a9417f85a90ea4a2cbf8
CRC32: 88b55f68
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --