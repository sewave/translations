Donald in Maui Mallard (Mega Drive)
Traducción al Español v1.0 (17/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Donald in Maui Mallard (E) [!].bin
MD5: 46a37b8927fc9404d054f6b85d620f3f
SHA1: cd3c50b7f9c2f97d7bb0042e4239a05066ae72e0
CRC32: b2dd857f
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --