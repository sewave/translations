Finders Keepers (ZX Spectrum)
Traducción al Español v1.0 (08/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Finders Keepers.tzx
MD5: e25f8f219a6c326cd38c8956131a2f7a
SHA1: c9bc875decec49c7f05bff958515f29ba3d7bc88
CRC32: 6550d66e
44232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --