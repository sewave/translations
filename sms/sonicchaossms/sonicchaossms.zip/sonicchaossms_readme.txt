Sonic Chaos (Master System)
Traducci�n al Espa�ol v1.0 (19/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sonic Chaos (E) [!].sms
MD5: 1d661134b14eedf6b4ae1c907581fd96
SHA1: f64c8eea26a103582f09831c3e02c6045a6aff94
CRC32: aedf3bdf
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --