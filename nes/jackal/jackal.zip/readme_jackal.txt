Jackal
Traducci�n al Espa�ol v1.0 (09/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Jackal
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Jackal
-----------------
Jackal es un shooter, para 1 o 2 jugadores simultaneos.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Jackal (U) [!].nes
131.088	bytes
CRC32: 2e52d091
MD5: 7d02d7a6d89ef993589d1f1d58e2bcda
SHA1: 86c392a1d9a731fa48e148afbe60af75f918cb5a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --