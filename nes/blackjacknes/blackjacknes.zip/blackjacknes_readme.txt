Blackjack (NES)
Traducción al Español v1.0 (13/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blackjack (USA) (Unl).nes
MD5: 971f2267cb118b5a144d4588c1d370ae
SHA1: 4d8057d1f834cec42bbdce96eb76cc5b7f547e1b
CRC32: 00ac0fac
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --