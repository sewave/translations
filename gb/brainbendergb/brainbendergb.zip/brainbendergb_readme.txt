Brainbender (Game Boy)
Traducción al Español v1.0 (05/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Brainbender (U) [!].gb
MD5: 63bbfce4fb22f4b77e68cc67f02c4b05
SHA1: 56ff8684284765a56918d14620ad38477aaaf0ad
CRC32: fbb1f2a1
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --