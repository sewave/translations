Time Trax (Mega Drive)
Traducción al Español v1.0 (21/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Time Trax (USA) (Proto).md
MD5: d45f98bea74f605640fd8e9e9eb578ce
SHA1: d7eb65f67ebb89a85c25a3accf06368554a13834
CRC32: dff045eb
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --