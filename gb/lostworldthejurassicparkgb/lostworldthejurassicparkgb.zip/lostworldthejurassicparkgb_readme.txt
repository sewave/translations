Lost World, The - Jurassic Park (Game Boy)
Traducci�n al Espa�ol v1.0 (10/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lost World, The - Jurassic Park (U) [S][!].gb
524.288 bytes
MD5: 81ad77f41587aab8e452f42cc0252e26
SHA1: 68bf63ba6a6c9f3a71a933d6f00e5212c66dcd03
CRC32: 391f532a

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --