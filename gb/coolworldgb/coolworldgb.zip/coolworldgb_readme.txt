Cool World (Game Boy)
Traducción al Español v1.0 (11/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cool World (USA, Europe).gb
MD5: 79bb2ba29c937253dd964142713a7869
SHA1: 1919495cc83c4126c90d6cfa2e14427b6364da3a
CRC32: a193c0d0
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --