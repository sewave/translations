Spot - The Video Game (NES)
Traducción al Español v1.0 (11/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spot - The Video Game (USA).nes
MD5: 686e154574427692103f05d83810ce09
SHA1: 86fb26e8415df93f0ad38934d81f2f1aa51e635d
CRC32: 1d6e0953
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --