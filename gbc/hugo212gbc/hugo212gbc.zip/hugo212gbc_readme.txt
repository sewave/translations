Hugo 2 1-2 (Game Boy Color)
Traducción al Español v1.0 (07/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hugo 2 1-2 (Germany) (GB Compatible).gbc
MD5: f1a64423cc8cc50338ab69feee3199f6
SHA1: 5d89a8b4de6e6b2ba5be3434f0a1eee03077eeda
CRC32: fab64b18
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --