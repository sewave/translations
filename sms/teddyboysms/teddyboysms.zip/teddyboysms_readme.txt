Teddy Boy (Master System)
Traducci�n al Espa�ol v1.0 (23/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Teddy Boy (UE) [!].sms
MD5: 66baea0a42353ffd3f131586e0c9c4d4
SHA1: 6ae39718703dbf7126f71387ce24ad956710a315
CRC32: 2728faa3
32.768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --