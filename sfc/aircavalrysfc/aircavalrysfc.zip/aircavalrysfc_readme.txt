Air Cavalry (Super Nintendo)
Traducción al Español v1.0 (07/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Air Cavalry (USA).sfc
MD5: b8fa02456b70f529afa265b2ba3d189f
SHA1: 65f8142ddbce9c03b175d03ecfd304e8589227c1
CRC32: 6b452801
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --