Chiller (ZX Spectrum)
Traducción al Español v1.0 (08/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chiller.tzx
MD5: 841c6f79d37f85e6b9472ce87f0dd4a0
SHA1: bb4941a7557504c9defdb83af7dae73bca0c7ed6
CRC32: 92e45dc1
23183 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --