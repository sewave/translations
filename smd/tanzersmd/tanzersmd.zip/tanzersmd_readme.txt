Tanzer (Mega Drive)
Traducción al Español v1.0 (16/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tanzer.bin
MD5: be2526b6c4dd6d09b31305e69c884e57
SHA1: 431ac87627674e936379a38eaec2fe97af3201dd
CRC32: 33e80d0d
4063232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --