Rainbow Islands - The Story of Bubble Bobble 2 (NES)
Traducci�n al Espa�ol v1.0 (01/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rainbow Islands - The Story of Bubble Bobble 2 (E) [!].nes
MD5: c97f6f262616db65fdf4d60398c50860
SHA1: f397de14a66972cf71fcb0f48e4362d873529757
CRC32: d3bdb2ed
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --