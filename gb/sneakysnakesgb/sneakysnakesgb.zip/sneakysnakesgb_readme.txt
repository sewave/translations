Sneaky Snakes (Game Boy)
Traducción al Español v1.0 (29/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sneaky Snakes (UE) [!].gb
MD5: 0b5127a54cc8581acfabe0413378ca3d
SHA1: 9087b44139ea56d85c8ecadb2603a2d599c2a00b
CRC32: 7bf40d7d
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --