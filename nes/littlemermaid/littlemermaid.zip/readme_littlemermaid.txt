Little Mermaid, The
Traducci�n al Espa�ol v1.0 (27/09/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Little Mermaid, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Little Mermaid, The
-----------------
Little Mermaid, The es un shooter/plataformas bastante curioso de la pelicula de disney.
Este parche lo traduce completamente al espa�ol.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Little Mermaid, The (U) [!].nes
131.088	bytes
CRC32: 08eb97db
MD5: 7a0b80fefb770bf5139a3d09e7835280
SHA1: 20622bb297a09e0d4863df21256b25210cbecd8a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --