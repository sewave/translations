Speedboat Assassin (ZX Spectrum)
Traducción al Español v1.0 (17/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Speedboat Assassin.tzx
MD5: e30591163a536a2a8148aef8fa5a28a2
SHA1: a92ea928da5a4251ff77e3a3c53ee52c22175123
CRC32: 6b03161f
56757 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --