Desert Strike - Return to the Gulf
Traducci�n al Espa�ol v1.1 (07/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Desert Strike - Return to the Gulf
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Desert Strike - Return to the Gulf
-----------------
Acci�n/aventuras sobre un helic�ptero que realiza misiones especiales.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
1.1:
Esta versi�n arregla errores en la intro del juego, especialmente con las letras grandes.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Desert Strike - Return to the Gulf (UE) [!].gen
1.048.576 bytes
CRC32: d7e7d8c358eb845b84fb08f904cc0b95d0a4053d
MD5: 6f37f036c8de2bf78d11079cd2424370
SHA1: d7e7d8c358eb845b84fb08f904cc0b95d0a4053d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --