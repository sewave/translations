Shanghai (Game Boy)
Traducción al Español v1.0 (20/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shanghai (U) [!].gb
MD5: d11777331e12f55ae4bab2f6e0bda918
SHA1: d5cc81d0379982fe69e8fe30868fdcc621dd1bae
CRC32: 580fcb18
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --