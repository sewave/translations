Hyper Lode Runner (Game Boy)
Traducción al Español v1.0 (01/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hyper Lode Runner (JU) [!].gb
MD5: dc79b733997e469e961e2d850448db23
SHA1: 261da795c7b4155f1b8083acc55da78699c8a0de
CRC32: b3a86164
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --