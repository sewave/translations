Home Alone (Game Gear)
Traducción al Español v1.0 (17/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Home Alone (U) [!].gg
MD5: 8747c4cc07059d97bc597c5eb757cbd9
SHA1: abad566f587affcb35102ed5b45c4e3a8ee22dc9
CRC32: dde29f74
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --