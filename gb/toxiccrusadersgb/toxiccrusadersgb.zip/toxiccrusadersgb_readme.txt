Toxic Crusaders (Game Boy)
Traducción al Español v1.0 (19/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Toxic Crusaders (U).gb
MD5: eee449a4c33f41681d0c44feeb91ac91
SHA1: 236420607be545e0156f2df0a5982c46bc6e10e3
CRC32: ea59c6e3
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --