Pipe Dream (Game Boy)
Traducción al Español v1.0 (20/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pipe Dream (U) [!].gb
MD5: 0f021462180b18436c21299e923cca91
SHA1: 12a2c76ec96cc94a4c7eead6536eddd5f3f9998f
CRC32: f59cedea
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --