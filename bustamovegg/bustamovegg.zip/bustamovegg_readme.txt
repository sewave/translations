Bust-A-Move (Game Gear)
Traducción al Español v1.0 (01/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bust-A-Move (U) [!].gg
MD5: 50a41b6b8062095c142acd186b6118c9
SHA1: e6bb5f72cffb11c8dd44ac3e378088b04cec1297
CRC32: c90f29ef
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --