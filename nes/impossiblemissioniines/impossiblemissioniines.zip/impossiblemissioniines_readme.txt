Impossible Mission II (NES)
Traducción al Español v1.0 (10/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Impossible Mission II (U) [!].nes
MD5: 8078da6fb648a9ad33423c5141cbfce5
SHA1: 1cfb560acf8a5647ee65280e3c451c70335aed85
CRC32: f73d26d6
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --