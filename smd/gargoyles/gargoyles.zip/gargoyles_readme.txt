Gargoyles
Traducci�n al Espa�ol v1.1 (18/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Gargoyles
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Gargoyles
-----------------
Juego de la serie de animacion Gargoyles.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Corregidos cr�ditos finales

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Gargoyles (U) [!].bin
3.145.728 bytes
CRC32: 2d965364
MD5: 182b253e376b3ed4c51be1f87a95aa29
SHA1: 2b76764ca1e5a26e406e42c5f8dbd5b8df915522

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --