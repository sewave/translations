Circus Lido (PC Engine)
Traducción al Español v1.0 (23/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Circus Lido (Japan).pce
MD5: bb10ab1d4e671e4c4adf7674acd7115f
SHA1: b7a4157ad47d1f89ede201b56d5cd57650bcf18e
CRC32: c3212c24
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --