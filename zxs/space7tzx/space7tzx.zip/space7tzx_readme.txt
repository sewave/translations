SPACE 7 (ZX Spectrum)
Traducción al Español v1.0 (29/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
SPACE7.TZX
MD5: c398043d7a71d3cd5a10699ae3f4a406
SHA1: 10ba96563bb19bd3b3e6972eeaa9bf9ce5251056
CRC32: 5285a130
55469 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --