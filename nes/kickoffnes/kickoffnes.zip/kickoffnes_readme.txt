Kick Off (NES)
Traducción al Español v1.0 (26/10/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kick Off (Europe).nes
MD5: f2790b7e0c5b5f8d187df638f844d91a
SHA1: 636ed07c1bf8c0fdb613b70193e6b5e8f670e183
CRC32: e2685bbf
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --