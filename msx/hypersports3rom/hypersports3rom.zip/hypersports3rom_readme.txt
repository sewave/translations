Hyper Sports 3 (MSX)
Traducción al Español v1.0 (12/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hyper Sports 3 (1985) (Konami) (J).rom
MD5: 01a2c85070d987a1b83f591e83b5bcfe
SHA1: af4e0490c178a18a47b34831fb5e3cf8b61d34d9
CRC32: 80a831e1
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --