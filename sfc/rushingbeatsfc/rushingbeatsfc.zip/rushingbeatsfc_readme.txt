Rushing Beat (Super Nintendo)
Traducción al Español v1.0 (11/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la traducción de FlashPV.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rushing Beat (J) [!].smc
MD5: ee392bdcd28d073585f198ce9187456f
SHA1: 19ca57776d3b3cdbc8cc3444cb26e7de1e40e9b9
CRC32: a6f0693d
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

--Original--
FlashPV	Hacking	Project Lead and hacking
Eien Ni Hen	Translation	Translation of level's names and game's ending
Shiroma3084	Translation	Translation of the game's introduction
Kung Fu Furby	Translation	Translation of the game's ending
Jonny2x4	Translation	Translation of the game's ending

-- FIN --