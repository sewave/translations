Bio Force Ape (NES)
Traducción al Español v1.0 (16/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bio Force Ape (Japan) (En) (Proto).nes
MD5: bc0a8c283bd8f336acb74569593b5d2a
SHA1: 4f8a7b228520cead719694a5f9b9222671599251
CRC32: 339d5a6d
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --