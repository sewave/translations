Zynaps (ZX Spectrum)
Traducción al Español v1.0 (19/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zynaps.tzx
MD5: a7c8e12d565f513c01d29446cee9e54f
SHA1: 60511d70de1b7c916666e5b68acdc3f8de0ccad6
CRC32: 06c77d5b
45885 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --