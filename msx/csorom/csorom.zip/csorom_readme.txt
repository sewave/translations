C-So! (MSX)
Traducción al Español v1.0 (24/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
C-So! (1985)(Pony Canyon).rom
MD5: 340ba6ae6cc3c4ef8c924bd6966b6670
SHA1: b9ac3ac15b49eaabcb640cc6b48f4706e0f18246
CRC32: b66d0dc9
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --