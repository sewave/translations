Big Nose Freaks Out (NES)
Traducción al Español v1.0 (22/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Big Nose Freaks Out (USA) (Unl).nes
MD5: e422c8261a1c8f4f23628d2379a52f61
SHA1: 91cf3e24b02ae75b7be395e524d9545bee50ab81
CRC32: ad16f6c7
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --