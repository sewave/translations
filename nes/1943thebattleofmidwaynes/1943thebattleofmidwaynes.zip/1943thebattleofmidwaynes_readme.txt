1943 - The Battle of Midway
Traducci�n al Espa�ol v1.0 (20/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre 1943 - The Battle of Midway
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre 1943 - The Battle of Midway
-----------------
Arcade de aviones port de recreativa.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
1943 - The Battle of Midway (U) [!].nes
131.088	bytes
CRC32: d131bf15
MD5: deeaf9d51fc3f13f11f8e1a65553061a
SHA1: 443d235fbdd0e0b3adb1dcf18c6caa7eceec8bee

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --