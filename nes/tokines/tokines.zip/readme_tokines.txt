Toki
Traducci�n al Espa�ol v1.0 (27/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Toki
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Toki
-----------------
Adaptacion bastante fiel de la recreativa a la 8 bits.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Toki (U) [!].nes
393.232	bytes
CRC32: 5bd50be6
MD5: 9a47af43ca5e8a6a11e58726f05ee5e8
SHA1: aaca3416696b8bfe96fdd53f7c652aef5e10b211

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --