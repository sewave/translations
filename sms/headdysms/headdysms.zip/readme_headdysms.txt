Dynamite Headdy
Traducci�n al Espa�ol v1.0 (21/11/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Dynamite Headdy
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Dynamite Headdy
-----------------
Version descafeinada para la 8bit sobremesa del juego de megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Se traducen la introduccion y el final (y creditos).

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Dynamite Headdy (B) [!].sms
524.288	bytes
CRC32: 7db5b0fa
MD5: 7f57481d870465fc3a6412d87f0a8e38
SHA1: 12877c1c9bfba6462606717cf0a94f700ac970e4

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --