Troddlers (Super Nintendo)
Traducción al Español v1.0 (10/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Troddlers (USA).sfc
MD5: 8b417009cef92249fadaed884ecb5ac4
SHA1: 59a850462151f420e9b4b72284b481fe248a8efa
CRC32: 6a7ff02d
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --