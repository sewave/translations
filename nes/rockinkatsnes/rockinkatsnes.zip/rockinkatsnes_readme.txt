Rockin' Kats (NES)
Traducci�n al Espa�ol v1.0 (01/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rockin' Kats (U) [!].nes
MD5: 2cad400be349dfe975234c033e495a74
SHA1: 56a494cdf35d11b515d3bd3630396ce97add66e1
CRC32: a3b4f5de
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --