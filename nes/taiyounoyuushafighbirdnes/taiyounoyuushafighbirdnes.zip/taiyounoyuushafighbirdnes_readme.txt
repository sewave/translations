Taiyou no Yuusha - Fighbird (NES)
Traducción al Español v1.0 (25/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de Zynk Oxhyde.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Taiyou no Yuusha - Fighbird (Japan).nes
MD5: a52b0cfbdff806f70f88a28aad3017bf
SHA1: 848faf41ef0b95923ddb2ed7adf6063f79fbe139
CRC32: be1d0344
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --