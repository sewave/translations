Truxton (Mega Drive)
Traducci�n al Espa�ol v1.0 (25/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Truxton (W) [!].gen
MD5: 75a42b19e5503c72b21018699314db0b
SHA1: 90039844478e7cb99951fdff1979c3bda04d080a
CRC32: 5bd0882d
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --