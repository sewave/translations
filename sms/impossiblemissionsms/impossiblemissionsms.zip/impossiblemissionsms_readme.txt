Impossible Mission (Master System)
Traducción al Español v1.0 (10/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Impossible Mission (E) [!].sms
MD5: af51ab03a173dec28c9241532227cd64
SHA1: d883f28e77e575edca6dcb1c4cd1f2b1f11393b2
CRC32: 64d6af3b
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --