Enduro Racer
Traducci�n al Espa�ol v1.0 (05/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Enduro Racer
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Enduro Racer
-----------------
Curiosa adaptacion del clasico de sega, con un modo mas original.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Enduro Racer (UE) [!].sms
131.072 bytes
CRC32: 00e73541
MD5: 06779a1a9dbada60efb1f37e37040a5b
SHA1: 10dc132166c1aa47ca7b89fbb1f0a4e56b428359

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --