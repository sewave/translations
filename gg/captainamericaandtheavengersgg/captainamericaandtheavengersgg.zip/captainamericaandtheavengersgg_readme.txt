Captain America and The Avengers
Traducci�n al Espa�ol v1.0 (12/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Captain America and The Avengers
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Captain America and The Avengers
-----------------
Beat em up de los vengadores version game gear.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Captain America and the Avengers (U) [!].gg
262.144	bytes
CRC32: 5675dfdd
MD5: dfb20211ef127b605849abfd85300afc
SHA1: 4b859174d57cc4a5a575f8aa9547a83d08e6c117

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --