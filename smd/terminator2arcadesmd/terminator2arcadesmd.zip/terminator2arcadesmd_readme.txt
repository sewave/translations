T2 - The Arcade Game (Mega Drive)
Traducci�n al Espa�ol v1.0 (13/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
T2 - The Arcade Game (UE) (REV01) [!].bin
MD5: 3c2666bcc3c42a4218e46c5aba2bca15
SHA1: 85cc1cf3379d3ce23ca3c03d84fe6e2b3adc9c56
CRC32: a1264f17
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --