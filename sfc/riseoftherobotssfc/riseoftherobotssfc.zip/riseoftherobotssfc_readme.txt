Rise of the Robots (Super Nintendo)
Traducción al Español v1.0 (21/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rise of the Robots (USA).sfc
MD5: db35a37e7b84d4168171c49e6cb9d827
SHA1: 49e06c1b2235a1c6465de665028f1c4aeda6eeb2
CRC32: 83ba0ac0
4194304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --