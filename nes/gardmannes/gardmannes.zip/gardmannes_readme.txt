Gardman (NES)
Traducción al Español v1.0 (04/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de Green Jerry.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gardman (Asia) (Unl).nes
MD5: 878ff7dd501f530b6dea8f797e9238f0
SHA1: 5e707b25bc69c2342b01163f147536b6bf6e6365
CRC32: 956a2ee5
524304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --