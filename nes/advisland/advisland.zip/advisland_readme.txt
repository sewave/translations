Hudson's Adventure Island
Traducci�n al Espa�ol v1.0 (28/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Hudson's Adventure Island
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Hudson's Adventure Island
-----------------
Primera parte de la saga clasica de plataformas.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Hudson's Adventure Island (U) [!].nes
65.552 bytes
CRC32: b78c09a2
MD5: be07098de1de3dc2512b6aa93f23ae3a
SHA1: 22ee75b82f4a6412aa6bb940e109704975b95185

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --