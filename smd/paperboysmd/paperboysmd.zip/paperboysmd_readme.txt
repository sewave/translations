Paperboy (Mega Drive)
Traducci�n al Espa�ol v1.0 (10/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Paperboy (UE) [!].bin
MD5: f185e7700fe58f34d1c2968074760cdc
SHA1: 10faaf47e585423eec45285be4f5ce1015ae3386
CRC32: 0a44819b
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --