Nazo no Murasamejou (Famicom Disk System)
Traducción al Español v1.0 (02/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Spinner 8 and friends.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nazo no Murasamejou (Japan).fds
MD5: fa04b0b2d99d560e7076198ab72a15d3
SHA1: 3102abcab2bec46f63e88461f73539b94aa73cbd
CRC32: 9a523757
131000 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --