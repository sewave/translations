Monster in My Pocket (NES)
Traducción al Español v2.0 (28/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducida licencia
-Revisión de guion
-Traducidas letras grandes
-Traducido "GAME OVER"
-Expandidos "1 JUGADOR"/"2 JUGADORES"
-Traducidos créditos

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Monster in My Pocket (USA).nes
MD5: 12700d194059470bcfeaa5fff0a116a6
SHA1: b3aec4e889c480402dac7265855a698101376e14
CRC32: cfd1eb5d
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --