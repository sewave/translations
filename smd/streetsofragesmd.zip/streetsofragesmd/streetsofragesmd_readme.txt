Streets of Rage (Mega Drive)
Traducci�n al Espa�ol v1.0 (07/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Streets of Rage (W) (REV01) [!].gen
524.288 bytes
MD5: 59a3b22a1899461dceba50d1ade88d3a
SHA1: 731cdf182fe647e4977477ba4dd2e2b46b9b878a
CRC32: 4052e845

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --