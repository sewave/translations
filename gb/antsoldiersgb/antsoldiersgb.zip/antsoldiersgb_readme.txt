Ant Soldiers (Game Boy)
Traducción al Español v1.0 (29/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ant Soldiers (Sachen) [!].gb
MD5: 5664703f9bfdba0302009e03e7df3171
SHA1: d81514eabcf08fdfd50921516300d0ce2b424bf8
CRC32: b4a5936e
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --