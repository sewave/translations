X-Men - Mojo World (Master System)
Traducción al Español v1.0 (24/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
X-Men - Mojo World (Brazil).sms
MD5: 758a1e837e51669700c0a2379e90d993
SHA1: 6405a2f8b6f220b4349f8006c3d75dfcdcd6db6d
CRC32: 3e1387f6
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --