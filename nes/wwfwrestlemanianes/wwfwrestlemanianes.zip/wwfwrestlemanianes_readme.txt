WWF Wrestlemania (NES)
Traducción al Español v1.0 (08/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
WWF Wrestlemania (USA).nes
MD5: e24b2194741950301f0fb82c08e19cae
SHA1: f721c5e1433975b801ea2b0981ebd862853528fd
CRC32: c7bce866
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --