Hideous (ZX Spectrum)
Traducción al Español v1.0 (18/05/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hideous.tzx
MD5: af78d18eceb3164865324e9f198f05c2
SHA1: fe816c47248a09e07a3b150e4f45f4a1a21e999a
CRC32: 5d2e5eda
34344 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --