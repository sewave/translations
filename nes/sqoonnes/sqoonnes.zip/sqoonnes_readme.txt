Sqoon (NES)
Traducci�n al Espa�ol v1.0 (20/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sqoon (U) [!].nes
40.976 bytes
MD5: 181a4dd87ff58e189831ebd6d8eeb059
SHA1: 4f1d13418adabcc8b96cba6b2de7cf75f6917289
CRC32: a3815bac

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.
juandex - Testing

-- FIN --