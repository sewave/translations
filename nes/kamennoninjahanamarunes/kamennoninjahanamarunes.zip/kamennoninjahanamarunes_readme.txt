Kamen no Ninja - Hanamaru (NES)
Traducci�n al Espa�ol v1.0 (05/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking est� basada en la traducci�n de pacnsacdave.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kamen no Ninja - Hanamaru (J).nes
MD5: 3327b32854f4908490cf8d320fff461a
SHA1: f869df4bf18dfdb25dd0963d34c87327ec48a17f
CRC32: 8b002a9d
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

Original:
pacnsacdave	Hacking

-- FIN --