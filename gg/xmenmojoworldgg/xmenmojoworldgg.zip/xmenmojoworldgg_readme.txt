X-Men - Mojo World (Game Gear)
Traducción al Español v1.0 (24/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
X-Men - Mojo World (U) [!].gg
MD5: ca15f2ba2507ebd836c42d9d10231eb1
SHA1: cff15c4a3e555c2868af93c55386b5ab3d3db4e3
CRC32: c2cba9d7
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --