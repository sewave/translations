Motocross Champion (NES)
Traducción al Español v1.1 (14/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de Suicidal Translations.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Cambiado "CALOR" por "ELIM." (Eliminatoria).

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Motocross Champion (Japan).nes
MD5: 89bed79cdfa34eb8cf83c03833b5fc4a
SHA1: 2742a8e3f32f2c2cd57e7b6b9bee6e3fe8ed9f6a
CRC32: 8b7a23b0
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --