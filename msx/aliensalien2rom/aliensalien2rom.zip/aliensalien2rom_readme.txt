Aliens - Alien 2 (MSX)
Traducción al Español v1.0 (27/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Aliens - Alien 2 (Japan).rom
MD5: 3dbb75d222dc216c72a8a046e400f2e6
SHA1: 5380e913d8dac23470446844cab21f6921101af8
CRC32: c6fc7bd7
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --