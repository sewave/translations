Turrican (PC Engine)
Traducci�n al Espa�ol v1.0 (08/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Turrican (U).pce
MD5: 52d40c4e0a8435308c22c69a54e4baae
SHA1: a5830c0d5cd94e3c6f33e1799bb123857400b1bc
CRC32: eb045edf
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --