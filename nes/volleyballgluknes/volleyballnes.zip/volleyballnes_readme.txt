Volley Ball (NES)
Traducción al Español v1.0 (03/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Volley Ball (Spain) (Gluk Video) (Unl).nes
MD5: d123865daff17fbfc6221903a5a9e9f7
SHA1: 31b93801f40605ad90ed88983d8a2dedc4f30b33
CRC32: 6034d8db
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --