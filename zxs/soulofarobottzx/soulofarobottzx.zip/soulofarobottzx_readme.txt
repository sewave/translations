Soul Of A Robot (ZX Spectrum)
Traducción al Español v1.0 (10/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Soul Of A Robot.tzx
MD5: 225e329f7176b44f6a8b0788e9a69f37
SHA1: 75303218bc8cc091e738d6fe0949aefd2082e758
CRC32: 2151cbbb
46085 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --