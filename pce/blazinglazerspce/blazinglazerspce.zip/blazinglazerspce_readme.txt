Blazing Lazers (PC Engine)
Traducción al Español v1.0 (16/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blazing Lazers (U).pce
MD5: 3c2f85fc7898de73a7c789033d22b8f5
SHA1: 13712aaee596ad96ab743d5e82ed96895089afeb
CRC32: b4a1b0f6
393216 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --