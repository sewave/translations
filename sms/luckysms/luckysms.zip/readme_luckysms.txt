Lucky Dime Caper, The - Starring Donald Duck
Traducci�n al Espa�ol v1.0 (11/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Lucky Dime Caper, The - Starring Donald Duck
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Lucky Dime Caper, The - Starring Donald Duck
-----------------
Plataformas de Disney para master system del pato donald.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Lucky Dime Caper, The - Starring Donald Duck (E) [!].sms
262.144	bytes
CRC32: a1710f13
MD5: 653f10042a5ee5854ccf971456641a4d
SHA1: a08815d27e431f0bee70b4ebfb870a3196c2a732

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --