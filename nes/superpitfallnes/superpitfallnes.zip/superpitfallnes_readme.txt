Super Pitfall (NES)
Traducción al Español v1.0 (30/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Pitfall (USA).nes
MD5: cc9fa49d1c3756a7a9533b8f040e0c4c
SHA1: 2373e952fecc5f7507f99476e82c298cab1f51cb
CRC32: a4958020
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --