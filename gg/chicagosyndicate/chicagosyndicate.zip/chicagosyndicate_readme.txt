Chicago Syndicate (Game Gear)
Traducci�n al Espa�ol v1.0 (17/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chicago Syndicate (U) [!].gg
MD5: a51438e3ba8c78df665df05b6310a38a
SHA1: d7746e4c78aa86bc698fc25a52a791ba27a71add
CRC32: 6b0fcec3
524288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --