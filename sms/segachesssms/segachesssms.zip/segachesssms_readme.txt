Sega Chess (Master System)
Traducci�n al Espa�ol v1.0 (01/12/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sega Chess (EB) [!].sms
MD5: 92334e9e52eeb8d27606e319b1f8b617
SHA1: 2c386825dce99b340084b28bdf90fb4ee7107317
CRC32: a8061aef
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --