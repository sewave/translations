F1 Championship (Master System)
Traducción al Español v1.0 (10/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
F1 Championship (EB) [!].sms
MD5: 5d67504b8334a0e36f6119515928717c
SHA1: 247fd74485073695a88f6813482f67516860b3a0
CRC32: ec788661
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --