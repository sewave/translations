Shodai Nekketsu Kouha Kunio-kun (Super Nintendo)
Traducci�n al Espa�ol v1.1 (04/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking est� basado en la traducci�n al ingl�s de Aeon Genesis.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglados fallos se�alados por Maeda Taison.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shodai Nekketsu Kouha Kunio-kun (J).smc
MD5: 089a633c541caf3fc7c48fae9fbfc8ff
SHA1: a77a297fc858cd78b7219dbf83a9934fe3eccc7f
CRC32: 56c05339
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.
Maeda Taison - Pruebas.

Contributor	Type of contribution	Listed credit
Gideon Zhi	Hacking	Project leader, lead ROM hacker, assembly hacker, writer
Tom	Translation	
g8z et al	Hacking	Menu assembly

-- FIN --