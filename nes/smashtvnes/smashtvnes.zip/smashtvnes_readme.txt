Smash T (NES)
Traducción al Español v1.0 (29/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Smash T.V. (U) [!].nes
MD5: f9c67bc1f58c512d5b7347ca51e54e9a
SHA1: 43dbc7d3342762f4669b09ba6121217a54a21e74
CRC32: 447a45a0
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --