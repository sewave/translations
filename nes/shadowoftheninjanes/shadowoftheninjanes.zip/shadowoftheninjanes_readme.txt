Shadow of the Ninja (NES)
Traducción al Español v1.1 (26/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:
-Traducida licencia
-Traducidos créditos
-Traducido GAME OVER
-Arreglada alineación de la intro
-Traducido menú secreto de melodías
-Traducido inicio de etapa
-Añadidos acentos a letras multicolor

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shadow of the Ninja (USA).nes
MD5: d459bae7337c21ce0d380efa86cbbde9
SHA1: c35ea6624d37d57953e4c06197be5c54931a7139
CRC32: f74a04ab
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --