H.E.R.O. (SG-1000)
Traducci�n al Espa�ol v1.0 (01/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
H.E.R.O. (SG-1000).sg
MD5: d10f38c614113cb34bbf4a19b487e1fb
SHA1: 19acb69b7b64da5083349d8bc40a47beacc88c41
CRC32: 4587de6e
32.768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --