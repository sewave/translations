Side Pocket (Game Gear)
Traducción al Español v1.0 (25/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Side Pocket (U).gg
MD5: 4f270030dd6bb1d72eba33f1ef054b20
SHA1: 794775a858ff04c9da1c897b51eede4677a35c21
CRC32: 6a603eed
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --