Chack 'n Pop (NES)
Traducci�n al Espa�ol v1.0 (01/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chack 'n Pop (J).nes
MD5: c394a2b283975b0fd98698f27ee8f1a4
SHA1: 7dfe9361647c7333d479ec726176a5bbb1fb920c
CRC32: e9b39b87
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --