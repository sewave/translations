Konami's Boxing (MSX)
Traducción al Español v1.0 (08/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Konami's Boxing (1985) (Konami) (J).rom
MD5: 3c276ae556ddd0feea9df0d5d31a5e1d
SHA1: 7adb6812f3702b93aa2b2a872722bbd40915670d
CRC32: 3a442408
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --