Star Soldier (MSX)
Traducción al Español v1.0 (19/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Star Soldier (1986) (Hudson) (J).rom
MD5: 5009b3eb94b67ceecb026685c1d9ae89
SHA1: 6a56b46b8bf014b25863433d6d96e64641a93eef
CRC32: 0b3d975d
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --