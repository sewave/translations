Zool (Game Boy)
Traducci�n al Espa�ol v1.0 (10/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zool (U) [!].gb
MD5: 52700ea227c3a31f170ccbc6a052a7a8
SHA1: 5c1b1af8e70cd23f5f72848d03fcc56869d18be7
CRC32: ef54b46e
131072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --