Tanque (NES)
Traducción al Español v1.0 (03/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tanque (Spain) (Gluk Video) (Unl).nes
MD5: 96489832e23f6eb12138ff74d739213b
SHA1: 42496d024d77bc3b3f6ac781f0acab823e2524f4
CRC32: 53c8c588
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --