Zero the Kamikaze Squirrel
Traducci�n al Espa�ol v1.0 (11/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Zero the Kamikaze Squirrel
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Zero the Kamikaze Squirrel
-----------------
Plataformas Spin-off de Aero the Acrobat para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Zero the Kamikaze Squirrel (U) [!].gen
2.097.152 bytes
CRC32: 423968df
MD5: 4e18827f7dd6ca39970a2ef0e0fa21d0
SHA1: db110fa33c185a7da4c80e92dbe4c7f23ccec0d6

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --