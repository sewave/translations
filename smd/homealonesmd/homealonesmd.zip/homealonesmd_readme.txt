Home Alone (Mega Drive)
Traducción al Español v1.1 (05/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado final al terminarse el tiempo.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Home Alone (USA, Europe).md
MD5: 089771a4c22d69f039e5c18bf4b2d84a
SHA1: c3794ef25d53cb7811dd0df73ba6fadd4cecb116
CRC32: aa0d4387
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --