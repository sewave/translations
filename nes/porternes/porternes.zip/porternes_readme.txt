Porter (NES)
Traducción al Español v1.0 (07/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Porter (Asia) (En) (Unl).nes
MD5: cc4109a5322cf3a9b60bab96d6500d25
SHA1: 72a4814028f0c679a55ff2e9eef3d620f1309868
CRC32: d4fb28e8
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --