Super Hang-On
Traducci�n al Espa�ol v1.0 (01/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Super Hang-On
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Super Hang-On
-----------------
Port del arcade a megadrive con un interesante modo original.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Super Hang-On (W) (REV01) [!].bin
524.288	bytes
CRC32: 3877d107
MD5: 9b5d500a7ce1de56fba9c554bbf9a0b2
SHA1: e58a8e6c472a34d9ecf3b450137df8a63ec9c791

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --