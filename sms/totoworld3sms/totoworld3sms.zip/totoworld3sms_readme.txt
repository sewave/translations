Toto World 3 (Master System)
Traducción al Español v1.0 (06/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Toto World 3 (K) [!].sms
MD5: 2c8d7ad9c6484f161dd9574670b598a4
SHA1: 55ca8a8b1f2a342fc8b8fc3f3ccd98ed44b2fe98
CRC32: 4f8d75ec
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --