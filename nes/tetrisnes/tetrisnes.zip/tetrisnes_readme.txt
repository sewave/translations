Tetris (NES)
Traducci�n al Espa�ol v1.0 (19/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tetris (U) [!].nes
MD5: ec58574d96bee8c8927884ae6e7a2508
SHA1: 77747840541bfc62a28a5957692a98c550bd6b2b
CRC32: 6d72c53a
49.168 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --