Antarctic Adventure
Traducci�n al Espa�ol v1.0 (23/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Antarctic Adventure
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Antarctic Adventure
-----------------
Port del cl�sico de Konami para la NES.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Antarctic Adventure (J) [!].nes
24.592 bytes
CRC32: 9da252b4
MD5: ca7a3966079d541c81113e834b087e3b
SHA1: c1644ba07ddb7f741247e342daf8bfdc6e33f548

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --