Woody Pop (Game Gear)
Traducci�n al Espa�ol v1.0 (13/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Woody Pop (U) (V1.1) [!].gg
MD5: a23e89266ddad3c856e7401d04a49c6c
SHA1: 4efbfa1d3234d8f1800a06ab72b2177fba6914cb
CRC32: b74f3a4f
32768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --