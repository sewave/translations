Mickey Mania - Timeless Adventures of Mickey Mouse
Traducci�n al Espa�ol v1.0 (03/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Mickey Mania - Timeless Adventures of Mickey Mouse
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mickey Mania - Timeless Adventures of Mickey Mouse
-----------------
Gran plataformas de mickey para la 16 bits de sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mickey Mania - Timeless Adventures of Mickey Mouse (U) [!].gen
2.097.152 bytes
CRC32: 629e5963
MD5: 965536e24760755413ae316d935710b1
SHA1: 20779867821bab019f63ce42e3067ffafb4fe480

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --