Psychic World
Traducci�n al Espa�ol v1.0 (01/12/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Psychic World
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Psychic World
-----------------
Curioso plataformas con muchos poderes para ir pasando a traves de las pantallas, esta version de GAME GEAR, es diferente a la de MASTER SYTEM, no un port directo, pero sigue siendo el mismo juego.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Psychic World (U) [!].gg
131.072	bytes
CRC32: 73779b22
MD5: 52cfddc12af6a3a64030f62ccf6aca83
SHA1: 3be13f79eeb26b82343afab3e740b3a1d35978eb

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --