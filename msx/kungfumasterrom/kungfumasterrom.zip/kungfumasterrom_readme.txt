Kung-Fu Master (MSX)
Traducción al Español v1.0 (16/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kung-Fu Master (1983) (Mass Tael) (J).rom
MD5: 5c45dcc46e8adb05dafe338132d4439c
SHA1: c1dfc86c441e1128194f3ab490c94e29275b5df9
CRC32: 08f23b3e
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --