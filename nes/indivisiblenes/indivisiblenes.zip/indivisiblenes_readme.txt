Indivisible (NES)
Traducción al Español v1.0 (27/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Indivisible.nes
MD5: 7ad6bad8f005b70dcf5b7cd2febbdc28
SHA1: d13c7b57f93bf4a677cc35285008317810e50867
CRC32: 9f304e88
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --