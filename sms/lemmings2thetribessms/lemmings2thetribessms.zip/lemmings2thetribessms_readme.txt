Lemmings 2 - The Tribes (Master System)
Traducción al Español v1.0 (06/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lemmings 2 - The Tribes (Unknown) (Proto).sms
MD5: 3da5f5122f3d94360de61bcb8478e169
SHA1: 30b97f8afac0044ceda2722f5fddd31ba30de571
CRC32: cf5aecca
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --