Beavis and Butt-head
Traducci�n al Espa�ol v1.0 (02/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Beavis and Butt-head
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Beavis and Butt-head
-----------------
Juego de aventura/plataformas de los famosos personajes de la MTV.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
B�sicamente se traducen los di�logos y la introducci�n, varios textos est�ticos no est�n traducidos.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Beavis and Butt-head (U) [!].bin
2.097.152 bytes
CRC32: f5d7b948
MD5: 8e4d7397374cb03528f4c886120dc3e9
SHA1: 9abfbf8c5d07a11f090a151c2801caee251f1599

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --