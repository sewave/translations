War Room (Colecovision)
Traducción al Español v1.0 (22/03/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
War Room (USA).col
MD5: 0d59da8c315d22f58909c73b851299ee
SHA1: 031eaec9188105150460ff354fe50e22ce738c53
CRC32: 261b7d56
24576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --