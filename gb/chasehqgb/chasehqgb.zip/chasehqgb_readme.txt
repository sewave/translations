Chase H.Q. (Game Boy)
Traducción al Español v1.0 (20/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chase H.Q. (USA, Europe).gb
MD5: 6884a31366f565ca25935e1fba52efbc
SHA1: cbcd6254b1b0227ba6aa8d95c979abb7fe8e4d38
CRC32: 67a45d19
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --