Gear Works (Game Gear)
Traducción al Español v1.0 (08/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gear Works (U) [!].gg
MD5: da9d059d844104d2a4d05f01aa4ff9fc
SHA1: dc71c749c4a78e28922e10df645d23cc8289531f
CRC32: e9a2efb4
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --