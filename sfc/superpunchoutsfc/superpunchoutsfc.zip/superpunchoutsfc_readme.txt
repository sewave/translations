Super Punch-Out!! (Super Nintendo)
Traducci�n al Espa�ol v1.0 (24/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Las frases en combate y algunos men�s no est�n traducidos.
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Punch-Out!! (U) [!].smc
2.097.152 bytes
MD5: 97fe7d7d2a1017f8480e60a365a373f0
SHA1: 3604c855790f37db567e9b425252625045f86697
CRC32: e2f92f84

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --