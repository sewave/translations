Earnest Evans (Mega Drive)
Traducci�n al Espa�ol v1.0 (22/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Earnest Evans (U) [!].bin
MD5: 6a2d2ac410a424fcb66a72ec0dff9484
SHA1: cb5a2a928e2c2016f915e07e1d148672563183f0
CRC32: a243816d
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --