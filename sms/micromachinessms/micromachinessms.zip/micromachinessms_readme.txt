Micro Machines (Master System)
Traducci�n al Espa�ol v1.0 (21/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Micro Machines (E) [!].sms
MD5: a90cf8d68fa8b1f0ba00f0ddb9d547b7
SHA1: 425621f350d011fd021850238c6de9999625fd69
CRC32: a577ce46
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --