Firelord (ZX Spectrum)
Traducción al Español v1.0 (29/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Firelord.tzx
MD5: a86b9cc73e3b92c06e00f6bb4ba79784
SHA1: 088e50ee9add33f3069e74e6a55eda48bfa33311
CRC32: 324ba32a
49867 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --