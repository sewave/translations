Rocky (Master System)
Traducci�n al Espa�ol v1.0 (23/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rocky (World).sms
MD5: 582d58d95c9774cd50555366c253a050
SHA1: 8601927ca17419f5d61f757e9371ce533228f7bb
CRC32: 1bcc7be3
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --