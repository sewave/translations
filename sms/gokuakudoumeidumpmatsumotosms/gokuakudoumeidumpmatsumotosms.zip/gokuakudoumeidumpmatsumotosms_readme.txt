Gokuaku Doumei Dump Matsumoto (Master System)
Traducción al Español v1.0 (24/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gokuaku Doumei Dump Matsumoto (J) [!].sms
MD5: 9e56576a5c7d571ce17c650c4116a77d
SHA1: 77f1e788f43fb59456f982472f02f109f53c7918
CRC32: a249fa9d
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --