Bill & Ted's Excellent Gameboy Adventure (Game Boy)
Traducción al Español v1.0 (03/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bill & Ted's Excellent Gameboy Adventure (UE) [!].gb
MD5: 9d94d01d3133165d4469bb27d58f0f6c
SHA1: e19a7e5a5bd8fde0f31773c22dbebc9b4cf3824e
CRC32: 5e8f656a
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --