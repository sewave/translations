Double Clutch (Mega Drive)
Traducción al Español v1.0 (26/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Clutch (Europe).md
MD5: 6f281d1e7aef0b9fd3f38369be7ee1a7
SHA1: e19905cfcf74185e56fa94ae292f78451c8f4e2e
CRC32: d98c623c
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --