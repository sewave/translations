High Speed (NES)
Traducción al Español v1.0 (19/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
High Speed (USA).nes
MD5: 98ece89a4f4bb430c2244f865c2e84f6
SHA1: b7e821b0fc0389ca7fe2e9a941840173b1779337
CRC32: 8ca37960
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --