Fantasy Zone 1 (MSX)
Traducción al Español v1.0 (24/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fantasy Zone 1 (1986) (Pony Cannon) (J).rom
MD5: 27b5d76f266e5a480b68ecb866adf0d3
SHA1: 048737f995eecb1dd8dd341d750efd005267796f
CRC32: 3e96d005
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --