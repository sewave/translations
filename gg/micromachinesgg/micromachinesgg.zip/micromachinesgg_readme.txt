Micro Machines (Game Gear)
Traducci�n al Espa�ol v1.0 (21/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Micro Machines (E).gg
MD5: c08b950e8ab836a737b07374f8235955
SHA1: 7b2d39b68622e18eac6c27fd961133b1d002342b
CRC32: f7c524f6
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --