Psychosis (PC Engine)
Traducción al Español v1.0 (05/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Psychosis (U).pce
MD5: c23ef1ca95a5aa6789c4172ac66d6b5d
SHA1: 1cfcfc95bb01b24755e1fc9c3dfea393cb3cc3a9
CRC32: 6cc10824
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --