Spy vs. Spy (Master System)
Traducción al Español v1.0 (21/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spy vs. Spy (UE) [!].sms
MD5: c6adc5db40d0db75c9c167e4bb2ed918
SHA1: feab16dd8b807b88395e91c67e9ff52f8f7aa7e4
CRC32: 78d7faab
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --