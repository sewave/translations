Ghosts 'N Goblins
Traducci�n al Espa�ol v1.0 (16/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Ghosts 'N Goblins
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Ghosts 'N Goblins
-----------------
Versi�n del arcade para NES.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Ghosts 'N Goblins (U) [!].nes
131.088	bytes
CRC32: 87ed54aa
MD5: 6dd3872fff67b4f324a740aa87ac2b93
SHA1: 8de81d363e11cecb570a9d18237f7b56b2b659db

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
Danilo1652 - Testing

-- END OF README --