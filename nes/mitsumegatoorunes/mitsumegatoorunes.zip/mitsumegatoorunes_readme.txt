Mitsume ga Tooru (NES)
Traducción al Español v2.0 (23/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basada en la traducción de Stardust Crusaders.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0: Versión basada en la traducción de Stardust Crusaders, más fiel a la original.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mitsume ga Tooru (Japan).nes
MD5: 0e991488c4272b560a0bcf9ecb38a8f8
SHA1: f79d87d9b32498477ec2bf1939979d0d1d7bab7f
CRC32: e27ec1ec
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --