Cosmic Epsilon (NES)
Traducción al Español v1.0 (16/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cosmic Epsilon (Japan).nes
MD5: c7dd9ccc48b785d58b654a3a28e7b414
SHA1: 6d596473086af6ec2f80102bfd3b9677ebf53dc7
CRC32: f817328a
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --