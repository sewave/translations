True Lies
Traducci�n al Espa�ol v1.0 (06/07/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Notas del Proyecto
2. Fallos Conocidos (o: Bugs que no son bugs)
3. Instrucciones de Parcheo
4. Cr�ditos del Parche

---------------------
1. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
2. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
3. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
True Lies (W) [!].gen
2.097.152 bytes
CRC32: 18c09468
MD5: 2fee5ef253faebaff73c017a7bda1cff
SHA1: d39174bed46ede85531b86df7ba49123ce2f8411

----------------------
4. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --