Super JetPak DX (Game Boy Color)
Traducción al Español v1.0 (17/09/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super_JetPak_DX_DMG-SJPD-UKV.gbc
MD5: e5bfbe8dd1f3017834496626208b9d7d
SHA1: e7438db01fbbdeea2404dbf3d093370421ec4e1c
CRC32: 22def6f9
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --