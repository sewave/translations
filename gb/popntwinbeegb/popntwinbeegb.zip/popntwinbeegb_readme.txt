Pop 'N TwinBee (Game Boy)
Traducción al Español v1.0 (01/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pop 'N TwinBee (E) [!].gb
MD5: 05d5cf3404868efc22ac06e22ab5ba89
SHA1: 0206230b55c15a8c18fbb85f852967e44b33a0a4
CRC32: d07db274
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --