Parasol Stars - The Story of Bubble Bobble 3
Traducci�n al Espa�ol v1.0 (22/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Parasol Stars - The Story of Bubble Bobble 3
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Parasol Stars - The Story of Bubble Bobble 3
-----------------
Tercera parte del cl�sico plataformas Bubble Bobble.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Los numerales de los records no est�n traducidos.
Si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Parasol Stars - The Story of Bubble Bobble 3 (E) [!].nes
262.160	bytes
CRC32: dc7a16e6
MD5: 85830dc502ab156ce12449af7fbc1026
SHA1: 538a3a203cdcba25a3e5f2b34cfc9493cf1bc7f5

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --