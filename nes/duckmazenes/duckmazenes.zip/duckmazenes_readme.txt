Duck Maze (NES)
Traducción al Español v1.0 (26/10/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Duck Maze (Australia) (Unl).nes
MD5: 4d59da81df10f01f0494e74413e81cab
SHA1: 7a4e1430c74b226ff9cf59f63c185e34ca09d568
CRC32: 01c1ca36
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --