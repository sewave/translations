Super James Pond (Game Boy)
Traducci�n al Espa�ol v1.0 (29/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super James Pond (E) [!].gb
MD5: c4b03180037d53cb64b93634439acea0
SHA1: cacb8a79cf66dcb8c3d4f71c94d535cf9e5ad63b
CRC32: 6dc1bb2c
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --