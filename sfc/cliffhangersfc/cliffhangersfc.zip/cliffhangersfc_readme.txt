Cliffhanger (Super Nintendo)
Traducción al Español v1.0 (07/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cliffhanger (U).smc
MD5: 48001f4c765da0965cea9d9ab4d59a35
SHA1: 5a494362063c61c3207d2bb49ee43766f9a4f00f
CRC32: 12f8a26c
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --