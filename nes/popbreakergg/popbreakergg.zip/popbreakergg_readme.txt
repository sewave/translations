Pop Breaker (Game Gear)
Traducción al Español v1.0 (20/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Hay que forzar el emulador a región japonesa o el juego no dejará pulsar start.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pop Breaker (Japan).gg
MD5: e0e2fbd5834c04574795c923b0147f39
SHA1: 9c358504d3c106dd62bd8981132b47cdb95903de
CRC32: 71deba5a
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --