Darkwing Duck (NES)
Traducción al Español v1.0 (05/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Darkwing Duck (USA).nes
MD5: 459837f4e8fcbaf29bd66ed926b6882e
SHA1: 7188d8ce3d8d2a0dcd7b10fbc23a6f84fa9c4161
CRC32: 307d0fc4
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --