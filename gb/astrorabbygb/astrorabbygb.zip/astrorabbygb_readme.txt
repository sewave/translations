Astro Rabby (Game Boy)
Traducción al Español v1.0 (23/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Astro Rabby (Japan).gb
MD5: 5a88b67ed5475e591747bc7956642456
SHA1: 3e53fd25f350c78a29e0642ee6de80208930d469
CRC32: 61e48eef
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --