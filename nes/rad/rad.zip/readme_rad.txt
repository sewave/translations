Totally Rad
Traducci�n al Espa�ol v1.0 (21/11/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Totally Rad
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Totally Rad
-----------------
Simpatico plataformas con varios poderes magicos, algo corto.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Todo esta traducido que yo sepa, se incluyen minusculas y acentos/�.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Totally Rad (U) [!].nes
262.160	bytes
CRC32: 9cbaddc7
MD5: ea3dd120bda4adcfcf778c0ae7594c75
SHA1: f1e87bd17eb7d56ec4b2df42deef7747f4ef2d65

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --