Old Towers (NES)
Traducción al Español v1.0 (11/10/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
oldTowers_1_1.nes
MD5: ab144fd3eba49764bd786294d92aa77b
SHA1: d393f85c76f64863d35c024edbe05ea7cad09c2c
CRC32: d9b8e753
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --