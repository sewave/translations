Motos (ZX Spectrum)
Traducción al Español v1.0 (31/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Motos.tzx
MD5: 74e4818396d613013778fc7558aeed2f
SHA1: 6655029412d4298a1f0c90f2b63e8891bf70c9c6
CRC32: d038f30f
39877 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --