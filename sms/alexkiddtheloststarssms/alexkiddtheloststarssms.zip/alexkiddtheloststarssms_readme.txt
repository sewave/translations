Alex Kidd - The Lost Stars (Master System)
Traducci�n al Espa�ol v1.0 (27/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alex Kidd - The Lost Stars (UE) [!].sms
MD5: ea50dcdd1241667f32d39d606a9f7083
SHA1: 6dbf2684c3dfea7442d0b40a9ff7c8b8fc9b1b98
CRC32: c13896d5
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --