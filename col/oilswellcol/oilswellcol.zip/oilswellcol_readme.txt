Oil's Well (Colecovision)
Traducción al Español v1.0 (05/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Oil's Well (1984) (Sierravision).col
MD5: e7d10b763454692ea8a6da95fccdbd87
SHA1: 779e43f183dbdb692dc26ae41dde6b35891f8f8b
CRC32: add10242
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --