Incredible Hulk, The
Traducci�n al Espa�ol v1.0 (23/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Incredible Hulk, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Incredible Hulk, The
-----------------
Versi�n portatil del incre�ble Hulk.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Incredible Hulk, The (U) [!].gg
524.288	bytes
CRC32: d7055f88
MD5: 7b239c8ae257cb78c46a8affa9bc8226
SHA1: 0410dafce21e5f40263ccb39871188ca84f7dd22

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --