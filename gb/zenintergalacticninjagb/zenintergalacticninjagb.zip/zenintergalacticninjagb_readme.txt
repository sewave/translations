Zen - Intergalactic Ninja (Game Boy)
Traducción al Español v1.0 (09/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zen - Intergalactic Ninja (U).gb
MD5: a517826d1cc3984a141f0f08d3ad72ee
SHA1: 47bbc472071770783b3d930141390f48741176af
CRC32: 88190730
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --