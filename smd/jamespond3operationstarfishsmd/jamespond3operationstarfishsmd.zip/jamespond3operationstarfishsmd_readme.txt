James Pond 3 - Operation Starfish (Mega Drive)
Traducción al Español v1.1 (20/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglos menores.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
James Pond 3 - Operation Starfish (UE) [!].gen
MD5: 0a72b5846ff1766662809318cf000c22
SHA1: df7fca887e7988e24ab2d08b015c6db2902fe571
CRC32: 26f64b2a
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --