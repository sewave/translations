Chakan (Game Gear)
Traducci�n al Espa�ol v1.0 (06/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chakan (U) [!].gg
MD5: 096e525c29af9f5a0a0ddd8b67dd8fbf
SHA1: bdb82464147ef20792162cff7922824d4dee0dc1
CRC32: dfc7adc8
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --