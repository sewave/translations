Super Mario World 2 - Yoshi's Island (Super Nintendo)
Traducción al Español v1.0 (19/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Mario World 2 - Yoshi's Island (USA, Asia) (Rev 1).sfc
MD5: ce1e3e33b6e39d37b43d7de599f9e785
SHA1: 34612a93741f156d6e497462ab7f253cb8a959a0
CRC32: cf98ddaa
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --