Super Adventure Island II (Super Nintendo)
Traducción al Español v1.0 (03/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Adventure Island II (USA).sfc
MD5: b4e732b3d742af1791605bcd7aa4a1c4
SHA1: 06776efd3cc3997513f90fbe2507939a1c61bb87
CRC32: 52fe16fd
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --