Ren & Stimpy - Quest for the Shaven Yak, The (Game Gear)
Traducci�n al Espa�ol v1.0 (28/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ren & Stimpy - Quest for the Shaven Yak, The (U) [!].gg
MD5: 42854dd79bf57019a26ddd73e12b68ac
SHA1: 83bc52f669183f99accb078a454f786b5e320e40
CRC32: 6c451ee1
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --