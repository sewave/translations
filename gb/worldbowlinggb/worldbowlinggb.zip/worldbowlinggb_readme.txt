World Bowling (Game Boy)
Traducción al Español v1.0 (26/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
World Bowling (U) [!].gb
MD5: e8d2a7833fd082f8cc62277d02e84a30
SHA1: f579890b04b33965c009dd3b7300623691ae206a
CRC32: 896e76a2
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --