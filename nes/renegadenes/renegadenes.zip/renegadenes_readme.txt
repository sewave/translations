Renegade (NES)
Traducción al Español v1.0 (17/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Renegade (USA).nes
MD5: a80d980b07453a86226250ff755a2744
SHA1: bce48217b901a2bbd81fb89586661da6a442a179
CRC32: 935f5d29
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --