Pooyan
Traducci�n al Espa�ol v1.0 (06/07/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Notas del Proyecto
2. Fallos Conocidos (o: Bugs que no son bugs)
3. Instrucciones de Parcheo
4. Cr�ditos del Parche

---------------------
1. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
2. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
3. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Pooyan (J).nes
24.592 bytes
CRC32: 1d54dd4c
MD5: 12b7858da54e821dc1fe6884a458128a
SHA1: 7c2f684531fb78704e38db749c71dec4175beaee

----------------------
4. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --