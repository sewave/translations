Dream T.V. (Super Nintendo)
Traducción al Español v1.0 (20/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dream T.V. (USA).sfc
MD5: a33cd61e05671df8529fbfa70da007d1
SHA1: 2ec99d3997677116caa8277544d4bb12d6f74b80
CRC32: ab5a9e40
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --