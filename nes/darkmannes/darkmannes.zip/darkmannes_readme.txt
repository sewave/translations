Darkman (NES)
Traducción al Español v2.0 (05/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducida licencia inicial.
-Traducido título.
-Mejorada traducción de historia con caracteres especiales.
-Mejorada traducción de intro de cada fase con caracteres especiales.
-Traducida barra de estado.
-Traducidos gráficos de sprites.
-Traducido GAME OVER.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Darkman (USA).nes
MD5: fc51c0aa5e3283bed572de31ac5985b5
SHA1: 21b4a65356b54815153303f14832bf5b1b8d3b83
CRC32: 5438a0ac
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --