Super Imposter Bros (Game Boy)
Traducción al Español v1.0 (27/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super_Imposter_Bros.gb
MD5: a455a70d52a9ffcfe8c4d8c164267500
SHA1: 301f93da4e5b0cd8dc3f1bf3e66e38176b8a909b
CRC32: a38d702f
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --