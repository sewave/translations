Cobra Mission (NES)
Traducción al Español v1.1 (14/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Forzada versión PAL al dar errores con NTSC, hace falta un emulador compatible con INES 2.0

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cobra Mission (Asia) (Unl).nes
MD5: 08b0991064598338e4908e041b1fd43a
SHA1: ef3e0ddfc6b2ff81c8349f223f59c650656807eb
CRC32: 0f6bc06c
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --