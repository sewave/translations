Batman - Revenge of the Joker (Mega Drive)
Traducción al Español v1.0 (12/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batman - Revenge of the Joker (U) [!].gen
MD5: 6c31495e2f75c4643837558488b03947
SHA1: e780c949571e427cf1444e1e35efe33fc9500c81
CRC32: caa044a1
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --