Teenage Mutant Ninja Turtles (NES)
Traducción al Español v2.0 (29/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
- Añadidos caracteres especiales
- Guión reescrito

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles (USA).nes
MD5: 5e24ccd733d15e42d847274e7add0a76
SHA1: 89adf2d9e453fc7fc491f968495c80c0c4a568d5
CRC32: 83213ca0
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --