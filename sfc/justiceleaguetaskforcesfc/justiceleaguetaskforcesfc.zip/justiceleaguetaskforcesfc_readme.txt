Justice League Task Force (Super Nintendo)
Traducción al Español v1.0 (23/03/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Biografías de los personajes no traducidas.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Justice League Task Force (USA).sfc
MD5: 2078b064bdf300eb656971946c26430f
SHA1: 5f42f74a03e8a7c0145751a6563dec707cbbe37c
CRC32: 31cf46d1
2621440 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --