Vigilante
Traducci�n al Espa�ol v1.0 (03/05/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Vigilante
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Vigilante
-----------------
Port del beat em up para la 8 bits de sega, bastante fiel, si no fuera por las colisiones.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Vigilante (UE) [!].sms
262.144	bytes
CRC32: dfb0b161
MD5: 6deabfc15d9aeb4c8ed1b641fb950de5
SHA1: 0dc37f1104508c2c0e2593b10dffc3f268ae8ff9

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --