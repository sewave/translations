Old Tower 128K (ZX Spectrum)
Traducción al Español v1.0 (27/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
OldTower128.tap
MD5: 3d029a612970067510ddd6e3b2b96b02
SHA1: e8aeb8da98533ddca3234068ec4ce17c5e7924f6
CRC32: 837df93f
97764 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --