Psychic World (Master System)
Traducción al Español v2.0 (25/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducido título
-Añadidos caracteres especiales
-Guion retraducido
-Traducido texto antes de Cecile
-Traducida la barra de estado

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Psychic World (Europe).sms
MD5: 1076f6358527d1cec1e1e75143997293
SHA1: 5fa54329692e680a190291d0744580968aa8b3fe
CRC32: 5c0b1f0f
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --