Zillion (Master System)
Traducción al Español v1.0 (27/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zillion (UE) (V1.1) [!].sms
MD5: d4bf9e7bcf9a48da53785d2ae7bc4270
SHA1: 3aab3e95dac0fa93612da20cf525dba4dc4ca6ba
CRC32: 5718762c
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --