After Burner (NES)
Traducci�n al Espa�ol v1.0 (11/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
After Burner (Tengen) [!].nes
MD5: 7a8d6a95e31c90286250d2bd6d03d622
SHA1: d7df3ed86114ed9426ae77384f67498b573451dc
CRC32: a0c558a9
393.232 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --