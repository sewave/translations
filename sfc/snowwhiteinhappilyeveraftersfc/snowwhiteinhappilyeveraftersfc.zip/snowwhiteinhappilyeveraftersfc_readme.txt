Snow White in Happily Ever After (Super Nintendo)
Traducción al Español v1.0 (22/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Snow White in Happily Ever After (USA).sfc
MD5: e23297ada3971709536596e4ca88ec3a
SHA1: ffb0baaec4318287359307932683721bb18fa568
CRC32: d68d1ab3
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --