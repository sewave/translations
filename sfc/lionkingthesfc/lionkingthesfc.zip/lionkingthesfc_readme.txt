The Lion King (Super Nintendo)
Traducción al Español v1.0 (12/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lion King, The (USA).sfc
MD5: 6a5b2f9bde72f7d72db7dfe9afd0f47a
SHA1: e5319132495fd34d03f141962d9d6e3d76fe7b02
CRC32: c8fbfaa8
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --