Hit the Ice - VHL - The Official Video Hockey League (Super Nintendo)
Traducción al Español v1.0 (09/11/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hit the Ice - VHL - The Official Video Hockey League (USA).sfc
MD5: 7b4088151df3fa7523010b385a757d49
SHA1: a8b2f000b1df0cf5b1fa0430697d23ad64ee962a
CRC32: ec13477e
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --