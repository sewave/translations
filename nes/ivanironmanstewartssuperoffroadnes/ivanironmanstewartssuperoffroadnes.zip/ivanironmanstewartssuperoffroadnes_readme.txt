Ivan 'Ironman' Stewart's Super Off Road (NES)
Traducción al Español v1.0 (09/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ivan 'Ironman' Stewart's Super Off Road (USA).nes
MD5: de38d18a05b39b4e1e15cbfebf47235d
SHA1: 57919b685b55ee3ed3ad98fb1d25626b98be7d39
CRC32: bbab7334
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --