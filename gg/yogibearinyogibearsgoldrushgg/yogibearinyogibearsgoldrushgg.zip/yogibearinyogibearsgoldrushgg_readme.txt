Yogi Bear in Yogi Bear's Goldrush (Game Gear)
Traducción al Español v1.0 (29/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Yogi Bear in Yogi Bear's Goldrush (Europe) (Proto).gg
MD5: 090c6be6de1d012f0ca478e4cd314449
SHA1: ea5f9ce4b3618565ea24a858f7efe3988b82eb8a
CRC32: e678f264
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --