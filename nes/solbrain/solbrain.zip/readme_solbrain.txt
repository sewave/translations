Tokkyuu Shirei - Solbrain
Traducci�n al Espa�ol v1.0 (27/11/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Tokkyuu Shirei - Solbrain
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Tokkyuu Shirei - Solbrain
-----------------
Version japonesa de shatterhand.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking esta basado en la traduccion de Aeon Genesis.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Tokkyuu Shirei - Solbrain (J).nes
262.160	bytes
CRC32: 9d922166
MD5: af77b204d8a38ace92f1f20185627808
SHA1: 414e7ab212cbd2f5502d4c57264f9cbfe5075ae7

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al espa�ol

Original:

Gideon Zhi - Romhacker, Translator

-- END OF README --