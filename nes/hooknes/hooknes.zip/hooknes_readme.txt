Hook (NES)
Traducción al Español v2.0 (19/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducidas licencias
-Traducido título
-Añadido al texto ÁÓÑ
-Traducido GAME OVER
-Traducidos gráficos de "SALIDA"
-Traducida pantalla de objetos recogidos

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hook (USA).nes
MD5: 673d873d0879ec4a1b003dd7899e6dab
SHA1: 37efdb13a6088bf770c14bc3562ede7a7975599f
CRC32: b5902c20
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --