Sky Jaguar (MSX)
Traducción al Español v1.0 (02/08/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sky Jaguar - Konami (1984) [RC-721] [GoodMSX] [2099].rom
MD5: f8c4add212b508f673974c808639e09e
SHA1: 1f8334dc7459cfcf2ad132e94976015c02e51390
CRC32: e4f725fd
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --