Golf (Game Boy)
Traducción al Español v1.0 (09/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Golf (World).gb
MD5: 6175a5ef55a1998944267e75d8ebf79d
SHA1: 2acee1a14ba611e73b0b7d6bce170107213fcc0c
CRC32: 6ed10383
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --