Little Nemo - The Dream Master (NES)
Traducción al Español v2.0 (29/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Nueva fuente
-Correcciones de guion
-Traducida licencia en el título
-Traducidos créditos
-Traducido "The End"

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Little Nemo - The Dream Master (USA).nes
MD5: 7d774124d8fe1ed4a21f6cc8a34aa800
SHA1: 1fc0ee2265a49974f99dffa92802c2331de86d93
CRC32: 71d868c4
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --