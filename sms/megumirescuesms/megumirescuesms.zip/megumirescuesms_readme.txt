Megumi Rescue (Master System)
Traducci�n al Espa�ol v1.0 (13/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Megumi Rescue (J) [!].sms
MD5: fd834dbb87682c674f7d7ed917355021
SHA1: 7bd156cf8dc2ad07c666ac58ccb3c0ff6671b93f
CRC32: 29bc7fad
131072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --