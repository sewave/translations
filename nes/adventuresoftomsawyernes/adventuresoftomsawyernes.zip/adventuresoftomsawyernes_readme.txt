Adventures of Tom Sawyer (NES)
Traducción al Español v1.1 (06/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado fondo y cambiada tabla de tiempos y EMPEZAR/CONTINUAR.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Adventures of Tom Sawyer (U) [!].nes
MD5: df266b997ee8a1b6bbbaef45bd127201
SHA1: 3d8828fa7ae7108b50979db60f737b95c85b2289
CRC32: 0336f9f3
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --