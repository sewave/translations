Scratch Golf (Game Gear)
Traducción al Español v1.0 (06/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Scratch Golf (USA).gg
MD5: a469a38397a5d530313beb549182558d
SHA1: 263033b62101a4bca2a4311695cef8b7dfbbcc4b
CRC32: c10df4ce
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --