Batman Returns
Traducci�n al Espa�ol v1.0 (21/05/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Batman Returns
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Batman Returns
-----------------
Plataformas de batman para la sobremesa de 8 bits de sega, muy parecido al de game gear, pero mcuho mas dificil y con algunos recortes.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Batman Returns (UE) [!].sms
262.144	bytes
CRC32: b154ec38
MD5: 215876a62d3ca48d28e98cd8a2c70a15
SHA1: 0ccc0e2d91a345c39a7406e148da147a2edce979

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --