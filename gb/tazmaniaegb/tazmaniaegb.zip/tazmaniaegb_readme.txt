Taz-Mania (EUR) (Game Boy)
Traducci�n al Espa�ol v1.0 (01/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Taz-Mania (E) [!].gb
MD5: bb922ce354fc5caec500f99985a07c39
SHA1: c184e8e11ef2388c60b69d445a46fc22a11d175e
CRC32: 0860b667
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --