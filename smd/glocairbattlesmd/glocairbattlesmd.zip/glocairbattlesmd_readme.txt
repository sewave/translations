G-LOC Air Battle (Mega Drive)
Traducción al Español v1.0 (02/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
G-LOC Air Battle (W) [c][!].bin
MD5: 59b8fcc1e0c2113d841025e7ee0d152f
SHA1: 81bb08c4080ca9a8af65597d1c7b11ce902c8d9e
CRC32: f2af886e
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --