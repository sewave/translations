Super R.C. Pro-Am (Game Boy)
Traducción al Español v1.0 (01/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super R.C. Pro-Am (USA, Europe).gb
MD5: 9ba2999ef3ecf9e27ac6c88e995c9d7a
SHA1: 37c0a74532ed283f56e940bb5c38e757a0eee6e0
CRC32: 7960f33f
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --