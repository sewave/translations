Roswell Conspiracies - Aliens, Myths & Legends (Game Boy Color)
Traducción al Español v1.0 (07/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Roswell Conspiracies - Aliens, Myths & Legends (USA) (En,Fr,De).gbc
MD5: dbd7bc8a47d78e84016f0c240e6aa179
SHA1: ec27e608b2787dc18184be7a5a713a1d88403afd
CRC32: 1f5ec131
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --