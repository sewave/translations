Batman - Return of the Joker (Game Boy)
Traducci�n al Espa�ol v1.0 (05/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batman - Return of the Joker (U) [!].gb
MD5: 97bc907deba1e7d7c9bc72fca0310822
SHA1: 345a332175f58304f91111a13b770662e5ea92c3
CRC32: 5124bbec
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --