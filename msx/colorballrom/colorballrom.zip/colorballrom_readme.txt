Color Ball (MSX)
Traducción al Español v1.0 (18/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Color Ball (1983) (Hudson) (J).rom
MD5: 51d3e2426907224ab2244315cb05132c
SHA1: ac391fe51f69e0a55fe3ab66c8ec3f2792dd5d08
CRC32: 12552a1f
8192 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --