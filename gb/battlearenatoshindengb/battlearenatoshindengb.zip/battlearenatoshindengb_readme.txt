Battle Arena Toshinden (Game Boy)
Traducción al Español v1.0 (29/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battle Arena Toshinden (USA) (SGB Enhanced).gb
MD5: 75b5f31fbacb972fc104b3e77d09003b
SHA1: 9c337d3f56938aa46cfc8b85c0db4631bcbe217c
CRC32: 2d0c1073
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --