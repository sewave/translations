RoadBlasters (NES)
Traducción al Español v1.0 (11/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
RoadBlasters (USA).nes
MD5: 88882ebda15b2fef3f3c869df4b1c2a0
SHA1: 9652d375e9ce2dc4a0e51e1e5b6d8ddba9ff0cfa
CRC32: e76915b9
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --