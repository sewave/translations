Devilish - The Next Possession (Mega Drive)
Traducci�n al Espa�ol v1.0 (14/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Devilish - The Next Possession (U) [c][!].gen
524.288 bytes
MD5: 6fa7cd092a175c9040b318d289ffff93
SHA1: bc6f346a162cf91a788a88e44daa246d3d31ee8b
CRC32: d3f300ac

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --