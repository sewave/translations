Batman Forever (Game Gear)
Traducción al Español v1.0 (05/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batman Forever (World).gg
MD5: 6e8f14a7ab173cac90317d390ff8d63b
SHA1: 775ecf7ba87345c2f89f0e9d6e55544db8878786
CRC32: 618b19e2
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --