Super Mario Bros. 2 
Traducci�n al Espa�ol v1.0 (09/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Super Mario Bros. 2 
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Super Mario Bros. 2 
-----------------
Que decir de este clasico.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes contactar en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Super Mario Bros. 2 (U) (PRG1) [!].nes
262.160	bytes
CRC32: e0ca425c
MD5: 25b7e8471ae58316593e58205fa16803
SHA1: 67f68cabc5237a5892aff746f5b784c62fccdfac

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --