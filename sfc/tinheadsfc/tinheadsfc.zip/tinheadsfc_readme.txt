Tinhead
Traducci�n al Espa�ol v1.0 (01/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Tinhead
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Tinhead
-----------------
Plataformas Beta port de Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Tinhead (E) (Beta).smc
1.048.576 bytes
CRC32: 1e079ac0
MD5: 15bf8dd13e3d155739f8103b8934cc80
SHA1: 0f5b3db4919f49d905f539f6128b03ccebab20cf

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --