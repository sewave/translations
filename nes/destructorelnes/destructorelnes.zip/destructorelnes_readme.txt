El Destructor (NES)
Traducción al Español v1.0 (30/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Destructor, El (Spain) (Gluk Video) (Unl).nes
MD5: a0513d51dde7fe7a6abf2e8bad8687de
SHA1: 6c4ba85b962170f471bde4c43623eaf3da748fd1
CRC32: eb33ea3b
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --