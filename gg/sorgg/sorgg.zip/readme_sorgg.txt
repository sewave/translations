Streets of Rage
Traducci�n al Espa�ol v1.0 (11/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Streets of Rage
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Streets of Rage
-----------------
El clasico beat em up de sega adaptado a la portatil, muy conseguido.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Streets of Rage (U) [!].gg
262.144	bytes
CRC32: 3d8bcf1d
MD5: 1ece7480d21fb862a65233ba126282d3
SHA1: ca8c8a00ee838e994b2fa17e595ddd40d898cf42

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --