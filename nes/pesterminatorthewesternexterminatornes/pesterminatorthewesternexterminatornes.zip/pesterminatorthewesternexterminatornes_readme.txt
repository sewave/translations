Pesterminator - The Western Exterminator (NES)
Traducción al Español v1.0 (31/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pesterminator - The Western Exterminator (Color Dreams) [!].nes
MD5: e57906c044453fad9d4078a06f3a5d61
SHA1: e2798f1b0f34fb4177b032ad37c6117632a2b8f7
CRC32: 5cf70751
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --