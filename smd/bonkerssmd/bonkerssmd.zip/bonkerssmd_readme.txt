Bonkers (Mega Drive)
Traducci�n al Espa�ol v1.0 (05/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bonkers (UE) [!].bin
MD5: 9b7b171a649415d2750e81337d641ad3
SHA1: 938642252fdb1c5aedc785bce2ba383fc683c917
CRC32: d1e66017
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --