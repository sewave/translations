OutRun (PC Engine)
Traducci�n al Espa�ol v1.0 (21/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
OutRun (J).pce
MD5: cf3a009d2ec0bede35613d7a6342810a
SHA1: 6fd6b8fb1bd2549a81a51567022ee59f2195da60
CRC32: 24d2165d
524.800 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --