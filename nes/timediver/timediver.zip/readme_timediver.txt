Time Diver Eon Man
Traducci�n al Espa�ol v1.0 (15/03/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Time Diver Eon Man
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Time Diver Eon Man
-----------------
Un decente plataformas que lamentablemente no paso de prototipo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Time Diver Eon Man (U) (Prototype).nes
262.160	bytes
CRC32: 9562d0d5
MD5: 7746ff8a57b5c906a8be46f40e2a417b
SHA1: eec46b641b8ec301857bb088a45112784d002b7b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --