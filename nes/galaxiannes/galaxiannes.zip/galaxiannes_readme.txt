Galaxian (NES)
Traducción al Español v1.0 (28/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato BPS, puedes usar Floating IPS.
Archivo utilizado:
Galaxian (Japan) (Rev A).nes
MD5: e2ee1d8466bc5cfc57ec7b91be56c663
SHA1: b9da18b3fb90f51cfb6277c651e935fd28d7212a
CRC32: a80da263
16400 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --