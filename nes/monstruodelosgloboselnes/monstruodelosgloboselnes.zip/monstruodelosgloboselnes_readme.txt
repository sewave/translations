Monstruo de los globos, El (NES)
Traducción al Español v1.0 (03/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Monstruo de los globos, El (Spain) (Gluk Video) (Unl).nes
MD5: 3113362bacf37b5722b28c86e772313c
SHA1: cfbc64fd79abd0bfad54714c0e50b1bdcefaddca
CRC32: 77298928
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --