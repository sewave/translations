Double Dragon 2
Traducci�n al Espa�ol v1.0 (13/08/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Double Dragon 2
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Double Dragon 2
-----------------
Segunda parte del famoso beat em up para game boy.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Double Dragon 2 (U) [!].gb
131.072	bytes
CRC32: 5b96e474
MD5: 4f3b84eb325f9162086fac77ac577e7c
SHA1: 3532462be3ab1a569890261d20a1a37bfe79e1ea

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --