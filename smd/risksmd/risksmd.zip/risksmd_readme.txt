Risk (Mega Drive)
Traducción al Español v1.0 (19/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Risk (USA).md
MD5: 7a1ef516a2a741aefdaa543c3a7c472a
SHA1: 6f4bf5e1dc0de79e42934e5867641e1baadba0d9
CRC32: 80416d0d
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --