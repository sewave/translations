Drac's Night Out (NES)
Traducción al Español v1.0 (27/07/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Drac's Night Out (USA) (Proto).nes
MD5: d0be294926474ac2440618e3a91b084a
SHA1: 2bfb09932be1e547ffe5bd62b0cc6bd1f0c55ff2
CRC32: 2f81e727
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --