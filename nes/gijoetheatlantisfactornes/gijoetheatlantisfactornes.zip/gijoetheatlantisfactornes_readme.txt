G.I. Joe - The Atlantis Factor (NES)
Traducción al Español v2.0 (02/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres especiales
-Traducido subtítulo
-Traducidos ROUTE y AREA
-Guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
G.I. Joe - The Atlantis Factor (USA).nes
MD5: c82eb393a36453cc6ba1270ab33ece3b
SHA1: ab57331556b5c5456c67a24a21da91a6c1decd73
CRC32: a8efac13
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --