Druaga no Tou (NES)
Traducción al Español v1.0 (22/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Druaga no Tou (Japan).nes
MD5: 0b285faecb0d54a28fc3ee813839f96a
SHA1: 729a2964005e06cbe6713c9a491c48bfd6f13c3e
CRC32: 0c045fb9
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --