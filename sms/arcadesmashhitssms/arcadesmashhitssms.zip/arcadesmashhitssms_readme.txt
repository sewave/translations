Arcade Smash Hits (Master System)
Traducción al Español v1.0 (06/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Arcade Smash Hits (E) [!].sms
MD5: c74e0be13dc3fbd085fb9a1ebd6e6afc
SHA1: 44ed3aeaa4c8a627b88c099b184ca99710fac0ad
CRC32: e4163163
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --