Nightshade
Traducci�n al Espa�ol v1.0 (11/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Nightshade
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Nightshade
-----------------
Una aventura grafica con combates, muy original.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Nightshade (U) [!].nes
524.304	bytes
CRC32: c6d266af
MD5: 5a79e31ef253afea61b75d1b68508358
SHA1: 75db8d9678dccb0f1341df03d9c35a80d567558f

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --