Exerion 1 (MSX)
Traducción al Español v1.0 (22/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Exerion 1 (1984) (Jaleco) (J).rom
MD5: 165e08772153f210dd5080e06b27bfa6
SHA1: 975fdf521c08030896eb50af4f39a23500eaf7ac
CRC32: 7abefd3d
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --