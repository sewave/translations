Bugs Bunny in Double Trouble (Game Gear)
Traducción al Español v1.0 (07/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bugs Bunny in Double Trouble (U) [!].gg
MD5: 04770c2c01095a6e3fde211a125d8964
SHA1: a29dabb90532ff6114437f28970203e16003c11e
CRC32: 5c34d9cd
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --