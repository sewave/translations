Gun-Nac (JAP)
Traducci�n al Espa�ol v1.0 (20/01/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Gun-Nac (JAP)
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Gun-Nac (JAP)
-----------------
Interesante shoot em up de Compile.
Esta versi�n tiene m�s introducci�n y algunos gr�ficos que fueron censurados en la versi�n americana.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basada en la de Zynk Oxhyde.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Gun-Nac (J).nes
262.160	bytes
CRC32: f39b41a4
MD5: 029daa688d2c51a296eb4e7fed953d0d
SHA1: 48ce296d9ddb59abf13ceccde777a3e43c27ff61

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Original:
Contributor	Type of contribution	Listed credit
Zynk Oxhyde	Hacking					Hacking & Translation
Jonny2x4	Translation				Translation from The Video Game Museum

-- END OF README --