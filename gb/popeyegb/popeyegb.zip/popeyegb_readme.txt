Popeye (Game Boy)
Traducción al Español v1.0 (14/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Popeye (Japan).gb
MD5: 55a2ca284b3b42f6c55d59f9e11c196c
SHA1: d7c4cfa460e65368477f9394164b67e03310fc69
CRC32: 2fb4da21
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --