Top Gear 2 (Super Nintendo)
Traducción al Español v1.0 (01/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Top Gear 2 (U) [!].smc
MD5: c9fc87528511770db888b28a4c506f46
SHA1: 8ac5dab79b319deb525de73f9a51877df7a7ed9f
CRC32: 2b88bee8
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --