Beetlejuice (Game Boy)
Traducción al Español v1.0 (30/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Beetlejuice (USA).gb
MD5: f6c1715b8b93356b8b8ad27f5574dc96
SHA1: a8bb9681dbf0700d64a88c7d9ad0093f08087046
CRC32: 33574ecb
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --