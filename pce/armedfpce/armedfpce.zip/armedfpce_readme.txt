Armed F (PC Engine)
Traducción al Español v1.0 (27/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Armed F (Japan).pce
MD5: c9efecc5c9854bfe79db25cd01614802
SHA1: a326c9cece6f14b82629c4c79b34df819b022dce
CRC32: 20ef87fd
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --