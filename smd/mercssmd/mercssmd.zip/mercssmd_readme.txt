Senjou no Ookami II ~ Mercs (Mega Drive)
Traducción al Español v2.0 (20/04/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducidos gráficos SHOOT y ENTER
-Traducido PAUSE
-Añadidos caracteres españoles a fuente pequeña
-Añadida Ó a fuente grande
-Guion retraducido
-Cadenas alargadas
-Falta:
-CONTINUE/GAME OVER
-CONGRATULATIONS
-Créditos original mode

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Senjou no Ookami II ~ Mercs (World).md
MD5: 4643f5da530463356ce56fae5c346ddc
SHA1: ab633913147325190ef13bd10f3ef5b06d3a9e28
CRC32: 16113a72
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --