Borderline (SG-1000)
Traducci�n al Espa�ol v1.0 (01/12/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Borderline (SG-1000).sg
MD5: 25c742e43bc9f1329f3f26502fefb10a
SHA1: b967340fa91d960f86548f15e6d25a8e7e2c5043
CRC32: 0b4bca74
16.384 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --