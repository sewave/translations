Dizzy the Adventurer (NES)
Traducción al Español v1.0 (16/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dizzy the Adventurer (USA) (Aladdin Compact Cartridge) (Unl).nes
MD5: 7dc7d65ea289fbbb32cb76cffb2c31c7
SHA1: 24b0b961c8cdbe3c6dd19477f29d6e8aebaec91c
CRC32: 92847456
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --