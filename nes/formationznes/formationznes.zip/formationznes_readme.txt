Formation Z (NES)
Traducción al Español v1.0 (14/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Formation Z (Japan) (Rev A).nes
MD5: 7c0a3a67f404c03f2d701b93a4566602
SHA1: 74883cd81ba34439c99cbdf76328f3eeae964a46
CRC32: 629eae68
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --