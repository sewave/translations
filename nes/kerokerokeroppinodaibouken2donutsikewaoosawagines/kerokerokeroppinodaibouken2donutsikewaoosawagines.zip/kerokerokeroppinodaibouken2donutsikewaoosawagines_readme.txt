Kero Kero Keroppi no Daibouken 2 - Donuts Ike wa Oosawagi! (NES)
Traducción al Español v1.0 (13/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de The Spoony Bard.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kero Kero Keroppi no Daibouken 2 - Donuts Ike wa Oosawagi! (Japan).nes
MD5: 01604c74ce2682d0aefb89d82eb78c64
SHA1: ae3ce6490a7823267f9655e2de192781cc3db404
CRC32: 2c46f2a3
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --