Felix the Cat
Traducci�n al Espa�ol v1.0 (12/12/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Felix the Cat
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Felix the Cat
-----------------
Juego basado en la serie de animacion, con multiples transformaciones y bastante largo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Felix the Cat (U) [!].nes
262.160	bytes
CRC32: 0639e88e
MD5: 2f037c1da6a59f56a0f65c6971f8b3bd
SHA1: d98426b4955ae9ec4feaedb2538aab35b8209c06

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --