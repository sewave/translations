Antarctic Adventure (Colecovision)
Traducci�n al Espa�ol v1.0 (30/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Antarctic Adventure (1984) (Konami).col
MD5: 1ea45edc04bc4df444a38e50f8a75d5d
SHA1: 00db7cf9bd66aecac3d9368dd205680781b2e542
CRC32: 275c800e
16.384 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --