Toejam & Earl in Panic on Funkotron (Mega Drive)
Traducci�n al Espa�ol v1.0 (31/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Los nombres de los lugares han sido traducidos, intentando que quedaran legibles.
Algunas partes de la traducci�n son bastante libres ya que utilizan expresiones
muy coloquiales y ademas no hay mucho espacio para las cadenas.
No se han a�adido acentos ya que no hay espacio en los tiles de las letras.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Toejam & Earl in Panic on Funkotron (U) [!].gen
2.097.152 bytes
MD5: 7ee9f6a3d28a94d7298bb9813478e504
SHA1: 0ea0da09183eb01d030515beeb40c1427c6e1f07
CRC32: aa021bdd

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --