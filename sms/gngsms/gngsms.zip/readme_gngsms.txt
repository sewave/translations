Ghouls 'n Ghosts
Traducci�n al Espa�ol v1.0 (26/11/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Ghouls 'n Ghosts
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Ghouls 'n Ghosts
-----------------
Adaptacion del famoso juego con una vuelta de tuerca, bastante bueno.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Ghouls 'n Ghosts (UE) [!].sms
262.656	bytes
CRC32: 6700985a
MD5: 501431ccbeb321a9a2762888f0aa61ce
SHA1: 06a3dbe52d1144b6c86bc7c5cf445a2f3b4fdd26

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --