R-Type (Master System)
Traducci�n al Espa�ol v1.0 (23/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
R-Type (UE) [!].sms
MD5: 9e5507d51ac6f24c702a52a7abce0d3c
SHA1: 08ec70a2cd98fcb2645f59857f845d41b0045115
CRC32: bb54b6b0
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --