Sector-90 (ZX Spectrum)
Traducción al Español v1.0 (14/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sector-90.tzx
MD5: 6d4b59b06546a73b9c1aed2beb192d98
SHA1: 5e36959ec4b57b1a8d4ec7bc10bb71ed022f945e
CRC32: ccff3c60
49060 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --