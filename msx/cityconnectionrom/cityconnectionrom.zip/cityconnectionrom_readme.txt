City Connection (MSX)
Traducción al Español v1.0 (20/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
City Connection (1986) (Jaleco) (J).rom
MD5: 8a3339bc88a1d1bf3aeb0b39202b7951
SHA1: 0071b2eb214ff002dbbb7532653585b35b56f243
CRC32: 6031a583
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --