Spanky's Quest (Game Boy)
Traducción al Español v1.0 (22/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spanky's Quest (U) [!].gb
MD5: 3c268409bf6869a8707839a7dd1ee1c7
SHA1: 8f448eab7e6a05266d62f3564a00813f79314736
CRC32: 6ee7ca79
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --