The Chessmaster (Game Gear)
Traducción al Español v1.0 (24/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chessmaster, The (U) [!].gg
MD5: b24d5c5548acb3b35aaf02802b3bb7d5
SHA1: daea9a76dedc080b9965cfa32e2ddb1eaaaab0b4
CRC32: da811ba6
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --