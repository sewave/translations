Penguin Adventure (MSX)
Traducción al Español v1.0 (09/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Penguin Adventure (Japan, Europe).rom
MD5: 9c3b9492f2b565cbddf562195f540993
SHA1: d53e0c8bcd98820afe820f756af35cc97911bfe4
CRC32: 0f6418d3
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --