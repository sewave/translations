Kung-Fu Taigun (MSX)
Traducción al Español v1.0 (16/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kung-Fu Taigun (1984) (Toshiba Emi) (J).rom
MD5: 8debfe14cb9a88a0bfda8d2023dddbb8
SHA1: e817ab7b50674c414b1c1b72530024eb03396a41
CRC32: c1aaf8cb
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --