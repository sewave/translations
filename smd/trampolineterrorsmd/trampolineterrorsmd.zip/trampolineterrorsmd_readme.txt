Trampoline Terror! (Mega Drive)
Traducción al Español v1.0 (20/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Trampoline Terror! (U) [!].bin
MD5: c4d2c80b3f21748325470667c1caf574
SHA1: d0dc2acdc17a1e1da25828f7d07d4ba9e3c9bd78
CRC32: aabb349f
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --