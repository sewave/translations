Xevious - Fardraut Saga (MSX)
Traducción al Español v1.0 (20/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Xevious - Fardraut Saga (1989) (Namcot) (J).mx2
MD5: 261a860dee771ea77c2d813b97366f9e
SHA1: f84d7fc089b31440cac1f4fbee3d45b2f6c90e37
CRC32: 97591725
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --