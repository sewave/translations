Sweet Home (NES)
Traducción al Español v1.2 (31/08/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
- Arreglada la pantalla de Game Over gracias a Jackic.

V1.2:
- Aplicadas correcciones informadas por signatux

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sweet Home (Japan).nes
MD5: 49dd966e8a0e17bae16bc3d393c9d742
SHA1: 54bfe479c12247e8b9996c6c5f331977035e1276
CRC32: 40803bc5
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
signatux - Pruebas.

-- FIN --