Cybernoid (ZX Spectrum)
Traducción al Español v1.0 (23/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cybernoid.tzx
MD5: 50921a76ee625feb31c4195aac63d020
SHA1: d0cd015bf78acf009e6f0184bcccfa5f9e8a0ec8
CRC32: 5aaff50e
45094 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --