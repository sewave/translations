Street Fighter IV (NES)
Traducción al Español v1.1 (24/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado Continuar

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Street Fighter IV (Unl).nes
MD5: d55df1ac4442a0488ee0cfd7911f340a
SHA1: 9654fd88ee3b525c4d3c69012a39487efd6c9958
CRC32: e7e52f44
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --