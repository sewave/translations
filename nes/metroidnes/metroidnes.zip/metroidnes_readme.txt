Metroid (NES)
Traducción al Español v2.0 (17/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Revisión de script
-Añadidos acentos
-Traducidos más gráficos

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Metroid (USA).nes
MD5: d77c8053168da14b360bf5caeccc5964
SHA1: ecf39ec5a33e6a6f832f03e8ffc61c5d53f4f90b
CRC32: a2c89cb9
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --