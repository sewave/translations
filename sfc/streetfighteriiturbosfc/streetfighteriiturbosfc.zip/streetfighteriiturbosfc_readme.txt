Street Fighter II Turbo (Super Nintendo)
Traducción al Español v1.0 (23/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Street Fighter II Turbo (USA) (Rev 1).sfc
MD5: 014863e139f5a9e9fc8ecf59a133223b
SHA1: 9f6e8f2585e60bd6690c068c692ac97653bae6a6
CRC32: d43bc5a3
2621440 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --