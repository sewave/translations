James 'Buster' Douglas Knockout Boxing (Mega Drive)
Traducción al Español v1.1 (06/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arregladas opciones

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
James 'Buster' Douglas Knockout Boxing (USA, Europe).md
MD5: 9635abe009beffdff9954c4214e8cc8d
SHA1: 617b61da9bceb6f4d8362d074dc1dad3f7304584
CRC32: 87bbcf2a
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --