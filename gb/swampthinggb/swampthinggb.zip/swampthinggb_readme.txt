Swamp Thing (Game Boy)
Traducción al Español v1.0 (20/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Swamp Thing (U) [!].gb
MD5: 85ccd61e2298b5f9b26312e8e182f10e
SHA1: 1ff322b5f44d21c951dcdf8d062d99ffa65827e3
CRC32: 76ae62c8
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --