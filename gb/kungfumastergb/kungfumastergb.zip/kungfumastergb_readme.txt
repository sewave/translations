Kung-Fu Master (Game Boy)
Traducción al Español v1.0 (29/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kung-Fu Master (U).gb
MD5: 18fe3526f170f47a277e0fac17d90170
SHA1: b0bb485e2b57793da9f153db074c13a060a1e0d4
CRC32: 3340e600
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --