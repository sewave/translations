Hook (Mega Drive)
Traducción al Español v2.0 (27/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Revisión de script
-Añadidos acentos
-Traducida barra de estado
-Traducido "Continue?"
-Traducido "PRESS START"

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hook (USA).md
MD5: 70b7314bb4f542cedc0ca9422808f269
SHA1: 67031af6ec4b771bd8d69a44c9945562a063593e
CRC32: 2c48e712
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --