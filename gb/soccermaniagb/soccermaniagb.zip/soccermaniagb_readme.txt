Soccer Mania (Game Boy)
Traducción al Español v1.0 (10/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Soccer Mania (JU) [!].gb
MD5: 12454fbcb38432e26f280282e7196e73
SHA1: 6e641fee2628e98890e579e3ab6574b1757b8d08
CRC32: 6f87b543
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --