Taz-Mania (Game Gear)
Traducción al Español v1.0 (07/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Taz-Mania (USA, Europe, Brazil).gg
MD5: 70220f584b2d4f69e5efa9a3268a4a88
SHA1: 0d0285bc5350146f365dae1f271ed0828971cf4d
CRC32: 36040c24
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --