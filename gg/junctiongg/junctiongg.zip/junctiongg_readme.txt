Junction (Game Gear)
Traducci�n al Espa�ol v1.0 (01/12/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Junction (U).gg
MD5: 7dd2ef762d2284a0e551447a9ee11458
SHA1: 70cac7959d29903ad22316e9f5edf60834381d27
CRC32: a8ef36a7
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --