Adventure Island (Game Boy)
Traducción al Español v1.0 (20/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Adventure Island (USA, Europe).gb
MD5: d67e58bf5f39d5fb073fed85c3d9bede
SHA1: 4a61945c1e3a37301748314777835c0e122a67e6
CRC32: 64f4fa44
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --