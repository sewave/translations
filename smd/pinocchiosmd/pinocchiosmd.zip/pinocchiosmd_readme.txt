Pinocchio (Mega Drive)
Traducción al Español v1.0 (12/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pinocchio (USA).md
MD5: bace0d15220dcfc8b8a3efb6668e45ba
SHA1: ad6098fe3642489d0281b1f168319a753e8bd02a
CRC32: cd4128d8
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --