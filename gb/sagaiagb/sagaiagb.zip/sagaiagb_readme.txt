Sagaia
Traducci�n al Espa�ol v1.0 (13/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Sagaia
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Sagaia
-----------------
Shooter espacial arcade.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Sagaia (J) [!].gb
131.072	bytes
CRC32: e43da090
MD5: 70a9ef90ad443881ca90cdd8d910ae66
SHA1: 79600f8602ca33f2b39a9b8d9824dff55dfc1ef0

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --