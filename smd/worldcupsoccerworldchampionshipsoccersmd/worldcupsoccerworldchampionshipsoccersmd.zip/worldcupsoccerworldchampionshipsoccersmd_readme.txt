World Cup Soccer ~ World Championship Soccer (Mega Drive)
Traducción al Español v1.0 (12/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
World Cup Soccer ~ World Championship Soccer (Japan, USA) (Rev C).md
MD5: a1647bee0108acba9e2f99daab336c18
SHA1: 9da376f266c98c93ae387bec541c513fec84a0e9
CRC32: bf272bcb
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --