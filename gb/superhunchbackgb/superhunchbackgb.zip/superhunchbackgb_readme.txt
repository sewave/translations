Super Hunchback (Game Boy)
Traducción al Español v1.0 (01/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Hunchback (U).gb
MD5: f5e132763e20e45f407258d3c6ec0c61
SHA1: 9d53fbfeeec5a1a8352177c157ce615621c4b30c
CRC32: 1a45706e
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --