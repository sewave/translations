QuackShot Starring Donald Duck ~ QuackShot - I Love Donald Duck - Guruzia Ou no Hihou (Mega Drive)
Traducción al Español v1.1 (20/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Reajustados punteros de la introducción para corregir un puntero erróneo en la rom original y dar más espacio a una frase.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
QuackShot Starring Donald Duck ~ QuackShot - I Love Donald Duck - Guruzia Ou no Hihou (World) (v1.1).md
MD5: 3d79d2fcc2038b140f7481b6f64a5038
SHA1: 7b1bd16fb817cc5e2af238cebe8521aaca8f6195
CRC32: 1801098b
1310720 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --