Little Red Hood (NES)
Traducción al Español v1.0 (09/11/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Little Red Hood (Australia) (Unl).nes
MD5: 892ab4c0563652224942f20d17a7fd28
SHA1: 7f4c3071ba94c3abf6a44f9b54b22141737fb0dc
CRC32: 96b201c7
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --