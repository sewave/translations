Quartet (Master System)
Traducci�n al Espa�ol v1.0 (10/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Quartet (UE) [!].sms
131.072 bytes
MD5: 63af7fce5106cc3de1e1b116c112095b
SHA1: 08a3484e862a284f6038b7cd0dfc745a8b7c6c51
CRC32: e0f34fa6

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --