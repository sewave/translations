Puss 'n Boots - Pero's Great Adventure (NES)
Traducción al Español v1.0 (08/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Puss 'n Boots - Pero's Great Adventure (USA).nes
MD5: 483c5881159c572a2e1668fa50fe45c1
SHA1: 6bbf9464374e5486c644f2aee6c775965de987c6
CRC32: 5d07670a
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --