Growl
Traducci�n al Espa�ol v1.0 (27/04/2017)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Growl
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Growl
-----------------
Port del beat em up de Arcade para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Growl (U) [!].bin
524.288	bytes
CRC32: f60ef143
MD5: 3152ebc067925b0ca35d20290de0985a
SHA1: 63a08057fe9fd489590f39c5c06709266f625ab0

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --