Thunder Force III
Traducci�n al Espa�ol v1.1 (09/01/2018)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Thunder Force III
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Thunder Force III
-----------------
Tercera parte de la saga de shoot em ups.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Arreglado final

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Thunder Force III (JU) [!].gen
524.288	bytes
CRC32: 1b3f399a
MD5: 64766dae889d039eb391bc5bf2973f5d
SHA1: 9eadee76eb0509d5a0f16372fc9eac7a883e5f2d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --