Wimbledon (Master System)
Traducción al Español v1.0 (24/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wimbledon (Europe).sms
MD5: a7f1049812a4cd1f180dcd644b10145f
SHA1: 07bc7896efc9eae77a9be68c190071c99eb17a8a
CRC32: 912d92af
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --