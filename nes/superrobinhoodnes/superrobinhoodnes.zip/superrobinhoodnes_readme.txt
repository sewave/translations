Super Robin Hood (NES)
Traducción al Español v1.0 (11/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super_Robin_Hood.nes
MD5: 98b14fa59a32f1628b8853d79c2a71ef
SHA1: 3fad4dc29d1e3177a96bededed72afea39179240
CRC32: 25baa274
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --