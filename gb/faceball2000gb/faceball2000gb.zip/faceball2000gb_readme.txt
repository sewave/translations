Faceball 2000 (Game Boy)
Traducción al Español v1.0 (08/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Faceball 2000 (USA).gb
MD5: 05ba7f165dab1ffd49b63b4f5c704c02
SHA1: b0bd15bace04e0a3eb89773f231ac3a532181a0a
CRC32: 7d890cd0
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --