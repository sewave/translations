Sumo Fighter (Game Boy)
Traducción al Español v1.0 (08/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sumo Fighter (USA).gb
MD5: e76fb477ef0e8163e83f9fac15fff7e9
SHA1: 48f225f86985d5fb09877e028baad8a6f3ee8d95
CRC32: badc7cee
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --