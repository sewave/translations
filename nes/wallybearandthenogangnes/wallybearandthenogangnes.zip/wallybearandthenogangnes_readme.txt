Wally Bear and the No! Gang (NES)
Traducción al Español v1.0 (14/09/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wally Bear and the No! Gang (USA) (Unl).nes
MD5: 89121902b892b7018f0f274534751632
SHA1: cd1ee26c0cef8c48b72cc4000ac7a577b8c4c0b5
CRC32: c562f258
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --