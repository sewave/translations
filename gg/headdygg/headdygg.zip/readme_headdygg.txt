Dynamite Headdy
Traducci�n al Espa�ol v1.0 (21/11/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Dynamite Headdy
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Dynamite Headdy
-----------------
Version descafeinada para la 8bit portatil del juego de megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Se traducen la introduccion y el final (y creditos).

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Dynamite Headdy (U).gg
524.288	bytes
CRC32: 610ff95c
MD5: 2da61f019f30eb0795cfd6eb9d5b54c6
SHA1: a8c8b5252a885d466e044e6055336513d988e661

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --