The Shadow (Super Nintendo)
Traducción al Español v1.0 (11/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shadow, The (USA) (Proto 1).sfc
MD5: bb103f88b7e4c432acc337cba93f2077
SHA1: 130618b7eb2449f564152ff0583353612babd483
CRC32: 13380511
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --