Croc (Game Boy Color)
Traducción al Español v1.0 (29/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Croc (USA, Europe).gbc
MD5: 0552078f981c2ef3977f2dfeee19510a
SHA1: dac6de548743c6b51a3daa5903c28b7fccdb6cb2
CRC32: 4664a167
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --