Magical Puzzle Popils (Game Gear)
Traducción al Español v1.0 (20/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Magical Puzzle Popils (World) (En,Ja).gg
MD5: e496ff2196c372f4d6111538950d25ca
SHA1: fb939f0810d0763b9abaeec1a2bfbabacaad5441
CRC32: cf6d7bc5
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --