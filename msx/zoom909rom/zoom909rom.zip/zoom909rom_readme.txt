Zoom 909 (MSX)
Traducción al Español v1.0 (05/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zoom 909 (1985) (Pony Cannon) (J).rom
MD5: d8e09f622af52e07a83f19ca58aee194
SHA1: 07db3e3ffb16c138f9da12cacde48bf7522a188c
CRC32: 64283863
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --