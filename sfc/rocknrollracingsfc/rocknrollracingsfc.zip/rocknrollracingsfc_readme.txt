Rock N' Roll Racing (Super Nintendo)
Traducción al Español v1.0 (20/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rock N' Roll Racing (USA).sfc
MD5: 1978359063c02ad2badd3c0e993aca14
SHA1: 66d864dd07f8eae86cf4e1f60f176b405a2ddbe9
CRC32: 7d06f473
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --