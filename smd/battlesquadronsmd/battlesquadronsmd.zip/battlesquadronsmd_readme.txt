Battle Squadron
Traducci�n al Espa�ol v1.1 (01/07/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Battle Squadron
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Battle Squadron
-----------------
Shoot em up multijugador para Mega Drive, port del Amiga.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

v1.1: Arreglada introducci�n.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Battle Squadron (UE) [!].bin
524.288	bytes
CRC32: 0feaa8bf
MD5: b5b815ef99b943fe0bad48dc13239b35
SHA1: f003f7af0f7edccc317c944b88e57f4c9b66935a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --