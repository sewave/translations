Kid Icarus - Of Myths and Monsters (Game Boy)
Traducci�n al Espa�ol v1.0 (14/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kid Icarus - Of Myths and Monsters (UE) [!].gb
MD5: 23c7be98ac9a4d3b046ad1be3f0965e4
SHA1: 465614bb236c507a5709ecab95827a8be4e2e6b8
CRC32: 0c042862
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --