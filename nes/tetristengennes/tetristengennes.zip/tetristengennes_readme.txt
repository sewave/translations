Tetris (Tengen) (NES)
Traducción al Español v1.0 (06/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tetris (USA) (Unl).nes
MD5: 1bcb1795a0feed766d6d0681196662fb
SHA1: 34113a102ccfff6a859f8ebb66c24260d43ec7ab
CRC32: 88f071c3
49168 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --