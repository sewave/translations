Street Fighter 2010 - The Final Fight
Traducci�n al Espa�ol v1.0 (09/03/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Street Fighter 2010 - The Final Fight
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Street Fighter 2010 - The Final Fight
-----------------
Secuela/adaptacion del famoso street fighter a un plataformas de 8 bits, aunque no tiene nada que ver...

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Se han a�adido caracteres especiales y minusculas.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Street Fighter 2010 - The Final Fight (U) [!].nes
262.160	bytes
CRC32: a7355946
MD5: 5d8c039d277892f86aebf1afd813392e
SHA1: 92f1dc8fc7c9420cf26d063611fa7d9067197740

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --