Gekitotsu Yonku Battle (NES)
Traducci�n al Espa�ol v1.0 (07/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gekitotsu Yonku Battle (J) [!].nes
MD5: 38e04f529acc9086bd07ac0cea605ffa
SHA1: f000ad1916aa29be3ae51f675ed42bf7b4e1c1b4
CRC32: c7e7f987
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --