Adventures of Bayou Billy, The
Traducci�n al Espa�ol v1.1 (01/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Adventures of Bayou Billy, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Adventures of Bayou Billy, The
-----------------
Principalmente un beat em up aunque combina pantallas de pistola y de conducci�n, dif�cil.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original, traduce el texto principal y la barra de estado.
V1.1: revisi�n de script y cr�ditos finales.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Adventures of Bayou Billy, The (U) [!].nes
262.160	bytes
CRC32: 0ac631ba
MD5: fadd166217e75f3759a5cb7af213734a
SHA1: 7ebcfdc5cebfcd64bb371ede1af42e1b36a7e3e1

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --