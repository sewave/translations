No Good Choice (NES)
Traducción al Español v1.0 (08/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
nogoodchoice.nes
MD5: 06e19c8b22060bf764ab266963f1bd52
SHA1: 18f83f733893f9a4d08eb32876e5554458c9f2c7
CRC32: 42813667
32784 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --