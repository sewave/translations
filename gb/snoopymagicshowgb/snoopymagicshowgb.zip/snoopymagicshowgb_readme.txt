Snoopy - Magic Show (Game Boy)
Traducción al Español v1.0 (27/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Snoopy - Magic Show (U) [!].gb
MD5: 8a06994b2e265244147a4d6d0e80623f
SHA1: bc21fb3aa1a58e2aef30fabe103b2e5bec02b535
CRC32: 2b7a5034
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --