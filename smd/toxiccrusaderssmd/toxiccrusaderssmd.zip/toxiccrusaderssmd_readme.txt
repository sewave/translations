Toxic Crusaders (Mega Drive)
Traducci�n al Espa�ol v1.0 (19/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Toxic Crusaders (U) [!].bin
MD5: a926370d03e278f76c26c868b909fd36
SHA1: fd83f309b6d4261f0c98ba97a8627cfb5212093b
CRC32: 11fd46ce
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --