Super Ghouls 'N Ghosts (Super Nintendo)
Traducci�n al Espa�ol v1.1 (08/04/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
V1.1: Arregla cadena al derrotar a un jefe.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Ghouls 'N Ghosts (U) [!].smc
MD5: 19b2d7a555ecef4c453a819e67e61574
SHA1: f12280b13eea88ca03d700b75cf3c13a0e13f3bc
CRC32: 6aaba901
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --