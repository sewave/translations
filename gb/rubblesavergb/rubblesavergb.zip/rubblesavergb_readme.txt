Rubble Saver (Game Boy)
Traducción al Español v1.0 (23/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rubble Saver (Japan).gb
MD5: 10c581e4d5b612831c79724434f93e9f
SHA1: b535b2b78611ba1eb59e530456545fced0fddb76
CRC32: e8aea452
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --