Super Skidmarks (Mega Drive)
Traducción al Español v1.1 (19/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado ajustes/carrera.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Skidmarks (Europe) (J-Cart).md
MD5: 533b890ed1113547691f36ad1c59e346
SHA1: 957850ce688dcf9c5966f6712b4804f0a5b7457d
CRC32: 4a9c62f9
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --