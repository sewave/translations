Rambo III
Traducci�n al Espa�ol v1.0 (13/08/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Rambo III
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Rambo III
-----------------
Libre adaptaci�n de rambo a la megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Rambo III (W) (REV01) [!].bin
262.144 bytes
CRC32: 4d47a647
MD5: d0140fde92f051cde0b986b854f28e99
SHA1: e337e618653830f84c77789e81724c5fc69888be

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --