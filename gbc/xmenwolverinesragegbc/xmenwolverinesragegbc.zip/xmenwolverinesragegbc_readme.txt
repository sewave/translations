X-Men - Wolverine's Rage (Game Boy Color)
Traducción al Español v1.0 (19/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
X-Men - Wolverine's Rage (USA).gbc
MD5: b1729716baaea01d4baa795db31800b0
SHA1: b7143367d71932ad525c5db94f5295686e6c58e5
CRC32: 12fc1a6e
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --