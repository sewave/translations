Terminator 2 - Judgment Day
Traducci�n al Espa�ol v1.0 (22/10/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Terminator 2 - Judgment Day
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Terminator 2 - Judgment Day
-----------------
Plataformas/accion absado en la pelicula.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Terminator 2 - Judgment Day (U) [!].nes
262.160	bytes
CRC32: c0b4bce5
MD5: 7e7edbc2801aefb931f4cefc638383a7
SHA1: 26a9230f97fffd39d8d43538dfb0195bfd38377b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --