Gunfighter (ZX Spectrum)
Traducción al Español v1.0 (04/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gunfighter.tzx
MD5: ebf190b3fb4c7c275d4436f9b2561d5e
SHA1: 489a5b3950f5240512e1d7622e0808d36f6a5cda
CRC32: 1318ce24
55211 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --