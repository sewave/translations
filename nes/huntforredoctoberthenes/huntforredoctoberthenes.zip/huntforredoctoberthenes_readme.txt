The Hunt for Red October (NES)
Traducción al Español v1.0 (29/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hunt for Red October, The (U) (REV1) [!].nes
MD5: 6b2c9e0554fcc30f3ef2dcb0bda0bd26
SHA1: 3108e9afd20b5407509a8ceca32f91495080b1da
CRC32: 64e47ba8
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --