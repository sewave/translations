Space Rider Jet Pack Co (ZX Spectrum)
Traducción al Español v1.0 (16/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Space Rider Jet Pack Co..tzx
MD5: eb3522897ac86b9493bbdcf4a6126c81
SHA1: 94ef207a147d6b536543beb4a3292fb9a3a09faa
CRC32: 6f625b04
47648 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --