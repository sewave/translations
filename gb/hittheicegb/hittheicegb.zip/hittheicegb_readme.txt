Hit the Ice - VHL - The Official Video Hockey League (Game Boy)
Traducción al Español v1.0 (07/12/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Faltan algunos textos que son gráficos comprimidos.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hit the Ice - VHL - The Official Video Hockey League (USA, Europe).gb
MD5: 66fc892b9682e8e2981fa83fa681ccad
SHA1: f1631e0a97fd60a285feba1b2fc9082bca3be829
CRC32: 2c77f399
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --