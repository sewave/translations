Tarzan - Lord of the Jungle (Game Gear)
Traducción al Español v1.0 (27/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tarzan - Lord of the Jungle (Europe).gg
MD5: d4a4bfd64544c362cc0212ce5e404331
SHA1: a787db71f221c71a89f39c6c3a153c43d6d5555a
CRC32: ef3afe8b
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --