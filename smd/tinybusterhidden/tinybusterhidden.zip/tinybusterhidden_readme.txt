Tiny Toon Adventures - Buster's Hidden Treasure
Traducci�n al Espa�ol v1.1 (14/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Tiny Toon Adventures - Buster's Hidden Treasure
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Tiny Toon Adventures - Buster's Hidden Treasure
-----------------
Plataformas de los Tiny Toons protagonizado por Buster Bunny.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1: Arreglado cient�fica por cient�fico.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Algunos textos son sprites y no est�n traducidos.
Si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Tiny Toon Adventures - Buster's Hidden Treasure (U) [!].bin
524.288	bytes
CRC32: a26d3ae0
MD5: 4831cb1b067887a086467ec51653af48
SHA1: d8d159c7c5a365242f989cc3aad2352fb27e3af3

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --