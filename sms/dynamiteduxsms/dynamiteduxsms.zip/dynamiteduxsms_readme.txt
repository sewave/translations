Dynamite Dux (Master System)
Traducción al Español v1.0 (25/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dynamite Dux (Europe, Brazil).sms
MD5: 5cb7ebaee5952ebfcdc42e7093072063
SHA1: 2a513aef0f0bdcdf4aaa71e7b26a15ce686db765
CRC32: 0e1cc1e0
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --