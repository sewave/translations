Tempo (Mega Drive 32X)
Traducción al Español v1.0 (28/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tempo (Japan, USA).32x
MD5: 30989c83d4e4ea3c35a1f3e2620b8465
SHA1: 6673ba83570b4f2c1b4a22415a56594c3cc6c6a9
CRC32: 14e5c575
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --