Ecco the Dolphin - Tides of Time (Master System)
Traducci�n al Espa�ol v1.0 (30/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ecco the Dolphin - Tides of Time (B).sms
MD5: fe58b4b23d58386cad7111fd522cbf75
SHA1: 61cef405e5bc71f1a603881c025bc245a8d14be4
CRC32: 7c28703a
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --