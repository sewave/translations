Dream Fighter (NES)
Traducción al Español v1.0 (08/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dream Fighter (Unl).nes
MD5: 8236a1eb65df3ca413641f33b0e420f1
SHA1: 5b1d313f9c449fb7b403a8a48495289f821593d7
CRC32: 44a66e8a
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --