Incredible Hulk, The
Traducci�n al Espa�ol v1.0 (23/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Incredible Hulk, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Incredible Hulk, The
-----------------
Versi�n sobremesa 8 bits del incre�ble Hulk.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Incredible Hulk, The (E) [!].sms
524.288	bytes
CRC32: be9a7071
MD5: 285d996c1d7dbf38458df61c28bbaa01
SHA1: 235ad7d259023610d8aa59d066aaf0dba2ff8138

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --