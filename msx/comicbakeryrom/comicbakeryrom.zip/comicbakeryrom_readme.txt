Comic Bakery (MSX)
Traducción al Español v1.0 (19/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Comic Bakery (1984) (Konami) (J).rom
MD5: df0af27c7fda4d2992a12ff1bd287f01
SHA1: fc327d3946366ca75de0d0619eb0917a27e1bd61
CRC32: a4097e41
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --