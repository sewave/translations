Alex Kidd in High Tech World
Traducci�n al Espa�ol v1.0 (10/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Alex Kidd in High Tech World
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alex Kidd in High Tech World
-----------------
Una nueva aventura de Alex Kidd mezcla de exploracion y plataformeo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alex Kidd in High Tech World (UE) [!].sms
131.072	bytes
CRC32: 013c0a94
MD5: 0f6ebfa2b24bb99dbea1142312fd33c9
SHA1: 2d0a581da1c787b1407fb1cfefd0571e37899978

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --