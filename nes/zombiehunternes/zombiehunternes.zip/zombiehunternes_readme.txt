Zombie Hunter (NES)
Traducción al Español v1.0 (28/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la traducción de KingMike's Translations.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zombie Hunter (Japan).nes
MD5: adc42539a052110af3dba31b94330574
SHA1: 087bce6f9d3be307b973ce050681cefa9d97449d
CRC32: cc5a32d5
163856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --