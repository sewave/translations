Rollergames
Traducci�n al Espa�ol v1.0 (15/03/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Rollergames
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Rollergames
-----------------
Curioso beat em up/carreras que sac� Konami.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Rollergames (U) [!].nes
262.160	bytes
CRC32: 80da9f53
MD5: b15ab11d5f8a5b4f76f47e252d05fb3c
SHA1: e2db0b04b75f19226c9d524d422143318141710a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --