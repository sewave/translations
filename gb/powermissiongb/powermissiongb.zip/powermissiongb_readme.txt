Power Mission (Game Boy)
Traducción al Español v1.0 (02/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Power Mission (USA).gb
MD5: 3c8dfc25fd8d2691cfe1cb2c375e097c
SHA1: 7eb044e49c370c8e85619cfe42a5b4fb41cbcf17
CRC32: 46cb2f33
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --