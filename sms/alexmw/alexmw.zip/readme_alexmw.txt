Alex Kidd in Miracle World
Traducci�n al Espa�ol v1.0 (26/10/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Alex Kidd in Miracle World
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alex Kidd in Miracle World
-----------------
Clasico juego de master system, que decir.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alex Kidd in Miracle World (UE) (V1.1) [!].sms
131.072	bytes
CRC32: aed9aac4
MD5: f43e74ffec58ddf62f0b8667d31f22c0
SHA1: 6d052e0cca3f2712434efd856f733c03011be41c

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --