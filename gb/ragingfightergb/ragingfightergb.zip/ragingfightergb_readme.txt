Raging Fighter (Game Boy)
Traducción al Español v1.0 (12/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Raging Fighter (USA, Europe).gb
MD5: 1752014c81020e4dbce44c47c301daf9
SHA1: 3e9ae5693208b8c377792c0fb67d682c6158b14d
CRC32: 1ef3bedb
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --