Star Voyager (NES)
Traducción al Español v1.0 (05/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Star Voyager (USA).nes
MD5: 9caefc42032f64f24898410cb6da9e0b
SHA1: 989c8dbb28a109ffbe87ccc830c0bdb72239daa7
CRC32: 686d4669
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --