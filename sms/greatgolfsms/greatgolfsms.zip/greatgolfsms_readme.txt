Great Golf (Master System)
Traducción al Español v1.0 (29/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Great Golf (JUE) [!].sms
MD5: 763580f2af57ea7baddf671fb51787da
SHA1: 3c0b12cfb70f2515429b6e88e0753d69dbb907ab
CRC32: 98e4ae4a
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --