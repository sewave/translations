Vector Ball (ZX Spectrum)
Traducción al Español v1.0 (19/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Vector Ball.tzx
MD5: e5ac092a2f04c24b29a0d0f66d11ded3
SHA1: dc0b5b4c571fdefc4e678ba6dcfc1f016d2df2f0
CRC32: 42c5cb62
46881 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --