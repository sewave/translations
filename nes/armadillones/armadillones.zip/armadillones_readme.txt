Armadillo (NES)
Traducción al Español v2.1 (14/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basada en la traducción de Vice Translations.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Pantalla de título totalmente traducida.
-Barra de estado traducida.
-INICIO-CLEAR traducido.
-Revisión del script.

V2.1:
-Sustituido Tejas por Texas.
-Cambiado Coge por Toma.
-Arreglado ¡ en intro del avión.
-Arreglada intro con "Escondite" mayúscula.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Armadillo (Japan).nes
MD5: 0e75b6acb92fe3925db58941e4983ffe
SHA1: 6d5fb990109f37bc320dff37eb60d06156d7d195
CRC32: ae73e0c2
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --