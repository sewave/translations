Rampage (Master System)
Traducción al Español v1.0 (21/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rampage (USA, Europe).sms
MD5: 54ee884bc658dbad88eac18e45e0eafc
SHA1: cbf5b6f06bec42db8a99c7b9c00118521aded858
CRC32: 42fc47ee
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --