Mighty Final Fight
Traducci�n al Espa�ol v1.0 (06/10/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Mighty Final Fight
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mighty Final Fight
-----------------
Entretenido beat em up parodia del final fight.
Este parche lo traduce completamente al espa�ol y a�ade minusculas y caracteres especiales.
Lo unico no traducido es: PLAYER, ENEMY, PL y el SELECT PLAYER

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mighty Final Fight (U) [!].nes
262.160	bytes
CRC32: 15eb0bee
MD5: 1355eccce09d3e9554ff9120387f64b0
SHA1: 1bb410bc457694fe3109791b6be8f75bf157b8c8

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --