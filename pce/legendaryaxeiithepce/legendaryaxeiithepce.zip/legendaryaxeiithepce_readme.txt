The Legendary Axe II (PC Engine)
Traducci�n al Espa�ol v1.0 (16/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Legendary Axe II, The (USA).pce
MD5: fbcbb34f678f6f70795bde96d295bc2f
SHA1: 3d537fbd2a7181639d297b829ce3f7d7556e831b
CRC32: 220ebf91
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --