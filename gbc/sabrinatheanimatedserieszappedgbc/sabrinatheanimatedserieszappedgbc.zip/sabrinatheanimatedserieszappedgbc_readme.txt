Sabrina - The Animated Series - Zapped! (Game Boy Color)
Traducción al Español v1.0 (22/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sabrina - The Animated Series - Zapped! (USA, Europe).gbc
MD5: ec39462e39e3cbcabe03667fabf12d5a
SHA1: 099e2ec855f47344f5d188cc57f540c88cdb33fd
CRC32: 5d39a9b0
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --