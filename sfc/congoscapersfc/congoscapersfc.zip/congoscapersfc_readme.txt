Congo's Caper (Super Nintendo)
Traducción al Español v1.0 (16/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Congo's Caper (USA).sfc
MD5: 9aea023fde7fb213c95480d6212265d6
SHA1: 7edddd098160d3f398ab54b0a587a7cc5ad98ae1
CRC32: 8a24fba8
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --