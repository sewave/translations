Rush'n Attack
Traducci�n al Espa�ol v1.0 (29/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Rush'n Attack
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Rush'n Attack
-----------------
Port del arcade cl�sico.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Rush'n Attack (U) [!].nes
131.088	bytes
CRC32: ed2c6a3b
MD5: 332c8c5202d4195a567d831f1197c563
SHA1: 0ad3979ba3c7696166fb60b0461f4409da653303

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --