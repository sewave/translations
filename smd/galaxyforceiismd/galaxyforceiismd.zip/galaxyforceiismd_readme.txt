Galaxy Force II (Mega Drive)
Traducción al Español v1.0 (29/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Galaxy Force II (W) (REV01) [!].gen
MD5: 9fa0649fcb53963a432812254ccb4f02
SHA1: db1615fc239cb0ed9fdc792217964c33e1e700fc
CRC32: d15f5c3c
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --