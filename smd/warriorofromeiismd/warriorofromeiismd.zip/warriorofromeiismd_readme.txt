Warrior of Rome II (Mega Drive)
Traducción al Español v1.0 (25/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Warrior of Rome II (USA).md
MD5: 8ab12498223286f3a4e519ce34f93e49
SHA1: fe4e3684212f1e695bdf4a4c41999fac773259f4
CRC32: cd8c472a
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --