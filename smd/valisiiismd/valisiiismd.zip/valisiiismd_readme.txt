Valis III
Traducci�n al Espa�ol v1.1 (18/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Valis III
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Valis III
-----------------
Tercera parte de la saga de acci�n Valis, con cinem�ticas estilo anime.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Valis III (U) [!].bin
1.048.576 bytes
CRC32: 59a2a368
MD5: a50202da29099f2c9d8b1c629653a718
SHA1: bb051779d6c4c68a8a4571177990f7d190696b4a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --