Bubsy in Claws Encounters of the Furred Kind (Mega Drive)
Traducci�n al Espa�ol v1.0 (17/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bubsy in Claws Encounters of the Furred Kind (UE) [!].bin
MD5: a603f331d2d8700543a67c60342e38f7
SHA1: 719140754763e5062947ef9e76ee748cfad38202
CRC32: 3e30d365
2097152 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --