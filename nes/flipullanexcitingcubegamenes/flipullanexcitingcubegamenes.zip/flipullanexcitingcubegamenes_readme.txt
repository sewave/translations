Flipull - An Exciting Cube Game (NES)
Traducción al Español v1.0 (26/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Flipull - An Exciting Cube Game (J).nes
MD5: 188da5261fb98fe427d7da9cc9def8c5
SHA1: bd6be9647749fb7dfe7760d557e94df605cd3c1f
CRC32: 5858ed71
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --