The Chessmaster (Game Boy)
Traducción al Español v1.0 (13/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chessmaster, The (UE) (V1.1) [!].gb
MD5: 6b6d4a25d3c1e2890b22271c44e62dbf
SHA1: f0351faab8b912967552684d4160f5cf94540d41
CRC32: 59ed370c
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --