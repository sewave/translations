Home Alone (Game Gear)
Traducción al Español v1.1 (03/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Traducidas frases al terminar una casa.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Home Alone (USA, Europe).gg
MD5: 8747c4cc07059d97bc597c5eb757cbd9
SHA1: abad566f587affcb35102ed5b45c4e3a8ee22dc9
CRC32: dde29f74
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --