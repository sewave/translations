Streets of Rage 2 (Mega Drive)
Traducción al Español v2.0 (26/10/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres españoles
-Textos retraducidos
-Traducido gráfico TIME

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Streets of Rage 2 (USA).md
MD5: cb75d5a6919b61efe917bea5762c1cb7
SHA1: 8b656eec9692d88bbbb84787142aa732b44ce0be
CRC32: e01fa526
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --