Tinhead
Traducci�n al Espa�ol v1.0 (01/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Tinhead
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Tinhead
-----------------
R�pido plataformas para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Tinhead (U) [!].gen
1.048.576 bytes
CRC32: d6724b84
MD5: 18763de130d8fa52a8dabbcafa8e7185
SHA1: e5acf758e76c95017a6ad50ab0f6ae2db5c9e8bc

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --