Crue Ball - Heavy Metal Pinball (Mega Drive)
Traducción al Español v1.0 (06/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Crue Ball - Heavy Metal Pinball (USA, Europe).md
MD5: d062b85cbbd54f57de313d09e5c0bfec
SHA1: f0c62f1beb4126d1d1d1b634d11fcd81f2723704
CRC32: 4b195fc0
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --