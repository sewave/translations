Salamander
Traducci�n al Espa�ol v1.0 (24/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Salamander
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Salamander
-----------------
Gran shooter de pc engine.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Salamander (J).pce
262.144	bytes
CRC32: faecce20
MD5: 3c60a87ef4f90b20e149330e26253f4d
SHA1: a24e3a4ff36ec9fffd5ea1f4c6b526f61f842584

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --