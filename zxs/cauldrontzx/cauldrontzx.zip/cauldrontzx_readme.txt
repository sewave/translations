Cauldron (ZX Spectrum)
Traducción al Español v1.0 (26/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cauldron.tzx
MD5: 7dde43cf1779dc6de14841f6602067e0
SHA1: bb87fabe0d7220c3d5077901ab363001d3ba0b77
CRC32: 55153ec7
48478 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --