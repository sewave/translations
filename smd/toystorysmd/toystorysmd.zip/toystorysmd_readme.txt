Toy Story
Traducci�n al Espa�ol v1.1 (25/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Toy Story
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Toy Story
-----------------
Adaptaci�n de la pel�cula de Pixar para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1.: Traducido se�or patata y 2 fallos en bonus y cr�ditos.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Toy Story (U) [!].bin
4.194.304 bytes
CRC32: 829fe313
MD5: 23dc9770c2044a05c7351cf83a139d74
SHA1: 49be571cd943fd594949c318a0bdbe6263fdd512

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --