The Simpsons - Night of the Living Treehouse of Horror (Game Boy Color)
Traducción al Español v1.0 (31/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Simpsons, The - Night of the Living Treehouse of Horror (USA, Europe).gbc
MD5: 2a4f3309fe05b47a98d8c5b4c81b91e5
SHA1: a5be079336e48552e53706f0380f35829d91b3c0
CRC32: ebaf4888
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --