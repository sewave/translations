Mercenary Force (Game Boy)
Traducción al Español v1.0 (11/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mercenary Force (UE) [!].gb
MD5: bf3d90ff1c8d4827b5657d7b15d84fde
SHA1: 35bbde8934792588620d1c242dedef1da9097a2e
CRC32: 9bb5ba03
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --