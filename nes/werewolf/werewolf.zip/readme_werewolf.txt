Werewolf
Traducci�n al Espa�ol v1.0 (11/09/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Werewolf
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Werewolf
-----------------
Un plataformas MUY dificil de data east.
Este parche lo traduce completamente al espa�ol.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es original no a�ade caracteres especiales.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Werewolf - The Last Warrior (U) [!].nes
262.160 bytes
CRC32: 19af4032
MD5: 19ad8f9c1e6ac449e3ac82e33bda7b2f	
SHA1: 8580b3deeddfa75c12dfe2f6cab8d062e52fdb34

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al Espa�ol

-- END OF README --