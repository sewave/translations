War Games (Colecovision)
Traducción al Español v1.0 (27/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
War Games (1983-84).col
MD5: a2b0ccd7ea648c3e5f3f750e9254f972
SHA1: 48828f603e65178c0feda275d6b3a11aff688eae
CRC32: 6e0150c1
24576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --