Sonic The Hedgehog (Master System)
Traducci�n al Espa�ol v1.0 (19/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sonic The Hedgehog (UE) [!].sms
MD5: dc13a61eafe75c13c15b5ece419ac57b
SHA1: 6b9677e4a9abb37765d6db4658f4324251807e07
CRC32: b519e833
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --