Bubble and Squeak (Mega Drive)
Traducción al Español v1.0 (18/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bubble and Squeak (U) [!].bin
MD5: 316c4eec04d89235978d17d06da33bba
SHA1: 0457b0220c86f58d8249cbd5987f63c5439d460c
CRC32: 28c4a006
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --