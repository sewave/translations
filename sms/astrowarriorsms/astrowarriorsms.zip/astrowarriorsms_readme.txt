Astro Warrior (Master System)
Traducci�n al Espa�ol v1.0 (10/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Astro Warrior (U) [!].sms
MD5: e645faa5628caab5129383fdbf4df090
SHA1: 901697a3535ad70190647f34ad5b30b695d54542
CRC32: 299cbb74
131072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --