Arkanoid 2 (MSX)
Traducción al Español v1.0 (13/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Arkanoid 2 (1987) (Taito) (J).rom
MD5: 2d594d9ebfb36faba7eea3c6b4e55dc8
SHA1: 1642891b693df616f27431299352e1d7750ac94b
CRC32: 00d36af6
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --