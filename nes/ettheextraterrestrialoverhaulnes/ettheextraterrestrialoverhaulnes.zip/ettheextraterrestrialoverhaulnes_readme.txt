E.T. - The Extra Terrestrial (Overhaul) (NES)
Traducción al Español v1.0 (21/12/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
E.T. - The Extra Terrestrial (USA) (Digital Release) (Aftermarket) (Unl).nes
MD5: 3c0cafca7495d3d72c18355fab75eebd
SHA1: e89e357408745059f7ced0848bdc3f762e43df87
CRC32: 8152a8f4
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --