DUET (ZX Spectrum)
Traducción al Español v1.0 (24/02/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
DUET.TZX
MD5: 9432a036dd2c71b820b4eb8e84872946
SHA1: 7ea1e09ded039e831a2d2f7875584631888fcd33
CRC32: 5acd6c49
46949 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --