Smart Ball (Super Nintendo)
Traducción al Español v1.0 (21/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Smart Ball (USA).sfc
MD5: e2b833084a3016313b61e113828f0b18
SHA1: 14fc687b5a8437ec0b3515c4d46aed579a8ef58b
CRC32: 3cfe77ab
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --