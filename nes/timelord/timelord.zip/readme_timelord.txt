Time Lord
Traducci�n al Espa�ol v1.0 (29/01/2016)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Time Lord
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Time Lord
-----------------
Accion plataformas en el que viajamos en el tiempo apra vencer a unos aliens.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Falta alguna cadena a traducir, como en las puntuaciones.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Time Lord (U) [!].nes
131.088	bytes
CRC32: e37ad9fb
MD5: 164139a2ef88ac4a0ee3d26a67396129
SHA1: e9061ddcd4d25d8e0f46b4c0a7dc8f81b3420d3b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --