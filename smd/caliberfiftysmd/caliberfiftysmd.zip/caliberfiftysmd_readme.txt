Caliber Fifty (Mega Drive)
Traducci�n al Espa�ol v1.1 (23/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
v1.1: Arreglados 29 a�os.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Caliber Fifty (U) [!].bin
MD5: 71a8c01301fe029f01f2f0b17f94d414
SHA1: a68f3b9350a3a05850c17d157b56de88556cd26a
CRC32: 44f4fa05
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --