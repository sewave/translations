Streets of Rage II
Traducci�n al Espa�ol v1.0 (11/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Streets of Rage II
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Streets of Rage II
-----------------
El clasico beat em up de sega adaptado a la portatil, muy conseguido.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Streets of Rage II (U) [!].gg
524.288	bytes
CRC32: 0b618409
MD5: 5566e332f860dc0f9da1507fd7feb1cd
SHA1: 2804b355347bda6e2903078ba30ed6b3a289ebba

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --