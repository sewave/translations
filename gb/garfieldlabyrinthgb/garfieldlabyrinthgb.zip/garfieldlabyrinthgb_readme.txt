Garfield Labyrinth (Game Boy)
Traducción al Español v1.0 (18/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Garfield Labyrinth (U).gb
MD5: 5e441af514d1bcdaec08c133ceea4e5e
SHA1: 106b0b65fe06ed352de34c9bf640c3e024d8c0e5
CRC32: 6a043abd
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --