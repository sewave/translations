Pitfall - The Mayan Adventure (Super Nintendo)
Traducción al Español v1.0 (09/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pitfall - The Mayan Adventure (USA).sfc
MD5: 02cae4c360567cd228e4dc951be6cb85
SHA1: b8e36f4afdfc0040dcde346291e1ce46d8718667
CRC32: 03e67d38
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --