Sweet Home
Traducci�n al Espa�ol v1.1 (20/06/2019)
(C) 2019 Wave Translations

---
TdC
---

1. Sobre Sweet Home
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Sweet Home
-----------------
Terror�fico rpg, precursor de resident evil.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basado en la traducci�n de JMN y The Siege.
V1.1: Arreglada la pantalla de game over gracias a Jackic.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Sweet Home (J) [!].nes
262.160	bytes
CRC32: 40803bc5
MD5: 49dd966e8a0e17bae16bc3d393c9d742
SHA1: 54bfe479c12247e8b9996c6c5f331977035e1276

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
Jackic - Ayuda con el arreglo de la pantalla de game over

Original:
JMN y The Siege - Hacking y traducci�n

-- END OF README --