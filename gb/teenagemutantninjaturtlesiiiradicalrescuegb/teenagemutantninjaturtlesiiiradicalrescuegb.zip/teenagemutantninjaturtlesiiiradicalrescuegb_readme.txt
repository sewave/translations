Teenage Mutant Ninja Turtles III - Radical Rescue (Game Boy)
Traducción al Español v2.0 (29/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Modificados acentos
-Cambiado PASSWORD por CLAVE
-Cambiado GAME OVER por FIN JUEGO
-Textos reajustados
-Añadidos gráficos para "MAPA"

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles III - Radical Rescue (USA).gb
MD5: e6104df1feb1318ff1764c791eb4ce0e
SHA1: 29f5de9e4c0f21bf8bffc721dacf1790446a5923
CRC32: 58832bbc
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --