Ballblazer (NES)
Traducción al Español v1.0 (05/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ballblazer (Japan).nes
MD5: a206136cd768926e9ce1e6cce5f1942c
SHA1: 34f0578113cdcd05a023a39207aad154e8544f8c
CRC32: 7b43b3ef
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --