Super Dyna'mix Badminton (NES)
Traducción al Español v1.0 (17/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Dyna'mix Badminton (J) [b1][o2].nes
MD5: 4888fcab368de614f4374c2c943073c7
SHA1: 5dfd1c7587724f51c049154e31fbd801674da194
CRC32: 435f0022
49168 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --