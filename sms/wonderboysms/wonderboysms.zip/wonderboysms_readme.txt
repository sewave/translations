Wonder Boy (Master System)
Traducci�n al Espa�ol v1.0 (19/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wonder Boy (UE) [!].sms
MD5: 7e805aa51bfb5f206c950a32ebcdab7c
SHA1: 63149f20bf69cd2f24d0e58841fcfcdace972f49
CRC32: 73705c02
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --