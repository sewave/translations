Choujin Sentai Jetman (NES)
Traducción al Español v1.0 (01/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de chronix.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Choujin Sentai Jetman (Japan).nes
MD5: 07db9592063fe3dce850ccc7c340cfd1
SHA1: 6613725b975b45eb77aac81c0d20f8cda58bba81
CRC32: f899bf59
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --