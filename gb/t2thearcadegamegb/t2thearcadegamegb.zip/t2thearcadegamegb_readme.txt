T2 - The Arcade Game (Game Boy)
Traducción al Español v1.0 (14/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
T2 - The Arcade Game (U) [!].gb
MD5: 43e26f216d50106a8fccbcc04cda0c29
SHA1: a362a05b2616bca1375d3f4f979d12bdb9bca53a
CRC32: 00f09c7f
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --