Home Alone 2 (Game Boy)
Traducción al Español v1.0 (17/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Home Alone 2 (U) [!].gb
MD5: 0611b365116b22c1aaa7e3ce4faed5ed
SHA1: 853e6f96bcba40bc4cfa72898b02aebc3f9d9498
CRC32: e8e430f1
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --