Chaos (ZX Spectrum)
Traducción al Español v1.0 (11/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chaos.tzx
MD5: f61bd03f575b8cc078e07105fd52b158
SHA1: c63f3796408674c37caf9805faff27c970d118fc
CRC32: dce3ee5b
41672 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --