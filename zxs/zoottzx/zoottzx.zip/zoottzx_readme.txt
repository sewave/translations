Zoot (ZX Spectrum)
Traducción al Español v1.0 (25/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zoot.tzx
MD5: c23cf9cdd0f08e47470737e72fb2ce97
SHA1: da74e6790ec1dd6660a64bd412572bf2de2e6700
CRC32: d6296c29
49579 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --