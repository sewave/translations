Cutthroat Island (Super Nintendo)
Traducción al Español v1.0 (22/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cutthroat Island (U) [!].smc
MD5: 669f9147ab96a16f07e93ca9f18ef779
SHA1: 40965e6c9d6aec698b7a0d3106241fef7f2e6ee8
CRC32: 19ea457b
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --