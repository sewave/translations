Addams Family, The
Traducci�n al Espa�ol v1.0 (09/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Addams Family, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Addams Family, The
-----------------
Plataformas basado en la pelicula, identico a su hermano mayor de master system.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Addams Family, The (U) [!].gg
262.160	bytes
CRC32: 1d01f999
MD5: f4f3211738002369b9ada7a099e33a45
SHA1: 3231d574e5eb0ac3a77b1d65d74f3a581819a9c7

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --