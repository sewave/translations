Hyper V-Ball (Super Nintendo)
Traducción al Español v1.0 (20/04/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Faltan algunos textos de creación de equipo, ya que son con gráficos y comprimidos.
Faltan textos en el título ya que es una pantalla comprimida.
Faltan textos al cambiar jugadores, ya que son con gráficos y comprimidos.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hyper V-Ball (USA).sfc
MD5: 5ef625d117e1359d055b2c82630cf52c
SHA1: c132aff55c61451dfb1498d43db64866486734f3
CRC32: 7d179e21
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --