Konami Hyper Soccer (NES)
Traducción al Español v1.0 (01/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Konami Hyper Soccer (Europe).nes
MD5: caf629530fcb9b76bb5751befa02e71c
SHA1: 1cc3e9d52c59599feb4b8f8243046d132967b815
CRC32: 144435af
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --