Onslaught (Mega Drive)
Traducción al Español v1.0 (29/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Onslaught (U) [c][!].bin
MD5: 455e836ca5dd9cb782e7455e584cf65a
SHA1: dc542ddfa878f2aed3a7fcedc4b0f8d503eb5d70
CRC32: 9f19d6df
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --