Stanley - The Search for Dr. Livingston
Traducci�n al Espa�ol v1.01 (19/09/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Stanley - The Search for Dr. Livingston
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Stanley - The Search for Dr. Livingston
-----------------
Stanley es un juego de exploraci�n MUY dif�cil, me recuerda a los cl�sicos de spectrum.
Este parche lo traduce completamente al espa�ol, a�ade la � y traduce algunos gr�ficos.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
No se han a�adido acentos ya que no hay espacio en los tiles de las letras.
v1.01 Corregida errata en texto

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Stanley - The Search for Dr. Livingston (U) [!].nes
262.160 bytes
CRC32: 4871ef6e
MD5: 3adb47fc672ec1092e11d76f0b188bce
SHA1: 33050727ddc8796bcbbb9c00ec3735e2faca48dd

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --