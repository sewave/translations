Rise of the Robots (Mega Drive)
Traducción al Español v1.0 (21/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rise of the Robots (E) [!].bin
MD5: e553d4ce75f106fbd75cf38a039566a3
SHA1: 646bf23a13a4c2ad249ca3cc58ff3cd3244e5dff
CRC32: 5650780b
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --