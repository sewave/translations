Superman - The Man of Steel (Mega Drive)
Traducción al Español v1.0 (28/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Superman - The Man of Steel (Europe).md
MD5: 6e3f8fa3e7e3d1d42283f2561fecf152
SHA1: c956730af44b737ee3d0c1e83c147f32e3504383
CRC32: 7db434ba
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --