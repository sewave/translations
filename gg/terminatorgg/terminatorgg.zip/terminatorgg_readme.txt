Terminator, The
Traducci�n al Espa�ol v1.0 (24/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Terminator, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Terminator, The
-----------------
Adaptacion de la pelicula para game gear.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Terminator, The (U) [!].gg
262.144	bytes
CRC32: c029a5fd
MD5: b9190f130f728ba8c05d82d5f01fde21
SHA1: 1889d019bd9f5919517805a2e02a9691de5ef634

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --