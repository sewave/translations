One-on-One (Colecovision)
Traducción al Español v1.0 (15/02/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Julius Erving and Larry Bird Go - One-on-One (USA).col
MD5: 0b70e3e59f72137a4a017f3761b24ff7
SHA1: 2c59bcd829c97948b88b45f447c4c57870d6bd77
CRC32: ef50e1c5
24576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --