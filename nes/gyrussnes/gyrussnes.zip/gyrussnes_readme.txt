Gyruss (NES)
Traducción al Español v1.0 (28/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gyruss (USA).nes
MD5: 1768b7c6dceb3a6e55b548e1e8da1ca8
SHA1: 704721c0b1209cb2bae8ac1c22f2d3bc3fd53edb
CRC32: 526ad690
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --