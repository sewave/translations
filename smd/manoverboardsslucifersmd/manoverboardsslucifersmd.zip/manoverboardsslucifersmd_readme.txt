Man Overboard! - S (Mega Drive)
Traducci�n al Espa�ol v1.0 (08/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Man Overboard! - S.S. Lucifer (E) [c][!].bin
MD5: ae6c1618e6f98d3101b1b91d3835ebac
SHA1: 36c66a1cbf44f4019b84538a6bf452c369239bc9
CRC32: cae0e3a6
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --