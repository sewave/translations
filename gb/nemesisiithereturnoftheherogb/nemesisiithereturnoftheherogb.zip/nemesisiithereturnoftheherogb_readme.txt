Nemesis II - The Return of the Hero (Game Boy)
Traducción al Español v1.0 (24/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nemesis II - The Return of the Hero (E) [!].gb
MD5: ba760b6d4b96baf0fa2e7ad6e4498a95
SHA1: ee59da08c23102ab99a28c5da9ceaf222e7fb461
CRC32: c3e62a35
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --