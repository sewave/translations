Gley Lancer
Traducci�n al Espa�ol v1.0 (21/05/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Gley Lancer
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Gley Lancer
-----------------
Gran shoot em up que solo salio en japon.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basado en la traducci�n de MIJET.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Gley Lancer (J) [!].gen
1.048.576 bytes
CRC32: 42cf9b5b
MD5: 8bd4a97783cda077c342173df0a9b51e
SHA1: 529d88f96eb7082bfbc00be3f42a1b2e365c34b7

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

---Original English Translation
M.I.J.E.T. - Full Hacking & Translation to english

-- END OF README --