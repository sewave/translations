Aladdin
Traducci�n al Espa�ol v1.0 (31/10/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Aladdin
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Aladdin
-----------------
Que decir, gran plataformas basado en la pelicula de disney para master system.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Aladdin (E) [!].sms
524.288	bytes
CRC32: c8718d40
MD5: e3f60072028eb6f02c2b0558804aed83
SHA1: 585967f400473e289cda611e7686ae98ae43172e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --