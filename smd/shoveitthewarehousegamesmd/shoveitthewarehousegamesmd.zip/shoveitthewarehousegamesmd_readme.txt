Shove It! ...The Warehouse Game (Mega Drive)
Traducción al Español v1.0 (18/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shove It! ...The Warehouse Game (USA).md
MD5: 2c6a960f66d1c87855424e6528d6eac6
SHA1: e4094c5a575f8d7325e7ec7425ecf022a6bf434e
CRC32: c51f40cb
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --