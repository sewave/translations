Double Dragon Remastered (NES)
Traducción al Español v1.0 (09/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
Aplicar a la rom con el hack "Double Dragon Remastered"

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Dragon Remastered (USA).nes
MD5: eb383fc983505f6dcef761fadbbd0703
SHA1: cb5de2fadce02dc74fd6b8e9a7b20fb30451f705
CRC32: c88c1b44
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --