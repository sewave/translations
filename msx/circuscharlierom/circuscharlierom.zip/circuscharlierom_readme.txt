Circus Charlie (MSX)
Traducci�n al Espa�ol v1.0 (31/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Circus Charlie (1984) (Konami) (J).rom
MD5: 5995cc6f08fdc9e883ecce34d1398029
SHA1: ae6d0efd55def94274f4cec459df8927d132675a
CRC32: 83b8d8f3
16384 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --