Nether Earth (ZX Spectrum)
Traducción al Español v1.0 (07/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nether Earth.tzx
MD5: b63b464eeab396134594d3952aec7af2
SHA1: 5a08d3cb2a04820ae870615aae188140e5be19a9
CRC32: 27a7707a
49001 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --