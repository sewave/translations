The Adventures of Batman & Robin (Mega Drive)
Traducción al Español v1.0 (19/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Adventures of Batman & Robin, The (USA).md
MD5: 5b1bcb3793262d2d0282b49e0c2ee053
SHA1: 1da4b3fc92a6572e70d748ebad346aeb291f89f3
CRC32: 0caaa4ac
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --