Tail 'Gator (Game Boy)
Traducción al Español v1.0 (21/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tail 'Gator (USA, Europe).gb
MD5: cac94925bf098982d31f7c9a2c296d25
SHA1: ed5f1110a9db4c48d26d53af0973e8b46fe7e4e1
CRC32: c5acce7c
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --