Return of the Ninja (Game Boy Color)
Traducción al Español v1.0 (27/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Return of the Ninja (U) [C][!].gbc
MD5: 178ea5a9eba6e7f35e894bad1ec34f77
SHA1: e33352f0ac19d28983ebed0758d022861473ec0e
CRC32: a07da702
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --