Mr. Do's Wild Ride (MSX)
Traducción al Español v1.0 (11/10/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mr. Do's Wild Ride (Japan).rom
MD5: f2c5eae5e6d01f4a3509dc71e6cac660
SHA1: e9b3652482a5b09ae662203f8758a30aa23af62f
CRC32: 6786a7ee
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --