Earthworm Jim (Game Boy)
Traducci�n al Espa�ol v1.0 (24/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Earthworm Jim (U) [!].gb
262.144 bytes
MD5: 0d24eeff28040ff2a8f63de5bc8cbea2
SHA1: f5d3085de17a5181c07739e49be7637faa5ff932
CRC32: 259ff267

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --