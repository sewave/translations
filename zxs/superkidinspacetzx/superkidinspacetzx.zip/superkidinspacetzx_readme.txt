Superkid In Space (ZX Spectrum)
Traducción al Español v1.0 (29/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Superkid In Space.tzx
MD5: 0ed688596c5922a5b929209cb3ab362b
SHA1: 622db0d33ed80540f3ac3e31bf62501cd6e0c482
CRC32: 5f3a2da4
50580 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --