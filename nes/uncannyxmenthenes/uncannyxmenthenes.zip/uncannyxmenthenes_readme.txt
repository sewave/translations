The Uncanny X-Men (NES)
Traducción al Español v1.0 (21/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Uncanny X-Men, The (U) [!].nes
MD5: 8ae4b4bc41c134b0c35be0ab3b284e8b
SHA1: 73a77854d7139671c51051402661decdc3166fdb
CRC32: 1e483ca6
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --