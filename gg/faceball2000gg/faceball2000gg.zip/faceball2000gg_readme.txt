Faceball 2000 (Game Gear)
Traducción al Español v1.0 (08/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Faceball 2000 (Japan).gg
MD5: 8dcfaa8a12425a56f5de7518b691158b
SHA1: 967c50a5b64adc6da7bc730900c267e45c90053a
CRC32: aaf6f87d
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --