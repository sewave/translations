Sky Shark (NES)
Traducción al Español v1.0 (08/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sky Shark (USA).nes
MD5: 1c93de3697d5ef4b2a10904b2c0e4386
SHA1: dbbfbabfd38f708099e0f88d077f227a2dd9ff67
CRC32: 147e6b6c
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --