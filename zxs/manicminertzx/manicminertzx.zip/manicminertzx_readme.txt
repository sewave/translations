Manic Miner (ZX Spectrum)
Traducción al Español v1.0 (11/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Manic Miner.tzx
MD5: 2750ccb6c240d14516c448e94f8d200e
SHA1: 841b7cc17a858fd9eb6bb4dcddef7ce5b3fe9754
CRC32: f89b74af
33205 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --