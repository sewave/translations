Sword of Sodan (Mega Drive)
Traducción al Español v1.0 (15/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sword of Sodan (UE) [!].bin
MD5: 7b5c722bccce6f5301dd90b6d6b17f01
SHA1: 088b81c3bcda86b9803b7e3f8067beb21d1d2553
CRC32: 9cb8468f
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --