Battle Cross (MSX)
Traducción al Español v1.0 (13/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battle Cross (1984) (Sony) (J).rom
MD5: 916ad37b0ef7dc3a01f5ec52936a52b8
SHA1: 8b63f36be31d7d021c19103ebe8c68b69aae699c
CRC32: 25e675ea
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --