Pinocchio (Super Nintendo)
Traducción al Español v1.0 (12/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pinocchio (USA).sfc
MD5: 085aef23df7c45e5eab8209345ece4ca
SHA1: 31382104e7f6a80ea6bab82314ba74b518ce4b3c
CRC32: 00fad8fd
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --