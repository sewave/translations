Predator 2 (Mega Drive)
Traducción al Español v1.0 (15/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Predator 2 (UE) [!].bin
MD5: 6413bc568d7750b308fe06a3c85e6ec8
SHA1: 0d482bae2922c81c8bc7500a62c396b038978114
CRC32: bdba113e
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --