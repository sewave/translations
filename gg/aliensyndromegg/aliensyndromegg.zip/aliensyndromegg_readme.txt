Alien Syndrome
Traducci�n al Espa�ol v1.0 (10/02/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Alien Syndrome
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alien Syndrome
-----------------
Versi�n para la portatil de sega del arcade.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alien Syndrome (USA, Europe).gg
131.072	bytes
CRC32: bb5e10e0
MD5: 6c29fc1bae1051774e9a83098f55bd4e
SHA1: 112c7fba070eb7b6bdd41675d49caf934c17dc17

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --