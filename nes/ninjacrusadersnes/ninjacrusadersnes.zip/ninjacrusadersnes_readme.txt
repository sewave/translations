Ninja Crusaders (NES)
Traducción al Español v1.1 (19/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Añadidos carácteres especiales, traducida licencia, script revisado.


------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Crusaders (USA).nes
MD5: 894f49a450f8eb6a702e064bab83d117
SHA1: 219e51e8da40024d2f43d4adef941be05e3eb6ed
CRC32: dc84deb0
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --