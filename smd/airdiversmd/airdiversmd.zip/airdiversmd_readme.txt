Air Diver (Mega Drive)
Traducci�n al Espa�ol v1.0 (27/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Air Diver (U) [!].bin
MD5: ac08a4c65e1d8d3b307ebd5331a1c285
SHA1: 0ea311e3ed667d5d8b7ca4fad66f9d069f0bcb77
CRC32: 2041885e
524288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --