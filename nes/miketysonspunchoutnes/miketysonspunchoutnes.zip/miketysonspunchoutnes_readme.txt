Mike Tyson's Punch-Out!! (NES)
Traducci�n al Espa�ol v1.0 (06/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mike Tyson's Punch-Out!! (U) (PRG1) [!].nes
MD5: c119a5a9b0e2959ad5d11562f9f4ce55
SHA1: 0f0c2c2e294ff8ce255a618964728c935fd8963b
CRC32: 3df8e170
262160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --