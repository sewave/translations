Sunman
Traducci�n al Espa�ol v1.0 (29/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Sunman
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Sunman
-----------------
Prototipo de Sunsoft de plataformas, que iba a ser un juego de superman.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Sunman (E) (Prototype).nes
262.160	bytes
CRC32: 2bce4dc7
MD5: 2e828058a1bd96d04ecdd04954e54c30
SHA1: 326e2f4d3be11a9cd8e7a0c8dc345ba9ecc7d1a9

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
Danilo1652 - Testing

-- END OF README --