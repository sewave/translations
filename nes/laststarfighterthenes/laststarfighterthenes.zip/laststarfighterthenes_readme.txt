The Last Starfighter (NES)
Traducción al Español v1.0 (31/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Last Starfighter, The (U) [!].nes
MD5: ab2beafb0c71d58f9b08a0a8c005b254
SHA1: cd7357f1bd15c423e2760f018d3fdd31445da6f8
CRC32: 26bceffd
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --