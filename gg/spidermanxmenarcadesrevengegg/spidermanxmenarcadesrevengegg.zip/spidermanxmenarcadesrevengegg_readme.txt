Spider-Man - X-Men - Arcade's Revenge (Game Gear)
Traducción al Español v1.0 (18/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Comic intro:
Sobre las calles de la ciudad
Spider-Man: ¡Solo espero no llegar demasiado TARDE!
Spider-Man: Primero Cíclope, luego Tormenta y ahora Lobezno...
Spider-Man: ¡¡Gambito!! ¡CUIDADO!
Spider-Man: Conozco ese CAMIÓN
Spider-Man: ...¡¡ARCADE!! TENGO que ir tras ellos
Spider-Man: ¡Las vidas de los X-MEN dependen de mi!

Comic final:
Lobezno: ¡CORRED! ..¡Todo este sitio va a EXPLOTAR!
Spider-Man: ¿Creéis que salió?
Gambito: Puedes contar con ello.
Cíclope: Venga... ¡Vamos a CASA!

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spider-Man - X-Men - Arcade's Revenge (USA).gg
MD5: 912075356cc3bb5bbab641e61d3904d7
SHA1: 4006a23571f194e1fcb3563557decd5d11e7b5c2
CRC32: 742a372b
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --