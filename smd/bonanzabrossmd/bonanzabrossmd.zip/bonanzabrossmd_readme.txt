Bonanza Bros.
Traducci�n al Espa�ol v1.0 (03/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Bonanza Bros.
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Bonanza Bros.
-----------------
Versi�n de Mega Drive del arcade de Sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
No todos los nombres de etapa estan traducidos.
El cartel final de la introduccion tampoco.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Bonanza Bros. (U) [!].gen
524.288	bytes
CRC32: 20d1ad4c
MD5: dc3847b07cd94a15b1b9e0fb2ff5db11
SHA1: 31c589bc0d1605502cdd04069dc4877811e84e58

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --