Shufflepuck Cafe (NES)
Traducción al Español v1.1 (02/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de MadHacker.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Arregladas opciones del robot azul.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shufflepuck Cafe (Japan).nes
MD5: 01c974f67d547578bab518b53e5fa273
SHA1: 8355ddb31223c91087c4a20c28bac25738665957
CRC32: 528af8b0
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --