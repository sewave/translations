Candoo Ninja (MSX)
Traducción al Español v1.0 (12/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Candoo Ninja (1983) (Ascii) (J).rom
MD5: 75ddcb444dc1139678d0848ae902cd3a
SHA1: 69710f4b9cc3440e58c54bd4c562b3e90ff323e0
CRC32: b6ab6786
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --