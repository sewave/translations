Valis
Traducci�n al Espa�ol v1.0 (09/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Valis
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Valis
-----------------
Juego de accion/plataformas con estilo anime, primero de una saga.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Valis (U) [!].bin
1.048.576 bytes
CRC32: 13bc5b72
MD5: da1638baec999b2203ac5e5fec31c744
SHA1: fed29e779aa0d75645a59608f9f3a13f39d43888

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --