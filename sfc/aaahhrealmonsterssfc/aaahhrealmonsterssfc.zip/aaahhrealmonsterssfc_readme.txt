Aaahh!!! Real Monsters (Super Nintendo)
Traducción al Español v1.0 (23/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Aaahh!!! Real Monsters (USA).sfc
MD5: e4e77b581700a6cd58e711ee02b1a61f
SHA1: 7a4452f38c76a1faa50aec790e7e38b069b2471e
CRC32: 27ff5ba1
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --