Mortal Kombat II
Traducci�n al Espa�ol v1.0 (08/05/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Mortal Kombat II
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mortal Kombat II
-----------------
Port del clasico juego de lucha para la sobremesa, muy parecido a la version de game gear.
Algunas cadenas no traducidas, como start o similar.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mortal Kombat 2 (E) [!].sms
524.288	bytes
CRC32: 2663bf18
MD5: c60f62f13a60bc585822bfd2d68ba75c
SHA1: 12bd887efb87f410d3b65bf9e6dfe2745b345539

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --