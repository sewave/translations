Sidewinder II (ZX Spectrum)
Traducción al Español v1.0 (10/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sidewinder II (Mastertronic Plus).tzx
MD5: 7147e95a1f8a8ae4b0892fab14e643cc
SHA1: b5419089b4fa0e4ab33b7e6f74d6b02de2071d0f
CRC32: 0239872c
42425 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --