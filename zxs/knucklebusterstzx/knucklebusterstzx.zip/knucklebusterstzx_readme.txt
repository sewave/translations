Knuckle Busters (ZX Spectrum)
Traducción al Español v1.0 (12/04/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Knuckle Busters.tzx
MD5: 2a896095a9beefe73f3372656526665e
SHA1: 0315ef7db5047b1acc02029b55c31c834b9cfdf4
CRC32: c532d7bd
48153 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --