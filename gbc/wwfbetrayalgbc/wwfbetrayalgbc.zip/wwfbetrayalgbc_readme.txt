WWF Betrayal (Game Boy Color)
Traducción al Español v1.0 (29/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
WWF Betrayal (USA, Europe).gbc
MD5: f270519e6357bc32fd07fc6386e14dec
SHA1: 27773b6396ccb55051227ce7ce81d01c33ea75d1
CRC32: 6c28bcb5
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --