8 Eyes (NES)
Traducción al Español v1.0 (12/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
8 Eyes (U) [!].nes
MD5: 0d3ddb15fb94c7c663062c9bbf804299
SHA1: fddc581f9837c47628fcfba01f258f3318af9641
CRC32: 18f9bb24
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --