Penguin-kun Wars (NES)
Traducción al Español v1.0 (19/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Penguin-kun Wars (Japan).nes
MD5: c390e718059f770ba4b4aa1e5b320fbe
SHA1: 5229238f547f35e52e7e5526c3fc638676a49412
CRC32: e5a58db5
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --