Pocket Bomberman (Game Boy Color)
Traducción al Español v1.0 (26/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pocket Bomberman (USA, Europe) (SGB Enhanced) (GB Compatible).gbc
MD5: 2f6b6379f8c7ce5d66a198162f345eaa
SHA1: b0ae803600e06cd1cc9a0d801f2511c9ecc50584
CRC32: fa2a66e9
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --