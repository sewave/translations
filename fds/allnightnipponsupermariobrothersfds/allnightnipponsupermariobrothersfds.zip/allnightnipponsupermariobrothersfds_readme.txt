All Night Nippon Super Mario Brothers (Famicom Disk System)
Traducción al Español v1.0 (14/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
All Night Nippon Super Mario Brothers (Japan) (Promotion Card).fds
MD5: c8719692d0b9d9649492ffb1c2d26aa3
SHA1: f30bdd3c556604d7eaa6d0f4864d5566e519b5d4
CRC32: 43e7fe95
65500 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --