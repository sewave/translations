Ironsword - Wizards & Warriors II (NES)
Traducción al Español v1.0 (27/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ironsword - Wizards & Warriors II (U) [!].nes
MD5: dd51f1685cb61679cdd4afd3ef887804
SHA1: 97b79e432f62403fb9f877090850c41112a9a168
CRC32: be2e7055
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --