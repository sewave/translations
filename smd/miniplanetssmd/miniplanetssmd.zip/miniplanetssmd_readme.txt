Miniplanets (Mega Drive)
Traducción al Español v1.0 (17/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Miniplanets.bin
MD5: b9d6441165975395b689925ae95ec044
SHA1: 88ccc6781746fb31c1e25b82568ad2a58071ea89
CRC32: 8ea40d2f
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --