The Simpsons - Krusty's Fun House (Game Gear)
Traducción al Español v1.0 (10/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Simpsons, The - Krusty's Fun House (U) [!].gg
MD5: 46be87d97e42dceef816dd7a6ad4d018
SHA1: a24fd153669e0c38d55ff939e1ea52b6a316ad0d
CRC32: d01e784f
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --