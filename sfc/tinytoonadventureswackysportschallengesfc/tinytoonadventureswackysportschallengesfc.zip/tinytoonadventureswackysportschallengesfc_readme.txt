Tiny Toon Adventures - Wacky Sports Challenge (Super Nintendo)
Traducción al Español v1.0 (13/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tiny Toon Adventures - Wacky Sports Challenge (USA).sfc
MD5: 3d946c89e1b62223a505f367babac5da
SHA1: 8443eb248f64511add665f200ea6fb802101039e
CRC32: afe72ff0
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --