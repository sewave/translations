Raster Scan (ZX Spectrum)
Traducción al Español v1.0 (24/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Raster Scan.tzx
MD5: 1ea6d90ab4b3275c4e0045b5144e8ab9
SHA1: 31355f2e8a886c39d017a3fb8fa129425f09476f
CRC32: 0e82b608
42528 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --