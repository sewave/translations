The Combatribes (Super Nintendo)
Traducción al Español v1.0 (25/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Combatribes, The (U).smc
MD5: 9bd5b32d479983dd2c0b49020e812e69
SHA1: 6827e8d9520ffdf05e8ffbeba71355fd32079af2
CRC32: 9304044a
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --