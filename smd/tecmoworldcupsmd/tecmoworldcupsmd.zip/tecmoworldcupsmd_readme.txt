Tecmo World Cup (Mega Drive)
Traducción al Español v1.0 (22/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tecmo World Cup (USA).md
MD5: 246a2c8520d29afa798522fdb332e9fb
SHA1: 53e47c40ac550c334147482610b3465fe9f6a535
CRC32: caf8eb2c
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --