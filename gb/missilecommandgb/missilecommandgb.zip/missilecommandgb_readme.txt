Missile Command (Game Boy)
Traducción al Español v1.0 (15/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Missile Command (U) [M][!].gb
MD5: ff0033ceecd7562360c5d5d3cae76575
SHA1: ed529062ae3d1feb4defbf54c2cc759211e3aeaa
CRC32: 3a6cd4d8
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --