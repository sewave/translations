Cloud Master
Traducci�n al Espa�ol v1.0 (27/04/2017)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Cloud Master
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Cloud Master
-----------------
Port de Master System del shoot em up.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Cloud Master (UE) [!].sms
262.144	bytes
CRC32: e7f62e6d
MD5: 4498afc1fce51ebd461798fbe61aa6f8
SHA1: b936276b272d8361bca8d7b05d1ebc59f1f639bc

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --