Ghouls 'N Ghosts (Mega Drive)
Traducci�n al Espa�ol v1.1 (02/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
v1.1: Arregla T�tulo y opciones despu�s de la demo.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ghouls 'N Ghosts (UE) (REV02) [!].gen
MD5: c61ff4bcdf10813c74f36ab57e29f646
SHA1: aab6d20f01db51576b1d7cafab46e613dddf7f8a
CRC32: 4f2561d5
655.360 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --