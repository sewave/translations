Uchuu Keibitai SDF (NES)
Traducción al Español v1.0 (02/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Uchuu Keibitai SDF (Japan).nes
MD5: ccc61db792952a0a5671ffe6401bf09d
SHA1: 157a0610ee484233aed3877f7113e89744f0d454
CRC32: e8a98391
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --