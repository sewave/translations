Widget (NES)
Traducción al Español v1.0 (27/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Widget (U) [!].nes
MD5: c21f99f0d2f564027c561b65759d3ddc
SHA1: c9c48e0b633feecfcc22ef7ccf14d27124709f70
CRC32: cd5a8930
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --