Janggun-ui Adeul (NES)
Traducción al Español v1.0 (12/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de pacnsacdave.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Janggun-ui Adeul (Korea) (Unl).nes
MD5: ed401d83acbe3b0f87d3bf3dd89edf44
SHA1: b189ef567e15c227618e70185f20dcb52a88db54
CRC32: 54171ca4
655376 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --