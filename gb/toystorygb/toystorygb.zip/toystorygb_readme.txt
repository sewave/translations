Toy Story (Game Boy)
Traducción al Español v1.0 (27/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Toy Story (USA) (Rev 1) (SGB Enhanced).gb
MD5: 344ed70fe1a7a8cc904eda886543252c
SHA1: 04227fcd3e049465f4499fefe6519322ee492a82
CRC32: 6f36b6ed
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --