Chuck Rock (Mega Drive)
Traducci�n al Espa�ol v1.0 (06/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chuck Rock (U) [c][!].gen
MD5: efd1546c7f4c8c76f36d6b3eeb9f5331
SHA1: f6177b4c9ac48325c53fa26531cdd9bbc673dda3
CRC32: f8ac454a
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --