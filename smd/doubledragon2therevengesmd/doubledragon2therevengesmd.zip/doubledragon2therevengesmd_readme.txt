Double Dragon 2 - The Revenge (Mega Drive)
Traducci�n al Espa�ol v1.0 (17/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Dragon 2 - The Revenge (J) [!].gen
524.288 bytes
MD5: 57169954f90bfef473f4952b9633e57a
SHA1: 68dc151ada307ed0ed34f98873e0be5f65f1b573
CRC32: a8bfdbd6

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --