Super Monaco GP (Master System)
Traducción al Español v1.0 (29/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Monaco GP (U) [!].sms
MD5: aed300f323aae6d00878eb6ba21c2eb7
SHA1: fc933d9ec3a7e699c1e2cda89b957665e7321a80
CRC32: 3ef12baa
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --