Summer Carnival '92 - Recca (NES)
Traducción al Español v1.0 (26/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Summer Carnival '92 - Recca (Japan).nes
MD5: 61da1e9ac94fe72a1ee385fff1a0c062
SHA1: 4558a330119e79fcb50b46ae21b4171da6623ce5
CRC32: d98ec487
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
Sensenic - Traducción del Japonés.

-- FIN --