The Incredible Hulk (Game Gear)
Traducción al Español v2.0 (20/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0: Añadidos acentos y revisión de script

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Incredible Hulk, The (USA, Europe).gg
MD5: 7b239c8ae257cb78c46a8affa9bc8226
SHA1: 0410dafce21e5f40263ccb39871188ca84f7dd22
CRC32: d7055f88
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --