Adventures of Lolo 3 (NES)
Traducci�n al Espa�ol v1.0 (27/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Adventures of Lolo 3 (U) [!].nes
MD5: 3dc676f6a0d1e400bb4e1bf908e4c46a
SHA1: fd8551f8b02323d31dcc38dcd69545725d6c0538
CRC32: e06a060b
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --