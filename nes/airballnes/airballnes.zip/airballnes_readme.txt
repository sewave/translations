Airball (NES)
Traducción al Español v1.0 (09/11/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Airball (Unknown) (Proto 2).nes
MD5: 89e85b203ad4eba05ad64d6619da9c86
SHA1: 3f5bfc9798660bfe141ad7efd47bc67bcad72139
CRC32: 1701b08d
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --