Mickey Mousecapade
Traducci�n al Espa�ol v1.0 (13/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Mickey Mousecapade
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mickey Mousecapade
-----------------
Plataformas de Mickey Mouse para NES.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mickey Mousecapade (U) [!].nes
65.552 bytes
CRC32: 3341274d
MD5: 56603d74c8ea8f67f9c094e0016b747c
SHA1: 4ae2ae167e06e65e14422d045bb52154612bb0a2

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --