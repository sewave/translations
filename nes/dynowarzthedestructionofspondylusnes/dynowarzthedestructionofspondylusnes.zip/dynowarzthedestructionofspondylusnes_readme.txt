Dynowarz - The Destruction of Spondylus (NES)
Traducción al Español v1.0 (06/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dynowarz - The Destruction of Spondylus (U) [!].nes
MD5: 7846fdd087d7d8705eab634087bba3bc
SHA1: 8a43530dac34a78b052c7702577bea91ea59cfee
CRC32: d05a18b7
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --