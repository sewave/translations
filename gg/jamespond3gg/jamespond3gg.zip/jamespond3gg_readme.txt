James Pond 3 - Operation Starfish (Game Gear)
Traducci�n al Espa�ol v1.0 (05/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
James Pond 3 - Operation Starfish (U) [!].gg
MD5: 1c88d6f7784efb05d2548f9f903889f3
SHA1: 53790edee813a0a444b0369fd15672bb2a343780
CRC32: 68bb7f71
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --