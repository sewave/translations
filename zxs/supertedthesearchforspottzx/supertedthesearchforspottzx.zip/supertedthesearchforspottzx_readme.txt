Super Ted - The Search For Spot (ZX Spectrum)
Traducción al Español v1.0 (13/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Ted - The Search For Spot.tzx
MD5: 84b83ef19a84ca8bd2a6cd7860080f76
SHA1: 52e8288671f828b726d45ccb3a92250381f96716
CRC32: 9c8fbd83
47992 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --