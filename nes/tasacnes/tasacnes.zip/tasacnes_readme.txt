Tasac (NES)
Traducción al Español v1.0 (28/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tasac (Asia) (Ja) (Unl).nes
MD5: 01355186e1f2f9969e0c243ed67dbd22
SHA1: 11b41ac1cec55eb538dbbd2446756d81edeb4851
CRC32: 5cfd8736
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --