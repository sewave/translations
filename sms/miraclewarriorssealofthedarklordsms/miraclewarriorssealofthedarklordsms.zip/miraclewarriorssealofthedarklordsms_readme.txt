Miracle Warriors - Seal of the Dark Lord (Master System)
Traducción al Español v1.0 (22/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Miracle Warriors - Seal of the Dark Lord (UE) [!].sms
MD5: e0a9cf889c27f3cb14903288f646d183
SHA1: f952406bca4918ee91a89b27e949e224eae96d85
CRC32: 0e333b6e
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --