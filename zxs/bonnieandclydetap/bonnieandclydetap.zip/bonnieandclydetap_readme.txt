Bonnie and Clyde (ZX Spectrum)
Traducción al Español v1.0 (13/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bonnie_and_Clyde.tap
MD5: 87bfa12484760ebd55038c478df0440a
SHA1: b23b5f16d622e673a4a07f774c61758ba06f1fb9
CRC32: f075ba62
47115 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --