Blackthorne (Game Boy Advance)
Traducción al Español v1.0 (13/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blackthorne (USA).gba
MD5: d0bb79fb5a05702ce8b7d03320fcdf52
SHA1: 8f7f8c2051130b881e1fc131360cbc4946a63535
CRC32: 8e6dcd53
4194304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --