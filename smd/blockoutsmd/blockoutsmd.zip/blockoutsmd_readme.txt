Block Out (Mega Drive)
Traducción al Español v1.0 (25/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Block Out (W) (REV01) [!].bin
MD5: c324d9a3cbfa530996b6ad202686627b
SHA1: f6620d3b712f3bd333d0bb355c08cf992af6e12d
CRC32: 5e2966f1
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --