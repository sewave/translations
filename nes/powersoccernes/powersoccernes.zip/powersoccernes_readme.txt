Power Soccer (NES)
Traducción al Español v1.0 (19/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Power Soccer (Japan).nes
MD5: 4cf4e422ff81aa284298bb295c7a99b5
SHA1: 32611dd816f9ab85470624511f816a47de555e7c
CRC32: a99fa4a9
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --