Home Alone 2 - Lost in New York (Super Nintendo)
Traducción al Español v1.0 (17/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Home Alone 2 - Lost in New York (U).smc
MD5: b41839190d010ff407bffca3dcb3f716
SHA1: b4094e81e8b1ffd42eb7dd2fa3c56bfc116fcc86
CRC32: d19165d9
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --