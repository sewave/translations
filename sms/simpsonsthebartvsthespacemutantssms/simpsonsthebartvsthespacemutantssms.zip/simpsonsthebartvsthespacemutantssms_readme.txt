Simpsons, The - Bart vs. The Space Mutants (MASTER SYSTEM)
Traducci�n al Espa�ol v1.0 (13/07/2018)
(C) 2018 Wave Translations

---------
Contenido
---------

1. Notas y Fallos Conocidos
2. Instrucciones de Parcheo
3. Cr�ditos del Parche

---------------------------
1. Notas y Fallos Conocidos
---------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
2. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Simpsons, The - Bart vs. the Space Mutants (E) [!].sms
262.144	bytes
CRC32: d1cc08ee
MD5: 26df4404950cb8da47235833c0c101c6
SHA1: 4fa839db6de21fd589f6a91791fff25ca2ab88f4

----------------------
3. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --