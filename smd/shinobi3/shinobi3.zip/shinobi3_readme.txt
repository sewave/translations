Shinobi III - Return of the Ninja Master
Traducci�n al Espa�ol v1.0 (10/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Shinobi III - Return of the Ninja Master
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Shinobi III - Return of the Ninja Master
-----------------
Tercera parte de shinobi para megadrive, espectacular.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Shinobi III - Return of the Ninja Master (U) [!].bin
1.048.576 bytes
CRC32: 5381506f
MD5: 691eeff9c5741724a8751ec0fa9cfbf0
SHA1: 1e07d7998e3048fcfba4238ae96496460e91b3a5

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --