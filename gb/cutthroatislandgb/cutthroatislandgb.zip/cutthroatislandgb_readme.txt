Cutthroat Island (Game Boy)
Traducción al Español v1.0 (22/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cutthroat Island (U).gb
MD5: c5858497d4e8fcfbb7221e327a0e79b5
SHA1: 5e99ea51b383cdcd53874eb027ebd59d2a3156b9
CRC32: eebdd360
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --