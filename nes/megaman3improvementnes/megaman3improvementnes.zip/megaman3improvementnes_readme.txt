Mega Man III
Traducci�n al Espa�ol v1.1 (31/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Mega Man III
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mega Man III
-----------------
Version mejorada de la tercera parte, arreglando bugs y a�adiendo 
nuevas caracteristicas como poder elegir poder con el bot�n select o
poder reentrar y salir de una escena ya terminada.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basada en la mejora de kuja killer.
V1.1: Corregida frase de la intro.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
El menu de selecci�n de armas no va bien en la primera parte de la pantalla de geminiman con alg�n emulador.
Este bug es originario del Improvement hack.
Si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Megaman III (U) [!].nes
393.232	bytes
CRC32: 452d8089
MD5: 75b924155cafee335c9ea7a01bfc8efb
SHA1: 53197445e137e47a73fd4876b87e288ed0fed5c6

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Original:
kuja killer - Hacking	

-- END OF README --