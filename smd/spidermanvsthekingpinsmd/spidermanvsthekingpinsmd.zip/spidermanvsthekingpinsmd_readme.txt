Spider-Man vs. The Kingpin
Traducci�n al Espa�ol v1.0 (09/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Spider-Man vs. The Kingpin
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Spider-Man vs. The Kingpin
-----------------
Versi�n de Mega Drive del juego de acci�n/plataformas de Spider-Man.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Spider-Man vs The Kingpin (W) [!].bin
524.288	bytes
CRC32: 70ab775f
MD5: 084403af61869de5c98cb00f59072abb
SHA1: 250f7a7301a028450eef2f2a9dcec91f99ecccbd

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --