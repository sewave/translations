The Lone Ranger (NES)
Traducción al Español v2.0 (13/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducidos minijuegos
-Traducido título
-Revisión de script
-Añadidos ¡¿ÁÉÍÓÚÑ

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lone Ranger, The (USA).nes
MD5: 270f04797f6d237c0a14c01f05a4f3d8
SHA1: 6b6dbfb4538ab3fca7d1bb4d89c6ca4cb32aedf9
CRC32: 06c65580
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --