Galaxian (MSX)
Traducción al Español v1.0 (12/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Galaxian (1984) (Namcot) (J) [a1].rom
MD5: 08165f2fec4cd6acaf7fbe0bf49303ea
SHA1: aa2ba89e0b1c91a4405f516ef003ad14a401096c
CRC32: 4980ffac
8192 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --