Fist of the North Star (NES)
Traducción al Español v1.0 (29/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fist of the North Star (USA).nes
MD5: 987a48a9258138ca4d7f819102d444f8
SHA1: 10d6d3500aba774a5ecb1f5b938768bb0540f8e5
CRC32: 35deffb7
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --