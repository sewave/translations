Panic Restaurant
Traducci�n al Espa�ol v1.0 (11/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Panic Restaurant
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Panic Restaurant
-----------------
Simpatico plataformas sobre un chef al que le roban el restaurante, versi�n americana.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Panic Restaurant (U) [!].nes
262.160	bytes
CRC32: 69c9e654
MD5: 0e1a559f0e7f31e961413c7466cf6113
SHA1: e6ad766b7f42113325deb96917ccd81da92eefa7

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --