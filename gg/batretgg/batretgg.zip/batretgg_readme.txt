Batman Returns
Traducci�n al Espa�ol v1.0 (21/05/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Batman Returns
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Batman Returns
-----------------
Plataformas de batman para la portatil de sega, muy parecido al de master system, pero con algunos cambios que yo creo que lo hacen mejor.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Batman Returns (U) [!].gg
262.144	bytes
CRC32: 7ac4a3ca
MD5: 1e8cfd2f30e9ad733f602cf2de696ba9
SHA1: 85994b2f506c7bded0b02a59d96b1d949e48d518

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --