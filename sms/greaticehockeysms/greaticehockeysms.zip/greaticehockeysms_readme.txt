Great Ice Hockey (Master System)
Traducción al Español v1.0 (29/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Great Ice Hockey (UJ) [!].sms
MD5: 374d762b51b1c5ea8ff7903f98586e0e
SHA1: bbe6bd6b59e5ae20cd1a4a8c72276aac7d2964a3
CRC32: 0cb7e21f
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --