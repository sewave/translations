X-Men - Gamemaster's Legacy (Game Gear)
Traducción al Español v1.0 (24/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
X-Men - Gamemaster's Legacy (U) [!].gg
MD5: 571ac03b80e3075c699cd583bf8651fd
SHA1: 872596d40aae1755c9dda99180cb165166267904
CRC32: c169c344
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --