A.T.A.C. (ZX Spectrum)
Traducción al Español v1.0 (09/03/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
A.T.A.C.tzx
MD5: e869d02297b980fb0f16537ec95e5ecc
SHA1: 8b2660499ee25a87e43012a767785d9e1def148e
CRC32: 02a4a824
47770 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --