Darius Alpha
Traducci�n al Espa�ol v1.0 (15/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Darius Alpha
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Darius Alpha
-----------------
Shoot em up de la saga Darius para PC Engine.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Darius Alpha (J).pce
393.728	bytes
CRC32: 13b020b1
MD5: 67854fafecfb74355376afc6f6294980
SHA1: 32fbb1b003197d6f37ad7addaf38aaadfcc86036

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --