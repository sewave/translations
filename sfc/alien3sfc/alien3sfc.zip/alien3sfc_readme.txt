Alien 3 (Super Nintendo)
Traducción al Español v1.0 (21/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alien 3 (USA).sfc
MD5: 09120ba8c0052997481117683b4e70db
SHA1: 7c29a915c28c534c8a67a940e86d8346958f4fa1
CRC32: 98e2ac15
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --