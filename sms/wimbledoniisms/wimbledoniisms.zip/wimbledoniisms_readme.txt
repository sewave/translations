Wimbledon II (Master System)
Traducción al Español v1.0 (24/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wimbledon II (Europe).sms
MD5: 41fa7c376327e7fa851103c0407e8e53
SHA1: 55dd4aaa92de4bdaa1d8b6463a34887f4a8baa28
CRC32: 7f3afe58
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --