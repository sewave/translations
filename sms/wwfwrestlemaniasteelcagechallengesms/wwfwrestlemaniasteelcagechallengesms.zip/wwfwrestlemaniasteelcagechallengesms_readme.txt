WWF Wrestlemania Steel Cage Challenge (Master System)
Traducción al Español v1.0 (30/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
WWF Wrestlemania Steel Cage Challenge (U) [!].sms
MD5: 5db168808d3b4756c8c5f8b836a7b05a
SHA1: 6fd4f5af0f14e1e0a934cd9e39a6bb476eda7e97
CRC32: 2db21448
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --