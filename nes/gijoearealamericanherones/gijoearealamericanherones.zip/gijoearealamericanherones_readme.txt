G.I. Joe - A Real American Hero (NES)
Traducción al Español v2.0 (26/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducción del título
-Añadidos caracteres especiales
-Guion reescrito
-Varios gráficos traducidos

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
G.I. Joe - A Real American Hero (USA).nes
MD5: 13c45cfa08f421655737394539055567
SHA1: d64aee0326d862664eeb35a9010cae31217a0c69
CRC32: 394fd25a
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --