Space Harrier (Game Gear)
Traducción al Español v1.0 (20/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Space Harrier (JU) [!].gg
MD5: cd3809b8d6d32144c45de8e102623aa0
SHA1: d00b8ff195d4423f2a344490eb34156017f4ee64
CRC32: 600c15b3
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --