Heroes of Might and Magic (Game Boy Color)
Traducción al Español v1.0 (18/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Heroes of Might and Magic (U) (M3) [C][!].gbc
MD5: 6a2a5ab0dc979f162cbfa4389d1cd71f
SHA1: 209d8a9cdd240a8c73d03d8575373bfa53948869
CRC32: bb0672a6
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --