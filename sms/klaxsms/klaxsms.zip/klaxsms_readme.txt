Klax (Master System)
Traducción al Español v1.0 (19/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Klax (E) [!].sms
MD5: dcea71eda85687d1835bed5c493f81a2
SHA1: 53ae621e66d8e5f2e7276e461e8771c3c2037a7a
CRC32: 2b435fd6
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --