Aladdin
Traducci�n al Espa�ol v1.0 (13/01/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Aladdin
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Aladdin
-----------------
Excelente plataformas basado en la pelicula, port de la versi�n de megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Aladdin (U) [S][!].gb
262.144	bytes
CRC32: 81b4e56ae235fbb123d7ad4bd7c1d96c3b69eb72
MD5: ed5525a71dda6eaf4bbf8d5601b6b3b9
SHA1: 81b4e56ae235fbb123d7ad4bd7c1d96c3b69eb72

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --