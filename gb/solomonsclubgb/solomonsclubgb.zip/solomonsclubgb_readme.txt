Solomon's Club (Game Boy)
Traducción al Español v1.0 (29/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Solomon's Club (U).gb
MD5: 8a5ccf172f31a0dbfa0600d40b388fdc
SHA1: 36abf2be4a16df8e9fe30307cbd8cb949a9b9bdb
CRC32: cea9622a
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --