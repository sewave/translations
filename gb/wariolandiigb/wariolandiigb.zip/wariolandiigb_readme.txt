Wario Land II (Game Boy)
Traducción al Español v1.0 (28/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wario Land II (USA, Europe) (SGB Enhanced).gb
MD5: e5e8910d436acb9fd218559a216501a3
SHA1: c65820b2e52d00e6ce60e0a432fab002fec4386f
CRC32: 9c54358d
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --