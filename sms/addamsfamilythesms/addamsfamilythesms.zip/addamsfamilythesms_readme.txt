The Addams Family (Master System)
Traducción al Español v2.0 (17/09/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Alargadas cadenas de objetos y localizaciones
-Guion retraducido
-Mejorado inventario

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Addams Family, The (Europe).sms
MD5: 09202bc26fcf19ebd3ffcbd80e23ed9d
SHA1: 3fc6ccc556a1e4eb376f77eef8f16b1ff76a17d0
CRC32: 72420f38
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --