Rescue Mission (Master System)
Traducción al Español v1.0 (14/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rescue Mission (UE) [!].sms
MD5: 717fdf868c8f11a712697260eb7db670
SHA1: 6a561bff2f8022261708b91722caf1ec0e63f9c4
CRC32: 79ac8e7f
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --