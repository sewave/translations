Paperboy 2 (Game Gear)
Traducci�n al Espa�ol v1.0 (10/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Paperboy 2 (U) [!].gg
MD5: 16899b0262f77cbbdf3dae252ec7fe29
SHA1: 2fa97c21bfd9d3968c473b6fa4fb7485b6dfb35d
CRC32: 8b2c454b
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --