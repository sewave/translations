Teenage Mutant Ninja Turtles - Back From the Sewers (Game Boy)
Traducci�n al Espa�ol v1.0 (05/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles - Back From the Sewers (U) [!].gb
MD5: 0221de99d11f50f79430c8ff9b430994
SHA1: 08aabd7be3d4b78a8b124a58afae4fec758b225f
CRC32: 44f51c73
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --