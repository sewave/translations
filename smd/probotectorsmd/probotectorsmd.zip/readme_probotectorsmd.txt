Probotector
Traducci�n al Espa�ol v1.0 (12/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Probotector
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Probotector
-----------------
Traduccion completa del clasico shoot em up ven ersion europea.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Probotector (E) [!].bin
2.097.152 bytes
CRC32: bc597d48
MD5: 22289fe42b00a5fe5df3299747480fc0
SHA1: 69d905751ffa6a921586767263e45ddeb73333c2

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --