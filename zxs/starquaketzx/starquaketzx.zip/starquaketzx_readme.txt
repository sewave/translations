Starquake (ZX Spectrum)
Traducción al Español v1.0 (19/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Starquake.tzx
MD5: c970954df1278e4d47e8208c90656f73
SHA1: 224037e7d9358273b11a0a990f06f8fad2a5a4bb
CRC32: 8043260a
49563 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --