Felix the Cat (Game Boy)
Traducción al Español v1.0 (29/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Felix the Cat (U).gb
MD5: 4d606ab4ffd5c3d3ecf914a6af1c1f90
SHA1: c4a0d02d5964335a18839c7c30ac05b6f40c33b3
CRC32: f53f7f00
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --