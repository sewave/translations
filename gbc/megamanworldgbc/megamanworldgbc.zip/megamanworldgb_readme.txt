Mega Man World: Dr. Wily's Revenge GBC (Game Boy Color)
Traducción al Español v1.0 (18/01/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Specialagentape.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mega Man - Dr. Wily's Revenge (USA).gb
MD5: 4ba4398181d98958fa7434ba7716f11a
SHA1: 277edb3c844e812ba4b3eb9a96c9c30414541858
CRC32: 47e70e08
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --