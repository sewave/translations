Demolition Man (Super Nintendo)
Traducción al Español v1.0 (23/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Demolition Man (USA).sfc
MD5: 53f35c2e352a75d1bc47339743895da9
SHA1: b55fac176b1dc86d7aca2e080086184349960c16
CRC32: 8afe2f91
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --