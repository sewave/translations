Ghostbusters (NES)
Traducción al Español v1.0 (21/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ghostbusters (USA).nes
MD5: 9631832afe458a2f59993de26b9bcb9a
SHA1: c2fae32ac6c49da99cd779badbb64825e35d4c2f
CRC32: b30a3e39
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --