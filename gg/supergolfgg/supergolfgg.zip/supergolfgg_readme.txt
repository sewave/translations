Super Golf (Game Gear)
Traducción al Español v1.0 (24/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Golf (J).gg
MD5: f2b5123b3614388677c9c15adaaa8d64
SHA1: 9ecb48513621086ec6d5bffa1375914f21f393e4
CRC32: 528cbbce
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --