Kosmos (ZX Spectrum)
Traducción al Español v1.0 (07/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kosmos.tzx
MD5: 259d90d83b30a590f4c2e969f988e232
SHA1: f944513ae3f705f9f102fbe46d010e865a2f4e8d
CRC32: dc492d84
48254 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --