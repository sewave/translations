James Bond 007 - The Duel (Master System)
Traducción al Español v1.0 (02/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
James Bond 007 - The Duel (E).sms
MD5: c52e496c497d427747769aaedfbb8dab
SHA1: 89f86869b90af986bee2acff44defe420e405a1e
CRC32: 8d23587f
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --