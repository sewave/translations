Fist of the North Star (Game Boy)
Traducción al Español v1.0 (04/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fist of the North Star (USA).gb
MD5: c88d94a984afde869426694a3b992894
SHA1: 0bf60583da14cd32947f8e8e6b995c2b176d95c5
CRC32: 9a84b6cf
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --