Castle of Illusion Starring Mickey Mouse
Traducci�n al Espa�ol v1.0 (13/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Castle of Illusion Starring Mickey Mouse
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Castle of Illusion Starring Mickey Mouse
-----------------
Que decir de este clasico plataformas, juegalo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Castle of Illusion Starring Mickey Mouse (U) (V1.1) [!].sms
262.144	bytes
CRC32: 953f42e1
MD5: e7e1ef0a9e20585e2266e8adbaf4b8c9
SHA1: c200b5e585d59f8bfcbb40fd6d4314de8abcfae3

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --