Last Action Hero (Mega Drive)
Traducción al Español v1.0 (29/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Last Action Hero (U) [!].bin
MD5: 960d31f44cc668d331d2711dd7def19d
SHA1: 8efa876894c8bfb0ea457e86173eb5b233861cd0
CRC32: 15357dde
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --