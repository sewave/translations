Gun.Smoke
Traducci�n al Espa�ol v1.0 (23/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Gun.Smoke
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Gun.Smoke
-----------------
Cl�sico shooter de capcom, port de la recreativa.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Gun.Smoke (U) [!].nes
131.088	bytes
CRC32: 6b8f23e0
MD5: b7323d5cf56f4049e20d44815ca6c45a
SHA1: 612f2aa339bf1ae54b466f1574752cd753097503

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --