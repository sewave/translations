The Pirates of Dark Water (Super Nintendo)
Traducci�n al Espa�ol v1.0 (05/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pirates of Dark Water, The (U).smc
MD5: e57ff9a6f8a23935a1171f871c0ce68f
SHA1: ee8cb83b46b0dfce33cbbfa16bf0c713fbf288ba
CRC32: 7ca0ca4d
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --