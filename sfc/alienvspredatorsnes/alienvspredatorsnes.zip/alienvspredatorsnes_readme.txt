Alien vs. Predator
Traducci�n al Espa�ol v1.0 (19/06/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Alien vs. Predator
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alien vs. Predator
-----------------
Curioso beat em up para la snes.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alien vs. Predator (U).smc
1.048.576 bytes
CRC32: 1803cf20
MD5: 1fc2ead45eadcac586d65e218b895912
SHA1: 309f5d60f15c2af06ed30ef95112a8a287132ad5

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --