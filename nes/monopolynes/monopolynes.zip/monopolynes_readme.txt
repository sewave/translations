Monopoly (NES)
Traducción al Español v1.0 (07/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Monopoly (USA).nes
MD5: 5d35aa4eff6c804b92df184a221a51a7
SHA1: 5db2c9e02d3551292a0218f73875f9f08318ecb9
CRC32: faf48d27
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --