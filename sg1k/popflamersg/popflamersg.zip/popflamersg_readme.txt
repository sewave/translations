Pop Flamer (SG-1000)
Traducci�n al Espa�ol v1.0 (09/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pop Flamer (SG-1000) [!].sg
MD5: 7f841aa0c225662e26ca7a8df20b2eb8
SHA1: 84b59a9f855ef5e953c43495d7a15dd78386d0a8
CRC32: db6404ba
16.384 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --