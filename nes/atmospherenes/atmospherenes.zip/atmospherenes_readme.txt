Atmo Sphere (NES)
Traducción al Español v1.0 (24/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Atmo Sphere.nes
MD5: d925b79f2307732bd15b07e7a37e4965
SHA1: fb19b188bec6c0082c535ea6becc30f3cef008fe
CRC32: a3353255
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --