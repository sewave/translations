Side Pocket (Game Boy)
Traducción al Español v1.0 (25/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Side Pocket (U) [!].gb
MD5: 3dbe9be772ca50da3a76d8860c7b08e2
SHA1: 0e9d907e9ebf8d69fb94133362590c8ac6aa6392
CRC32: 9a1e30b4
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --