Wanpaku Kokkun no Gourmet World
Traducci�n al Espa�ol v1.0 (11/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Wanpaku Kokkun no Gourmet World
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Wanpaku Kokkun no Gourmet World
-----------------
Simpatico plataformas sobre un chef al que le roban el restaurante, versi�n japonesa.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basada en la traducci�n al ingl�s por:
Stardust Crusaders

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Wanpaku Kokkun no Gourmet World (J).nes
262.160	bytes
CRC32: fffb5ead
MD5: 29da48e6a9bef7131233cec0eeb43a01
SHA1: 7124b65b810a4e817b9401aa08cd7e8c5cb3029e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
Original:
Contributor	Type of contribution	Listed credit
Pennywise	Hacking	
Paul Jensen	Translation	Main Translation, Misc Translation Support
Ryusui	Translation	Additional Translation Support
sin_batsu	Graphics	Title Screen Design
DvD	Hacking	Additional Title Screen Design & Hacking

-- END OF README --