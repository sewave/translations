Super Mario Bros (NES)
Traducción al Español v2.2 (28/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Arreglos menores de guion
-Corregidos gráficos F, S, 1, 2 en "GAME OVER"
-Traducido "GAME OVER"
-Acentuado "CONTINÚA"
-Traducidos gráficos "START"
-Traducidos gráficos "1UP" por "1VD"
-Traducidos gráficos "POW" por "POD"
-Traducidos gráficos "THE END"
V2.1:
-Arreglado "GAME OVER" en mundos de pantallas múltiples
-Cambiado "CONTINÚA" por "CONTINUAR"
V2.2:
-Eliminado uso de Q y U al estar usados por otras letras.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Mario Bros. 3 (USA) (Rev A).nes
MD5: 86d1982fea7342c0af9679ddf3869d8d
SHA1: 6bd518e85eb46a4252af07910f61036e84b020d1
CRC32: 0b742b33
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --