Marksman Shooting & Trap Shooting & Safari Hunt (Master System)
Traducción al Español v1.0 (08/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Marksman Shooting & Trap Shooting & Safari Hunt (Europe).sms
MD5: bf7ea79ac0df3ebe7256da6331b21c34
SHA1: eaae5c9d9de24c0991500122042b3aa2210d50d9
CRC32: e8215c2e
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --