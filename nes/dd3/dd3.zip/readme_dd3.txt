Double Dragon III - The Rosetta Stone (J) [!].nes
Traducci�n al Espa�ol v1.0 (02/11/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Double Dragon III - The Rosetta Stone
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Double Dragon III - The Rosetta Stone
-----------------
Clasico beat em up, tercera parte que aunque fue menospreciada, a mi me encanta :)

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es basado en el de pacnsacdave.
Se han a�adido minusculas y ������.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Double Dragon III - The Rosetta Stone (J) [!].nes
262.160	bytes
CRC32: 40759ab5
MD5: 99b59bb8439790a5eb3a384efbd75767
SHA1: c2eb62a13faca63c55efa68984ae515b4dbea9c0

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al espa�ol

Original al ingles
pacnsacdave - Hacking y traducci�n al ingl�s

-- END OF README --