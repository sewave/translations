Looney Tunes (Game Boy)
Traducción al Español v1.1 (14/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
-Añadidas Ú y Ñ

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Looney Tunes (USA, Europe).gb
MD5: 6e9dd3c1fb169da79292a1962e95a884
SHA1: 97d96f8ec66acba996c7bec0a713c84075f22680
CRC32: a662a8ef
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --