Power Strike (Master System)
Traducci�n al Espa�ol v1.0 (09/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Power Strike (UE) [!].sms
MD5: 8d9f02dcfea8f9728a3665ca12b044d1
SHA1: f6f245c41163b15bce95368e4684b045790a1148
CRC32: 4077efd9
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --