Balloon Kid (Game Boy)
Traducción al Español v1.0 (25/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Balloon Kid (W) [!].gb
MD5: f70c60ca87714fa9d81be60c9ac93de0
SHA1: 0cb5adc9bdef5320f3f156efed0d47a618e2299f
CRC32: d4b655ec
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --