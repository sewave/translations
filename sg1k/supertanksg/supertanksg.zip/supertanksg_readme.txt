Super Tank (SG-1000)
Traducci�n al Espa�ol v1.0 (01/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Tank (SG-1000) [!].sg
MD5: 59d01bf1093a65e9ec08e533cfbbc5ff
SHA1: 58d7d51b91b763d812376d56643a4f8a331e826b
CRC32: 084cc13e
32.768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --