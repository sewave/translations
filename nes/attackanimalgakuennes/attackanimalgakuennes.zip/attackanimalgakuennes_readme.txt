Attack Animal Gakuen (NES)
Traducción al Español v1.0 (02/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Attack Animal Gakuen (Japan).nes
MD5: 10796ae8f2a39d4bf5d1b3bf1cd02297
SHA1: 37b6d96ca31901270cefa4396348c90de578c6c4
CRC32: 4e5c1c1d
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --