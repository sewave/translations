Rapid Fire (ZX Spectrum)
Traducción al Español v1.0 (27/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rapid Fire.tzx
MD5: 5a70ef65a75de881f6417af59cd02f1d
SHA1: a84597af7092b2f4a59582f32a0b5a9827bfe2a8
CRC32: e0d1f341
48768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --