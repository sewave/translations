konami's ping pong (MSX)
Traducción al Español v1.0 (12/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
konami's ping pong (1985) (konami) (j).rom
MD5: 9352eca87ee56a2e1e5db813fd686b91
SHA1: ae5b8e69732a23aee102bcd996ad06225f1b3eba
CRC32: 3f200491
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --