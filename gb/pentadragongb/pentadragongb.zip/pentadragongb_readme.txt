Penta Dragon (Game Boy)
Traducción al Español v1.0 (11/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de HTI.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Penta Dragon (Japan).gb
MD5: df43e0adfdc74b2829c7e95e91c71a28
SHA1: fd75d43258e79f14d104fb4756e219141882c837
CRC32: 1e2efaee
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --