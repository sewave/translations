Dino Dini's Soccer (Mega Drive)
Traducción al Español v1.0 (23/11/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dino Dini's Soccer (Europe).md
MD5: 6a492e2983b2bc306eec905411ee24a8
SHA1: 49d4a654dd2f393e43a363ed171e73cd4c8ff4f4
CRC32: 4608f53a
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --