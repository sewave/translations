Pinball Quest (NES)
Traducción al Español v1.0 (11/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pinball Quest (USA).nes
MD5: 392630ff141f918469c0b1e3391c3669
SHA1: 1c99ddd0a0addf875dadffcf899ff4d8c5be953e
CRC32: 488bf94e
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --