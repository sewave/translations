Balance (MSX)
Traducción al Español v1.0 (13/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Balance (1984) (Hal) (J).rom
MD5: 9c3c4f7c76ce97efb8b755c0b1dac233
SHA1: cd452442338366411f6b24739fe59e20f3ac24dc
CRC32: cdabd75b
8192 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --