A Dinosaur's Tale (Mega Drive)
Traducción al Español v1.0 (29/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dinosaur's Tale, A (USA).md
MD5: 122f44df25f3dd6a7f74f0f125905257
SHA1: b1f8e741399fd2c28dfb1c3340af868d222b1c14
CRC32: 70155b5b
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --