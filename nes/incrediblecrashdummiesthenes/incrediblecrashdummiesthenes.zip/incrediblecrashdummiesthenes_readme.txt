The Incredible Crash Dummies (NES)
Traducción al Español v1.0 (16/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Incredible Crash Dummies, The (U) [!].nes
MD5: 3ff77ed038e5fa4ec9c46479fba1e4e5
SHA1: 936d7a6451d00b6a523ae9a880d5c257c3c7b268
CRC32: 8c684ea4
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --