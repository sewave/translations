Heavy Shreddin' (NES)
Traducción al Español v1.0 (23/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Heavy Shreddin' (USA).nes
MD5: 334d6a716110da23d89f190874d10f2e
SHA1: 70913f26f9c913c78bd87a038556abd49e7bc283
CRC32: 86a637b0
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --