Mickey Mouse III - Yume Fuusen
Traducci�n al Espa�ol v1.1 (25/02/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Mickey Mouse III - Yume Fuusen
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mickey Mouse III - Yume Fuusen
-----------------
Plataformas de Mickey Mouse solo para jap�n.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
He a�adido min�sculas y acentos.
Basado en la traducci�n de NikcDC.
V1.1: Arreglos menores

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mickey Mouse III - Yume Fuusen (J) [!].nes
262.160	bytes
CRC32: 7d426a63
MD5: 5436d1b38e3cac2ae326f77572b3e503
SHA1: 8f9744e3ecfb6009746ca5d70c295cc58db2302b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --