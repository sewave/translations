Hurricanes (Super Nintendo)
Traducción al Español v1.0 (24/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hurricanes (USA).sfc
MD5: 3838ba14b7c686c9f4da9a0da6f48c11
SHA1: 2a47ccdf945a0965915e3d6f9d638e820d367f11
CRC32: 42ff4f08
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --