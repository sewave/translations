Keroppi to Keroriinu no Splash Bomb! (NES)
Traducción al Español v1.0 (06/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Suicidal Translations.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Keroppi to Keroriinu no Splash Bomb! (Japan).nes
MD5: d57daf5848cae6640577e605b7cfe4b3
SHA1: d7cdc031c61d2b2bd1bd2a1fe2079b4e13ba12af
CRC32: cc6fbdae
163856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --