Paperboy 2 (Super Nintendo)
Traducción al Español v1.0 (02/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Paperboy 2 (USA).sfc
MD5: 55112a9e516a1d74eb4f446588616c85
SHA1: dc9e458d9463877802d4440141186bcafea0eba2
CRC32: c85aa66a
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --