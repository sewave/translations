The Aquatic Games - Starring James Pond (Mega Drive)
Traducción al Español v1.1 (20/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglos menores.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Aquatic Games - Starring James Pond, The (UE) [!].gen
MD5: 0eec7f8771ca70ad5ace3d46cb4be9d4
SHA1: 3bbd0853099f655cd33b52d32811f8ccb64b0418
CRC32: 400f4ba7
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --