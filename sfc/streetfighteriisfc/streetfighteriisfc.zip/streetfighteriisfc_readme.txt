Street Fighter II (Super Nintendo)
Traducción al Español v1.0 (23/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Street Fighter II (USA).sfc
MD5: be7fc84ac1151b99ad48329327e2aaa7
SHA1: 7ddcb96e0d9fea94d9370635262ac7c28da85214
CRC32: bc3dcd9d
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --