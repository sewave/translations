Art of Fighting
Traducci�n al Espa�ol v1.0 (19/06/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Art of Fighting
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Art of Fighting
-----------------
Buena adaptaci�n del arcade a la megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Art of Fighting (U) [!].gen
2.097.152 bytes
CRC32: c9a57e07
MD5: 3b878b854302596cb197602878d0cf07
SHA1: 7603f33a98994e8145c942e1ed28e6b072332324

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --