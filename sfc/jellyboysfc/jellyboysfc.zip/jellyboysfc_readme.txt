Jelly Boy (Super Nintendo)
Traducción al Español v1.0 (10/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jelly Boy (E).smc
MD5: c6ce4362e71935aa9b9af2820bb5630a
SHA1: 5b21a7646e0aa768845d42b54a8d8f6e125a8d61
CRC32: f8c72a24
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --