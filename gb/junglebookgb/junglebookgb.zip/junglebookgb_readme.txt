Jungle Book, The
Traducci�n al Espa�ol v1.0 (25/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Jungle Book, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Jungle Book, The
-----------------
Adaptaci�n de la pel�cula de Disney para la 8 bits port�til de Nintendo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Jungle Book, The (U) [!].gb
131.072	bytes
CRC32: b64d27ee
MD5: e5876720bf10345fb2150db6d68c1cfb
SHA1: ca69dde7b176d4bec9c51f92c37a5d68402af616

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
juandex - Testing

-- END OF README --