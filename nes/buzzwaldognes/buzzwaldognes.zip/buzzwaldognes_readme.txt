Buzz & Waldog (NES)
Traducción al Español v1.0 (01/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Buzz & Waldog (USA) (Proto) (Unl).nes
MD5: 313d661fa6878f97f5c6b08eaa8abae1
SHA1: 0f923de8d7726ad3a78c25cd866e6466ef9f6458
CRC32: 1587bc5f
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --