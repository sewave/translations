The Humans (Super Nintendo)
Traducción al Español v1.0 (15/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Humans, The (Europe).sfc
MD5: 00aa4464eaa6289c61999646549ece48
SHA1: 50c85ebd587a296b9cf00f209df3a2f07e6683ed
CRC32: d2af01d4
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --