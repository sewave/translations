Destination Earthstar (NES)
Traducción al Español v1.0 (27/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Destination Earthstar (U) [!].nes
MD5: 5ae2e4a3f7346f0f7c38a8517906c3d8
SHA1: 87735915491cd25274956cd9ae037c63c8849079
CRC32: a4b27af2
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --