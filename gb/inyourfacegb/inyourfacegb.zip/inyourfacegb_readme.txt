In Your Face (Game Boy)
Traducción al Español v1.0 (30/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
In Your Face (USA).gb
MD5: a4fc8158d1f2b6359ddac6c66d747a95
SHA1: 0be0f2a952497b321655dbee5c89678f40bf0b5a
CRC32: 80ac487e
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --