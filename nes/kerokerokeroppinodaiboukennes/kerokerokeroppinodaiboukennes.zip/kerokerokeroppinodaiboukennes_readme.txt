Kero Kero Keroppi no Daibouken (NES)
Traducción al Español v1.0 (13/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Gaijin Productions.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kero Kero Keroppi no Daibouken (Japan).nes
MD5: 767e5e722c8eb27b5166c23f8d7defdb
SHA1: 01eaeaf328c345cb385eb6850cca55bf53bf579e
CRC32: 32592407
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --