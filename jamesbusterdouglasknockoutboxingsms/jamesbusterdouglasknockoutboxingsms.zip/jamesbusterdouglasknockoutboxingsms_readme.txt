James 'Buster' Douglas Knockout Boxing (Master System)
Traducción al Español v1.0 (01/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
James 'Buster' Douglas Knockout Boxing (U) [!].sms
MD5: b3a4815ca9fdc900cf7fe6ad961f8125
SHA1: b07000feb0c74824f2e3e74fd415631a8f3c4da6
CRC32: 6a664405
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --