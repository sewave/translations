Kat Trap (ZX Spectrum)
Traducción al Español v1.0 (06/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kat Trap.tzx
MD5: df85cf9c5e6035e7cff87da3b7210cfa
SHA1: 4fcb5d71ef7b0a747b7534bf074c1489e31632de
CRC32: 0ba3af6a
48942 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --