Metroid (NES)
Traducci�n al Espa�ol v1.0 (07/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Metroid (USA).nes
MD5: d77c8053168da14b360bf5caeccc5964
SHA1: ecf39ec5a33e6a6f832f03e8ffc61c5d53f4f90b
CRC32: a2c89cb9
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --