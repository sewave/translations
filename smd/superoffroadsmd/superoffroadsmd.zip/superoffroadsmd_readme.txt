Super Off Road (Mega Drive)
Traducci�n al Espa�ol v1.0 (23/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Off Road (U) [!].gen
MD5: 539e2797cf613f39115cc86ae005d705
SHA1: 89f264afba7aa8764b301d46cc8c51f74c23919e
CRC32: 8f2fdada
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --