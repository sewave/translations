James Pond 3 - Operation Starfish (Super Nintendo)
Traducción al Español v1.0 (16/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
James Pond 3 - Operation Starfish (E).smc
MD5: 9df7471059e5bdd708f1e868142f02b6
SHA1: 14f5a0f9284365169a82a6902eb80b1886efcf0d
CRC32: 9d3e313f
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --