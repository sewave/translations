Cat Ninden Teyandee
Traducci�n al Espa�ol v1.0 (07/09/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Cat Ninden Teyandee
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Cat Ninden Teyandee
-----------------
Un juego de plataformas muy simpatico.
Este parche lo traduce completamente al espa�ol excepto algunos nombres porque no cabr�a la traducci�n.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es derivada de la de Vice Translations.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Kyatto Ninden Teyandee (J) [!].nes
262.160 bytes
CRC32: 6f1485ed
MD5: e7502f63aac2f2b5f8c5dec1a501e650
SHA1: 4366aa9d91adc80ec063667c59421b6245b0b786

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al Espa�ol

Vice Translations
  Foxhack - Game hacking, font insertion, general lazyness.
  MottZilla - Game expansion hacking.
  Shih Tzu - Main translation support.
  Optomon - Samurai Pizza Cats NES theme song.
  BMF54123, RedComet, Gil-Galad, KingMike - Additional assistance over the years.
  DarknessSavior - Additional translation suggestions and comments.

-- END OF README --