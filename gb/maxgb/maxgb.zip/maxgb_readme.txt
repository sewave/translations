Max (Game Boy)
Traducción al Español v1.0 (30/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Max (Europe).gb
MD5: 660a98b774e7d136e302dfe6557405e9
SHA1: 1f995332ae8a8832c178b22505d05080bf978aa8
CRC32: 1b167f00
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --