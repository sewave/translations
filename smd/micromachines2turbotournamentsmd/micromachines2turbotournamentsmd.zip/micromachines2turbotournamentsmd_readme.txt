Micro Machines 2 - Turbo Tournament (Mega Drive)
Traducción al Español v1.0 (26/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Micro Machines 2 - Turbo Tournament (Europe) (J-Cart).md
MD5: a145194b26c433c8a7159a00bafaba06
SHA1: ab29077a6a5c2ccc777b0bf22f4d5908401f4d47
CRC32: 42bfb7eb
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --