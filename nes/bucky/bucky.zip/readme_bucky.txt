Bucky O'Hare
Traducci�n al Espa�ol v1.2 (29/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Bucky O'Hare
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Bucky O'Hare
-----------------
En run'n gun con alta calidad t�cnica basada en al serie.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1: Revisi�n de los di�logos y a�adido de ������.
v1.2: Arreglado texto al rescatar al pato.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Bucky O'Hare (U) [!].nes
262.160	bytes
CRC32: cb0de10e
MD5: 2a8b36c8db90988ebf5c952b3d6c5162
SHA1: 1ac57d0e2924edb3b3c1ad96b29f32a2d48663e7

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --