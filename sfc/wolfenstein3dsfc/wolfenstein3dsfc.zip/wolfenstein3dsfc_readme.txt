Wolfenstein 3-D (Super Nintendo)
Traducción al Español v1.0 (05/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wolfenstein 3-D (USA).sfc
MD5: 418034d574ebdaea7659b3a90eebef58
SHA1: 88fe872eb984af84f8ca7633ef5bd3904a2baeb4
CRC32: 6582a8f5
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --