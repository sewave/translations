Taz-Mania
Traducci�n al Espa�ol v1.0 (27/01/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Taz-Mania
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Taz-Mania
-----------------
Plataformas de Master System sobre el demonio de Tazmania.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Taz-Mania (E) [!].sms
262.144	bytes
CRC32: 7cc3e837
MD5: cfc878f0163933fcfcc89e134fbeb31f
SHA1: ac98f23ddc24609cb77bb13102e0386f8c2a4a76

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --