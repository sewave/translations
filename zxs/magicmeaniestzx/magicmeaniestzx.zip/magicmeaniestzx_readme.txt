Magic Meanies (ZX Spectrum)
Traducción al Español v1.0 (08/06/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Magic Meanies.tzx
MD5: e4b67462003b9855dc20be3163f28c36
SHA1: 674d86487f74fc13253c3b28621f105a59285f36
CRC32: c29163a2
7529 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --