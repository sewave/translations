Time Zone (NES)
Traducción al Español v2.0 (12/10/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la traducción al inglés de King Mike.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres españoles
-Traducido Presents del principio
-Traducido PUSH START del título
-Traducidos S, AD y BC de la barra de estado
-Traducidas letras grandes

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Time Zone (Japan).nes
MD5: fe0adeaf7a696da636e7b8263c8f81d1
SHA1: b8bafdd2d63747906b00dc320ddf1fe62b2803f4
CRC32: c99628bc
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --