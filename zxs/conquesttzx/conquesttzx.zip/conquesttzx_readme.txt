Con-Quest (ZX Spectrum)
Traducción al Español v1.0 (04/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Con-Quest.tzx
MD5: 2949416226f4c0b92da76c55c394d8b0
SHA1: 3efe8fb60fd752c57dc487e914bf6bd44ecc8faf
CRC32: b04ec95b
48633 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --