Skatin' USA (ZX Spectrum)
Traducción al Español v1.0 (18/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Skatin' USA.tzx
MD5: 8061e83fa95a0aa3addc92df7af3ca3b
SHA1: b9076575d3dbc952d753f3648b261f013ea99579
CRC32: cb19399e
50454 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --