Desert Strike - Return to the Gulf (Game Boy)
Traducción al Español v1.0 (14/09/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Desert Strike - Return to the Gulf (Europe) (SGB Enhanced).gb
MD5: 6b371b815a02c5e90836f314b1625b21
SHA1: b49bc8f5d292f0e2b71957c8c4af37b20cfead80
CRC32: b700f7f7
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --