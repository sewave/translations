Fighting Road (NES)
Traducción al Español v1.0 (15/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Deep_wolf e Immutable.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fighting Road (Japan).nes
MD5: 74f3136b246d822c28f64f01b13a2dce
SHA1: 2ce010bfe7bfed1f4316e393b389a67619b253ac
CRC32: bdde0fd7
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --