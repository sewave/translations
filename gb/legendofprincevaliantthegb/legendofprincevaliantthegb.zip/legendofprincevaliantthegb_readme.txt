The Legend of Prince Valiant (Game Boy)
Traducción al Español v1.0 (28/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Legend of Prince Valiant, The (Europe) (En,Fr,De).gb
MD5: 017ace47f4970576043075f7ba86073c
SHA1: d56b59ad9e483f6912e8e5869c43e1771cf167c2
CRC32: 179c494e
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --