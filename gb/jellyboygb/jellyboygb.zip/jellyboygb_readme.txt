Jelly Boy (Game Boy)
Traducción al Español v1.0 (10/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jelly Boy (U).gb
MD5: 0acefb175380637bf0d49ad96da23d52
SHA1: 579579d660cdc84af2428ccd1b30b40a2fb592fa
CRC32: 7e6598bb
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --