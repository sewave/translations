Hoops (NES)
Traducción al Español v1.0 (12/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hoops (USA).nes
MD5: 1daaf7386b84e6b8aa0659a757e6d82a
SHA1: 88673645fcc3324b1afef53ce18159f37bfa24de
CRC32: 99d27118
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --