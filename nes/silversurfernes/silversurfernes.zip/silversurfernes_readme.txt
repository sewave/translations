Silver Surfer (NES)
Traducción al Español v1.0 (19/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Silver Surfer (U) [!].nes
MD5: c6352f73a0ee986e3d8382b5aebfae75
SHA1: 71fa0ce2d49870c3d64130d572854ebb5f25c54c
CRC32: 9a83817c
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --