Arkanoid - Doh It Again (Super Nintendo)
Traducci�n al Espa�ol v1.0 (07/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Arkanoid - Doh It Again (USA).sfc
MD5: 03d30ca9aaa89738640cf14532ddfe6c
SHA1: 6b08e8fa5c17aa3b435bf611aae7db0abb0a878e
CRC32: b50503a0
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --