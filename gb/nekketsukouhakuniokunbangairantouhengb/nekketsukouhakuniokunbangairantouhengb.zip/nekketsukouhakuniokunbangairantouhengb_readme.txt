Nekketsu Kouha Kunio-Kun - Bangai Rantou-Hen (Game Boy)
Traducci�n al Espa�ol v1.0 (09/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking est� basado en la de Ice Translations.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nekketsu Kouha Kunio-Kun - Bangai Rantou-Hen (J) [!].gb
MD5: eb771fb255fa207a830df06338af6d87
SHA1: 28e6edff470613a2abf015c9795581e8e2822029
CRC32: 28e6edff470613a2abf015c9795581e8e2822029
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

Credits	Contributor	Type of contribution	Listed credit
iceman X	Hacking	Hacking & Script Revision
Kitsune Sniper (Foxhack)	Hacking	Title Screen & Script Revision
Aphixe	Translation	
Killer Yoshi	Translation	

-- FIN --