Legend of Galahad, The
Traducci�n al Espa�ol v1.0 (13/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Legend of Galahad, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Legend of Galahad, The
-----------------
Curioso plataformas de electronic arts para la megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Legend of Galahad, The (UE) [!].bin
1.048.576 bytes
CRC32: 679557bc
MD5: 536e5a1ffb50d33632a9978b35db5df6
SHA1: 3368af01da1f3f9e0ea7c80783170aeb08f5c24d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --