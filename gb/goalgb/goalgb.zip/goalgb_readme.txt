Goal! (Game Boy)
Traducción al Español v1.0 (26/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Goal! (U) [!].gb
MD5: 009aea0ac7f214ff6f3c8c070d4a6421
SHA1: 9bb15769b2674d41075b45256dbfffc18483fd84
CRC32: 00d4caf2
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --