Ninja Spirit (Game Boy)
Traducción al Español v1.0 (14/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Spirit (J).gb
MD5: 322965849b9103a3d6906c9697a19c09
SHA1: f983bd9b58ee07204e50c9fdd8a76ba57f2fb40c
CRC32: b864a3b6
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --