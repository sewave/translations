Aaahh!!! Real Monsters (Mega Drive)
Traducción al Español v1.0 (23/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Aaahh!!! Real Monsters (USA).md
MD5: 9f54481697efc9e6b96fcd054883ae70
SHA1: fa579a7e47ee4a1bdb080bbdec1eef480a85293e
CRC32: fdc80bfc
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --