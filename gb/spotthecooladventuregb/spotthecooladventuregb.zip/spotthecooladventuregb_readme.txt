Spot - The Cool Adventure (Game Boy)
Traducción al Español v1.0 (08/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spot - The Cool Adventure (U).gb
MD5: ef5f38b5d7d44df4b187d6d82175e06e
SHA1: 7e80ddc835ecde69ea11c4702a6cfb93575e917a
CRC32: 0e08f59b
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --