Running Battle (Master System)
Traducci�n al Espa�ol v1.0 (10/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Running Battle (E) [!].sms
262.144 bytes
MD5: c32c95222ce705c0c93732a8922f7453
SHA1: 8f680b3a9782304a2f879f6590dc78ea4e366163
CRC32: 1fdae719

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --