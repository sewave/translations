Dropzone (Game Boy)
Traducción al Español v1.0 (19/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dropzone (Europe).gb
MD5: 8b20f7ae1cbfc0b5be6629c0f1553e27
SHA1: 703be7960b363f187737f7ee5fd4af60b6c98428
CRC32: 6cb45fc6
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --