Argus (NES)
Traducción al Español v1.0 (13/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Argus (J) [!].nes
MD5: 8222c0c55f8df3c2ee5290a9d3bac636
SHA1: 8f53765ffac1e34681c5f0edab444fc058a550ed
CRC32: d6396aa7
49168 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --