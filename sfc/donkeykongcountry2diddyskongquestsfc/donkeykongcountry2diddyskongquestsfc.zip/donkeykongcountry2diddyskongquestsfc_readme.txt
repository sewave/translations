Donkey Kong Country 2 - Diddy's Kong Quest (Super Nintendo)
Traducción al Español v1.1 (19/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglos menores, "mirad" y "los letras".

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Donkey Kong Country 2 - Diddy's Kong Quest (U) (V1.1) [!].smc
MD5: d323e6bb4ccc85fd7b416f58350bc1a2
SHA1: 69d0f91bfd05837b44023e33a6699aa28fca19cb
CRC32: 4e2d90f4
4194304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --