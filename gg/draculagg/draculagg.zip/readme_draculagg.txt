Bram Stoker's Dracula (Game Gear)
Traducci�n al Espa�ol v1.0 (24/12/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Bram Stoker's Dracula
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Bram Stoker's Dracula
-----------------
Plataformas basado en la pelicula, bastante logrado.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Bram Stoker's Dracula (U) [!].gg
262.160	bytes
CRC32: 69ebe5fa
MD5: 016e9447e43cc042443f0727721a2e4a
SHA1: ea753b5dce4b319cc1709451a4c8cb55daf2b76b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --