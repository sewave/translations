Side Arms - Hyper Dyne (PC Engine)
Traducción al Español v1.0 (05/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Side Arms - Hyper Dyne (U).pce
MD5: a97b9af7e814deb4e4358a466e7cd3c2
SHA1: 773a372ef5ee599ebd6f048fddb86739e255583e
CRC32: d1993c9f
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --