California Games II (Master System)
Traducción al Español v1.0 (13/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
California Games II (E) [!].sms
MD5: 5ac58b3a7fda23161ab1185b3ee797ac
SHA1: 5c7d99ba54caf9a674328df787a89e0ab4730de8
CRC32: c0e25d62
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --