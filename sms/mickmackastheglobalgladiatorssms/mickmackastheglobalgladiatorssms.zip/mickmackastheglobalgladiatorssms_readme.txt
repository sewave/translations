Mick & Mack as The Global Gladiators (Master System)
Traducci�n al Espa�ol v1.0 (12/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mick & Mack as The Global Gladiators (E) [!].sms
MD5: 73569d2abefb7cdcbe9a13456df525c2
SHA1: e2e2f45e43f0d4fa5974327e96d7c3ee7f057fad
CRC32: b67ceb76
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --