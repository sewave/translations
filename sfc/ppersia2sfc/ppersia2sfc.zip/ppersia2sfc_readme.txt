Prince of Persia 2 - The Shadow & The Flame
Traducci�n al Espa�ol v1.0 (10/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Prince of Persia 2 - The Shadow & The Flame
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Prince of Persia 2 - The Shadow & The Flame
-----------------
Adaptaci�n para Super Nintendo del juego de accion/plataformas de PC.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Prince of Persia 2 - The Shadow & The Flame (U).smc
2.097.152 bytes
CRC32: 50581d9d
MD5: 8eb86c3a88c4faa2cb17e53854f665e2
SHA1: 5a56447af32aaeaa919d2bd22394a515dfcfa6de

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --