Ninja Gaiden (Master System)
Traducción al Español v1.0 (05/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Gaiden (Prototype) [!].sms
MD5: b070dc2ba3f106e89d1e9551f49a0027
SHA1: c67db6539dc609b08d3ca6f9e6f8f41daf150743
CRC32: 761e9396
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --