Silver Eagle (NES)
Traducción al Español v1.0 (11/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Silver Eagle (Asia) (PAL) (Unl).nes
MD5: d4f3e15aa70b625a2f5ba354327da28f
SHA1: 26e6a3b895c7d1bff4c95aa0c55f5fa5997abce7
CRC32: 8e386dd9
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --