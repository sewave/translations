The Adventures of Star Saver (Game Boy)
Traducción al Español v1.0 (12/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Adventures of Star Saver, The (USA, Europe).gb
MD5: 91ecec5f8d06f18724bd1462b53c4b3d
SHA1: 408b19a92c73daa11b3b1a52aa6a987cc6615e97
CRC32: 5d461374
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --