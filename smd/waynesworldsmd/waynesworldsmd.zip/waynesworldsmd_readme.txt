Wayne's World (Mega Drive)
Traducción al Español v1.0 (11/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wayne's World (USA).md
MD5: f0e8150da96d61f7364a020d6c1df07c
SHA1: 2b55be87cd53514b261828fd264108fbad1312cd
CRC32: d2cf6ebe
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --