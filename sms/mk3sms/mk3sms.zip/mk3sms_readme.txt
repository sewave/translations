Mortal Kombat 3 (Master System)
Traducci�n al Espa�ol v1.0 (14/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mortal Kombat 3 (E) [!].sms
524.288 bytes
MD5: 3ba73c09f35ea91bf36cd0b01bc1c044
SHA1: f1f43f57982dd22caa8869a85b1a05fa61c349dd
CRC32: 395ae757

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --