Jumpman Junior (Colecovision)
Traducción al Español v1.0 (03/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jumpman Junior (1984) (Epyx).col
MD5: 5454538f617f2ccf56cb7e0f5a45d11b
SHA1: b79d4312e2d5fc30e37ee46916dc31908c84590e
CRC32: 060c69e8
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --