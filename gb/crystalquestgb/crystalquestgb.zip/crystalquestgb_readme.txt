Crystal Quest (Game Boy)
Traducción al Español v1.0 (25/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Crystal Quest (U) [!].gb
MD5: e15a6b601c845e425f62ef2b7aed691f
SHA1: 6c3ba1e407ff378dc004ac58d6a16180bd76a1b3
CRC32: 51300cfd
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --