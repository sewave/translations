Yeti (ZX Spectrum)
Traducción al Español v1.0 (24/02/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
YETI.TAP
MD5: 7568a7d3da681cb975b6e9f7dd7b87f1
SHA1: 8445ffb88cc8142640f9246c92ea108dc4cd1a07
CRC32: 0536775c
48009 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --