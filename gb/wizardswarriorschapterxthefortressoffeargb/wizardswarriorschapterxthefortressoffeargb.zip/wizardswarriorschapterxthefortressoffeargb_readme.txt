Wizards & Warriors Chapter X - The Fortress of Fear (Game Boy)
Traducción al Español v1.0 (14/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wizards & Warriors Chapter X - The Fortress of Fear (E) [!].gb
MD5: f9445b104ebb70d8fb91c8c64452c0a4
SHA1: 22a514056e58263dc08602778bc3bf2c0ca6e681
CRC32: 104eb503
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --