Alpha Mission (NES)
Traducci�n al Espa�ol v1.0 (16/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alpha Mission (U) [!].nes
MD5: 5cd88979c69262ae982e40a61f93acc9
SHA1: a58f8aa49e7292035ad22a82b67cfe57ebff6c56
CRC32: 02e67223
65.552 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --