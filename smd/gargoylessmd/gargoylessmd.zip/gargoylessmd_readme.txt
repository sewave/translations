Gargoyles (Mega Drive)
Traducción al Español v2.0 (04/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gargoyles (USA).md
MD5: 182b253e376b3ed4c51be1f87a95aa29
SHA1: 2b76764ca1e5a26e406e42c5f8dbd5b8df915522
CRC32: 2d965364
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --