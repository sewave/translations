Puzzle (NES)
Traducción al Español v1.0 (03/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Puzzle (Spain) (Gluk Video) (Unl).nes
MD5: 17afd3e0949e8dcc8ff2ada44f7516a0
SHA1: 4b85a35242485d8d479a3463a115b79f8c0b0c5a
CRC32: 2db8afa2
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --