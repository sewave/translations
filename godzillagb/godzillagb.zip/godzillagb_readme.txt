Godzilla (Game Boy)
Traducción al Español v1.0 (08/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Godzilla (USA, Europe).gb
MD5: e83411adccf5266f2deb263e67b68bc1
SHA1: c0fa19386aa1e325af42e8dd2caf8e66112b9578
CRC32: fe4f80b7
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --