Dynamite Duke (Mega Drive)
Traducción al Español v1.0 (20/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dynamite Duke (W) [!].bin
MD5: f9fa610acdb525e08f73b160eb014557
SHA1: 1bd77ad31665f7bdda85d9dfb9f08c0338ec4da9
CRC32: 39d01c8c
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --