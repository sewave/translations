Top Gun (NES)
Traducción al Español v1.0 (11/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Top Gun (U) (PRG1) [!].nes
MD5: ac956bd3edb35ccc907561d5a98735da
SHA1: 6e233846ca3bb2f50b0176cc31f5cd9667a635f5
CRC32: 0c9a67a8
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --