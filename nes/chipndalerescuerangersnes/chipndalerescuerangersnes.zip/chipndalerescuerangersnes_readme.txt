Chip 'n Dale - Rescue Rangers (NES)
Traducción al Español v2.1 (08/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducido título
-Traducido game over/continue
-Revisión de script
-Traducido menú pausa
V2.1:
-Traducidos gráficos del título
-Arreglado bug al elegir a Chop que salía el icono de Chip
-Cambiado P por V en el estado

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chip 'n Dale - Rescue Rangers (USA).nes
MD5: 785b8003d146cdcc9f3df1c29ea18ead
SHA1: 39a5fdb7efd4425a8769fd3073b00dd85f6cd574
CRC32: e641bd98
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --