Home Alone
Traducci�n al Espa�ol v1.0 (02/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Home Alone
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Home Alone
-----------------
Juego basado en la primera pel�cula de Solo en Casa.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Home Alone (U) [!].sms
262.144	bytes
CRC32: c9dbf936
MD5: b0100ad9f1838332b15d0434bfa9fe29
SHA1: 9b9be300fdc386f864af516000ffa3a53f1613e2

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --