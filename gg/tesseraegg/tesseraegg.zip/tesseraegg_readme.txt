Tesserae (Game Gear)
Traducción al Español v1.0 (05/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tesserae (U) [!].gg
MD5: 5e203cd85b4bc7d81b54d8b407e0f307
SHA1: 2b2652c7e03218b212e4d6a6246bd70e925e7ee1
CRC32: ca0e11cc
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --