Donkey Kong Land III (Game Boy)
Traducción al Español v1.0 (22/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Donkey Kong Land III (U) (V1.1) [S][!].gb
MD5: 333444e90c0bfb99c4ff89fdcb920fe4
SHA1: a6ce883727212e1afb45b48431a46cfbc6f7f6ef
CRC32: a19acdb6
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --