NBA Jam (Game Boy)
Traducción al Español v1.0 (13/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
NBA Jam (U) [!].gb
MD5: 1a4aaf4af4b3610ca74ef3b307b6b2a9
SHA1: ceca1552909acaad74241cb3cef360ebb845ac3b
CRC32: 0ca07cda
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --