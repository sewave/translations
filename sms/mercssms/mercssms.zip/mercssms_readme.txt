Mercs (Master System)
Traducci�n al Espa�ol v1.0 (20/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mercs (E) [!].sms
524.288 bytes
MD5: 7d5696c3da0dbed04b35543f7bdbef40
SHA1: f2cfad96a116bde9a91240eb1ad520dc448fa20f
CRC32: d7416b83

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --