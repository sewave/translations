Street Smart (Mega Drive)
Traducción al Español v1.0 (29/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Street Smart (JU) [!].bin
MD5: 7a926aaea9e526066a75c253738b633c
SHA1: a9cb2295b9cd42475904cba19b983e075a1b6014
CRC32: b1dedfad
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --