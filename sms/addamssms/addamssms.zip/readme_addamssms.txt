Addams Family, The
Traducci�n al Espa�ol v1.0 (10/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Addams Family, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Addams Family, The
-----------------
Plataformas sobre la pelicula, casi identica a la version de game gear.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Addams Family, The (E) [!].sms
262.144	bytes
CRC32: 72420f38
MD5: 09202bc26fcf19ebd3ffcbd80e23ed9d
SHA1: 3fc6ccc556a1e4eb376f77eef8f16b1ff76a17d0

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --