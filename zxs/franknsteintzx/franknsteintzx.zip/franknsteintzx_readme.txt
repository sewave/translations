Frank N Stein (ZX Spectrum)
Traducción al Español v1.1 (16/11/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
-Adaptada traducción al nuevo TZX

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
FrankNStein.tzx
MD5: 0bf326c895ed9749403a18f36098bfa2
SHA1: dfef7becc94586485994a7abd5093372493c2036
CRC32: 37c1c1d1
47918 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --