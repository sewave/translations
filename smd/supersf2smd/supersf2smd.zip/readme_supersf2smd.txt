Super Street Fighter II - The New Challengers
Traducci�n al Espa�ol v1.0 (07/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Super Street Fighter II - The New Challengers
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Super Street Fighter II - The New Challengers
-----------------
Clasico juego de lucha de capcom, para la 16 bits de sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
El menu de opciones, los combos y alguna otra cadena de menus queda por traducir.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Super Street Fighter II - The New Challengers (U) [c][!].bin
5.242.880 bytes
CRC32: 165defbf
MD5: 75950e3aa9357a21715ffe2fa51a454c
SHA1: 9ce6e69db9d28386f7542dacd3e3ead28eacf2a4

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --