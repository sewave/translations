Hypa Raid (ZX Spectrum)
Traducción al Español v1.0 (01/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hypa Raid.tzx
MD5: daa5bc34191115a3fc0b47a3e77b537a
SHA1: dee733d548c9af88d685c8afcd97ab6194f9b8ac
CRC32: 8cba09c3
48271 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --