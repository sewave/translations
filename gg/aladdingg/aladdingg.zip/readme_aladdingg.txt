Aladdin
Traducci�n al Espa�ol v1.0 (31/10/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Aladdin
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Aladdin
-----------------
Que decir, gran plataformas basado en la pelicula de disney para game gear.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Aladdin (U) [!].gg
524.288	bytes
CRC32: 7a41c1dc
MD5: 1ab3a94109af90a333a68479a02a5643
SHA1: 20ba7f5e5c801fbe48a537d2551a3d4525eb63e7

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --