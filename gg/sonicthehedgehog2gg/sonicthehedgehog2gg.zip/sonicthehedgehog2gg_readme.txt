Sonic The Hedgehog 2 (Game Gear)
Traducci�n al Espa�ol v1.0 (19/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sonic The Hedgehog 2 (U) [!].gg
MD5: 9c64846563d8b9a24400471322e53fb5
SHA1: dabb452e416b4fa9cb83d8ddd307c2a32c3a1a7f
CRC32: 95a18ec7
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --