Shadow of the Ninja
Traducci�n al Espa�ol v1.0 (17/12/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Shadow of the Ninja
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Shadow of the Ninja
-----------------
Interesante plataformas ninja con opciond e dos jugadores.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original, se �aden acentos y �.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Shadow of the Ninja (U) [!].nes
262.160	bytes
CRC32: f74a04ab
MD5: d459bae7337c21ce0d380efa86cbbde9
SHA1: c35ea6624d37d57953e4c06197be5c54931a7139

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --