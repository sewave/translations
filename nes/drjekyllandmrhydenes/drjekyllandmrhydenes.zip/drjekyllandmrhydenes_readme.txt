Dr. Jekyll and Mr. Hyde (NES)
Traducci�n al Espa�ol v1.0 (10/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dr. Jekyll and Mr. Hyde (U) [!].nes
163.856 bytes
MD5: cdbc8542700f8d0fceab727a52b8fb62
SHA1: 3385afbdef21c423b7f1db3ada436a184e94dde1
CRC32: c006a41b

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --