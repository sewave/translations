Knights of the Round (Super Nintendo)
Traducción al Español v1.0 (14/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Knights of the Round (USA).sfc
MD5: e2c47c0754f874b2b16d5f06be3dbe34
SHA1: dd0b603b51e9b8d78af67696e0e0ea8f0ab9ccf8
CRC32: aaa82126
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --