The Revenge of Shinobi (Mega Drive)
Traducción al Español v2.0 (16/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Retraducción de script con cadenas ampliadas
-Traducido título
-Traducción de gráficos varios
-Traducidos textos grandes

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Revenge of Shinobi, The (USA, Europe).md
MD5: b7eeed1bd8420ce1d895b2ca46a0643a
SHA1: a88546e159bc882bf05eba66c09a3b21dee4154e
CRC32: 05f27994
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --