To The Earth (NES)
Traducción al Español v1.0 (17/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
To The Earth (U) [!].nes
MD5: 1f9348f7417e31710e215d4904b05cfd
SHA1: 0a030b4c334445ddba4d5dfb6aae0e60f38a8a4a
CRC32: 4137b9b3
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --