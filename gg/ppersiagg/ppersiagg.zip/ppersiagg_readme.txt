Prince of Persia
Traducci�n al Espa�ol v1.0 (01/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Prince of Persia
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Prince of Persia
-----------------
Version para game gear calcada a la de master system de prince of persia.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
No todos los emuladores detectan que es un juego en formato GG-SMS, Emulicious por ejemplo lo ejecuta correctamente.
Si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Prince of Persia (E) [S][!].gg
262.144	bytes
CRC32: 45f058d6
MD5: 197e31dcafea7023cc948fea29c50230
SHA1: 0672814b9fb20dd217141f7853db300343f2c1ea

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --