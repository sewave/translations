Marble Madness (Game Gear)
Traducci�n al Espa�ol v1.0 (03/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Marble Madness (U).gg
MD5: b83f36fd113a8f75f1a29652acb641fc
SHA1: 42c5cd5afebbf860a8ad80ea684f9b216762109e
CRC32: 9559e339
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --