Buggy Run
Traducci�n al Espa�ol v1.0 (19/06/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Buggy Run
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Buggy Run
-----------------
Divertido juego de carreras para la master system.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Buggy Run (E) [!].sms
524.288	bytes
CRC32: b0fc4577
MD5: db41b17f3268d9076e0928911a2791e0
SHA1: 4b1975190ac9d6281325de0925980283fdce51ca

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --