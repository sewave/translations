Punisher, The
Traducci�n al Espa�ol v1.1 (01/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Punisher, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Punisher, The
-----------------
Port del cl�sico beatemup de capcom para megadrive, bastante buena adaptaci�n.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Todo traducido menos las fichas de los jugadores.
v1.1: Arreglado error al elegir 2 jugadores y revisi�n de script.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Punisher, The (U) [!].bin
2.097.152 bytes
CRC32: 695cd8b8
MD5: 0711541847d139a7dae88958b68f92ee
SHA1: 4ef2675e728903925a7b865daa75ed66bbe24829

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --