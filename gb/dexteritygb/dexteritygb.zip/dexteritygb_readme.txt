Dexterity (Game Boy)
Traducción al Español v2.0 (14/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres especiales
-Arreglado bug de pausa
-Traducido P- por J-
-Traducido GAME OVER

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dexterity (USA, Europe).gb
MD5: a58f2b1a317cfb1d60b59f3875f6a9c2
SHA1: 85f0a9ff87ece93097a855d238bc6c7014893c08
CRC32: 659e2283
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --