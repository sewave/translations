Syd of Valis
Traducci�n al Espa�ol v1.1 (21/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Syd of Valis
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Syd of Valis
-----------------
Parodia de los valis anteriores con historia nueva, sencillo y corto.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Arreglada frase "apurada" en la introduccion.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Syd of Valis (U) [!].bin
524.288	bytes
CRC32: 37dc0108
MD5: a81d327574d49aab69c2a6fe4cdc893a
SHA1: 36e010f16791816108d395fce39b39ab0a49268c

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --