Two Crude Dudes (Mega Drive)
Traducci�n al Espa�ol v1.0 (28/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Two Crude Dudes (U) [!].gen
MD5: 36f90726fa2158885d5265bb4b50c8ee
SHA1: e8c2faa0de6d370a889426b38538e75c264c4456
CRC32: 721b5744
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --