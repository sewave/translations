Don Doko Don (NES)
Traducción al Español v1.0 (26/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Don Doko Don (Japan).nes
MD5: 878fdf903b6673b55d95120ab0df50d2
SHA1: 1fbefd95d9e6d2e9c86d098e4cf7b614caaf21f3
CRC32: 6db7e711
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --