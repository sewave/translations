Power Drift (PC Engine)
Traducción al Español v1.0 (16/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Power Drift (Japan).pce
MD5: c7f4c99ccb9f56ef954f3ccf332ce0db
SHA1: 1ffe1111a570b0cca256a356965fd6cdf7bcf2e9
CRC32: 25e0f6e9
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --