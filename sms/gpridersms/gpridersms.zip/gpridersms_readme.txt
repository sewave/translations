GP Rider (Master System)
Traducción al Español v1.0 (08/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
GP Rider (EB) [!].sms
MD5: 1af1cdf8d40c305f936e72b51cb4740d
SHA1: 3083069782c7cfcf2cc1229aca38f8f2971cf284
CRC32: ec2da554
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --