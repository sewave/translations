High School! Kimengumi (Master System)
Traducci�n al Espa�ol v1.0 (09/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking est� basado en la traducci�n al ingl�s de Nick P y Aya H.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
High School! Kimengumi (J) [!].sms
MD5: ab38b53584c89476cd4646105b16083a
SHA1: d3c0aeeacccef77c45ab4219c7d6d8ed04d467cb
CRC32: 9eb1aa4f
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

Credits	Contributor	Type of contribution	Listed credit
Nick P	Hacking	
Aya H	Translation

-- FIN --