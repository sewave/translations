Super Street Fighter II (Mega Drive)
Traducción al Español v2.0 (10/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

-No traducido STAGE-START en las pantallas de bonos
-No traducidos combos de combate

V2.0:
-Guion retraducido y añadidos ¡¿áéíñóú
-Añadidos ÁÉÍÑÓÚ en opciones
-Reescritas fichas de luchadores
-Traducidos gráficos 1P...8P
-Traducidos nombres de los países
-Traducidos varios menús con textos diferentes
-Traducidos gráficos "STAGE SELECT", "ATTACK LEVEL", "ROUND", "BONUS", ...

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Street Fighter II (USA).md
MD5: 75950e3aa9357a21715ffe2fa51a454c
SHA1: 9ce6e69db9d28386f7542dacd3e3ead28eacf2a4
CRC32: 165defbf
5242880 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --