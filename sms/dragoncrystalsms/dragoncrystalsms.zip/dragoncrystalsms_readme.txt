Dragon Crystal (Master System)
Traducción al Español v1.0 (02/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon Crystal (E) [!].sms
MD5: e05484f93011055c5b76ffabfea84367
SHA1: 021c6983fdab4b0215ca324734deef0d32c29562
CRC32: 9549fce4
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --