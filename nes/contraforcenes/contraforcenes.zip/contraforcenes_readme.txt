Contra Force (NES)
Traducción al Español v1.0 (21/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Contra Force (USA).nes
MD5: af7bb9a170ba5728829c3080035e897a
SHA1: 9fa1ee5fcacada43cfda91773c7298c722b7d990
CRC32: 83d69922
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --