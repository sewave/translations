Ninja Gaiden (NES)
Traducción al Español v1.1 (31/08/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
- Aplicadas correcciones informadas por signatux
- Movido acento a tile propio en el título

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Gaiden (USA).nes
MD5: 0c2cccda6ba6cab7bede0ff05e7f6852
SHA1: ca513f841d75efeb33bb8099fb02beeb39f6bb9c
CRC32: 11f953f6
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
signatux - Pruebas.

-- FIN --