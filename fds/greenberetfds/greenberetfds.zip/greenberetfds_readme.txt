Green Beret (Famicom Disk System)
Traducción al Español v1.0 (15/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Green Beret (Japan).fds
MD5: 06dc760df96a2573ffc6998aac7a7e5d
SHA1: 45c596f097abc975c114cedd0fd27615f0cee1e5
CRC32: 576f8809
131000 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --