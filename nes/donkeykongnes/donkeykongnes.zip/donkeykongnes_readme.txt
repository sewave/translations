Donkey Kong (NES)
Traducci�n al Espa�ol v1.0 (29/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Donkey Kong (U) (PRG1) [!].nes
MD5: 40319cad12c80fc095901eb0182df838
SHA1: d8dfacbfec34cdc871d73c901811551fe1706923
CRC32: e40b593b
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --