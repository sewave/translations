Bomberman (NES)
Traducci�n al Espa�ol v1.0 (11/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bomberman (U) [!].nes
MD5: 97ddb647898b01065f395eb64c3d131f
SHA1: 12531701e633d2196c9a15f944b101a8205248e4
CRC32: b9804046
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --