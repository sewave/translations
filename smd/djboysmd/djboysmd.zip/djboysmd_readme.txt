DJ Boy (Mega Drive)
Traducci�n al Espa�ol v1.0 (12/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
DJ Boy (U) [!].bin
MD5: 6aef0333e2b1a495c867577ccf037493
SHA1: 981f0eeffa28210cc55702413305244aaf36d71c
CRC32: dc9f02db
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --