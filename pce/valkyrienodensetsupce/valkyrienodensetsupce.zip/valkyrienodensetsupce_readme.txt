Valkyrie no Densetsu (PC Engine)
Traducci�n al Espa�ol v1.0 (27/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking est� basada en la traducci�n al ingl�s de cabbage y Shawn Cox.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Valkyrie no Densetsu (Japan).pce
524.288	bytes
MD5: f08a37d37a69315652e1a0ec8dbba650
SHA1: 2054898ae28f962d2e20cdaca62e8b88e932f304
CRC32: a3303978

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

Original:
cabbage - Hacking	
Shawn Cox - Translation

-- FIN --