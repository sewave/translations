No Escape (Mega Drive)
Traducción al Español v1.0 (20/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
No Escape (USA).md
MD5: c4d5c13d6ef3184fd5e123668f035fae
SHA1: d72302927b618165cd94ec2e072c8d8bbf85cbb9
CRC32: 44ee5f20
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --