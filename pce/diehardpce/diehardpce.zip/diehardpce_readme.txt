Die Hard
Traducci�n al Espa�ol v1.1 (27/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Die Hard
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Die Hard
-----------------
Adaptaci�n (libre) de la pelicula "la jungla de cristal".
v1.1: Parche para rom japonesa.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basada en la de Spinner 8 and friends.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Die Hard (Japan).pce
524.288	bytes
CRC32: 1b5b1cb1
MD5: 7dd298a6e9f2abce6f85d262ec37f483
SHA1: 96aeca126bb6ac0ca0df5ee260a8a1ee25f44d6d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al espa�ol

Versi�n en ingl�s
Spinner 8 Hacking
DarknessSavior Translation

-- END OF README --