Alien Soldier (Mega Drive)
Traducción al Español v1.0 (14/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alien Soldier (Japan).md
MD5: fd04c4616bb559e646937effdd343a09
SHA1: 8f6eb584ed9487b8504fbc21d86783f58e6c9cd6
CRC32: 90fa1539
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --