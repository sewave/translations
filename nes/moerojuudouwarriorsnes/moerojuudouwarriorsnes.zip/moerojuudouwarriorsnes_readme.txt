Moero!! Juudou Warriors (NES)
Traducción al Español v1.1 (27/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de MrRichard999.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado "UNE" por "UNA"

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Moero!! Juudou Warriors (Japan).nes
MD5: 8a1b591d066afea9010ea40f52090568
SHA1: 31bda7025cdd017c55cc3a44dc03be2ec50b4a42
CRC32: 0a186cd1
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --