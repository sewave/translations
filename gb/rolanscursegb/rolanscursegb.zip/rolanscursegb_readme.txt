Rolan's Curse (Game Boy)
Traducción al Español v1.0 (13/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rolan's Curse (U) [!].gb
MD5: ebd1866dc6c13ca48f45538ed33ea46f
SHA1: d5eeb34b24691eb6895d3349a05e2a75d910cf16
CRC32: 1a602590
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --