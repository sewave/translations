King's Valley 2 (MSX)
Traducción al Español v1.0 (13/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
King's Valley 2 (1988) (Konami) (J).rom
MD5: 2f8a812f46e09e39dd3d0da8524ee96c
SHA1: cfd872d005b7bd4cdd6e06c4c0162191f0b0415d
CRC32: e82a8e8e
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --