Twin Cobra
Traducci�n al Espa�ol v1.0 (26/06/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Twin Cobra
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Twin Cobra
-----------------
Shoot em up port del arcade a la 8 bits de nintendo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Twin Cobra (U) [!].nes
262.160	bytes
CRC32: 24643875
MD5: 71109c1c36462be5b1f42467070c268c
SHA1: 029ec13b5ce19b1566a93467b4227cbeb411edee

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --