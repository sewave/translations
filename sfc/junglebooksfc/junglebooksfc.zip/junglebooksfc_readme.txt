The Jungle Book (Super Nintendo)
Traducci�n al Espa�ol v1.0 (05/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jungle Book, The (U).smc
MD5: cf539bef183bcb97c192562bb1cb29ec
SHA1: f9dbb76fb1a62d47f8de4e7db46bfbcb1a038ca5
CRC32: 3511efb3
2.097.152 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --