Fire & Forget 2 (Master System)
Traducci�n al Espa�ol v1.0 (27/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fire & Forget 2 (E) [!].sms
MD5: d27d8fee8f711db361a71817864bd139
SHA1: f934b35d27330cc2737d6a2d590dcef56004b983
CRC32: f6ad7b1d
262144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --