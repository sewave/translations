Captain Silver (Master System)
Traducci�n al Espa�ol v1.0 (01/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Captain Silver (U) [!].sms
MD5: 1dfaadbfe7d8019e73bd980fd4b819ea
SHA1: 7c2b23f4a806c89a533f27e190499243e7311c47
CRC32: b81f6fa5
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --