Loopz (NES)
Traducción al Español v1.0 (12/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Loopz (USA).nes
MD5: 68e6703d179596cb1d4e9ee6278efd0e
SHA1: 5fff85f9dfdce9c3800d8b78c5350f1bc094da12
CRC32: ce84bf41
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --