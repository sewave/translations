Duck Tales 2
Traducci�n al Espa�ol v1.1 (17/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Duck Tales 2
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Duck Tales 2
-----------------
Segunda parte de las Patoaventuras para la 8 bits de nintendo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Arreglado final.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Duck Tales 2 (U) [!].nes
131.088	bytes
CRC32: 40ce2fc0
MD5: ee092394b1e64b8bee7ca54c3dc7faad
SHA1: 76093ea07a16fdaa8aa58730fd29b4977a264b5e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --