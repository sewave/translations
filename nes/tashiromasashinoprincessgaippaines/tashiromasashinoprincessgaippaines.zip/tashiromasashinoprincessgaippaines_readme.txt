Tashiro Masashi no Princess ga Ippai (NES)
Traducción al Español v1.0 (27/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Suicidal Translations.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tashiro Masashi no Princess ga Ippai (Japan).nes
MD5: 87f0b9fd185ae0f6e643f18a192f782a
SHA1: fc7f85103b5f5daca4325203325fa4b1c565a125
CRC32: 7b5a1e17
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --