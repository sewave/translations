Frogger (Game Gear)
Traducción al Español v1.0 (10/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Frogger (Prototype) [!].gg
MD5: 0d78ea34987ae32f1ce844a3f647189f
SHA1: b917ac6fbd3e5d18c07246f1309d81943ee1dd47
CRC32: 02bbf994
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --