Urban Strike (Game Gear)
Traducción al Español v1.0 (07/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Urban Strike (USA).gg
MD5: e6bc90f958617e9bde26367b5348518c
SHA1: 2d33d049a7f3dcde8c4f294cca5597ca590bb407
CRC32: 185e9fc1
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --