Dragon's Eye Plus - Shanghai III (Mega Drive)
Traducción al Español v1.0 (20/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon's Eye Plus - Shanghai III (Japan).md
MD5: 3e92d413ca258268cc138e545cea52b1
SHA1: b5a2a3b0b65058614d24853c525505b709f00851
CRC32: 81f0c3cf
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --