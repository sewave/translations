Batman Beta (NES)
Traducci�n al Espa�ol v1.0 (19/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batman (U) (Older Beta).nes
o
Batman (U) (Earlier Proto).nes
MD5: 87ccb4ffae82f46857c3b6f1f19914d4
SHA1: 2a5708d6855639b82ff724466a004e493da480bb
CRC32: abf9d9ea
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --