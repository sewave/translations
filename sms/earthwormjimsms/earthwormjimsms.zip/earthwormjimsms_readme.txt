Earthworm Jim (Master System)
Traducci�n al Espa�ol v1.0 (24/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Earthworm Jim (B) [!].sms
524.288 bytes
MD5: f26bf8d41e0b6159fc436567b447363f
SHA1: a1966c2d8e75ea17df461a46c4a1a8b0b5fecd4e
CRC32: c4d5efc5

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --