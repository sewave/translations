Master of Darkness (Master System)
Traducci�n al Espa�ol v1.2 (16/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
v1.2: Corregida pantalla de CONTINUAR.
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Master of Darkness (UE) [!].sms
262.144	bytes
CRC32: 96fb4d4b
MD5: 8354932a7f20e84a808471b3724a56f8
SHA1: ed3569be5d5a49ff5a09b2b04ec0101d4edfa81e

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --