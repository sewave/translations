Quattro Sports (NES)
Traducción al Español v1.0 (07/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Pro Tennis no está traducido ya que usa pantallas comprimidas para los textos.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Quattro Sports (USA) (Unl).nes
MD5: 38bd9ef3c809da0d6f35315e5eb9c543
SHA1: 66b0aea42d030ccd1f240bd22a484cffb5408067
CRC32: 9adc4130
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --