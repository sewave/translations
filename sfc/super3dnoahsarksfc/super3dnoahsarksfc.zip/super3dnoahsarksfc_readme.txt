Super 3D Noah's Ark (Super Nintendo)
Traducción al Español v1.0 (05/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super 3D Noah's Ark (USA) (Unl).sfc
MD5: 7ac06e83800051995bbd2189d1415063
SHA1: 78d50ce39528cf4232f2eeb34b475fe830ed3e72
CRC32: a2315a14
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --