Halley Wars (Game Gear)
Traducción al Español v1.0 (26/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Halley Wars (U) [!].gg
MD5: 1ef93397c3c6d2049b0701d69255a22b
SHA1: 77637e9916a774529d971370c1509eec0b7e1651
CRC32: 7e9dea46
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --