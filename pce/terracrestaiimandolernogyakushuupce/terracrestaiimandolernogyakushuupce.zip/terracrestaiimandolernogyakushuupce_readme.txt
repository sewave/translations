Terra Cresta II - Mandoler no Gyakushuu (PC Engine)
Traducción al Español v1.0 (26/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Terra Cresta II - Mandoler no Gyakushuu (Japan).pce
MD5: 64716e1013c5230e25f0249d8e641d5b
SHA1: c58d3ea8df6cb518349d431d6b3d6fd2c14898ec
CRC32: 1b2d0077
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
Sensenic - Traducción del japonés.

-- FIN --