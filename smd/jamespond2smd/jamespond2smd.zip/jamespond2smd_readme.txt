James Pond II - Codename RoboCod (Mega Drive)
Traducci�n al Espa�ol v1.0 (05/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
James Pond II - Codename RoboCod (UE) [!].bin
MD5: bb689dd3822853a5417cdec4a3da114b
SHA1: e00c9ab1f22aeed3031ed9dd985539aa6e31a7a4
CRC32: f4abedba
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --