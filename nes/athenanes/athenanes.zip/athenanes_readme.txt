Athena (NES)
Traducción al Español v1.0 (22/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Athena (U) [!].nes
MD5: 766b9bdb269df5a3f409a08d7b615bf0
SHA1: 8526bf8919b36a891af39cfe447186fb5795af28
CRC32: 14d42113
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --