Goonies (NES)
Traducción al Español v1.0 (12/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Goonies (Japan).nes
MD5: 460d3e6805496c35d630f538d01e68e4
SHA1: 78e80a5bdf23feb5f287fda15a9bffa4431fc7ba
CRC32: 5589af04
49168 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --