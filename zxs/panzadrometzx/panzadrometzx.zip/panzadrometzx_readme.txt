Panzadrome (ZX Spectrum)
Traducción al Español v1.0 (11/10/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Panzadrome.tzx
MD5: 9a5128cd9298d6fc04ba8153383e20c3
SHA1: ead77ea60a61357e12e0705072e841e170541808
CRC32: aa9786a5
48757 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --