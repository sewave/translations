Battletoads in Battlemaniacs (Super Nintendo)
Traducción al Español v1.0 (09/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battletoads in Battlemaniacs (USA).sfc
MD5: e44b9987e33ef7237b24457a6c997723
SHA1: 3041c5c2a88449cf358a57d019930849575f8f6d
CRC32: 617ac925
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --