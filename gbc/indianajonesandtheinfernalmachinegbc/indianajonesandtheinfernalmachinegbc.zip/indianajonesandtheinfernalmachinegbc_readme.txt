Indiana Jones and the Infernal Machine (Game Boy Color)
Traducción al Español v1.0 (08/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Indiana Jones and the Infernal Machine (USA, Europe) (En,Fr,De).gbc
MD5: 4adc91b001cf02dc42d2c0339535b8f9
SHA1: 6d568438aa3b9b67c55aded582cec136b15c46d7
CRC32: 7fff1142
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --