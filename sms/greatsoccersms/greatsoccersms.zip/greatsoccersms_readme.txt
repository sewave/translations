Great Soccer (Master System)
Traducción al Español v1.0 (10/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Great Soccer (E) [!].sms
MD5: 5c9815b45b5cb3d9b3436c56c6fcadaf
SHA1: 7d1a381be96474f18ba1dac8eaf6710010b0e481
CRC32: 0ed170c9
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --