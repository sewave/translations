Battleship (Game Gear)
Traducci�n al Espa�ol v1.0 (27/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battleship (U) [!].gg
MD5: ba836ae19e88f6354d746a86582beff8
SHA1: eae1ebec2c1be522924f669a2dc884f9f4a68cf3
CRC32: fddd8cd9
65.536 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --