Bravoman (PC Engine)
Traducción al Español v1.0 (25/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bravoman (USA).pce
MD5: f60f3d46b7fab6060c3be9aad2103558
SHA1: 6fb31af03a5370c5c9bc280e0f8f8169d114150b
CRC32: cca08b02
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --