Clue (Mega Drive)
Traducción al Español v1.1 (27/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Pequeños arreglos.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Clue (USA).md
MD5: b570c484099ee0cb5ade264a4ea45db5
SHA1: d1f9114f41a3d6237e24392629fea5fbeb3f0b87
CRC32: 7753a296
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --