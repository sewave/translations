3D Starstrike (ZX Spectrum)
Traducción al Español v1.0 (25/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
3D Starstrike.tzx
MD5: 7eccd27be4a13548882756d195ec10f8
SHA1: 853e71ecf5b021471e82872dc0f835bc2396cfa6
CRC32: 65d1d056
49169 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --