Castle of Deceit (NES)
Traducci�n al Espa�ol v1.0 (16/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Castle of Deceit (Bunch) [!].nes
MD5: 5cb37d0e566c5aa2e6445630cc390a62
SHA1: 0ddf18b2eb1c9d44829b9eb19d2655a310fecf68
CRC32: 02e20d38
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --