Power Blade 2
Traducci�n al Espa�ol v1.0 (18/05/2018)
(C) 2018 Traducciones Wave

---
TdC
---

1. Sobre Power Blade 2
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Power Blade
-----------------
Power Blade 2 es un juego de plataformas.
Este parche lo traduce completamente al espa�ol y a�ade ��������.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
A�adidos ��������, cambiados gr�ficos de STAGE, POW, Trajes, Vida, CHANGE y el gracias del final.
v0.91: cambiada rom compatible a version goodnes
V1.0: revisi�n de script

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Hay 2 o 3 cutscenes donde es obligatorio utilizar solo mayusculas sin acentos, una pena :(, si encuentras alguno mas puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Power Blade 2 (U) [!].nes
262.160 bytes
CRC32: f8e0bc9b
MD5: 7c48ad4d6b511f7ce6530c46f8179d9c
SHA1: cbd35c583d99d2181f0e482666adff3fb8456d74

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --