Batman Returns
Traducci�n al Espa�ol v1.0 (07/09/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Batman Returns
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Batman Returns
-----------------
Un beat em up bastante logrado para la 8bits.
Este parche lo traduce completamente al espa�ol.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es original y solo a�ade la � como caracter especial.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Batman Returns (U) [!].nes
393.232 bytes
CRC32: e625e398
MD5: 1fe9c970c5c04aec359a833820718e6a	
SHA1: 43a0fee6878cdf35288395524923cb8c61e6974a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al Espa�ol

-- END OF README --