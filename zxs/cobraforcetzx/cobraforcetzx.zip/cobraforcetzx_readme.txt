Cobra Force (ZX Spectrum)
Traducción al Español v1.0 (29/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cobra Force.tzx
MD5: 62c33a91263d3b19e613724d1a355105
SHA1: a84239fc461fe3508eb8179c5058cb1e4e90e4da
CRC32: 5f2c9f5e
54643 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --