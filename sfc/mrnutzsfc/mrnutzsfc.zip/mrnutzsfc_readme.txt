Mr. Nutz (Super Nintendo)
Traducci�n al Espa�ol v1.0 (25/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mr. Nutz (U).smc
MD5: f5889db38b2152fde80258c3a89f6a83
SHA1: e803e7c067832c3a2604463e2262728117efeca4
CRC32: a99bdd9a
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --