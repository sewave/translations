Worms (Mega Drive)
Traducción al Español v1.0 (17/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Worms (E) [!].bin
MD5: 0d53ce8f8d060900805b798a1d9d2579
SHA1: 1a15447a4a791c02b6ad0a609f788d39fe6c3aa6
CRC32: b9a8b299
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --