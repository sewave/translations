F-1 Sensation (NES)
Traducción al Español v1.2 (09/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Varios arreglos.
V1.2: Varios arreglos.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
F-1 Sensation (J).nes
MD5: 432309cdcb51256b64cd0645746d78ae
SHA1: 04aeededf0c42b214acfbe6e03e5c63171d67797
CRC32: 6a2be608
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --