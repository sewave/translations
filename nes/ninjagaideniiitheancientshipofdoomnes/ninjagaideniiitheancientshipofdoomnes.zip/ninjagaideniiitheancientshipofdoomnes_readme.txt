Ninja Gaiden III - The Ancient Ship of Doom (NES)
Traducción al Español v1.1 (31/08/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
- Movido gráfico de coma un poco a la izquierda para no pegarse tanto a la siguiente palabra
- Aplicadas correcciones informadas por signatux y Jackic
- Aplicados gráficos de la pantalla de título de Terwilf

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Gaiden III - The Ancient Ship of Doom (USA).nes
MD5: 8a551c78e96e93782e5a0cfb263eb96b
SHA1: 6ade8f54951843fccc46fc8be439e6c56d56b14f
CRC32: 4d26fa27
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
Terwilf - Gráficos del título.
signatux - Pruebas.
Jackic - Pruebas.

-- FIN --