Teenage Mutant Ninja Turtles - The Hyperstone Heist (Mega Drive)
Traducción al Español v2.0 (10/02/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducción parcial de opciones del título
-Traducido texto mini-intro
-Traducida barra de estado
-Traducido "PAUSE"
-Añadidos caracteres españoles a intro
-Traducidos nombres de escenas
-Guion retraducido
-Créditos HARD mejorados
-Traducido mensaje "MASTER" al derrotar a Tatsu.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles - The Hyperstone Heist (USA).md
MD5: 30ede62c8efe3e046e5409758b091eb6
SHA1: f440dfa689f65e782a150c1686ab90d7e5cc6355
CRC32: 679c41de
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --