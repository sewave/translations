Alien 8 (MSX)
Traducción al Español v1.0 (30/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alien 8 (Japan).rom
MD5: 2d71ca6a0ee125631020ebd7b2aa791c
SHA1: 5fb90be078e432db92dd39e621d12f612dbea4a8
CRC32: 93a25be1
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --