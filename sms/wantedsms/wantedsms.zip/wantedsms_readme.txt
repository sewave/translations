Wanted (Master System)
Traducción al Español v1.0 (19/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wanted (UE) [!].sms
MD5: 0070737ddb0a2e5e822f1d8f46437b07
SHA1: 6135e4d0f76812f9d35ddb5b3e7d34d56a5458b3
CRC32: 5359762d
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --