Trouble Shooter 
Traducci�n al Espa�ol v1.0 (26/06/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Trouble Shooter 
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Trouble Shooter 
-----------------
Shoot em up original de la 16 bits de sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Trouble Shooter (U) [!].bin
524.288	bytes
CRC32: becfc39b
MD5: f29c5049a48f37a37b811a22dc731e3c
SHA1: 3fc9ffa49ece5e9cbba1f2a5ba1dfd068b86c65d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --