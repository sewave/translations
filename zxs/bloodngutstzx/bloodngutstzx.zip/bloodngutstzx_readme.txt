Blood 'n' Guts (ZX Spectrum)
Traducción al Español v1.0 (04/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blood 'n' Guts.tzx
MD5: 796c6a5e5a6fee6773d0b0c21a8730b3
SHA1: 4392683ab039490bf63d5f438d0a2880e94c2cf8
CRC32: 2093ee93
49424 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --