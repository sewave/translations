Hugo (Game Boy)
Traducción al Español v1.0 (16/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hugo (Europe) (SGB Enhanced).gb
MD5: 6c960f0e87a857a7b49ef08484f79ce0
SHA1: d314dffcf5fb441d5d6d6419e01dc825e90cf0fc
CRC32: 74aa5e0f
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --