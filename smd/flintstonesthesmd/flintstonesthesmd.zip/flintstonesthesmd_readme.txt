The Flintstones (Mega Drive)
Traducción al Español v2.0 (07/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Alargadas cadenas
-Retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Flintstones, The (USA).md
MD5: 60ea3535c8a939d26ded83bde0f4809d
SHA1: 5541579ffaee1570da8bdd6b2c20da2e395065b0
CRC32: 7c982c59
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --