Dr.Acula (ZX Spectrum)
Traducción al Español v1.0 (13/07/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
DrAcula.tzx
MD5: 4225b36af96a82dcc4c8a2fcb27d120d
SHA1: e9493ab1909fbdeba2765188a2959d2d8f28e73a
CRC32: e52c939b
46708 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --