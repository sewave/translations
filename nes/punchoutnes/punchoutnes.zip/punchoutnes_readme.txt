Punch-Out!! (NES)
Traducci�n al Espa�ol v1.1 (28/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
v1.1: Arreglado t�tulo, algunos textos, cambiado �Lucha! por �Pelea! y a�adidos � y �.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Punch-Out!! (U) [!].nes
MD5: 3e4af91097aece830b3039af3f2c0802
SHA1: 025faf9059c06d6706409b66fb0cb2ee17deb548
CRC32: a827ff1b
262160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --