Ashura (Master System)
Traducción al Español v1.0 (20/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ashura (J) [!].sms
MD5: e5693a4806de29ea9b1e1b5fea1a9566
SHA1: e9f90d63320295e4bd9a87e6078186c5efb7e84e
CRC32: ae705699
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --