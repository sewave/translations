SWAT Kats - The Radical Squadron (Super Nintendo)
Traducción al Español v1.0 (24/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
SWAT Kats - The Radical Squadron (USA).sfc
MD5: 8e9e2d07222dcefa13adf2bab05b1776
SHA1: aa9ebe608e934607ade003e0821c11e4c6eae8de
CRC32: ea2a23fb
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --