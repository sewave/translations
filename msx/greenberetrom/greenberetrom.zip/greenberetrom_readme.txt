Green Beret (MSX)
Traducción al Español v1.0 (13/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Green Beret (1986)(Konami).rom
MD5: 697f6a318b187510655a28f3a0fe698d
SHA1: 3ea788262557f578b25e4e36e61c1cf9fb1155d1
CRC32: 61f41bcd
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --