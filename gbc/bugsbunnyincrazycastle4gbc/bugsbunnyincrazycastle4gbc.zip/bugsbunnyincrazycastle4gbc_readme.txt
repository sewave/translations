Bugs Bunny in Crazy Castle 4 (Game Boy Color)
Traducción al Español v1.0 (01/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bugs Bunny in Crazy Castle 4 (USA).gbc
MD5: 0877a4b1765287c5b50ea53a47a1d7ad
SHA1: a22b9765e901b2a23a48c44b0b829ab73b9c1a82
CRC32: 98dbffe0
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --