Madoola no Tsubasa (NES)
Traducción al Español v1.0 (28/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Madoola no Tsubasa (Japan).nes
MD5: 7d79e975ec418bc465b976696ddc84ea
SHA1: 25cdee719399cdf7624e1a3d2addce1898db439b
CRC32: 929899d8
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --