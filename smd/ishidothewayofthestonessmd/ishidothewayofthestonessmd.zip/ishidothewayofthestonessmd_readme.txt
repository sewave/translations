Ishido - The Way of the Stones (Mega Drive)
Traducción al Español v1.0 (24/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ishido - The Way of the Stones (U) [c][!].bin
MD5: 30ee5ae0e2a4b2995a79173f67278c69
SHA1: 3bd159e323d86e69031bf1ee9febeb6f9bb078d4
CRC32: b1de7d5e
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --