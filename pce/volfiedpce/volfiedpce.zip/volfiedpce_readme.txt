Volfied (PC Engine)
Traducción al Español v1.0 (19/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Volfied (Japan).pce
MD5: 998cfe18bf12b235462d21eb6d80c25f
SHA1: 0ecee557815b93fc37f2f5675c2c01c77ef8569e
CRC32: ad226f30
393216 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --