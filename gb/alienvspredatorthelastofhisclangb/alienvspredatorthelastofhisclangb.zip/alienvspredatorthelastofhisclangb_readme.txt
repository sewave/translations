Alien vs Predator - The Last of His Clan
Traducci�n al Espa�ol v1.0 (15/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Alien vs Predator - The Last of His Clan
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alien vs Predator - The Last of His Clan
-----------------
Plataformas de alien vs predator.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alien vs Predator - The Last of His Clan (U) [!].gb
131.072	bytes
CRC32: 4bbcf652
MD5: 50a208bd0a223c037e01ffe07b04fa5b
SHA1: c0d39ee87b908cdbd68c59f73e5dc2a7a6ccbedc

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --