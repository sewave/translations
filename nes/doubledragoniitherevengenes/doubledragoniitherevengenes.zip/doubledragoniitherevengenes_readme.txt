Double Dragon II - The Revenge (NES)
Traducci�n al Espa�ol v1.0 (17/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Dragon II - The Revenge (U) (PRG1) [!].nes
262.160 bytes
MD5: b94be0bf2e861bca19339920cd786f53
SHA1: e4fbbe69b3b539b198ae0e037fdc2558074a283f
CRC32: a0f7027d

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --