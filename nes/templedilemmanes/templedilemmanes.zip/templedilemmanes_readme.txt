Temple Dilemma (NES)
Traducción al Español v1.0 (01/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Temple Dilemma (USA) (Aftermarket) (Unl).nes
MD5: e1c4883cff22ec45ca027496fa813e62
SHA1: 4da2382ab21827c7102eeabb184892ba530e6911
CRC32: ba482267
524304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --