Tecmo World Cup Soccer (NES)
Traducción al Español v1.0 (17/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tecmo World Cup Soccer (Japan).nes
MD5: 87061d9afddeaea479a0616f3ef870f5
SHA1: 6f44cd9456563f5c6898b53221d96cffdb5199b4
CRC32: 19f24980
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --