Greendog - The Beached Surfer Dude
Traducci�n al Espa�ol v1.0 (24/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Greendog - The Beached Surfer Dude
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Greendog - The Beached Surfer Dude
-----------------
Curioso plataformas playero para megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Greendog - The Beached Surfer Dude (UE) [!].bin
524.288	bytes
CRC32: c4820a03
MD5: 12199da6628b92c9bbd59460ae602a8c
SHA1: fe47514e9aeecabaed954a65d7241079dfec3d9e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --