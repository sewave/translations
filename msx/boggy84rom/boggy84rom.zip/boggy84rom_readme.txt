Boggy'84 (MSX)
Traducción al Español v1.0 (18/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Boggy'84 (1984) (Nippon Columbia) (J).rom
MD5: ed3620892fb8a70154732ffac6f0b1ef
SHA1: 5c96169207e197237aa728d8ce4e24c0635d5904
CRC32: ec089246
8192 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --