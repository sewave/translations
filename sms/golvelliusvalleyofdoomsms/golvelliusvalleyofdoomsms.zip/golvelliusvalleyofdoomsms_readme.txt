Golvellius - Valley of Doom (Master System)
Traducción al Español v1.0 (17/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Golvellius - Valley of Doom (UE) [!].sms
MD5: 2101295c258cb6b845bdb72be617691d
SHA1: cb8c2de9a8e91c0e4e60e5d4d9958e671d84da4c
CRC32: a51376fe
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --