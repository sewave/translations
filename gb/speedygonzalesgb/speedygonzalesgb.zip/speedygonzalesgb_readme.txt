Speedy Gonzales (Game Boy)
Traducción al Español v1.0 (02/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Speedy Gonzales (USA, Europe).gb
MD5: 7e1bedf88581ee7370c8eb86c6863e2c
SHA1: 805be36b4701dda53b967c0153b9bfcc2c059f75
CRC32: 27cde8d6
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --