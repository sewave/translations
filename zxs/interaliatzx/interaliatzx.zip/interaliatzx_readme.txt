Interalia (ZX Spectrum)
Traducción al Español v1.0 (04/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Interalia.tzx
MD5: 5a3531204b18d4109af1df5a58b1f430
SHA1: 7068aca79c729fc8361677415d1c868c0be2fae8
CRC32: b912e1ef
50575 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --