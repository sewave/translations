Böbl (NES)
Traducción al Español v1.0 (02/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
böbl-1.1.nes
MD5: 60a240bced6110c602eed4462d78d523
SHA1: 48347620ac8d6d643763dcfac08c43b59f8b075f
CRC32: 831956ea
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --