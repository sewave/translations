Mega SWIV (Mega Drive)
Traducci�n al Espa�ol v1.0 (03/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mega SWIV (E).bin
MD5: 1e29842b5721eb1845bb55e0a2e31cef
SHA1: 6396fb0f204c9f23d0af0b39d069ff0883e191aa
CRC32: 78c2f046
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --