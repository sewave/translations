Kyuukyoku Tiger (PC Engine)
Traducción al Español v1.0 (15/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kyuukyoku Tiger (Japan).pce
MD5: 467c1ee6a921a3bbb4a94fc078f7353d
SHA1: e062b7e1fe9fe04f9c29df38165e3a4eb867fe2d
CRC32: 09509315
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --