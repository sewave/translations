Shadow Blasters (Mega Drive)
Traducción al Español v1.0 (15/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shadow Blasters (U) [c][!].bin
MD5: 3593e0995aa5ac87bf54e54da56e4631
SHA1: 8485453264fd67ff8e4549a9db50b4f314a6fcb5
CRC32: 713d377b
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --