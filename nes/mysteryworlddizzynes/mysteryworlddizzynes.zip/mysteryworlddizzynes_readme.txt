Mystery World Dizzy (NES)
Traducción al Español v1.0 (12/10/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
MysteryWorldDizzy.nes
MD5: bce510e6901972a9fe531b2fb603d80e
SHA1: a0dbcbd3f32c43653205a85a6c4c11983a54b0f3
CRC32: 03124bf3
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --