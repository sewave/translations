Deep Duck Trouble
Traducci�n al Espa�ol v1.0 (08/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Deep Duck Trouble
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Deep Duck Trouble
-----------------
Plataformas de Donald.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Deep Duck Trouble (E) [!].sms
524.288	bytes
CRC32: 42fc3a6e
MD5: 05e3071aad9c36b6e18f1656592eeb3d
SHA1: 26ec82b96650a7329b66bf90b54b869c1ec12f6b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --