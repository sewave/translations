Mr. Nutz (Mega Drive)
Traducci�n al Espa�ol v1.0 (25/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mr. Nutz (E) [!].bin
MD5: 00ee0a02b8794b32584ea1aabadd4580
SHA1: 318ff3a44554b75260d5b9b9e7b81a3cfd07581a
CRC32: 0786ea0b
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --