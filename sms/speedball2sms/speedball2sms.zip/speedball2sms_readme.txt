Speedball 2 (Master System)
Traducción al Español v1.0 (07/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Speedball 2 (Europe).sms
MD5: b37e0c8177c4792594356b11757f9ac5
SHA1: 4e0b456441f0acef737e463e6ee5bbcb377ea308
CRC32: 0c7366a0
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --