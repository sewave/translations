Sukeban Deka 2 (Master System)
Traducción al Español v1.0 (08/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basada en la de enigmaopoeia	y SSTranslationsinal.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sukeban Deka 2 (J) [!].sms
MD5: e80ce989b68b1faa5e40016ce7b096fe
SHA1: 5cd041990c7418ba63cde54f83d3e0e323b42c3b
CRC32: b13df647
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
Credits	Contributor	Type of contribution	Listed credit
Stephen Seehorn	Hacking	
enigmaopoeia	Translation

-- FIN --