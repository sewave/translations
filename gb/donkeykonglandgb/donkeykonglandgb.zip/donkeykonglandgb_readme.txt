Donkey Kong Land (Game Boy)
Traducción al Español v1.0 (29/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Donkey Kong Land (U) [S][!].gb
MD5: 89bb0d67d5af35c2ebf09d9aef2e34ad
SHA1: 4e6d8f085ca197479d59912c1d58e4f3b40c28ac
CRC32: 49dc0d37
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --