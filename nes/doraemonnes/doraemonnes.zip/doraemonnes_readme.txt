Doraemon (NES)
Traducción al Español v1.0 (25/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de Sky Yoshi.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Doraemon (Japan) (Rev A).nes
MD5: 690968b1c1927e7a4169dc48940d5e55
SHA1: 20c5e40ab706a637d0572b1549eeff9a0048a065
CRC32: 2768309d
163856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --