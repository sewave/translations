NBA Jam - Tournament Edition (Game Boy)
Traducción al Español v1.0 (16/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
NBA Jam - Tournament Edition (USA, Europe).gb
MD5: 802cfbc386bb79b0889d7dd2b6abdc13
SHA1: 981de2c70a2dfb5ae829d39cc5f302815780e771
CRC32: 27d74c50
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --