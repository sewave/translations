Masters of Combat
Traducci�n al Espa�ol v1.0 (22/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Masters of Combat
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Masters of Combat
-----------------
Juego de lucha con algo de historia.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Masters of Combat (E) [!].sms
262.144	bytes
CRC32: 93141463
MD5: 7f4c7a57ae46837f01ef9a0c85065250
SHA1: 9596400394f2bb3dbf7eb4a26b820cdfe5cd6094

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --