The Dark Redux (ZX Spectrum)
Traducción al Español v1.0 (25/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
The_Dark_Redux.tap
MD5: 78d0ab74ad5f7062e29f31ac1c9dba1b
SHA1: 2438bfc520b7038825e29d2bbe1d5441c7e782b3
CRC32: 34f3deef
46873 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --