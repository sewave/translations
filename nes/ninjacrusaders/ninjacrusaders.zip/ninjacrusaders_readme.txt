Ninja Crusaders
Traducci�n al Espa�ol v1.0 (19/06/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Ninja Crusaders
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Ninja Crusaders
-----------------
Muy buen plataformas conopcion cooperativa.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Ninja Crusaders (U) [!].nes
131.088	bytes
CRC32: dc84deb0
MD5: 894f49a450f8eb6a702e064bab83d117
SHA1: 219e51e8da40024d2f43d4adef941be05e3eb6ed

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --