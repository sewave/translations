Paperboy (Game Gear)
Traducci�n al Espa�ol v1.0 (10/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Paperboy (U).gg
MD5: 60e9482350815e3be5adc2a59234f05a
SHA1: b1f81f9e2b7197b2fa1475b9cd422479780ef7f2
CRC32: f54b6803
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --