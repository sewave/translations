The Tick (Mega Drive)
Traducción al Español v1.0 (22/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tick, The (U) [!].gen
MD5: 9927d1daf990e0014846d63559642d82
SHA1: e0fe77f1d512a753938ce4c5c7c0badb5edfc407
CRC32: 425132f0
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --