Nangoku Shirei!! - Spy vs Spy (NES)
Traducción al Español v1.0 (12/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de pacnsacdave.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nangoku Shirei!! - Spy vs Spy (Japan).nes
MD5: 1b8b2cc4de0a9c02e6013991c97058e1
SHA1: 494e13a5bd6f7a4acd3246835d7901d144a9f4ca
CRC32: 23dff27d
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --