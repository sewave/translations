Super Boy II (Master System)
Traducción al Español v1.0 (06/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Boy II (KR).sms
MD5: 6120c9ba0f2c24031c9a836035060717
SHA1: f0c239e4cf90cd4c699889792f811717670ac85c
CRC32: 67c2f0ff
49152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --