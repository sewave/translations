Vixen 357 (Mega Drive)
Traducci�n al Espa�ol v1.2 (18/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking est� basado en la traducci�n de Nebulous Translations.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglada intro y traducidas algunas frases faltantes.
V1.2: M�s arreglos en la intro.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Vixen 357 (J) [!].gen
MD5: 4ad9e56271eb9f5aee6c7c6d05e498b4
SHA1: 460037301df0d67947bd17eddb38a3011896cb43
CRC32: 3afa2d7b
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

Contributor	Type of contribution	Listed credit
celcion	Hacking	
Miralita	Hacking	Additional hacking
TheMajinZenki	Translation	Lead translator
cccmar	Script Editing/Revision	Initial testing/spot translation/script editing

-- FIN --