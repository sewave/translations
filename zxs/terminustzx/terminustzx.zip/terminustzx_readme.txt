Terminus (ZX Spectrum)
Traducción al Español v1.0 (07/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Terminus.tzx
MD5: 209b89bee207371814e23fbac3da07bc
SHA1: 7cf60a18d28426aaa01e5501308e92100c2b5a9f
CRC32: 5e687c2c
47377 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --