TaleSpin (NES)
Traducción al Español v1.0 (03/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
TaleSpin (USA).nes
MD5: 877ed4765915510493e7866ff317b9c7
SHA1: fb47c50d404ebab3274f2e9b1aac0be1f1bc9664
CRC32: 143dcab6
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --