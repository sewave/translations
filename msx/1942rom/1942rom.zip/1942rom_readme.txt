1942 (MSX)
Traducción al Español v1.0 (15/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
1942 (1986) (Ascii) (J).rom
MD5: 284f6df2bc8b829bc99775b52a00c509
SHA1: 0733cd627467a866846e15caf1770a5594eaf4cc
CRC32: a27787af
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --