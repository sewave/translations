Submarine Attack (Master System)
Traducci�n al Espa�ol v1.0 (23/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Submarine Attack (UE) [!].sms
MD5: 5eaa50519e87d57f40f50731caff5f62
SHA1: 44384ec8bf91e1ca5512ff88bbcf1ae1ce5a1a35
CRC32: d8f2f1b9
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --