Gomola Speed (PC Engine)
Traducción al Español v1.0 (04/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gomola Speed (Japan).pce
MD5: 58418c0db028885a2f49abf4993f2b0e
SHA1: fe4b08fb0cd9d0a53726c2709db3e31fbeae1213
CRC32: 4bd38f17
393216 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --