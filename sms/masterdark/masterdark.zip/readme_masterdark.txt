Master of Darkness
Traducci�n al Espa�ol v1.1 (01/11/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Master of Darkness
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Master of Darkness
-----------------
Plataformas/accion clonico de castlevania, pero con algunos toques originales.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Master of Darkness (UE) [!].sms
262.144	bytes
CRC32: 96fb4d4b
MD5: 8354932a7f20e84a808471b3724a56f8
SHA1: ed3569be5d5a49ff5a09b2b04ec0101d4edfa81e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --