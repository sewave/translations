Jammit (Mega Drive)
Traducci�n al Espa�ol v1.0 (08/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jammit (U) [!].bin
MD5: 946d261192111ed5baaae7c7d917d1be
SHA1: 2f43bfd04f563a67f4a2c8b8e36c541c19913a50
CRC32: d91b52b8
2097152 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --