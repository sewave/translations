Metal Slug - 2nd Mission (Neo Geo Pocket)
Traducci�n al Espa�ol v1.0 (01/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Metal Slug - 2nd Mission (JUE) [!].ngc
MD5: a58f7c41cd9e6c96cd5b4b477f022570
SHA1: 9c1a829d4678dd9c51fdfe30c76b7f9670311bfb
CRC32: ac549144
4.194.304 bytes

--------
Cr�ditos
--------
Wave - Hacking y traducci�n
Neo Geo pocket Espa�a (Davidvaldivia) - Tester

-- FIN --
