Kick Master
Traducci�n al Espa�ol v1.0 (08/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Kick Master
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Kick Master
-----------------
Plataformas sobre artista marcial especializado en patadas y grandes saltos.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Kick Master (U) [!].nes
262.160	bytes
CRC32: 7b978bac
MD5: 00d39f706953ba112d627877becf5286
SHA1: 8675bd893b287dd686642a3f609fa4f42c6d02ba

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --