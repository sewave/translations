Heavy Barrel (NES)
Traducción al Español v1.0 (26/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Heavy Barrel (USA).nes
MD5: ca5c8c3e7d98947f85d25a71d7264c63
SHA1: e2472cf182961f8fbc378ac41ced33e408a54c27
CRC32: 1e79b8a6
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --