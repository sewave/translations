Mitsume ga Tooru
Traducci�n al Espa�ol v1.0 (12/04/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Mitsume ga Tooru
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mitsume ga Tooru
-----------------
Interesante plataformas de grandes sprites y buenos efectos graficos.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking esta basada en la de The Spoony Bard.
Se a�aden caracteres especiales.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mitsume ga Tooru (J).nes
262.160	bytes
CRC32: e27ec1ec
MD5: 0e991488c4272b560a0bcf9ecb38a8f8
SHA1: f79d87d9b32498477ec2bf1939979d0d1d7bab7f

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --