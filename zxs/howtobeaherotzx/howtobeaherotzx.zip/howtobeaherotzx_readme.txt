How To Be A Hero (ZX Spectrum)
Traducción al Español v1.0 (11/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
How To Be A Hero.tzx
MD5: 4049f6044688afd6090e74ecd1e772aa
SHA1: 3f47f2a364dba649b3b1942216ca68470fe9e642
CRC32: ea3563aa
90490 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --