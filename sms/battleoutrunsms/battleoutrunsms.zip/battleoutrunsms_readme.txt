Battle Out Run (Master System)
Traducción al Español v1.0 (24/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battle Out Run (E) [!].sms
MD5: 83609eb760c3af64915fd6e73ee7d99e
SHA1: cfa8721d4fc71b1f14e9a06f2db715a6f88be7dd
CRC32: c19430ce
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --