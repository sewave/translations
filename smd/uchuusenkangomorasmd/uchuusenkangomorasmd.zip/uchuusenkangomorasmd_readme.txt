Uchuu Senkan Gomora (Mega Drive)
Traducción al Español v1.0 (17/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Uchuu Senkan Gomora (Japan).md
MD5: 2bd7578ddcbd3931e76f706cc0d72429
SHA1: 4e1d77cc1bf081e42abfd1c489fbd0073f0236af
CRC32: c511e8d2
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --