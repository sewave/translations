Meikyuu Jiin Dababa (Famicom Disk System)
Traducción al Español v1.0 (15/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Meikyuu Jiin Dababa (Japan).fds
MD5: a25724f497e6e80c73321039013c2625
SHA1: 8bd7c7a6e83f69617e1cb3cb0352be945905f71e
CRC32: b488b769
131000 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --