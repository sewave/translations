Dragon - The Bruce Lee Story (SNES)
Traducci�n al Espa�ol v1.0 (31/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon - The Bruce Lee Story (U).smc
2.097.152 bytes
MD5: 103152554973d6db6e53013eb10c383f
SHA1: af3c96d6b26b9a7efc4850b81ede469027b0b173
CRC32: 407c5c24

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --