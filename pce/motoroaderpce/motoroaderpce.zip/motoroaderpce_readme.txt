Moto Roader (PC Engine)
Traducción al Español v1.0 (05/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Moto Roader (U).pce
MD5: 1b10baf9f65c8339a507e382bda5ed44
SHA1: bd92a8e6a1e860305a0943878a3b4a56ddde5478
CRC32: e2b0d544
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --