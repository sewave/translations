Super Mario Land 2 - 6 Golden Coins (Game Boy)
Traducción al Español v1.0 (18/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Mario Land 2 - 6 Golden Coins (USA, Europe) (Rev B).gb
MD5: 4bd6e929ec716a5c7fe7dc684860d551
SHA1: d11d94fa3c36b9f72e925070b66bb4f16d31001e
CRC32: 635a9112
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --