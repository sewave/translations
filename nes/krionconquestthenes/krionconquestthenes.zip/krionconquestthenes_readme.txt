The Krion Conquest (NES)
Traducción al Español v1.0 (08/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Krion Conquest, The (USA).nes
MD5: ae0ddce9d9b2c91514f3c8c5b7dd2a80
SHA1: 8887894d6e4443a0ee4c35362779c7625a4cf68e
CRC32: 29b42609
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --