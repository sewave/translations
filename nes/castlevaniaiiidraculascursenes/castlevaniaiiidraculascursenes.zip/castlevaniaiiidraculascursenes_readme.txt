Castlevania III - Dracula's Curse (NES)
Traducción al Español v1.0 (19/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Castlevania III - Dracula's Curse (USA).nes
MD5: d16a502d0125f23cc3d980ddc6b6f2e8
SHA1: f91281d5d9cc26bcf6fb4de2f5be086bc633d49b
CRC32: 7cc9c669
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --