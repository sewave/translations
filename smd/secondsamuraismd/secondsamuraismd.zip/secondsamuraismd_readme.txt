Second Samurai (Mega Drive)
Traducción al Español v1.0 (19/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Second Samurai (Europe).md
MD5: 333f15e8bc4ecacf168b399a988fe1e7
SHA1: 72bfe0d4c56d9600a39fae00399fef157eb1fe6f
CRC32: 78e92143
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --