Jackal (NES)
Traducción al Español v2.0 (20/01/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Textos retraducidos y mejor ajustados.
-Agregados ¡ y Ó al texto final.
-Mejorada pantalla de título

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jackal (USA).nes
MD5: 7d02d7a6d89ef993589d1f1d58e2bcda
SHA1: 86c392a1d9a731fa48e148afbe60af75f918cb5a
CRC32: 2e52d091
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --