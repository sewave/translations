Fortified Zone (Game Boy)
Traducción al Español v1.0 (07/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fortified Zone (U) [!].gb
MD5: a981378da19c08597db03f3ee02cd6d7
SHA1: 232d2f57ab4bef748eb832dfb4085cc3df1fd532
CRC32: e3b59b7e
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --