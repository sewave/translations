Fire 'n Ice (NES)
Traducción al Español v1.0 (06/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fire 'n Ice (USA).nes
MD5: 1d494d4483a8bb5e62c3453a797b2090
SHA1: 9ae1a706fbdcf73d11ca734dc698cd8166d028fe
CRC32: ffa7c11c
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --