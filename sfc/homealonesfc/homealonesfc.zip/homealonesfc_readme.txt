Home Alone (Super Nintendo)
Traducción al Español v1.0 (17/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Home Alone (U).smc
MD5: 87447e71a602b02797054a4d80349c20
SHA1: e1f96f63603f4d899ec8e29975d0cdf0170cde73
CRC32: 07c494b1
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --