Rock 'n Roll (ZX Spectrum)
Traducción al Español v1.0 (21/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rock 'n Roll - Side A.dsk
MD5: ba57e3b95f21ad12d12fb33472f55b2d
SHA1: 378a77e1e653679e97a16245342c6a0cfd76560e
CRC32: 8e00a1a0
194816 bytes

Rock 'n Roll - Side B.dsk
MD5: 92b084537ec412f78a45c56dc1652139
SHA1: d6135a003ada344ad6572f4b4a2f3b7fa6c0fc3f
CRC32: 9c629673
194816 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --