Streets of Rage 2
Traducci�n al Espa�ol v1.0 (06/07/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Notas del Proyecto
2. Fallos Conocidos (o: Bugs que no son bugs)
3. Instrucciones de Parcheo
4. Cr�ditos del Parche

---------------------
1. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
2. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
3. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Streets of Rage 2 (E) [!].sms
524.288	bytes
CRC32: 04e9c089
MD5: e680b108e67caf02e4fb77d419f48358
SHA1: cc18171a860711f6ad18ff89254dd7bd05c54654

----------------------
4. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --