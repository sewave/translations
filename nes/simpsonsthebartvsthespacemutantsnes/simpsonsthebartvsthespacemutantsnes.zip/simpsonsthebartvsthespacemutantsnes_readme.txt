The Simpsons - Bart vs. the Space Mutants (NES)
Traducción al Español v2.0 (03/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducción de la versión USA
-Retraducción sin usar herramientas externas
-Revisión de textos

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Simpsons, The - Bart vs. the Space Mutants (USA) (Rev 1).nes
MD5: 3ba5363fb1459334efc16779089c1ad8
SHA1: 3b497a98aed743e52d42821f46fb842915d82b40
CRC32: c8602800
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --