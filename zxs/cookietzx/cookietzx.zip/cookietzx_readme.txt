Cookie (ZX Spectrum)
Traducción al Español v1.0 (19/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cookie (1983)(Ultimate).tzx
MD5: e1d47dd7e12da98a9388390a625ebd9b
SHA1: 81308c265b8a4a7ce19c50a048fa1277b9787519
CRC32: dd316aca
15959 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --