Bubble Bobble
Traducci�n al Espa�ol v1.0 (25/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Bubble Bobble
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Bubble Bobble
-----------------
Adaptaci�n del cl�sico de arcade.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Bubble Bobble (U) [!].gg
262.144	bytes
CRC32: fba338c5
MD5: 4f08cab3e252c2e3979ef33e9e59f294
SHA1: c2c99d798bd0d4960021743a55e74644ad9020c6

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
juandex - Testing

-- END OF README --