Captain America and The Avengers
Traducci�n al Espa�ol v1.0 (12/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Captain America and The Avengers
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Captain America and The Avengers
-----------------
Beat em up de los vengadores version game boy.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Captain America and the Avengers (U) [!].gb
131.072	bytes
CRC32: c762b783
MD5: dd5d45d9f8722f8ded9ab85097daa4e5
SHA1: a067c4e20642a6c17f35a855e2d4815470fc6c6b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --