Dig Dug (MSX)
Traducción al Español v1.0 (24/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dig Dug (1984) (Namcot) (J).rom
MD5: c0cbfd77ff3cabb9cf44ed53bf0ed14b
SHA1: 6e2e5cff4ee4dd935fbe6684f2c54b39eca06092
CRC32: 3c749758
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --