Quattro Arcade (NES)
Traducción al Español v1.0 (31/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Quattro Arcade (USA) (Unl).nes
MD5: 9d770d30d61a8e20cd13156675a26ee0
SHA1: b7285ac31ab2a0587133aefe0048a60a02aef091
CRC32: 2f36c2f1
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --