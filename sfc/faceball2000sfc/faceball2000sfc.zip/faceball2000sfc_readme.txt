Faceball 2000 (Super Nintendo)
Traducción al Español v1.0 (08/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Faceball 2000 (USA).sfc
MD5: f67294affb35c2cf8acab2e7cdd5caa3
SHA1: 4b5e0657306cc9e8ebcc72214ffc6f75efbdfb28
CRC32: 8d4df815
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --