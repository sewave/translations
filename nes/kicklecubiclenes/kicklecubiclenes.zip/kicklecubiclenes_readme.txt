Kickle Cubicle (NES)
Traducción al Español v1.0 (19/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kickle Cubicle (U) [!].nes
MD5: d4951408a8970c17ab247d40e9f89647
SHA1: 36096c4dedfff0a3ef7d597896ec0f2d332a6a82
CRC32: e783d470
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --