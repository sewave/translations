Kid Chameleon (Mega Drive)
Traducci�n al Espa�ol v1.0 (20/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kid Chameleon (UE) [!].bin
1.048.576 bytes
MD5: 756e603b6cf9b3ebbb1b0f79d9447e43
SHA1: 28b904000b2863b6760531807760b571f1a5fc1d
CRC32: ce36e6cc

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --