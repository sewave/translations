Final Mission (NES)
Traducción al Español v1.0 (10/05/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Stardust Crusaders.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Final Mission (Japan).nes
MD5: 2bac7b435070b63b925120257b48f53d
SHA1: 6e82b123cc9a1687a4c423438a418eff3f15d817
CRC32: b8273b87
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --