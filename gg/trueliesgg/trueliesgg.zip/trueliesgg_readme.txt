True Lies (Game Gear)
Traducción al Español v1.0 (18/11/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
True Lies (World).gg
MD5: 758bfe2baba5d8b518c6f746864bb8d5
SHA1: 7ee525e68b9f3bca2a5bdd6de14711108dcbc288
CRC32: 5173b02a
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --