Geimos (NES)
Traducción al Español v1.0 (06/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Geimos (Japan).nes
MD5: cbfefd5b59a60e64897ec38d7fe996ed
SHA1: c2c2d8c22ce9483ade6e69eb52c8a9a7e9756118
CRC32: e36038b7
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --