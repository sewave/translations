Zanac (Famicom Disk System)
Traducción al Español v1.0 (17/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zanac (Japan).fds
MD5: 0e168445805fb0d16476d1cbc84ae152
SHA1: 3e01f23f3a326b86b1719d213b36cb03f2d3878d
CRC32: daa74bc4
65516 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --