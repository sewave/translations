Tetris (Game Boy)
Traducción al Español v2.0 (08/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Mejorada pantalla de título
-Traducido modo multijugador

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tetris (World) (Rev A).gb
MD5: 982ed5d2b12a0377eb14bcdc4123744e
SHA1: 74591cc9501af93873f9a5d3eb12da12c0723bbc
CRC32: 46df91ad
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --