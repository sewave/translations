Feud (ZX Spectrum)
Traducción al Español v1.0 (23/12/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Feud.tzx
MD5: 62d441b11deb9b702509c1356bc20d33
SHA1: 6e99a9c692eb1483aca05ca094447be2e7bb5942
CRC32: 55924abb
47959 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --