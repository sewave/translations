Kinnikuman - Muscle Tag Match (NES)
Traducción al Español v1.0 (30/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kinnikuman - Muscle Tag Match (Japan) (Rev 1).nes
MD5: ffcc769cfa84f98cd2d8aee81f7fbb15
SHA1: 067390bf77f8cbc7e76f76f3744e4fc19978525a
CRC32: c261904e
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
Sensenic - Traducción pantalla de título.

-- FIN --