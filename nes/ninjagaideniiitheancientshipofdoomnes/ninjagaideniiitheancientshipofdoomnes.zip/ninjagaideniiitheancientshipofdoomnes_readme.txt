Ninja Gaiden III - The Ancient Ship of Doom (NES)
Traducción al Español v1.0 (24/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Gaiden III - The Ancient Ship of Doom (USA).nes
MD5: 8a551c78e96e93782e5a0cfb263eb96b
SHA1: 6ade8f54951843fccc46fc8be439e6c56d56b14f
CRC32: 4d26fa27
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --