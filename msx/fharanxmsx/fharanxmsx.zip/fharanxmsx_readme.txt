Fharanx (MSX)
Traducción al Español v1.0 (18/05/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la traducción de Django.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
Para cargar el juego es necesario tener un MSX sin controlador de discos,
de esta forma aparecerá "28815 Bytes free" y entonces podrá cargarse con:
CLOAD
RUN

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fharanx (1985)(Enix)[By Django][BLOAD'CAS-',r].cas
MD5: a7fd8e04e5393d39d118bfbb627f3643
SHA1: 8a37933ce5bfa1f52a967a219722d54d91c7ab76
CRC32: 50d7a6bb
36719 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --