The Young Indiana Jones Chronicles (NES)
Traducción al Español v1.0 (13/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Young Indiana Jones Chronicles, The (USA).nes
MD5: ca90891fa082efc5d9922f1b9e0e10af
SHA1: 9d4142b9af92d5592de54dfe508ab4b70e4e7db2
CRC32: 1f55fde6
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --