Space Marauder (Game Boy Color)
Traducción al Español v1.0 (03/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Space Marauder (USA).gbc
MD5: 5ee49eaf9a2c19623478215788c0bfdc
SHA1: e6738767434f53af8221fb06513c0758ab228a94
CRC32: 4f83b35e
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --