Championship Pro-Am (Mega Drive)
Traducción al Español v1.0 (01/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Championship Pro-Am (USA).md
MD5: 3565daea22cc305dac5950d2c707971e
SHA1: 6e3cc6e97d33890996dcbad9a88b1aef361ca2d9
CRC32: b496de28
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --