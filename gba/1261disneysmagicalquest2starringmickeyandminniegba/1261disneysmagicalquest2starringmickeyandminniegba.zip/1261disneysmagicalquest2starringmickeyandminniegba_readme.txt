Disney's Magical Quest 2 Starring Mickey and Minnie (GBA)
Traducci�n al Espa�ol v1.0 (03/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
1261 - Disney's Magical Quest 2 Starring Mickey and Minnie (U)(Evasion).gba
MD5: 9397ee8e46cd0357d49af1cff6fd97b3
SHA1: 85358586e818913485da97089910712adaf4eb69
CRC32: 69f1117d
4.194.304 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --