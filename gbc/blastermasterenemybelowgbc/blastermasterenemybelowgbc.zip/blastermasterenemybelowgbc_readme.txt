Blaster Master - Enemy Below (Game Boy Color)
Traducción al Español v1.0 (26/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blaster Master - Enemy Below (USA, Europe) (SGB Enhanced).gbc
MD5: 756664aa0c9418b200946aa4e1dddf53
SHA1: 8b2e83d7f2b7d72d5cc1ac81c28c2173ad2fc9ba
CRC32: 2f91e17c
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --