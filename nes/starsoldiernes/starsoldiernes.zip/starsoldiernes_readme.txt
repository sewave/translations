Star Soldier (NES)
Traducción al Español v1.0 (30/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Star Soldier (U) [!].nes
MD5: 35cb35571e392b28c695e97c7fc5fa56
SHA1: b8450ce305c57a2159d4bb426afd3fd268627bc7
CRC32: 69004001
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --