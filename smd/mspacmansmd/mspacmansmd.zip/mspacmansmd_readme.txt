Ms. Pac-Man (Mega Drive)
Traducci�n al Espa�ol v1.1 (04/12/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
v1.1:Corregido READY y GAME OVER
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ms. Pac-Man (U) [!].bin
MD5: cfe7f3023b21bcf697bcf5e1be461ee7
SHA1: 29fff97e19a00904846ad99baf6b9037b28df15f
CRC32: af041be6
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --