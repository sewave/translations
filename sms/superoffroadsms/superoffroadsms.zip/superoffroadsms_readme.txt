Super Off-Road (Master System)
Traducci�n al Espa�ol v1.0 (05/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Off-Road (E) [!].sms
MD5: e3d3dfde69345e1f62cce512e9010bf8
SHA1: 804cd74bbcf452613f6c3a722be1c94338499813
CRC32: 54f68c2a
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --