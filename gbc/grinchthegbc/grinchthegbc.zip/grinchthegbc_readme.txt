The Grinch (Game Boy Color)
Traducción al Español v1.0 (18/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Grinch, The (USA).gbc
MD5: 42ad3639f6abf013d5dacd4358abf6ca
SHA1: 84c2397fe07011511225b9d9f442f16c026576d3
CRC32: c5a47896
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --