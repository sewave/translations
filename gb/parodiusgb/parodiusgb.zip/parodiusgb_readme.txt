Parodius (Game Boy)
Traducción al Español v1.0 (05/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Parodius (Europe).gb
MD5: c94afb46cada0118aa8ff08cc07749a4
SHA1: a00a1adc326d368e9198c006d43c0fd1ab290219
CRC32: 85748525
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --