Snake's Revenge
Traducci�n al Espa�ol v1.0 (25/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Snake's Revenge
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Snake's Revenge
-----------------
Segunda parte en NES de las aventuras de Solid Snake.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Para los passwords, cambian estos caracteres:
!!=>�
�=>�
'=>�

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Snake's Revenge (U) [!].nes
262.160	bytes
CRC32: 255a25fe
MD5: 17262cb7b1f1ea96055d93b83bac379e
SHA1: 49f1369c0e3926da1ae4ef9baa6c41f8c649b893

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --