Raid 2020 (NES)
Traducción al Español v1.0 (31/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Raid 2020 (Color Dreams) [!].nes
MD5: fef1eaf13a3a73e31a05c3401defb64f
SHA1: 38e3580d7750263495e0639c703c974d5f3b0074
CRC32: f69a2c11
98320 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --