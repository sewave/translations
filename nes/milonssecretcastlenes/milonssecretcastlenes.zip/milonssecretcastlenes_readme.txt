Milon's Secret Castle (NES)
Traducción al Español v1.0 (03/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Milon's Secret Castle (USA).nes
MD5: 22667d02d3bde0a44a42194cb6bf26f3
SHA1: 6ed393942539aaf99fe5a94cfe3a2aaa471f9b1d
CRC32: 1741286b
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --