Dragon Ball - Shen Long no Nazo 
Traducci�n al Espa�ol v1.0 (26/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Dragon Ball - Shen Long no Nazo 
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Dragon Ball - Shen Long no Nazo
-----------------
Uno de los primeros juegos de Dragon Ball, de aventura/plataformas.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basada en la version de TransBRC.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Dragon Ball - Shen Long no Nazo (J) [hM34].nes
164.368	bytes
CRC32: a1fc6ed3
MD5: ec98ff89daad60f15d00484896f451a5
SHA1: dd2400f3bbb1da15fc6154260bb2ac2e29b1afcb

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Original:
Contributor	Type of contribution
Blibber	Hacking	
Lemon	Translation

-- END OF README --