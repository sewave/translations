Warrior of Rome (Mega Drive)
Traducción al Español v1.1 (25/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:
-Arreglado fijado de interrupciones

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Warrior of Rome (USA).md
MD5: bcf98c92d475c94a451442f3df55ec51
SHA1: d75eb583e7ec83d6b8308f6dc7cdb31c62b4dbf9
CRC32: 5be10c6a
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --