Worms (Game Boy)
Traducción al Español v1.0 (17/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Worms (U) [!].gb
MD5: 45dcc259728a00118fe86f841d48564f
SHA1: 26137ca97b840c63a462bcf85677a5f3db67fadf
CRC32: 2ebc40c2
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --