Battletoads
Traducci�n al Espa�ol v1.0 (27/04/2017)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Battletoads
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Battletoads
-----------------
Port del beat em up de NES para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Battletoads (W) [!].bin
524.288	bytes
CRC32: d10e103a
MD5: f1e299d6eb40e3ecec6460d96e1e4dc9
SHA1: 5ef3c29b6bdd04d24552ab200d0530f647afdb08

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --