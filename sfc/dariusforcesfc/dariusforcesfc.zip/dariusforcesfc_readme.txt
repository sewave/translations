Darius Force (SNES)
Traducci�n al Espa�ol v1.0 (18/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
"ZONE SELECT" no est� traducido.
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Darius Force (J).smc
MD5: 576e89ea12fc942b9a4f4b03df5f72b9
SHA1: 8f45123bcbdcd02fef42dfbd131704a3b1e7226d
CRC32: 3e828e49
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --