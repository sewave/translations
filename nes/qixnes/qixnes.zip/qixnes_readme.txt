QIX (NES)
Traducción al Español v1.1 (25/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:Arreglada pantalla de porcentaje.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
QIX (USA).nes
MD5: d8c62c8b76a12bf1fd31237f651f486f
SHA1: d9492dd8f558b7db25e6fee6b95f008e9f7e6061
CRC32: 4724713d
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --