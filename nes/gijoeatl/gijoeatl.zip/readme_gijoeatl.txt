G.I. Joe - The Atlantis Factor
Traducci�n al Espa�ol v1.0 (05/10/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre G.I. Joe - The Atlantis Factor
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre G.I. Joe - The Atlantis Factor
-----------------
Segunda parte del shooter de gijoe, menos inspirado que la primera.
Este parche lo traduce completamente al espa�ol, excepto el menu entre rutas y la barra de estado.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
G.I. Joe - The Atlantis Factor (U) [!].nes
393.232	bytes
CRC32: a8efac13
MD5: c82eb393a36453cc6ba1270ab33ece3b
SHA1: ab57331556b5c5456c67a24a21da91a6c1decd73

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --