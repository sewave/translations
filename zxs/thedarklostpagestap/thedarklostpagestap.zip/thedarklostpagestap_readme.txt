The Dark: Lost Pages (ZX Spectrum)
Traducción al Español v1.0 (17/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
The_Dark_Lost_Pages.tap
MD5: 724b9c8267df7ac76cde6e700b8040cf
SHA1: 3dfb6685c899f1e428a3feff104a55a2c573a950
CRC32: 4ee940ee
55037 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --