Lethal Weapon (NES)
Traducción al Español v1.0 (15/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lethal Weapon (U) [!].nes
MD5: 7ada021c92a802b3da9ee5a9d00e91ba
SHA1: 48cc6cf036bf9c1d3bd491365455b8378a104e52
CRC32: 1dc4915b
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --