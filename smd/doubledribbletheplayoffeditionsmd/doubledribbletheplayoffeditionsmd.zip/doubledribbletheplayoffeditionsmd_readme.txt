Double Dribble - The Playoff Edition (Mega Drive)
Traducción al Español v1.0 (12/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Dribble - The Playoff Edition (USA).md
MD5: a2b23303055f28e68afce7b7e2ea9edf
SHA1: d97bbe009e9667709e04a1bed9f71cea7893a495
CRC32: 8352b1d0
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --