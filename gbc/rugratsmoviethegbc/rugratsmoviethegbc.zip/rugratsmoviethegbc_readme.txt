The Rugrats Movie (Game Boy Color)
Traducción al Español v1.0 (16/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rugrats Movie, The (USA) (SGB Enhanced) (GB Compatible).gbc
MD5: 1383da42b08bf94b6fad381cada66fad
SHA1: c64ddf11c12d34f13d86e4a468b1eedacb698081
CRC32: febe2606
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --