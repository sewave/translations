Slider (Game Gear)
Traducción al Español v1.0 (29/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Slider (U).gg
MD5: 634a3ef93d9e93b79f194559541adeb8
SHA1: ab37b26ca62339720d1cefcb152a0aca545359aa
CRC32: 4dc6f555
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --