Shadow Dancer - The Secret of Shinobi
Traducci�n al Espa�ol v1.01 (13/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Shadow Dancer - The Secret of Shinobi
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Shadow Dancer - The Secret of Shinobi
-----------------
Adaptaci�n libre del arcade para la 16 bits de sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
1.01: Arreglado error tipografico.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Shadow Dancer - The Secret of Shinobi (W) [c][!].gen
524.288	bytes
CRC32: ebe9ad10
MD5: 1f2a9f322e770be0a3cc2aabdf8bc575
SHA1: c5f096b08470a564a737140b71247748608c32b6

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --