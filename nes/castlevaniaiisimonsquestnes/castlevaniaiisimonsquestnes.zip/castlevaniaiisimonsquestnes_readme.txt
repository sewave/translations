Castlevania II - Simon's Quest (NES)
Traducción al Español v1.0 (19/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Castlevania II - Simon's Quest (USA).nes
MD5: 1b827c602c904d8c846499c9f54b93e0
SHA1: d6b96fd98ae480c694a103fe9a5d7d84eeafb6f7
CRC32: a9c2c503
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --