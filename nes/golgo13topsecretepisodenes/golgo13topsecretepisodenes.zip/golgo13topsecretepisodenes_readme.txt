Golgo 13 - Top Secret Episode (NES)
Traducción al Español v1.0 (20/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Golgo 13 - Top Secret Episode (USA).nes
MD5: d69b15bd48083cc78267c7e27b0b67e4
SHA1: 8451a90be5a05f82b5fa29c742ebd32b21e36f4f
CRC32: 9881d1b4
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --