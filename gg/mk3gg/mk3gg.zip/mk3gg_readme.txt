Mortal Kombat 3 (Game Gear)
Traducci�n al Espa�ol v1.0 (14/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mortal Kombat 3 (U) [!].gg
524.288 bytes
MD5: 034cc8983558b3e42a4b9c2217d1bb68
SHA1: 034ecd615609efb4d96669dda7f32f546d5782f8
CRC32: c2be62bb

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --