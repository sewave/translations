Prince of Persia (Mega Drive)
Traducción al Español v1.0 (15/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Prince of Persia (E).bin
MD5: bb8dede1a266d8c48a8f2ea1e4d12e58
SHA1: 6e645b791e6e2b84a206dca6cf47e8f955e60a72
CRC32: 61de6fe0
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --