Penguin Adventure (Master System)
Traducción al Español v1.0 (09/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
La rom modificada no funciona en varios emuladores por la forma en la que se
detectan los juegos portados de MSX, a mi solo me ha funcionado correctamente
en Emulicious.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Penguin Adventure (Korea) (Unl) (Pirate).sms
MD5: cada8fbd55b6444f2308e770c79eaccc
SHA1: 9d0c8fb5f1ff6f596aa156264db8d7c1c778b1bf
CRC32: 445525e2
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --