Lamborghini American Challenge (Super Nintendo)
Traducción al Español v1.0 (17/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lamborghini American Challenge (USA).sfc
MD5: 08d373c5a350eb7b7f593657e2a5f252
SHA1: 62afa5e2bd795c9b205421e9b50db175bc04b527
CRC32: d2fb701b
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --