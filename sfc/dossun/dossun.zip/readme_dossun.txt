Dossun! Ganseki Battle
Traducci�n al Espa�ol v1.0 (10/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Dossun! Ganseki Battle
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Dossun! Ganseki Battle
-----------------
Curioso juego de puzzles estilo columns.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking esta basado en la traduccion de Aeon Genesis.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Dossun! Ganseki Battle (Japan).sfc
1.048.576 bytes
CRC32: 1aa002d6
MD5: 663fbb07dcd22c366cf940bbb9a5db85
SHA1: 544201ff2f0ad09a14142d3d7c02a2e07cfc7c5a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Original:
-----------------
Those Responsible
-----------------
Gideon Zhi - Romhacker
DDS - Translation

-- END OF README --