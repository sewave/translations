Saiyuuki World (NES)
Traducci�n al Espa�ol v1.0 (03/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking est� basado en la traducci�n al ingl�s de Nebulous Translations.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Saiyuuki World (J).nes
MD5: 0a513b7908397e9756f34979e5c3a06f
SHA1: c2f12d915a4d0b1ffdf8a64ae1092ce6a2d08770
CRC32: 5ad9aeef
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

CreditsContributor	Type of contribution	Listed credit
celcion	Hacking	
TheMajinZenki	Translation	
cccmar	Script Editing/Revision

-- FIN --