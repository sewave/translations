Dirty Pair - Project Eden (Famicom Disk System)
Traducción al Español v1.0 (02/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basada en la de Stardust Crusaders.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dirty Pair - Project Eden (Japan) [b].fds
MD5: 16c53a215ed21315f46b352d83e48abd
SHA1: d6a4a1b28edf01dbbf445ec0fbcf9a0901435d8c
CRC32: 3c63db59
131000 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --