Takahashi Meijin no Bugutte Honey (NES)
Traducción al Español v1.0 (29/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Takahashi Meijin no Bugutte Honey (Japan).nes
MD5: 89c77a1a6cdb689a9e0804e8e35bef87
SHA1: f57d77e9964ab64998e652a1e6bc77215d7cf7a2
CRC32: 312e6a31
163856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --