Fatal Fury Special (Game Gear)
Traducci�n al Espa�ol v1.0 (31/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
El modo 2 jugadores no est� comprobado.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fatal Fury Special (U) [!].gg
MD5: 4292c099f98cc0c6d03025f0729f64df
SHA1: 7ce20ca34b7bc91ba7e73f830b40830ad6bafbc8
CRC32: 449787e2
524288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --