Warp Warp (MSX)
Traducción al Español v1.0 (16/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Warp Warp (1984) (Namcot) (J).rom
MD5: a594c61fd7de01723674eb6fcb19875d
SHA1: 52f95f6f4261be00ae1b9caf88a05c021c229e28
CRC32: 90f5f414
8192 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --