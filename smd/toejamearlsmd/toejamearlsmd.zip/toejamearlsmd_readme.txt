Toejam & Earl (Mega Drive)
Traducción al Español v1.0 (22/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Toejam & Earl (UE) (REV00) [!].bin
MD5: 0a6af20d9c5b3ec4e23c683f083b92cd
SHA1: 7f82d8b57fff88bdca5d8aff85b01e231dc1239a
CRC32: d1b36786
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --