Sobre Alex Kidd in Shinobi World
Traducci�n al Espa�ol v1.1 (06/08/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Sobre Alex Kidd in Shinobi World
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alex Kidd in Shinobi World
-----------------
Nuevas aventuras de Alex Kidd en el mundo de Shinobi.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: modificada pantalla titulo

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alex Kidd in Shinobi World (UE) [!].sms
262.144	bytes
CRC32: d2417ed7
MD5: d62b631506913712a2103f54912458a5
SHA1: e7c7c24e208afb986ab389883f98a1b5a8249fea

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --