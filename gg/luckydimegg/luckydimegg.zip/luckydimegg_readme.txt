Lucky Dime Caper, The Starring Donald Duck
Traducci�n al Espa�ol v1.0 (11/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Lucky Dime Caper, The Starring Donald Duck
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Lucky Dime Caper, The Starring Donald Duck
-----------------
Plataformas de Disney para game gear del pato donald.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Lucky Dime Caper, The Starring Donald Duck (U) [!].gg
262.144	bytes
CRC32: 07a7815a
MD5: 78a7964b341ccc4379a837ee998805c7
SHA1: 5cc5caa887a63c580c1e3ff344a4b0ade643f24b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --