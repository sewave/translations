The Simpsons - Bartman Meets Radioactive Man (Game Gear)
Traducción al Español v1.0 (12/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Simpsons, The - Bartman Meets Radioactive Man (U) [!].gg
MD5: 5f263de21f316a2a318dd6d5f732b2c8
SHA1: 9dd99ca1b28dbb16f5f118e2729613d1452aba73
CRC32: ffa447a9
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --