Joe & Mac 2 - Lost in the Tropics (Super Nintendo)
Traducci�n al Espa�ol v1.0 (14/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Joe & Mac 2 - Lost in the Tropics (U).smc
MD5: 1e5fa71516afa912e0db1dd6ff07d2bc
SHA1: 14d4911403854bf0bb59e3a6081181678a23d598
CRC32: 0c3b4201
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --