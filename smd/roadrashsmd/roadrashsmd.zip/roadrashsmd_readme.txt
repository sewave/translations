Road Rash (Mega Drive)
Traducción al Español v1.0 (05/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
Sin traducir:
-NEW/OLD level
-Todo conduciendo
-Datos tienda, CREDIT/PRICE/etc

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Road Rash (USA, Europe).md
MD5: 543b64ccb26c18edc6c98c12b1302dc0
SHA1: 8ff2b2a58b09c42eeb95f633bd8ea5227ac71358
CRC32: dea53d19
786432 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --