El Viento (Mega Drive)
Traducción al Español v1.0 (11/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
El. Viento (USA).md
MD5: 6ddf640c2c5f91f12487d813b6257114
SHA1: b53e901725fd6220d8e6d19ef8df42e89e0874db
CRC32: 070a1ceb
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --