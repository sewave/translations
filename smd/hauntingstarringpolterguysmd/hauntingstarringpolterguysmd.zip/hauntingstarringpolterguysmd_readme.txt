Haunting Starring Polterguy (Mega Drive)
Traducción al Español v1.0 (29/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Haunting Starring Polterguy (UE) [!].bin
MD5: 3f18b4cfc9d286df11db970f2e894392
SHA1: d6227ef00fdded9184676edf5dd2f6cae9b244a5
CRC32: c9fc876d
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --