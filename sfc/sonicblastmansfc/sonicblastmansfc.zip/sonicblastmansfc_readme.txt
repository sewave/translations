Sonic Blast Man (Super Nintendo)
Traducción al Español v1.0 (25/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sonic Blast Man (U) [!].smc
MD5: 10eec032e7beaaa85c3e5ace9a323c53
SHA1: 9e153eda423295806b3b7384d0a73e2630d1c314
CRC32: 8886396e
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --