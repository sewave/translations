Bonanza Bros
Traducci�n al Espa�ol v1.0 (25/10/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Bonanza Bros
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Bonanza Bros
-----------------
Curioso plataformas que va sobre dos "ladrones" que deben ir desvalijando varios lugares.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Bonanza Bros (E) [!].sms
262.656	bytes
CRC32: d778f3fe
MD5: be417ce26ceffd0d3a97fc89aea3b3c6
SHA1: 83ddd69f2003581c31df93845b278e924f7f4e72

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --