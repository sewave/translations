Normy's Beach Babe-O-Rama (Mega Drive)
Traducción al Español v1.0 (27/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Normy's Beach Babe-O-Rama (UE) [!].bin
MD5: 62146cdc28437a346fb4816877e56a91
SHA1: 286d4f922fa9a95740e791c284d141a49983d871
CRC32: b56a8220
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --