Laser Wheel (ZX Spectrum)
Traducción al Español v1.0 (23/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Laser Wheel.tzx
MD5: 159261cbf9e6ee3a0fa25bc75422bd13
SHA1: 8a3906cb728a42d5837ebb433a442580c8028a8a
CRC32: 1bad80d0
41313 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --