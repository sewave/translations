Wario Land II (Game Boy Color)
Traducción al Español v1.0 (28/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wario Land II (USA, Europe) (SGB Enhanced).gbc
MD5: b7598a51e0acc0d74ca8f464826371ed
SHA1: ae37915058035df4ceedd72d709f91efb4878eff
CRC32: 047bdf80
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --