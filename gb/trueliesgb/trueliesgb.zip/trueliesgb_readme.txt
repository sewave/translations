True Lies (Game Boy)
Traducción al Español v1.0 (18/11/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
Las pantallas estáticas de cada etapa no están traducidas.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
True Lies (USA, Europe).gb
MD5: c013958fa8447be55f1e037ed4a1a9f9
SHA1: 95dda9821e6755c12fec9d4c0c9db8bb515843a6
CRC32: edec63e6
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --