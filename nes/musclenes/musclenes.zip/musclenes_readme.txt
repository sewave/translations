M.U.S.C.L.E. (NES)
Traducción al Español v1.0 (30/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
M.U.S.C.L.E. (U) [!].nes
MD5: 115c1170578a07f1b8a918e768ee6a36
SHA1: 5de10c55a0212778574b786b8d42e06196832bc4
CRC32: edee9759
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --