Sagaia
Traducci�n al Espa�ol v1.0 (13/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Sagaia
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Sagaia
-----------------
Shooter espacial arcade con multiples finales.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Sagaia (U) [c][!].gen
1.048.576 bytes
CRC32: f1e22f43
MD5: c9ab9dd499c7d56772fccbd2ec2ae465
SHA1: 0aa2632da5ec3c1db21b273bcb8630d84b7bb805

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --