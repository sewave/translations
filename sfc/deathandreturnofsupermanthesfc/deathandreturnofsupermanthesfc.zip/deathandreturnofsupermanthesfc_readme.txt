The Death and Return of Superman
Traducci�n al Espa�ol v1.0 (30/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre The Death and Return of Superman
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre The Death and Return of Superman
-----------------
Adaptaci�n del comic a beat em up para la SNES.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Las biograf�as de los personajes no est�n traducidas.
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Death and Return of Superman, The (U).smc
2.097.152 bytes
CRC32: a567957c
MD5: dbf576310985b10fa48c6a1c8915b19d
SHA1: a509da90497b3c29c8763fdefd4808e55ea4b35c

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --