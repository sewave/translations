Kung Fu Kid (Master System)
Traducci�n al Espa�ol v1.0 (25/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kung Fu Kid (UE) [!].sms
MD5: 126687037bf172174f697d16cd7e7296
SHA1: 7e1c32f5abf9ff906ffe113ffab6eecd1c86b381
CRC32: 1e949d1f
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --