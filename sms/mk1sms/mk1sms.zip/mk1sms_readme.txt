Mortal Kombat
Traducci�n al Espa�ol v1.0 (28/04/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Mortal Kombat
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mortal Kombat
-----------------
Mas que decente port del famoso titulo para la 8 bits de sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mortal Kombat (E) [!].sms
524.288	bytes
CRC32: 302dc686
MD5: a429ed37b51cc9f46c943f968d88e29f
SHA1: 3f67e0e702f391839b51a43125f971ae1c5fad92

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --