Rocky Rodent (Super Nintendo)
Traducción al Español v1.0 (06/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rocky Rodent (USA).sfc
MD5: bb457a174348e3e0d6a05026c1c57f22
SHA1: 07baf0370f1d5b2457e6afff2c256eadc142ab96
CRC32: c81a7b07
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --