Nemesis 2 (MSX)
Traducción al Español v1.0 (29/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nemesis 2 (Japan, Europe) (Alt 1).rom
MD5: ee3e6a50e3de131d217e5dab55519011
SHA1: ab30cdeaacbdf14e6366d43d881338178fc665cb
CRC32: 32aba4e3
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --