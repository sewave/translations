Little Indian in Big City (Game Boy)
Traducción al Español v1.0 (15/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Little Indian in Big City (U) [S].gb
MD5: 1d2fed99f9f478f404f161940e53cea6
SHA1: 168337cdd8e4d919ce3b62ea4802ec6b959c6893
CRC32: e37e1832
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --