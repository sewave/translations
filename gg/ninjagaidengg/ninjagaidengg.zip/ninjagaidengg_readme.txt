Ninja Gaiden (Game Gear)
Traducción al Español v2.0 (29/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres especiales
-Revisión de guion

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Gaiden (USA, Europe).gg
MD5: 764388b8b5dc2e762fab9badd0eca6ba
SHA1: 1a5c44e76a0e913d76f590affae3b2e24fbd0f59
CRC32: c578756b
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --