Makai Island (NES)
Traducción al Español v1.0 (19/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Makai Island (USA) (Proto).nes
MD5: c9f4cb22090a8da157211d54cfa5a23a
SHA1: bdf9436c18aeb976000db060f9a0e8a2a47ba99d
CRC32: 66bdd61f
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --