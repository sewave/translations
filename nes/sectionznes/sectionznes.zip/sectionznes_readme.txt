Section Z (NES)
Traducción al Español v1.0 (11/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Section Z (U) [!].nes
MD5: 15d915cb1e6e944e4b17ad2ae72d6137
SHA1: 93e3548481f35111602f2fbf0e843bea4dfec56c
CRC32: 3ce543e6
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --