Gaiares (Mega Drive)
Traducción al Español v2.0 (02/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales en fuente principal
-Guion reescrito

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gaiares (Japan, USA).md
MD5: 47e140ae1e70984e6cd638e6e8f8485f
SHA1: f62e8be872dc116c4cc331c50ae63a63f013eb58
CRC32: 5d8bf68b
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --