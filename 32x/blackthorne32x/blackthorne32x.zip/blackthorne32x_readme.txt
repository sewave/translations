Blackthorne (Mega Drive 32X)
Traducción al Español v1.1 (19/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
-Alargado texto que se salía de la ventana
-Arreglado texto que congelaba el juego en el nivel 4

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blackthorne (USA).32x
MD5: c238b112113b0297b2b9f4f618d56598
SHA1: 4bf120cf056fe1417ca5b02fa0372ef33cb8ec11
CRC32: d1a60a47
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --