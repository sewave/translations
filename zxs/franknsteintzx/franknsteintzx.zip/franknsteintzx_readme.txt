Frank N Stein (ZX Spectrum)
Traducción al Español v1.0 (14/09/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
FrankNStein.tzx
MD5: 11ebae5c6d163b9772258a4de84702f5
SHA1: 3c03df495235bb95dcf9bb1f9d017494132006fa
CRC32: f0bad5c8
47888 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --