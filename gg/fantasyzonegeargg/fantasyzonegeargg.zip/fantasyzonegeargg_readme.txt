Fantasy Zone Gear (Game Gear)
Traducci�n al Espa�ol v1.0 (23/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fantasy Zone Gear (JU) [!].gg
MD5: 4c6c42493b5af22540e6c2014d2c367a
SHA1: 5951d500d6f53b0537f045adb85d94068a838f32
CRC32: d69097e8
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --