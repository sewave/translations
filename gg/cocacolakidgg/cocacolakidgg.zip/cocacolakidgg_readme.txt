Coca Cola Kid (Game Gear)
Traducci�n al Espa�ol v1.0 (01/12/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking est� basada en la de filler.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Coca Cola Kid (J) [!].gg
MD5: dbede5c20828e3d251b05356d9176c79
SHA1: e0a6caba7d8433175a3b7f1dfb593f9ca2c67cd1
CRC32: c7598b81
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.
Contributor	Type of contribution	Listed credit
filler	Translation

-- FIN --