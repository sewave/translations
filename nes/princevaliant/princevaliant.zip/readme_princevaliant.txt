Legend of Prince Valiant, The
Traducci�n al Espa�ol v1.0 (30/04/2018)
(C) 2018 Traducciones Wave

---
TdC
---

1. Sobre Legend of Prince Valiant, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Legend of Prince Valiant, The
-----------------
Legend of Prince Valiant, The es un juego de plataformas.
Este parche lo traduce completamente al espa�ol.
v1.0: Correcciones de script.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
No se han a�adido acentos ya que no hay espacio en los tiles de las letras.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Legend of Prince Valiant, The (E) [!].nes
262.160 bytes
CRC32: 90cdbb50
MD5: a3583a98ca40c2472085c8f1b8670529
SHA1: 1586d84972b46844d8665b931e34d155e11f3a02

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --