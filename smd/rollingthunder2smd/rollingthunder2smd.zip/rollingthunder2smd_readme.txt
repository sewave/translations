Rolling Thunder 2
Traducci�n al Espa�ol v1.1 (16/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Rolling Thunder 2
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Rolling Thunder 2
-----------------
Port del arcade para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Revisi�n script

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Rolling Thunder 2 (U) [c][!].bin
1.048.576 bytes
CRC32: 3ace429b
MD5: 3753ae738edf6f37203763f3a8a6e406
SHA1: 1b451389910e6b353c713f56137863ce2aff109d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --