Nobunaga's Ambition (Game Boy)
Traducción al Español v1.0 (01/02/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nobunaga's Ambition (USA).gb
MD5: 7cc78ea5dbc099e8f89849a11a08c38e
SHA1: d4dd65535d2a15f177289b53a49f1bc9e9b739f3
CRC32: 5a843008
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --