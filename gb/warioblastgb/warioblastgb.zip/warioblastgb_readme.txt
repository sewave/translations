Wario Blast featuring Bomberman! (Game Boy)
Traducción al Español v1.0 (27/07/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wario Blast featuring Bomberman! (USA, Europe) (SGB Enhanced).gb
MD5: 14fe7234ee4bcb14adf20c743f084a35
SHA1: 279fb0223e362db553b739b1b8f9c18b81d92413
CRC32: 927b57a1
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --