Billy BlueBottle (ZX Spectrum)
Traducción al Español v1.0 (20/01/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Billy BlueBottle.tzx
MD5: f2626f1c76b4d6eea2f47440739bc85e
SHA1: 4d049816c24fbe42b3c7d473daad6b03bd5df5ae
CRC32: 6fc66736
46483 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --