Super Off Road (Game Boy)
Traducci�n al Espa�ol v1.0 (10/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Off Road (U) [!].gb
MD5: 85d05f95c07ed1b7d787062fe4d2e251
SHA1: acde7750bcf99d7bb76b895534fda43ece222dfa
CRC32: 3e2810be
131072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --