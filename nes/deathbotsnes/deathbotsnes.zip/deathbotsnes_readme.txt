Deathbots (NES)
Traducción al Español v1.1 (23/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
-Arreglada compatibilidad con fceux al cambiar de mapper.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Deathbots (USA) (Rev 1) (Unl).nes
MD5: 7dcbc04dc458c72f580d94245884e57d
SHA1: 951e4b55c1f83e483e1f3f675f25ead216cb5725
CRC32: cd12d2be
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --