Soukoban (Game Gear)
Traducción al Español v1.0 (14/10/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Soukoban (Japan).gg
MD5: 0a98b767910b054ca3c5263eba3bfbdc
SHA1: e5865a22dc3a9714160ef14bc59d510502d39b97
CRC32: 0f3e3840
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --