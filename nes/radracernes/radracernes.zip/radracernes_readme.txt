Rad Racer (NES)
Traducción al Español v1.0 (24/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rad Racer (U) [!].nes
MD5: 1f0014742b957f323599f5109f7fad73
SHA1: 97f4195a0113caa268ce4f8729dfb719c6d6d460
CRC32: 595daa35
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --