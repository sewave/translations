Mighty Morphin Power Rangers (Mega Drive)
Traducci�n al Espa�ol v1.0 (03/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mighty Morphin Power Rangers (U) [!].bin
2.097.152 bytes
MD5: cdcfb24231942f535a18d2097ab5b68e
SHA1: dbe0c63c9e659255b091760889787001e85016a9
CRC32: 715158a9

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --