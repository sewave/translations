Rod Land (NES)
Traducci�n al Espa�ol v1.0 (16/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rod Land (E) [!].nes
MD5: 0ee0779ad39042e1767ff09aeafb92dd
SHA1: 34e755c33ef9be6ac5d2270f4d48c5a49f2365b4
CRC32: 11a245a0
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --