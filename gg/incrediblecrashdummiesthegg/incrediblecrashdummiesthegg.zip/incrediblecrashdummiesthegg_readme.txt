The Incredible Crash Dummies (Game Gear)
Traducción al Español v1.0 (10/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Incredible Crash Dummies, The (U).gg
MD5: 4d7fafe13d1aa4c9ea893bd4ec2f8332
SHA1: 6858554fc26f2382a262736854496e11f0925d40
CRC32: 087fc247
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --