D-Day (MSX)
Traducción al Español v1.0 (20/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
D-Day (1984) (Toshiba Emi) (J).rom
MD5: f791fdd30dfd64019281ae53e4343bd4
SHA1: 18e87e15b09ec2fddc52fad10edc57918fadec34
CRC32: 5d284ea6
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --