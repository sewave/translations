Moomin's Tale (Game Boy Color)
Traducción al Español v1.0 (24/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Moomin's Tale (Europe) (En,Fr,De).gbc
MD5: 517ef53718009b20d7bf7771aef191dd
SHA1: 06e57b38b7f9ec71809f309aa7d220af48ca96b6
CRC32: 45543ba2
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --