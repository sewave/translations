Super Mario Bros. 3
Traducci�n al Espa�ol v1.0 (22/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Super Mario Bros. 3
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Super Mario Bros. 3
-----------------
Tercera parte de Super Mario para la NES.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Super Mario Bros. 3 (U) (PRG1) [!].nes
393.232	bytes
CRC32: 0b742b33
MD5: 86d1982fea7342c0af9679ddf3869d8d
SHA1: 6bd518e85eb46a4252af07910f61036e84b020d1

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --