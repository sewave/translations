Bugs Bunny (Game Boy)
Traducción al Español v1.0 (16/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bugs Bunny (U) [!].gb
MD5: 43189b859c0036119f233d46b1f2e9fd
SHA1: 2a3e982e542a849f95b4497025ca5b04db2abe8c
CRC32: 403e1b7e
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --