Wardner
Traducci�n al Espa�ol v1.0 (11/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Wardner
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Wardner
-----------------
Adaptaci�n del arcade de plataformas para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Wardner (U) [!].gen
524.288	bytes
CRC32: 1e369ae2
MD5: 03fcaef50c6a5e889690a25b1433499a
SHA1: 23bd6421f0e3710350e12f9322e75160a699ace8

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --