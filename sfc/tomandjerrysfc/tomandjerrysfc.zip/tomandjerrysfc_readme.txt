Tom and Jerry (Super Nintendo)
Traducción al Español v1.0 (16/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tom and Jerry (USA).sfc
MD5: bc16be2e9c7e170f7cd10da919f3e099
SHA1: 768b7b339804ddf13aaca59713a4e2c5e7ef9f3a
CRC32: 8b1dafbb
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --