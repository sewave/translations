Radical Rex (Mega Drive)
Traducci�n al Espa�ol v1.0 (19/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Radical Rex (U) [!].bin
MD5: 41b34e2f22ca4cfffb2d6190fad878e4
SHA1: 51019abbb8a4fc246eacd5f553628b74394fab66
CRC32: 2e6eec7e
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --