Rainbow Islands (Master System)
Traducci�n al Espa�ol v1.0 (01/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rainbow Islands (E) [!].sms
MD5: ffba9869948e2cef2bda6f805cc72087
SHA1: acff4b6175aaaed9075f6e41cf387cbfd03eb330
CRC32: c172a22c
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --