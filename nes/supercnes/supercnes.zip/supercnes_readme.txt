Super C (NES)
Traducción al Español v1.0 (25/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super C (U) [!].nes
MD5: 5fef80625f484fca06fdb58ebff9d8bb
SHA1: 32f706c6222e7ec877c08a1adc6b7c7bbb69f3da
CRC32: 1ac846f0
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --