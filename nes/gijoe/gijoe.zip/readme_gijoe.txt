G.I. Joe
Traducci�n al Espa�ol v1.0 (20/09/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre G.I. Joe
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre G.I. Joe
-----------------
Un juego de accion/plataformas bastante interesante.
Este parche lo traduce completamente al espa�ol, a�ade la � y acentos.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
G.I. Joe (U) [!].nes
393.232 bytes
CRC32: 394fd25a
MD5: 13c45cfa08f421655737394539055567
SHA1: d64aee0326d862664eeb35a9010cae31217a0c69

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --