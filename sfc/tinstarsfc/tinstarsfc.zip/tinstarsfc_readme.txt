Tin Star (Super Nintendo)
Traducción al Español v1.0 (25/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tin Star (USA).sfc
MD5: 54981549724b1da80e7f52407f9c83cf
SHA1: ea8eaa3a726de927bb0f999bcd2883eef1e011dc
CRC32: ec26f75b
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --