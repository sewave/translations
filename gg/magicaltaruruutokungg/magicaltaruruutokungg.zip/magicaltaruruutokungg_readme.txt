Magical Taruruuto-kun (Game Gear)
Traducción al Español v1.0 (03/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Magical Taruruuto-kun (Japan).gg
MD5: 3af0c6ddf5f00a493e1f159fcedc0933
SHA1: 40fae12f1d565849158ff87700e25d6967038867
CRC32: 6e1cc23c
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --