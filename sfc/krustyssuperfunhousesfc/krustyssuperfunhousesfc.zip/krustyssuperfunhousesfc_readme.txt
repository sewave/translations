Krusty's Super Fun House (Super Nintendo)
Traducción al Español v1.0 (10/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Krusty's Super Fun House (U) (V1.1).smc
MD5: 1b977c1e3af2666a1d348cc0b9cc4a94
SHA1: 02b7a15f1c712503a36fc927ad688ade9ad8a0e5
CRC32: ac5116d9
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --