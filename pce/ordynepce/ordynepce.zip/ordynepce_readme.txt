Ordyne (PC Engine)
Traducción al Español v1.0 (16/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ordyne (U).pce
MD5: d803eb8f622521e515ff1dd715e725c0
SHA1: 06880cfeaf9a495cefa49e8c4fc2e94887d1543b
CRC32: e7bf2a74
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --