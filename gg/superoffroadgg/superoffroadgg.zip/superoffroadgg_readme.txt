Super Off-Road (Game Gear)
Traducci�n al Espa�ol v1.0 (05/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Off-Road (U).gg
MD5: aa2e29bcb367406f14f2f230647d1cfc
SHA1: 0d2fc2fa9e52e24cf0930e47c16e43a7c26adad7
CRC32: 2e217fae
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --