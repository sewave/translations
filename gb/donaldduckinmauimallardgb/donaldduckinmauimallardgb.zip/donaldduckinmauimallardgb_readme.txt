Donald Duck in Maui Mallard (Game Boy)
Traducción al Español v1.0 (17/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Donald Duck in Maui Mallard (U) [!].gb
MD5: 6dfcaebffc8e2645bb2b1e5be69e1514
SHA1: eb401c5ddff1488013ff032918ed365e82104ae0
CRC32: 6f30a43a
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --