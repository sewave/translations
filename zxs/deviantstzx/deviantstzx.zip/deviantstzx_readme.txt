Deviants (ZX Spectrum)
Traducción al Español v1.0 (10/02/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Deviants.tzx
MD5: 241586cbade194814f4901baaeeeb435
SHA1: f792463222a028227317a0ec352504ac61226b2b
CRC32: 389e2eb0
51287 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --