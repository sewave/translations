Ninja Hattori-kun - Ninja wa Syugyou de Gozaru no Maki (NES)
Traducción al Español v1.0 (31/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Hattori-kun - Ninja wa Syugyou de Gozaru no Maki (Japan).nes
MD5: e49a883a846f1217e97d3c13ac459f13
SHA1: dabbea6667446ca476678678b2bc08eb7c370643
CRC32: b20403ef
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --