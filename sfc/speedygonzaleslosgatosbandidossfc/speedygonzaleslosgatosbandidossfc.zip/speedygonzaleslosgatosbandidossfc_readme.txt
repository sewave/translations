Speedy Gonzales - Los Gatos Bandidos (Super Nintendo)
Traducción al Español v1.0 (19/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Speedy Gonzales - Los Gatos Bandidos (USA) (Rev 1).sfc
MD5: a8c26fa9951d764d958fcb1beebe5089
SHA1: 5ca97bc5e260e04ed7f5ff228c358f5d591ceec7
CRC32: cb0653d0
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --