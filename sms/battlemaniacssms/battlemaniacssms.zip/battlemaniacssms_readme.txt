Battlemaniacs
Traducci�n al Espa�ol v1.0 (03/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Battlemaniacs
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Battlemaniacs
-----------------
Version de Master System de Battletoads in Battlemaniacs.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Battlemaniacs (B) [!].sms
262.144	bytes
CRC32: 1cbb7bf1
MD5: 5401ddcc788c0f1a5dfe26e56f239fbf
SHA1: 0854e36d3bb011e712a06633f188c0d64cd65893

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --