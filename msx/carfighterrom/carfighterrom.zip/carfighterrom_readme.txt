Car Fighter (MSX)
Traducción al Español v1.0 (19/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Car Fighter (1985) (Casio) (J).rom
MD5: afb607270f33db1915766b58108c6af7
SHA1: e93c396649bf6328103e8da0247952ebef2a04e9
CRC32: 303187f5
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --