Taz-Mania
Traducci�n al Espa�ol v1.0 (27/01/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Taz-Mania
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Taz-Mania
-----------------
Plataformas de Mega Drive sobre el demonio de Tazmania.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Taz-Mania (W) [!].bin
524.288	bytes
CRC32: 0e901f45
MD5: 659550d4c9588ff594a927eb173877d2
SHA1: 01875bb6484d44a844f3d3e1ae141864664b73b8

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --