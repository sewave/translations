Whip Rush 2222 AD (Mega Drive)
Traducción al Español v1.0 (25/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Whip Rush 2222 AD (U) [!].bin
MD5: 85ec5e2358cc4e8041206bec66d47fe9
SHA1: f05560b088565c1c32c0039dc7bf58caa5310680
CRC32: 7eb6b86b
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --