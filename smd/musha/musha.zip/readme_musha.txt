M.U.S.H.A
Traducci�n al Espa�ol v1.0 (29/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre M.U.S.H.A
2. Notas del M.U.S.H.A
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre M.U.S.H.A
-----------------
Shoot em up con tintes de anime.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
M.U.S.H.A (U) [!].bin
524.288	bytes
CRC32: 58a7f7b4
MD5: d5ced66ba18ec2b8eb69b8b1a6baf0d0
SHA1: 821eea5d357f26710a4e2430a2f349a80df5f2f6

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --