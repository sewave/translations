Ka-Ge-Ki - Fists of Steel (Mega Drive)
Traducci�n al Espa�ol v1.0 (17/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ka-Ge-Ki - Fists of Steel (U) [!].bin
MD5: 31ca6dabd0443625f0c7ce3c1a6229c6
SHA1: 893b1bae5242f25494b6de64a861b1aa1dc6cf14
CRC32: effc0fa6
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --