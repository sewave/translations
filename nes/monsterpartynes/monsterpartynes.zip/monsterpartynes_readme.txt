Monster Party (NES)
Traducción al Español v1.0 (23/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Monster Party (USA).nes
MD5: 93a6a8ad271791502723fdd5c47ec629
SHA1: 2bc8244cab439ac20baa4724e8a92748d4e430e1
CRC32: 6f0ac6ec
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --