Alien Soldier
Traducci�n al Espa�ol v1.1 (11/01/2017)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Alien Soldier
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alien Soldier
-----------------
Impresionante shoot em up de treasure para megadrive, un boss rush constante.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Varios arreglos en los textos.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alien Soldier (E) [!].gen
2.097.152 bytes
CRC32: 0496e06c
MD5: 32aeea27591d0cb88dc571baa738804e
SHA1: fa141778bd6540775194d77318f27d2a934e1ac1

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --