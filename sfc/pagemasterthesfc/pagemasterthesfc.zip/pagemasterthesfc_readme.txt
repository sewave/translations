The Pagemaster (Super Nintendo)
Traducción al Español v1.0 (19/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pagemaster, The (USA).sfc
MD5: 46fbdebb1227b6068d7a44f03a0f04a4
SHA1: 02fa190bfbed8699ce8f741bac6675f3582ced68
CRC32: 26c38eee
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --