Ball Jacks (Mega Drive)
Traducción al Español v1.0 (21/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ball Jacks (JE) [c][!].bin
MD5: 4e1dea42312f072440322da246e8bbdf
SHA1: c8aa71c5632a5cc59da430ca3870cffb37fbd30f
CRC32: f5c3c54f
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --