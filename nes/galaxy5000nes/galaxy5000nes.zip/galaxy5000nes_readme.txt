Galaxy 5000 (NES)
Traducción al Español v1.0 (27/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Galaxy 5000 (U) [!].nes
MD5: 87cfe186d691f75c4e01623f54946f91
SHA1: cd11e05e8eaed1d3158e88857df0fce270ae7ff6
CRC32: 37b3ad54
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --