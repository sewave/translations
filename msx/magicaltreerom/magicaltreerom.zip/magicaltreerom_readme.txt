Magical Tree (MSX)
Traducción al Español v1.0 (03/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Magical Tree (1984) (Konami) (J).rom
MD5: 91181b037e4a772149a00990e9f8b51c
SHA1: b82dc590aadc930b43db303bb3e3458e7695e3b5
CRC32: 827038a2
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --