Mortal Kombat 4 (Game Boy Color)
Traducción al Español v1.0 (17/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mortal Kombat 4 (USA, Europe) (SGB Enhanced).gbc
MD5: 168ae412b379786f7df07bd8231baf44
SHA1: ea54fb35cd8c4d4cea234423a81f8f953b1d33e4
CRC32: 4eb71448
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --