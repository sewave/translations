Bare Knuckle III (Mega Drive)
Traducción al Español v1.0 (10/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la traducción de Twilight Translations.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bare Knuckle III (Japan).md
MD5: f1cb9e887bf4bc512d9535c89e420df7
SHA1: b9b2b4a98a9d8f4c49aa1e5395e2279339517fdb
CRC32: 5d09236f
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --