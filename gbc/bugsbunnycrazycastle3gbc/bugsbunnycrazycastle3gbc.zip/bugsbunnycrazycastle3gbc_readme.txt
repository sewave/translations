Bugs Bunny - Crazy Castle 3 (Game Boy Color)
Traducción al Español v1.0 (01/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bugs Bunny - Crazy Castle 3 (USA, Europe).gbc
MD5: 2ebf6f830013d8702eebf93955db52d5
SHA1: f4ac94b7f59191f8d4adc1b5b5ac39bee5dfd064
CRC32: 7a2801fb
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --