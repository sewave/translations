Rival Turf (Super Nintendo)
Traducción al Español v1.0 (11/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rival Turf (U).smc
MD5: e061f15d6f87cd47e27f5b9f11fe1b7e
SHA1: 86541ccb1b3e886794ef2165d93d018b158569e2
CRC32: ca988f59
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --