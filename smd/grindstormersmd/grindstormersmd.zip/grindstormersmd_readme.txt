GRIND Stormer (Mega Drive)
Traducción al Español v1.0 (25/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
GRIND Stormer (U) [!].bin
MD5: 0b11fadd7c858144c5b9f890b711b77d
SHA1: 8f93445e2d0b1798f680dda26a3d31f8aee88f01
CRC32: 7e6bef15
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --