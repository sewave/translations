Flight of the Intruder (NES)
Traducción al Español v1.0 (29/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Flight of the Intruder (USA).nes
MD5: 7efc4d5d65a5440100e56bdb5d848343
SHA1: 18e4116d04aa688a8a8629f3b6770ec8436d2778
CRC32: ca2234c6
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --