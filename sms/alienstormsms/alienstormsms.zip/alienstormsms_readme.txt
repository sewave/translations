Alien Storm
Traducci�n al Espa�ol v1.0 (23/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Alien Storm
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alien Storm
-----------------
Port del arcade beat em up de Sega para la 8 bits de sobremesa.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alien Storm (E) [!].sms
262.656	bytes
CRC32: 62a2846f
MD5: fe200aacdaf99f81b6f5adfc79ac5e21
SHA1: d10fd429f780ccd6e9c62a6b6447ff58faf755da

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --