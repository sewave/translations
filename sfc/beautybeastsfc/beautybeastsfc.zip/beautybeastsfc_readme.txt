Beauty and the Beast
Traducci�n al Espa�ol v1.0 (30/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Beauty and the Beast
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Beauty and the Beast
-----------------
Adaptaci�n de la pelicula para super nintendo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Beauty and the Beast (U).smc
1.048.576 bytes
CRC32: 956e183c
MD5: 509ab1888290b42dde397c02e4371576
SHA1: a8943fd4911b67f3ddf25fb05e7ce049775d0f62

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --