Factory Panic (Game Gear)
Traducción al Español v1.0 (08/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Factory Panic (U) [!].gg
MD5: 784f3ff02e544e3a9cf18b3b1da1f062
SHA1: 94beb8b6334bb9dc104ffdb0ad2bdd4964ed91a5
CRC32: 59e3be92
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --