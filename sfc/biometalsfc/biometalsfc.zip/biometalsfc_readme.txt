BioMetal (Super Nintendo)
Traducción al Español v1.0 (26/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
BioMetal (USA).sfc
MD5: 96b4e98c45b9b77b2641d7f81d77e890
SHA1: b2f13be7ec7e955ef8fdd398bca44e06b690a8e2
CRC32: 53d8410e
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --