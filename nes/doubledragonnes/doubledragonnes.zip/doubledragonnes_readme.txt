Double Dragon (NES)
Traducci�n al Espa�ol v1.0 (17/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Dragon (U) [!].nes
262.160 bytes
MD5: 79aa819580967ffb27a9698efbf493b9
SHA1: 84698b12f4e56a37c67bb47359758124c9b012bb
CRC32: 62afe166

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --