El Viento
Traducci�n al Espa�ol v1.0 (17/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre El Viento
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre El Viento
-----------------
Plataformas/shooter con toque anime.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basado en la mejora de MIJET.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
El Viento (U) [!].bin
1.048.576 bytes
CRC32: 070a1ceb
MD5: 6ddf640c2c5f91f12487d813b6257114
SHA1: b53e901725fd6220d8e6d19ef8df42e89e0874db

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Contributor	Type of contribution	Listed credit
M.I.J.E.T.	Hacking	

-- END OF README --