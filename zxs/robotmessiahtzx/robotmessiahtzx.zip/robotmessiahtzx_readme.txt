Robot Messiah (ZX Spectrum)
Traducción al Español v1.0 (02/08/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Robot Messiah.tzx
MD5: 59517e6d28c935463ded7360dc99306d
SHA1: 561e9e3b5fadf8e3aeaa987f7d65b00f8dfa7cf0
CRC32: 2002bbdb
48173 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --