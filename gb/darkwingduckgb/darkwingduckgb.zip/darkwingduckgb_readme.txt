Darkwing Duck
Traducci�n al Espa�ol v1.0 (03/02/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Darkwing Duck
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Darkwing Duck
-----------------
Plataformas de la serie de animaci�n para la Game Boy.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Darkwing Duck (U) [!].gb
131.072	bytes
CRC32: 238b9646
MD5: 7d776329212fa7cc2b00c5a46f06dd92
SHA1: cc1f12f3ec3852657a14d11c13d1ef91fbdda5bb

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --