Wizards & Warriors III - Kuros - Visions of Power (NES)
Traducci�n al Espa�ol v1.0 (14/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wizards & Warriors III - Kuros - Visions of Power (U) [!].nes
262.160 bytes
MD5: 36a820680b83c3a5efbc46f43e36cca9
SHA1: 9c04e7357e5b39cfd9d0a119c52102197b4a1be0
CRC32: 4f505449

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --