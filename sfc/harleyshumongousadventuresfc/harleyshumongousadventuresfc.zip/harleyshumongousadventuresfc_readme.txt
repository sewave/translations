Harley's Humongous Adventure (Super Nintendo)
Traducción al Español v1.0 (20/01/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Harley's Humongous Adventure (USA).sfc
MD5: c8ec889cc6be02aafe8cc15dbf3e84b3
SHA1: a9ea1251ad46990e62abaf505ce2062e2d6acb64
CRC32: 91e0c960
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --