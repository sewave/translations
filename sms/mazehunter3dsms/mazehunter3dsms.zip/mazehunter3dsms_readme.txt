Maze Hunter 3D (Master System)
Traducción al Español v1.0 (14/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Maze Hunter 3D (U) [!].sms
MD5: 2349ee42a09088a4a590e2c65474cdaf
SHA1: 6d94c2159a67f3140d0c9158b58aa8f0474eaaba
CRC32: 31b8040b
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --