Legendary Wings
Traducci�n al Espa�ol v1.0 (30/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Legendary Wings
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Legendary Wings
-----------------
Shoot em up de NES.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Legendary Wings (U) [!].nes
131.088	bytes
CRC32: 91109f99
MD5: 524b8bbec8d33123829c5c48339551fa
SHA1: 087a470b4d723501daf66deb77b6b2be3324675d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --