Super Adventure Island (Super Nintendo)
Traducción al Español v1.0 (27/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Adventure Island (USA).sfc
MD5: 206e6c5c05ac1a83dde21400325a4a7d
SHA1: 74a3671878b1d7c8b3fd5a14677c16b2d5566af0
CRC32: dcd46848
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --