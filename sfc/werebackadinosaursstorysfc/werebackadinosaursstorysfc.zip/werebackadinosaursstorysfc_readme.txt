We're Back! - A Dinosaur's Story (Super Nintendo)
Traducción al Español v1.0 (29/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
We're Back! - A Dinosaur's Story (USA).sfc
MD5: 8a693a871eb6034c00a4dbf752d55289
SHA1: 5dfed05ffbdf6565cbfc56becc0a2d432f1a027a
CRC32: 3f654414
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --