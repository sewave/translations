Panther (MSX)
Traducción al Español v1.0 (19/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Panther (1986) (Irem) (J).rom
MD5: 629f18292b2f7a7d3862678a7c221a95
SHA1: 479608b5a86d7c77bd6c4dd00605b8efb2e5b43e
CRC32: 33b9968c
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --