Rocket Knight Adventures
Traducci�n al Espa�ol v1.1 (10/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Rocket Knight Adventures
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Rocket Knight Adventures
-----------------
Primera parte de Mega Drive de la zarig�eya con cohete.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1: Arreglado final en pr�ctica.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Rocket Knight Adventures (U) [!].gen
1.048.576 bytes
CRC32: a6efec47
MD5: ce0fde21d2c418b24c3d904e57df466e
SHA1: 49634bb09c38fa03549577f977e6afb6cebaac48

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --