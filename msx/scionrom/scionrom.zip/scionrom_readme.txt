Scion (MSX)
Traducción al Español v1.0 (12/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Scion (1985) (Sony) (J).rom
MD5: 855e2bf57c9211ba347facc0b3124b0d
SHA1: 09fbbd923e0deb82f5e20fa8ce2d842adbf4a646
CRC32: ba3a8ea1
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --