Deep Duck Trouble Starring Donald Duck
Traducci�n al Espa�ol v1.0 (08/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Deep Duck Trouble Starring Donald Duck
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Deep Duck Trouble Starring Donald Duck
-----------------
Plataformas de Donald.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Deep Duck Trouble Starring Donald Duck (U) [!].gg
524.288	bytes
CRC32: 5a136d7e
MD5: cd792cf0d4e8ebb6f77a906ac0744b66
SHA1: 24485549001bc57b5cffee1449ad0af80e862773

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --