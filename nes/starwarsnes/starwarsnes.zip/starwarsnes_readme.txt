Star Wars (NES)
Traducción al Español v1.0 (15/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Star Wars (U) [!].nes
MD5: 2196b9d3dcce0a29d82a707f63761bc6
SHA1: 372cbd8991c8a1d5ed15189b47d5990fba5d4485
CRC32: eb506bf9
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --