Riddick Bowe Boxing (Game Gear)
Traducción al Español v1.0 (23/12/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Riddick Bowe Boxing (USA).gg
MD5: e63ff3a1086c16f7e3b2c4c63371e551
SHA1: b8487bdb0a6167753fc6de82714793181d7718db
CRC32: 38d8ec56
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --