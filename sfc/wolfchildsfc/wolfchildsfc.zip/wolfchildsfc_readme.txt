Wolfchild (Super Nintendo)
Traducci�n al Espa�ol v1.0 (12/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wolf Child (U) [!].smc
MD5: a7541f6554a7fa1aab250039ce24bcd8
SHA1: 40ef16824bce5300c90130f340b1a2ebc94a8901
CRC32: 13bfb3a0
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --