Magical Chase (PC Engine)
Traducción al Español v1.0 (19/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Magical Chase (U) [!].pce
MD5: 74d9f1bd96ba2690ed4cb989ebaeb948
SHA1: 50c940cc9b52167cb99dd760c25079a19fc0aa2b
CRC32: 95cd2979
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --