Ecco the Dolphin - Tides of Time (Game Gear)
Traducci�n al Espa�ol v1.0 (30/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ecco - The Tides of Time (U) [!].gg
MD5: 8f8cbaef1a8e1becfcc7f07b134a3d83
SHA1: 61913f6803977bb54fda7c3d969dc2c0f7c6da62
CRC32: e2f3b203
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --