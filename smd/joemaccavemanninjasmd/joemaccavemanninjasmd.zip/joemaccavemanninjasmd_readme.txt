Joe & Mac Caveman Ninja (Mega Drive)
Traducci�n al Espa�ol v1.0 (14/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Joe & Mac Caveman Ninja (U) [!].bin
MD5: 9800244038a6235c6d437582aa75f52f
SHA1: d238ecdbc76affb0b92946a1ee984399b6e8fe27
CRC32: 85bcc1c7
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --