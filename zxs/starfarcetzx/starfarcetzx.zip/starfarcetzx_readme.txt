Star Farce (ZX Spectrum)
Traducción al Español v1.0 (31/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Star Farce.tzx
MD5: cb8b609ccc42d4918b0153234db5aba7
SHA1: 19620b90681e468cc299410d3e25c7475f795604
CRC32: 28f166fb
45024 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --