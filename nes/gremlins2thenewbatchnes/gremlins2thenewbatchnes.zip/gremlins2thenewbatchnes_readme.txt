Gremlins 2 - The New Batch (NES)
Traducci�n al Espa�ol v1.0 (21/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gremlins 2 - The New Batch (U) [!].nes
MD5: 163a1d2f069e15a3023dab1830b6d5d1
SHA1: 7b3cc145cfdb80aac8e1a005a3e36c9c16a56ea9
CRC32: 2abb2ee7
393.232 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --