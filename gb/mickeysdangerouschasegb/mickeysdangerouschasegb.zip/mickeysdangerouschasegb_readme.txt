Mickey's Dangerous Chase (Game Boy)
Traducción al Español v1.0 (30/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mickey's Dangerous Chase (U) [!].gb
MD5: 16bc18ef00088094e9fad502e613be5e
SHA1: 37d0737be3773ad62664645d34505a136f0be99b
CRC32: 7b822d8f
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --