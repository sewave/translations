Secret Ties (NES)
Traducción al Español v1.0 (10/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Secret Ties (U) (Prototype).nes
MD5: f13a9ab225112c6d257128771eb97f2c
SHA1: a660792f0f05b84ed76b21fcb2b2586f239cf023
CRC32: 9e131010
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --