Hook
Traducci�n al Espa�ol v1.0 (02/11/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Hook
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Hook
-----------------
Curioso plataformas basado en la pelicula.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Hook (U) [!].gg
262.160	bytes
CRC32: f53ced2e
MD5: 5b0659fc95d81f10400bc449c2da251b
SHA1: b9bd292fa4f3ef7dd86ebae9e1b5364ce6653c45

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --