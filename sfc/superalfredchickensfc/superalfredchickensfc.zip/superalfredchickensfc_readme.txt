Super Alfred Chicken (Super Nintendo)
Traducci�n al Espa�ol v1.0 (08/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Alfred Chicken (USA).sfc
MD5: f961db05f8b7054695e2abef308380b6
SHA1: 8ee35aabd7b15c2dbeb2ff401874fc792f9aa49c
CRC32: f21c5a9d
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --