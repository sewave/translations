Altered Beast
Traducci�n al Espa�ol v1.0 (27/08/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Altered Beast
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Altered Beast
-----------------
Adaptacion de la recreativa a nes.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basado en la inglesa de aka translations.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Juuouki (J) [!].nes
262.160	bytes
CRC32: 4de1c214
MD5: 3cf0e744813aeb6b19460d4f82fc832b
SHA1: dbdbb9cc04feaaa8cea5998a3be52adac910bce8

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
Original:
akadewboy	Translation	Hacking, Translation

-- END OF README --