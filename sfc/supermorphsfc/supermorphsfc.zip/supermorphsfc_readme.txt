Super Morph (Super Nintendo)
Traducción al Español v1.0 (12/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Morph (Europe).sfc
MD5: 5afbba346d499fa38552c500478df101
SHA1: 322adec252911bf7c7a38da7c23ecedb26fd92b3
CRC32: 388f6daa
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --