The Addams Family - Pugsley's Scavenger Hunt (Game Boy)
Traducción al Español v1.0 (08/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Addams Family, The - Pugsley's Scavenger Hunt (USA, Europe).gb
MD5: 57726c28dc09949029a154f63b891dd0
SHA1: f9020e3d104cb5c5347e28f45ed9e24e6c0ebddd
CRC32: 7e054a88
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --