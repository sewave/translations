Robocop versus The Terminator
Traducci�n al Espa�ol v1.0 (13/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Robocop versus The Terminator
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Robocop versus The Terminator
-----------------
Buen port para master system del shooter.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Robocop versus The Terminator (UE) [!].sms
524.288	bytes
CRC32: 8212b754
MD5: 7e29ab7dae0049e1e3944af7da2757fb
SHA1: a5fe99ce04cb172714a431b12ce14e39fcc573e4

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --