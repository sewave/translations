Robodemons (NES)
Traducción al Español v1.0 (21/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Robodemons (Color Dreams) [!].nes
MD5: 94518fa094e776857c48ad1713aba9ae
SHA1: a586f83541c0c23da273d28b0e9f9b457cdc3d54
CRC32: 26ad792b
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --