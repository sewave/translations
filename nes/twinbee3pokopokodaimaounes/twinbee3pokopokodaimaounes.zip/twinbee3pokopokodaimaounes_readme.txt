TwinBee 3 - Poko Poko Dai Maou (NES)
Traducción al Español v1.0 (14/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la traducción de Demiforce.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
TwinBee 3 - Poko Poko Dai Maou (J) [!].nes
MD5: 17127aebd4f484036bcc78e80e4c0050
SHA1: 212d65d2ed4a8597cabcdc01e9bea50f4c003ad9
CRC32: 96529c68
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
Original:
Demi	Hacking	Full Hacking & Translation

-- FIN --