LOBO (Mega Drive)
Traducción al Español v1.0 (23/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
LOBO (Prototype) (SegaSaturno.com) [!].bin
MD5: 0a9cc02ee4ee9f0d8d1009b3de989db1
SHA1: 749fe1f7581352562a38997cb7323019b6ff1d93
CRC32: b5e09338
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --