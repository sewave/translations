Xenon 2 - Megablast (Mega Drive)
Traducción al Español v1.0 (20/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Xenon 2 - Megablast (E) [c][!].gen
MD5: 3d1d9912136bf271332eac1c6e56fa2b
SHA1: 055b554f7d61ed671eddc385bce950b2baa32249
CRC32: 59abe7f9
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --