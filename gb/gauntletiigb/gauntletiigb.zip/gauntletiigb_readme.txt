Gauntlet II (Game Boy)
Traducción al Español v1.0 (22/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gauntlet II (USA, Europe).gb
MD5: cdca15cfd1645c02fe1cc327b772264e
SHA1: dc37df322b54a5df5d04bc637e26b011b84598bf
CRC32: 1907dac5
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --