Lemmings (NES)
Traducción al Español v1.0 (19/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lemmings (USA).nes
MD5: 84e47f5f43b6101426a3058935eebe56
SHA1: 62e587ce49ff641fac3be1e6268d21038212d0fa
CRC32: cb2c08d4
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --