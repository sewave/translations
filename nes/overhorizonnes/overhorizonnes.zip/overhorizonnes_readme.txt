Over Horizon (NES)
Traducción al Español v1.0 (18/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Over Horizon (Japan).nes
MD5: e1601a6e4c20da1a70f779a8b4c0b374
SHA1: 7a30437d2ff1d02b5ccfa4da9587e584f9ab7b64
CRC32: e495fa46
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --