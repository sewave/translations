Tom and Jerry - The Movie (Master System)
Traducci�n al Espa�ol v1.0 (25/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tom and Jerry - The Movie (E).sms
MD5: 965e5576d569794aa27e89048855615f
SHA1: 30224286c65beddf37dc83f688f1bd362f325227
CRC32: bf7b7285
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --