Golgo 13 (SG-1000)
Traducci�n al Espa�ol v1.0 (25/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Golgo 13 (SG-1000).sg
MD5: cb25a12e86c729f6a51ba3dea91c1547
SHA1: bf27536c6ae71b333da8b362479da0a838d0715e
CRC32: 0d159ed0
32.768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --