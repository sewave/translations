Casino Games (Master System)
Traducción al Español v1.0 (30/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Casino Games (UE) [!].sms
MD5: ec16428b908a2c0036b799e55614be3d
SHA1: 8353b86965a87c724b95bb768d00dc84eeadce96
CRC32: 3cff6e80
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --