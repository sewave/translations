Wonder Boy - The Dragon's Trap (Game Gear)
Traducci�n al Espa�ol v1.0 (16/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wonder Boy - The Dragon's Trap (E) [!].gg
MD5: 0e8146c23d7947b4677b9b2ca12850e0
SHA1: d98344a2c644ce9a0184e8f836271c038aa16a23
CRC32: a74c97a7
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --