Quarth (Game Boy)
Traducción al Español v1.0 (22/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Quarth (USA, Europe).gb
MD5: de2236723c8d218e04c93849ebcda72d
SHA1: 89448b17700a6016a3f81de09a15e097c060d103
CRC32: bfb112ad
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --