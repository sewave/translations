The Adventures of Dino Riki (NES)
Traducci�n al Espa�ol v1.0 (07/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Adventures of Dino Riki, The (U) [!].nes
MD5: cfa4b1475a25918ced2efd63972d3411
SHA1: d0a91cbf4b268e898f17e1b4ad2c0eff6f2cd7bf
CRC32: d4f5287b
65.552 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --