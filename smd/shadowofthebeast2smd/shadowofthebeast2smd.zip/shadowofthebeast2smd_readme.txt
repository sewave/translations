Shadow of the Beast 2 (Mega Drive)
Traducci�n al Espa�ol v1.0 (01/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shadow of the Beast 2 (UE) [!].gen
MD5: 596c1dda590f4b6611132206c9184970
SHA1: 260a497348313c22f2d1a626150b0915990720c2
CRC32: 2dede3db
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --