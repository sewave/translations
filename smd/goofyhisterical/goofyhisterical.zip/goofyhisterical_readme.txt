Goofy's Hysterical History Tour
Traducci�n al Espa�ol v1.0 (30/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Goofy's Hysterical History Tour
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Goofy's Hysterical History Tour
-----------------
Plataformas de Goofy para MEGA DRIVE.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Goofy's Hysterical History Tour (U) [!].bin
1.048.576 bytes
CRC32: 4e1cc833
MD5: 426471b87024c7b1e688fa8474390624
SHA1: caaeebc269b3b68e2a279864c44d518976d67d8b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --