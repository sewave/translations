Castlevania Legends (Game Boy)
Traducción al Español v2.0 (18/11/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

La traducción está completa excepto el final con todos los tesoros, 
eso son imágenes aunque parezca texto, la traducción sería así:
Tras un tiempo, la joven chica de nuestra leyenda fue madre,
cuyo niño llevaría el destino y la tragedia de la familia
Belmont y el linaje de las maneras oscuras.
Un niño cargado con un destino maldito.
Y aún así este niño, antes contento en el amor de su madre,
también se alzará para luchar valientemente contra el
Príncipe de la Oscuridad, que volverá una vez más.
Este niño quien, un día será alabado por todo el mundo como
héroe...

V2.0:
-Cambiado Transylvania por Transilvania
-Traducidos gráficos L, B, P de la barra de estado
-Añadidos Ó e Í al menú
-Cambiado PASSWORD por CLAVE en introducción de clave
-Añadidos acentos y ¡¿ñ y reescritos los diálogos principales y los finales
-Traducido STAFF por GRUPO en los créditos y añadidas Á y Ñ

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Castlevania Legends (USA, Europe) (SGB Enhanced).gb
MD5: 1475824e7262c0d6359f43c287e034a5
SHA1: 91a8e49bf6eac5fe62ec2cc5e6decbd08ce9b515
CRC32: ad9c17fb
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --