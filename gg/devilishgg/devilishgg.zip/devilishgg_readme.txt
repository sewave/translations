Devilish (Game Gear)
Traducci�n al Espa�ol v1.0 (14/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Devilish (U) [!].gg
131.072 bytes
MD5: f0ceed28d0e83bc4adc688d06d12bf2e
SHA1: 421a416c71dd245d80b362af57d01c80547cf042
CRC32: c01293b0

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --