Mega Man X (Super Nintendo)
Traducción al Español v1.0 (29/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mega Man X (USA) (Rev 1).sfc
MD5: df1cc0c8c8c4b61e3b834cc03366611c
SHA1: c65216760ba99178100a10d98457cf11496c2097
CRC32: ded53c64
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
Denim - Mega Man X Compression / Decompression Tools.

-- FIN --