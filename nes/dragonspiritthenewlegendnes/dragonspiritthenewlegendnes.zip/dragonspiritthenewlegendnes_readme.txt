Dragon Spirit - The New Legend (NES)
Traducci�n al Espa�ol v1.0 (30/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon Spirit - The New Legend (U) [!].nes
MD5: f4284501969a05ef76e53fe43d193729
SHA1: 01b206f8cba9669fc6166a62b78c1522475d863a
CRC32: fd719491
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --