Super Fantasy Zone (Mega Drive)
Traducción al Español v1.1 (04/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Especial -> espacial.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Fantasy Zone (Europe).md
MD5: bd52a3c0097986a473f42dd58279408e
SHA1: ed4f8a98eed7838d29fa31a6f34d11f6d8887c7f
CRC32: 927975be
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --