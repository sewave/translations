Indiana Jones and the Last Crusade (NES)
Traducción al Español v1.0 (08/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Indiana Jones and the Last Crusade (U) (UBI Soft) [!].nes
MD5: b0a610f4e1a87d5a7d7baf1afa95a779
SHA1: bc45ee64cb6b8d19b14d512d86b192a736854b24
CRC32: ed5fa6c4
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --