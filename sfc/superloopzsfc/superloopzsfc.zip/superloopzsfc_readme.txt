Super Loopz (Super Nintendo)
Traducción al Español v1.0 (12/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Loopz (Japan).sfc
MD5: 3f8a4c4ac29a36a47b2c2cd8c5388a1c
SHA1: 26ea349aefa5926dc94b493284ece8052a86b7a8
CRC32: 49601821
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --