Golden Axe III (Mega Drive)
Traducción al Español v2.0 (28/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Golden Axe III (Japan).md
MD5: 7d9f963c9c2e22b542516edd03ada6f6
SHA1: cd9ecc1df4e01d69af9bebcf45bbd944f1b17f9f
CRC32: c7862ea3
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --