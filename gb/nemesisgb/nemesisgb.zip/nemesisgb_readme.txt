Nemesis (Game Boy)
Traducción al Español v1.0 (03/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nemesis (U) [!].gb
MD5: 1eb7ff636e532321a18885eea660604a
SHA1: 0ad4a8f156bc6899e2337417cedf9e279f8abc08
CRC32: 5110e971
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --