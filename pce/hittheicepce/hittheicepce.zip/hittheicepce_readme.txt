Hit the Ice - VHL - The Official Video Hockey League (PC Engine)
Traducción al Español v1.0 (23/11/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hit the Ice - VHL - The Official Video Hockey League (USA).pce
MD5: d2f94b64b528c320d5ee148fe77f05f5
SHA1: 19f201ffeb790c4d5685e5241cf5b37c25e15480
CRC32: 8b29c3aa
393216 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --