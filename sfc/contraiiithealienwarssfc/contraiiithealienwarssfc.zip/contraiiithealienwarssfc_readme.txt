Contra III - The Alien Wars (Super Nintendo)
Traducción al Español v1.0 (30/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Contra III - The Alien Wars (USA).sfc
MD5: ede82658dafdd6febbfbe6a9c9082500
SHA1: 265886e3f665adf2507e7b2f08b6b2ed9d0018b2
CRC32: 84da7cfe
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --