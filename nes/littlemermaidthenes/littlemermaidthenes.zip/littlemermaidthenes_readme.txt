The Little Mermaid (NES)
Traducción al Español v2.0 (12/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Retraducción de script

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Little Mermaid, The (USA).nes
MD5: 7a0b80fefb770bf5139a3d09e7835280
SHA1: 20622bb297a09e0d4863df21256b25210cbecd8a
CRC32: 08eb97db
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --