Super Shadow of the Beast (Super Nintendo)
Traducci�n al Espa�ol v1.0 (01/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Shadow of the Beast (U).smc
MD5: eb4effee6bf3e97632b92768ab51fa1c
SHA1: 463fc84a163e1946190aa9683f518dc4e1bf0b97
CRC32: beadfd61
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --