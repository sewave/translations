Toki (NES)
Traducción al Español v2.0 (20/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
Texto de JUGADOR, JUGADORES, CRÉDITO completos.
Añadido Ó y É.
Traducidos gráficos de la barra de estado.
Traducido GAME OVER.
Revisión de textos.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Toki (USA).nes
MD5: 9a47af43ca5e8a6a11e58726f05ee5e8
SHA1: aaca3416696b8bfe96fdd53f7c652aef5e10b211
CRC32: 5bd50be6
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --