Journey to Silius (NES)
Traducción al Español v1.1 (28/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado "CONTINÚA"

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Journey to Silius (USA).nes
MD5: 407b5151f2642523cba218f927926e9c
SHA1: 275244538589393b552b159ab1d380090c8e8996
CRC32: 8f77cce0
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --