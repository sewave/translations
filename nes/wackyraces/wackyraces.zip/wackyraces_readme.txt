Wacky Races
Traducci�n al Espa�ol v1.1 (24/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Wacky Races
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Wacky Races
-----------------
O los Autos Locos, buen plataformas de ATLUS.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Se a�aden acentos, � y ��
1.1: A�adida pantalla de titulo de sics

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Wacky Races (U) [!].nes
262.160	bytes
CRC32: 6a862965
MD5: c952e53c6df29b5c1438113a763ecdec
SHA1: d332ef83160434cdb1099332c3a3d4b765ae25b5

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
Sics - Pantalla titulo

-- END OF README --