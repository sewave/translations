Jordan vs Bird (Mega Drive)
Traducción al Español v1.0 (12/10/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jordan vs Bird (USA, Europe) (v1.1).md
MD5: 0b37c95079a0c8e64230df35eb3888c2
SHA1: 4c3c6696157a3629f10aa60626f504cd64c36a58
CRC32: 4d3ddd7c
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --