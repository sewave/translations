Great Basketball (Master System)
Traducción al Español v1.0 (08/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Great Basketball (JUEB) [!].sms
MD5: 450d68460d4ae07a7cc98d36491fd4f8
SHA1: 2fdb7ebce61e316ded27b575535d4f475c9dd822
CRC32: 2ac001eb
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --