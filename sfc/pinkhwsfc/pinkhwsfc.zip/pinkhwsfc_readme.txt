Pink Panther in Pink Goes to Hollywood (Super Nintendo)
Traducci�n al Espa�ol v1.0 (23/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pink Panther in Pink Goes to Hollywood (U).smc
MD5: a547adcaf7977ccd482278edbbfad684
SHA1: 94466ff1143311261dc514f2e30f682b55de71c1
CRC32: 8bae9438
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --