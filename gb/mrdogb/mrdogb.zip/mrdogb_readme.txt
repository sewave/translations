Mr. Do! (Game Boy)
Traducción al Español v1.0 (17/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mr. Do! (U).gb
MD5: 65e455737df458e59cc7b0892b95e6cd
SHA1: 1262a3119e7d7cb724863afa0ac467756f2fe611
CRC32: a1122fc0
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --