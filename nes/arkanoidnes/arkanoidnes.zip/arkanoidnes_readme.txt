Arkanoid (NES)
Traducci�n al Espa�ol v1.1 (31/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
V1.1: Arreglado "GAME OVER" -> "FIN JUEGO"

Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Arkanoid (U) [!].nes
MD5: 6a2bfa3c6e9b1ce1e21aabd0dfbf2779
SHA1: b2b30c4f30dd853c215c17b0c67cfe63d61a3062
CRC32: ee93a28c
49.168 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --