The Happiest Days Of Your Life (ZX Spectrum)
Traducción al Español v1.0 (10/02/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
The Happiest Days Of Your Life.tzx
MD5: 9546010f19bf102c7e5ab89b3961c23c
SHA1: c502afa8f017288448f9b9ba6c4b2f1390ceb242
CRC32: c9872e93
48672 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --