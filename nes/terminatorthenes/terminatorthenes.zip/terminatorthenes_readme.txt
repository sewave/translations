The Terminator (NES)
Traducción al Español v1.0 (19/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Terminator, The (U) [!].nes
MD5: 66848964bd8a3a14e51d07a4c0416dd3
SHA1: 5b4c78a47ce7d494b7cdd2e952009c20f9c5b131
CRC32: 48e1cddb
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --