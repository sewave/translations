Bomber Man (MSX)
Traducción al Español v1.0 (19/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bomber Man (1983) (Hudson) (J).rom
MD5: 7a277f7ac3fcc30b995cbd672c8fc094
SHA1: 5324e053709ff8da6c18ae4afba6a2e0c3a722ba
CRC32: 9a5aef05
8192 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --