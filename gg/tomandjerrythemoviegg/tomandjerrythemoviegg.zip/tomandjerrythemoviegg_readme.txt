Tom and Jerry - The Movie (Game Gear)
Traducci�n al Espa�ol v1.0 (25/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tom and Jerry - The Movie (U) [!].gg
MD5: c0246eed0c11ebe7a9b144a00ed61df1
SHA1: 514f8bc2e9306f4005d5a8aa2dc49304d48bfc82
CRC32: 5cd33ff2
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --