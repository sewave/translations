Squashed (NES)
Traducción al Español v1.0 (24/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Squashed (USA) (Proto).nes
MD5: 09aa9678774afea90a57ef94151016c6
SHA1: b0a96664cdd218b93412aa544665d9c0ebce26a7
CRC32: daad65e0
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --