Sonic The Hedgehog (Game Gear)
Traducci�n al Espa�ol v1.0 (19/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sonic The Hedgehog (U) (V1.1) [!].gg
MD5: b1de7027824c434ce8de59782705f5c9
SHA1: 7dbbbca2229e74fcb8f90ec794aa6e5cb168e489
CRC32: d163356e
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --