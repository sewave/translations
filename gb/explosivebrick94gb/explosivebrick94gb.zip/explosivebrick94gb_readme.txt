Explosive Brick '94 (Game Boy)
Traducción al Español v1.0 (15/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Explosive Brick '94 (Sachen) [!].gb
MD5: 377d58fdbc0928ebb4516e41885c5b4b
SHA1: 81bac46c005183313117d3e9145122db6a3e6227
CRC32: e5541ff5
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --