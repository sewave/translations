Choplifter (Master System)
Traducción al Español v1.0 (24/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Choplifter (UEB) [!].sms
MD5: 747a206eaaadf48714695e8b4ccead7e
SHA1: 856e741eec9692fcc3b22c5c5642f54482e6e00b
CRC32: 4a21c15f
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --