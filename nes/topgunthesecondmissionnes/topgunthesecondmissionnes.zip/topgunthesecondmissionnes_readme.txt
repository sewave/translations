Top Gun - The Second Mission (NES)
Traducción al Español v1.0 (11/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Top Gun - The Second Mission (U) [!].nes
MD5: a403fefedb1ad7819a27b54270f33c1c
SHA1: ee7747f09f98e6fc1717652a7a485982f5b2d6d6
CRC32: 4519fb7a
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --