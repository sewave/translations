Hudson's Adventure Island III
Traducci�n al Espa�ol v1.1 (11/03/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Hudson's Adventure Island III
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Hudson's Adventure Island III
-----------------
Tercera parte del famoso plataformas de hudson.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Arreglada la pantalla EXIT/SKIP

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Hudson's Adventure Island III (U) [!].nes
262.160	bytes
CRC32: 952cdacf
MD5: f15d5835041c4b28b98b9551fb3ce764
SHA1: 9f8d51762125df0c1a6ab6eff41fbf7d0e65d465

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --