Predator 2 (Master System)
Traducción al Español v1.0 (15/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Predator 2 (E) [!].sms
MD5: 1389419d90834d3700b772e984143fde
SHA1: ee26c9f5fd08ac73b5e28b20f35889d24c88c6db
CRC32: 0047b615
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --