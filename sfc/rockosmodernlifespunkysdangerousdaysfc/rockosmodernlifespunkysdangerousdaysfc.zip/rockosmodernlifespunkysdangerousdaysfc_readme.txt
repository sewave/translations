Rocko's Modern Life - Spunky's Dangerous Day (Super Nintendo)
Traducción al Español v1.1 (02/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglada pausa.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rocko's Modern Life - Spunky's Dangerous Day (USA).sfc
MD5: 08dd2df63a638d46ac30c83e1530ae7e
SHA1: c5051c6dfc40f5894d17e2b757261cd6d75c7dfe
CRC32: 197b4cba
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --