Phantom 2040 (Game Gear)
Traducción al Español v1.0 (05/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Phantom 2040 (U) [!].gg
MD5: 28f08375a5cdb864564c7d5a3207d0f3
SHA1: 0e054455d99b6d1732abbe9d0ca1b25825b70b87
CRC32: 281b1c3a
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --