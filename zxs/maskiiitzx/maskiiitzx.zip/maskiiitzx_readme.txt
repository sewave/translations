Mask III (ZX Spectrum)
Traducción al Español v1.0 (05/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mask III.tzx
MD5: 558163ec2f9b32b86f1d00e1378a1481
SHA1: beb94c095027c0e2df39fcc5cc86873df8b19406
CRC32: 74ed046e
51775 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --