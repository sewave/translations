AirForce Delta (Game Boy Color)
Traducción al Español v1.0 (25/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
AirForce Delta (USA).gbc
MD5: ee37c79e8df6475d90e99e527823f92f
SHA1: 82530325b940e14edea459879289b4dce1818066
CRC32: ff31cc92
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --