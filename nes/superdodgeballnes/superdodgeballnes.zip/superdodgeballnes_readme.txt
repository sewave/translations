Super Dodge Ball (NES)
Traducción al Español v1.0 (02/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Dodge Ball (USA).nes
MD5: 9c819e679f5fab4ef836761d31e98adc
SHA1: 42f954e9bd3256c011aba14c7e5b400abe35fde3
CRC32: 052a50d7
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --