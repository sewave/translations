Power Blazer (NES)
Traducción al Español v1.0 (19/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Power Blazer (Japan).nes
MD5: 987e46b9f01368503c1af30bab5d171f
SHA1: 2ffffbf15a6dd9b739b8655b55b9bf085e300349
CRC32: 2b17a194
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --