Captain Commando
Traducci�n al Espa�ol v1.1 (08/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Captain Commando
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Captain Commando
-----------------
Port de la recreativa para SNES, versi�n americana.
v1.1:Arreglada alguna frase al derrotar un jefe.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Captain Commando (U).smc
2.097.152 bytes
CRC32: 81db73c7
MD5: fa1aca992a1bbe309651fff64541866f
SHA1: 9c28b15e170a1975acf0953ff66185a3c5c988ac

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --