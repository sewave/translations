The Mask (Super Nintendo)
Traducción al Español v1.0 (16/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mask, The (USA).sfc
MD5: c918a40bb2b3f44f3468d6a1ba0a5f88
SHA1: 6831f93eaa478eb87a51e0cae10f6935730575bb
CRC32: e17626e2
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --