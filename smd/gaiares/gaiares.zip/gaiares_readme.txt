Gaiares
Traducci�n al Espa�ol v1.0 (14/05/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Gaiares
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Gaiares
-----------------
Genial shoot em up para megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Gaiares (JU) [!].gen
1.048.576 bytes
CRC32: 5d8bf68b
MD5: 47e140ae1e70984e6cd638e6e8f8485f
SHA1: f62e8be872dc116c4cc331c50ae63a63f013eb58

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --