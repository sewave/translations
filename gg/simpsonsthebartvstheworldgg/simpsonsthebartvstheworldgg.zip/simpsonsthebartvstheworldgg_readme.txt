The Simpsons - Bart vs. The World (Game Gear)
Traducci�n al Espa�ol v1.0 (31/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Simpsons, The - Bart vs. The World (U) [!].gg
262.144 bytes
MD5: b71c156bb1fcfa6c3c48924a7b3747ff
SHA1: 256672261c9a2d35e10eb06e990e8ebc46fb35c1
CRC32: da7bd5c7

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --