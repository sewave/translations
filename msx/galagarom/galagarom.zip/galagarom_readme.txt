Galaga (MSX)
Traducci�n al Espa�ol v1.0 (19/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Galaga (1984) (Namcot) (J).rom
MD5: ad242a3199771cd5ee35ea5cdd5276b5
SHA1: faa5aef23febc61a875e28eebe3aadf83e1f5ba7
CRC32: 8856961d
32768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --