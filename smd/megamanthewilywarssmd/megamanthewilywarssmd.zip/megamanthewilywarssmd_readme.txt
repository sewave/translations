Megaman - The Wily Wars
Traducci�n al Espa�ol v1.1 (15/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Megaman - The Wily Wars
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Megaman - The Wily Wars
-----------------
Recopilaci�n de los tres primeros MegaMan de NES con el a�adido de nuevas pantallas y jefes una vez pasados.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking contiene el parche de sram y movimiento mejorado:
https://www.romhacking.net/hacks/3837/
https://www.romhacking.net/hacks/514/
V1.1: Cambiado silbato por silbido y retraducci�n de la intro de megaman 2.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Varios textos que no utilizan las letras normales no est�n traducidos, tambi�n que usan sprites.
Si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Megaman - The Wily Wars (E).bin
2.097.152 bytes
CRC32: dcf6e8b2
MD5: bb891aec8a7dfe6164033f57af2025bd
SHA1: ea9ae2043c97db716a8d31ee90e581c3d75f4e3e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Parche SRAM/Movimiento:
Contributor	Type of contribution	Listed credit
Ar8temis008	Hacking	
MottZilla	Hacking	

-- END OF README --