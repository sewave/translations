Lost World, The - Jurassic Park
Traducci�n al Espa�ol v1.0 (08/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Lost World, The - Jurassic Park
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Lost World, The - Jurassic Park
-----------------
Segunda parte de Jurassic Park para Game Gear.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Lost World, The - Jurassic Park (U).gg
1.048.576 bytes
CRC32: 8d1597f5
MD5: 68d9f394bf0dd0382a8052e60b3b8a1b
SHA1: 1730b85fac5478da92b0905c6525e715bb4470d4

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --