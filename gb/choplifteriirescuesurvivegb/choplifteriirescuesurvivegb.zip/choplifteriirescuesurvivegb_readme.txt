Choplifter II - Rescue & Survive (Game Boy)
Traducción al Español v1.0 (15/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Choplifter II - Rescue & Survive (USA).gb
MD5: d5f88d0799c85b6d59f12542da403691
SHA1: 76ef770b9c75485cc29869fca6118887aee208da
CRC32: 9c7d5e79
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --