Psychic World (Game Gear)
Traducción al Español v2.0 (25/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales y minúsculas
-Guion reescrito
-Traducida barra de estado

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Psychic World (USA, Europe) (Rev 1).gg
MD5: 52cfddc12af6a3a64030f62ccf6aca83
SHA1: 3be13f79eeb26b82343afab3e740b3a1d35978eb
CRC32: 73779b22
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --