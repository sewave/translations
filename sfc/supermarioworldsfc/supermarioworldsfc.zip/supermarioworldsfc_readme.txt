Super Mario World (Super Nintendo)
Traducción al Español v1.0 (08/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Para la compresión/descompresión gráfica se ha usado Lunar Compress 1.8.1 de
FuSoYa's Niche:  http://fusoya.eludevisibility.org
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Mario World (U) [!].smc
MD5: cdd3c8c37322978ca8669b34bc89c804
SHA1: 6b47bb75d16514b6a476aa0c73a683a2a4c18765
CRC32: b19ed489
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --