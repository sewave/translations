Minesweeper - Soukaitei (Game Boy)
Traducción al Español v1.0 (21/12/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Minesweeper - Soukaitei (Japan).gb
MD5: a36b4c6c13d1dc9a98af66f963858ba9
SHA1: 8538358957b2f6d6c58e2ceb2c83cf82149985fd
CRC32: 5532b3d1
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --