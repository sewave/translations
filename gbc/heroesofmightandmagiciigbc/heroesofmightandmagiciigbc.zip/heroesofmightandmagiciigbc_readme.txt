Heroes of Might and Magic II (Game Boy Color)
Traducción al Español v1.0 (12/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Heroes of Might and Magic II (U) (M3) [C][!].gbc
MD5: ad37726c92f43ad7915225b7eaf94ffd
SHA1: 1d6ae18073c8b789c288039b0f579ebf15d1f03c
CRC32: 53156d4d
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --