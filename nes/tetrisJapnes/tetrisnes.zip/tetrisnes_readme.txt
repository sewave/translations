Tetris (NES)
Traducción al Español v1.0 (15/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tetris (Bulletproof) (Japan) (Rev B).nes
MD5: e986b2e5202e16c480241a5c866f4bb2
SHA1: 218dbaa3827650c9ad9917f41f2d886aeb688c58
CRC32: 8032bdb7
49168 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --