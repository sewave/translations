The Adventures of Elmo in Grouchland (Game Boy Color)
Traducción al Español v1.0 (04/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Adventures of Elmo in Grouchland, The (USA).gbc
MD5: cbdc5112eb8b9878fa5fe905e0aca556
SHA1: 60f240476d2fac81b1efb83e1128e6223c766f15
CRC32: 2c4c2a5f
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --