Chuck Rock (Game Boy)
Traducci�n al Espa�ol v1.0 (06/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chuck Rock (U) [!].gb
MD5: 435b566a4b3745b0acc5a976bedd9245
SHA1: 601453f98ba7d92ebe71f3e86952a584cbea090c
CRC32: c5951d9e
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --