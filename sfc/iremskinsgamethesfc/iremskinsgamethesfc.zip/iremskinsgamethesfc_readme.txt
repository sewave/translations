The Irem Skins Game (Super Nintendo)
Traducción al Español v1.0 (03/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Irem Skins Game, The (USA).sfc
MD5: d07c40904845786944d8dac3ec327e3b
SHA1: c65b1a6effbc4a876ead6554704d821f52f39618
CRC32: b95ddc44
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --