Gumshoe (NES)
Traducción al Español v1.0 (15/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gumshoe (USA, Europe).nes
MD5: bf8a62b0189fb15b856bdf32e3d30bd4
SHA1: d2c9308fdce6ac6a6ed4819ff51ff3985ced5c68
CRC32: aab00873
163856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --