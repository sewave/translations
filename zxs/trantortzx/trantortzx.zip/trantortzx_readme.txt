Trantor (ZX Spectrum)
Traducción al Español v1.0 (22/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Trantor (Erbe).tzx
MD5: 97555ccf2ce4c17f24ef9b0031aa154d
SHA1: 053d1b7b2d4fca40c7fe60d7638e1f4382aea65d
CRC32: 40a7a0a3
48135 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --