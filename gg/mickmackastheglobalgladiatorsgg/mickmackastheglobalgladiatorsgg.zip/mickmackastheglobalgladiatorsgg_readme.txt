Mick & Mack as the Global Gladiators (Game Gear)
Traducci�n al Espa�ol v1.0 (12/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mick & Mack as the Global Gladiators (U) [!].gg
MD5: d3a436b1fb64fd6295a30cc12ba6bed9
SHA1: ddad863406d429acb218c75042d5e5c511bdad4f
CRC32: d2b6021e
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --