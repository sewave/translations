Rainbow Islands - The Story of Bubble Bobble 2 (Mega Drive)
Traducci�n al Espa�ol v1.0 (01/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rainbow Islands - The Story of Bubble Bobble 2 (J) [c][!].bin
MD5: 30682a233a4afba0b0065d0e98b5c6cc
SHA1: e35fcc88e37d1691cd2572967e1ae193fcd303eb
CRC32: c74dcb35
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --