Megaman
Traducci�n al Espa�ol v1.1 (21/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Megaman
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Megaman
-----------------
Primera parte de Megaman para la portatil de 8 bits de Sega, un mix entre Megaman 4 y 5.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1: Traducida la adquisici�n de armas, arreglada pantalla de selecci�n al eliminar a un jefe.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Megaman (U) [!].gg
524.288	bytes
CRC32: 1ace93af
MD5: 8583950be61ffbaf0f63dde8dded2ab3
SHA1: 085517c4ac940b937d0e0a900e4735a2247ca4dd

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --