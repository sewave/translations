Jaws (NES)
Traducción al Español v1.0 (01/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jaws (USA).nes
MD5: 374a3c97ea6e2df7baf88ab07c7d7f13
SHA1: 52d1645037756d76a656ea358e88209aefbd1bd6
CRC32: fece3f05
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --