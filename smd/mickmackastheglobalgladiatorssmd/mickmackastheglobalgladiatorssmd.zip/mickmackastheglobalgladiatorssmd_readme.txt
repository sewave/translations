Mick & Mack as the Global Gladiators (Mega Drive)
Traducci�n al Espa�ol v1.0 (12/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mick & Mack as the Global Gladiators (U) [!].gen
MD5: c39fe061955784a4625255f4d04084c6
SHA1: 4fd2818888a3c265e148e9be76525654e76347e4
CRC32: 40f17bb3
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --