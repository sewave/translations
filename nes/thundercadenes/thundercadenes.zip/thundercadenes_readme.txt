Thundercade (NES)
Traducción al Español v1.0 (26/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Thundercade (USA).nes
MD5: 239975b0d4860c47e6017c9ab328c98c
SHA1: dbca566355d482f529d853dd6801b0b6868b18e4
CRC32: 6c430704
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --