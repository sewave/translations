Operation Wolf (NES)
Traducción al Español v1.0 (18/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Operation Wolf (U) [!].nes
MD5: 65d93f24c8bc24420556d7b1aec013a9
SHA1: 58a2d8fd7049c3b5582516633ca6a23a91291b9e
CRC32: 80704705
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --