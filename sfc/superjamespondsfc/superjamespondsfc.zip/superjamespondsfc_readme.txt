Super James Pond (Super Nintendo)
Traducci�n al Espa�ol v1.0 (29/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super James Pond (U).smc
MD5: 14df5ecb8cc0b7cb11e3a0968da3d2a0
SHA1: b8cbc41a93787a41f1ee253041fa8dda14c51475
CRC32: d7c34122
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --