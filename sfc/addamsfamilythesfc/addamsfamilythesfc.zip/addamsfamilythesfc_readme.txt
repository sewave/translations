The Addams Family
Traducci�n al Espa�ol v1.0 (03/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Addams Family, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Addams Family, The
-----------------
Adaptaci�n de la pel�cula para SNES.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Addams Family, The (U) [!].smc
1.048.576 bytes
CRC32: 2e8034ab
MD5: 278a88adb028a8e4c279b9b468b592ed
SHA1: 3f6863985a8c6cfad71867c2349aa0ac79cb1274

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
juandex - Testing

-- END OF README --