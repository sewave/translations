Hebereke (NES)
Traducción al Español v2.0 (23/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la versión de BMF54123 y RahanAkero.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducción de cero
-Traducido el menú de juego
-Traducido START/PASSWORD
-Traducido menú de password
-Traducidos los créditos
-Parche en formato BPS como la versión inglesa

------------------------
Instrucciones de Parcheo
------------------------
En formato BPS, puedes usar Floating IPS.
Archivo utilizado:
Hebereke (Japan).nes
MD5: 1efdab0641c6d72c54bf5a57e23250bb
SHA1: 5ce5daab012ae6a49b2fe18e162343d3ea705eac
CRC32: 2a137974
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --