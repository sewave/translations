Earthworm Jim (Mega Drive)
Traducci�n al Espa�ol v1.0 (24/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Earthworm Jim (U) [!].gen
3.145.728 bytes
MD5: 074dcf012f3fd11a4c7e624474944d81
SHA1: a544211d1ebab1f096f6e72a0d724f74f9ddbce8
CRC32: df3acf59

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --