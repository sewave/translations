Jungle Strike (Mega Drive)
Traducción al Español v1.0 (06/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jungle Strike (USA, Europe).md
MD5: 3164c16bab8088a7991857750edaecb6
SHA1: 7a7568e39341b1bb218280ee05c2b37c273317b5
CRC32: a5d29735
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --