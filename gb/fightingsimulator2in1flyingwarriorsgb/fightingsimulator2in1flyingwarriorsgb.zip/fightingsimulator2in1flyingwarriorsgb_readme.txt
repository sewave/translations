Fighting Simulator 2 in 1 - Flying Warriors (Game Boy)
Traducción al Español v1.0 (12/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fighting Simulator 2 in 1 - Flying Warriors (USA, Europe).gb
MD5: 42b8ce5b0d54f4565ba99e02f09fe115
SHA1: 9073276d8adf1e59829ae48073b42ae19c9770ce
CRC32: 52678ae8
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --