Battle Field (ZX Spectrum)
Traducción al Español v1.0 (26/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battle Field.tzx
MD5: 3796d99c84ec6cd5c9e57be8627c1e38
SHA1: 6d78db2bbd22c6fe288ae80dcbbd1127f05296ef
CRC32: 6592ff47
47639 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --