Wimbledon Championship Tennis (Mega Drive)
Traducción al Español v1.0 (24/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wimbledon Championship Tennis (USA).md
MD5: 7978bb18dc7c6269f6b5c2178b93b407
SHA1: db9083fd257d7cb718a010bdc525980f254e2c66
CRC32: f9142aee
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --