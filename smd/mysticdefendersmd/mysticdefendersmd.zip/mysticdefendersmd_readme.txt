Mystic Defender
Traducci�n al Espa�ol v1.1 (27/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Mystic Defender
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mystic Defender
-----------------
Juego de acci�n/plataformas segunda parte de Spellcaster.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Traducida parte de continuar.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mystic Defender (W) (REV01) [!].gen
524.288	bytes
CRC32: 50fd5d93
MD5: 780baa7dd2f030f0b1c64897b5d4cc10
SHA1: aec8aefa11233699eacefdf2cf17d62f68cbdd98

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --