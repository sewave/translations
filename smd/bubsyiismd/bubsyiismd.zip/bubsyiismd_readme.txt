Bubsy II (Mega Drive)
Traducción al Español v1.0 (25/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bubsy II (USA, Europe).md
MD5: 87352883152efc168d1950cc0bbc73ab
SHA1: 0cfb6c619798ba47f35069dea094fbc96f974ecb
CRC32: f8beff56
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --