Ikki (NES)
Traducción al Español v1.0 (25/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ikki (Japan).nes
MD5: 0e4978aaab59bb47fb85b094df91ee02
SHA1: ededb2e90535fb23d054646051c30daabad7ea28
CRC32: e00264b5
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --