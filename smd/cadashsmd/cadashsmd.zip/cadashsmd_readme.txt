Cadash (Mega Drive)
Traducción al Español v1.0 (20/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cadash (JU) [c][!].bin
MD5: c9b85d5f6880e7734112887675115220
SHA1: 5791cc9a1b118c58fc5209bf2e64156ffdb80134
CRC32: 13bdf374
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --