Shooting Range (NES)
Traducción al Español v1.1 (07/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado modo fiesta.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shooting Range (USA).nes
MD5: 38c316bacf54b39637bd3d12b6e64c92
SHA1: e3bb45c92aa325c1fa8e37d189626594c49290a0
CRC32: ca35a3a2
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --