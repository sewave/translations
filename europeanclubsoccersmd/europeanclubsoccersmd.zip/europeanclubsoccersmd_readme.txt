European Club Soccer (Mega Drive)
Traducción al Español v1.0 (01/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
European Club Soccer (Europe).md
MD5: 150e6205d8acb22bd4034f90eeda0229
SHA1: 03e1a6c7fb8003e196c0f0bf787276a14daa313e
CRC32: 6a5cf104
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --