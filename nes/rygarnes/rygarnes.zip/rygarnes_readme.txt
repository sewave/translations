Rygar (NES)
Traducción al Español v1.0 (17/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rygar (USA) (Rev A).nes
MD5: 527cc09ab3a503372abbbf567b76db46
SHA1: a495dd96e798dee9ce14bcca7b6b44e93280db50
CRC32: 04cda7e1
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --