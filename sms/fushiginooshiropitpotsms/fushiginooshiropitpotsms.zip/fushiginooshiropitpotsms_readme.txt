Fushigi no Oshiro Pit Pot (Master System)
Traducción al Español v1.0 (21/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fushigi no Oshiro Pit Pot (J) [!].sms
MD5: 209ee37dcabc263aa462c781d3123fce
SHA1: b1afa682b2f70bfc4ab2020d7c3047aabbaf9a24
CRC32: e6795c53
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --