Batman Returns (Mega Drive)
Traducci�n al Espa�ol v1.0 (25/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batman Returns (W) [!].gen
MD5: ae267331cfe46a61f65f3cbd5abcbe72
SHA1: b173d388485461b9f8b27d299a014d226aef7aa1
CRC32: 4a3225c0
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --