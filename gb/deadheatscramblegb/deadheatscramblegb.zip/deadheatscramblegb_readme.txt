Dead Heat Scramble (Game Boy)
Traducción al Español v1.0 (08/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dead Heat Scramble (U) [!].gb
MD5: c2212d75077638539d6af4673b4939e6
SHA1: 71e560dd2b5f5c4f4dcca0837c74bb1b843a15aa
CRC32: 9e3e3656
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --