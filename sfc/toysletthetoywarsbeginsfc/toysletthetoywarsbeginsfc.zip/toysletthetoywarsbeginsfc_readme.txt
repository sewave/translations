Toys - Let the Toy Wars begin! (Super Nintendo)
Traducción al Español v1.0 (17/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Toys - Let the Toy Wars begin! (USA).sfc
MD5: a568d9a73a7c8c6ab1e2e88669c81d6d
SHA1: 9164d8adfcc0ed348a6770b3b365dc026114aee9
CRC32: efebf501
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --