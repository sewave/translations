Earthworm Jim 2 (Mega Drive)
Traducción al Español v1.0 (28/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Earthworm Jim 2 (USA).md
MD5: 2ed39b147fa5fa67d6d0707f54a5a078
SHA1: ef7cccfc5eafa32fc6acc71dd9b71693f64eac94
CRC32: d57f8ba7
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --