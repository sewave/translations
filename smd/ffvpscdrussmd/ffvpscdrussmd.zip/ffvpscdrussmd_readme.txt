Fight for Vengeance (Mega Drive)
Traducción al Español v1.0 (25/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
FFV_PSCDRus.bin
MD5: fac65792015c3ea60a1c174e85e2b434
SHA1: d241dd7a13d2c69d9a8a0fca11113cc81eb4affd
CRC32: 7db61291
4194304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --