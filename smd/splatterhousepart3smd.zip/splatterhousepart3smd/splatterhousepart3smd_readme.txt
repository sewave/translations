Splatterhouse Part 3 (Mega Drive)
Traducci�n al Espa�ol v1.0 (07/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Splatterhouse Part 3 (J) [c][!].gen
2.097.152 bytes
MD5: 7277b3202363800a03e6790d3810f362
SHA1: 1fcb8adfdb19cb772adabac14e78c560d4f2e718
CRC32: 31b83d22

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --