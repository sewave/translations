Super Monaco GP (Game Gear)
Traducción al Español v1.0 (29/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Monaco GP (U) [!].gg
MD5: 91558564f8c32117d7f05e1fef3b8c17
SHA1: d834e43d7ec6dbadf2e367afd45b7e1e4362035b
CRC32: fcf12547
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --