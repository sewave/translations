California Games (Master System)
Traducción al Español v1.0 (15/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
California Games (UE) [!].sms
MD5: 182b179a1226fb5b1e1cf6bb2f351c50
SHA1: d0f8298bb2a30a3569c65372a959612df3b608db
CRC32: ac6009a7
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --