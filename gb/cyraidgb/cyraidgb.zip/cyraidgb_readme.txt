Cyraid (Game Boy)
Traducción al Español v1.0 (22/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cyraid (U) [!].gb
MD5: e55ecbd33d5813fe6e9a4ca1d04e9f15
SHA1: e295fce5531be0df7f5a10628608e0dcf54da71b
CRC32: 9d00da55
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --