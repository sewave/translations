Super Smash TV (Master System)
Traducción al Español v1.0 (29/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Smash TV (E) [!].sms
MD5: fd65b6794d6778c7948cd9b8b02a12f5
SHA1: b4515aad1cad31980d041632e23d3be82aa31828
CRC32: e0b1aff8
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --