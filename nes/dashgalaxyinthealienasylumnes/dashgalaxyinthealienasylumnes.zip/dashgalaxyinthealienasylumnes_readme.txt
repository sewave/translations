Dash Galaxy in the Alien Asylum (NES)
Traducci�n al Espa�ol v1.0 (19/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dash Galaxy in the Alien Asylum (U) [!].nes
MD5: a40d804361cb13b9d2a3f90ed6d0cc44
SHA1: a0a70eef5948f05236099a14aeb1657b43f90624
CRC32: 28aa07ba
65552 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --