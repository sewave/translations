Cool Ball (Game Boy)
Traducción al Español v1.0 (01/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cool Ball (E) [!].gb
MD5: 57b192b42b4e1945cc7f20c98f7e1dab
SHA1: f1932d4a3f063c5395e8558a63c64e5840789ce6
CRC32: e045b886
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --