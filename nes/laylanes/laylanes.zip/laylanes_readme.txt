Layla (NES)
Traducción al Español v1.1 (17/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Arreglado INVINCIBLE.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Layla (J) [!].nes
MD5: 7a1232559a7349579816814e63d52d0a
SHA1: 668b885abf865b74f84c221fa2cc4c9ae58d1b98
CRC32: d9381fe7
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --