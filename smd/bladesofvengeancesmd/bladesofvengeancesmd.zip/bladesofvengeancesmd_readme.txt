Blades of Vengeance
Traducci�n al Espa�ol v1.0 (27/04/2017)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Blades of Vengeance
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Blades of Vengeance
-----------------
Juego fant�stico/medieval de acci�n/plataformas para 1 o 2 jugadores.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Blades of Vengeance (UE) [!].gen
1.048.576	bytes
CRC32: 74c65a49
MD5: 0ef8cf31e77cf8fab03bd7540a4751c0
SHA1: 11f342ec4be17dcf7a4a6a80649b6b5ff19940a5

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --