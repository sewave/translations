Putt & Putter (Master System)
Traducci�n al Espa�ol v1.0 (17/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Putt & Putter (E) [!].sms
MD5: c13dab68a85fef5ba28ae0f5ba4fd05f
SHA1: 760d330047a77b98e2fff786052741dc7e3760e8
CRC32: 357d4f78
131072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --