Indiana Jones and the Last Crusade (Game Boy)
Traducción al Español v1.0 (08/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Indiana Jones and the Last Crusade (UE) [!].gb
MD5: a27e15cde0a8fbfc4489e0f599a53a9a
SHA1: b656ba6c03d0cb5c81c2ed8c5c64ea8e36660aaa
CRC32: 9189921a
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --