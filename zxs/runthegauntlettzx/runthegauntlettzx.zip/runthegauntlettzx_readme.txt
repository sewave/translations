Run The Gauntlet (ZX Spectrum)
Traducción al Español v1.0 (08/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Run The Gauntlet.tzx
MD5: 95b888e0122690479641f8e464f2c335
SHA1: 0c02d6f5140179b16e22a4f236aae86c63874186
CRC32: 9268543f
125513 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --