Dynamite Headdy (JAP) (Mega Drive)
Traducción al Español v2.0 (24/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Jon Najar.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Arreglado bug que al iniciar el juego sin entrar en opciones no responden los controles
-Añadidos ¡¿áéíóú al guion principal

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dynamite Headdy (Japan).md
MD5: cdb36911439289d3453060f58682057c
SHA1: 02727a217e654f3cdf5a3fcd33b2f38d404a467d
CRC32: d03cdb53
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --