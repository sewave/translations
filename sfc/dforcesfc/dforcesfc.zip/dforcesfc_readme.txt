D-Force (Super Nintendo)
Traducción al Español v1.0 (05/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
D-Force (USA).sfc
MD5: 5837085dc684e7790d835b548c3e90b2
SHA1: 444a4001511c80f99d9cd52866828ccc668724d2
CRC32: 24230807
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --