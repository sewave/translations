Ultracore (Mega Drive)
Traducción al Español v1.0 (06/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ultracore (Japan) (En).md
MD5: 42781a2d30441e259cec4b4a4ee10097
SHA1: a7ecac360c0588cb8d4866d2593ca0c94bd6cd00
CRC32: ae7fda5a
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --