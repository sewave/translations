Probotector (Mega Drive)
Traducción al Español v2.0 (08/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0: Retraducción con acentos y ñ¡¿.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Probotector (Europe) (En,Fr,De).md
MD5: 22289fe42b00a5fe5df3299747480fc0
SHA1: 69d905751ffa6a921586767263e45ddeb73333c2
CRC32: bc597d48
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --