OutRunners (Mega Drive)
Traducci�n al Espa�ol v1.0 (10/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
OutRunners (U) [!].gen
MD5: dad0322e38b9efaa5551c0aa881fd633
SHA1: 5d00ad7d9dccd9067c4bd716c2ab9c0a18930ae2
CRC32: ede636b9
2.097.152 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --