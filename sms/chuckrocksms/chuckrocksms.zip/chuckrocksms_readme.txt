Chuck Rock (Master System)
Traducci�n al Espa�ol v1.0 (06/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chuck Rock (E) [!].sms
MD5: 2594f33f210ee4cf6356ac7b2ab8c4e7
SHA1: 0199c62afb5c09f09999a4815079875b480129f3
CRC32: dd0e2927
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --