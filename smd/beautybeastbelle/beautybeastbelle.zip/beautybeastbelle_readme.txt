Beauty and the Beast - Belle's Quest
Traducci�n al Espa�ol v1.0 (30/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Beauty and the Beast - Belle's Quest
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Beauty and the Beast - Belle's Quest
-----------------
Adaptaci�n de la pelicula para megadrive desde el punto de vista de bella.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Beauty and the Beast - Belle's Quest (U) [!].bin
1.048.576 bytes
CRC32: befb6fae
MD5: c86c3f1e23e09714ada725e69c81c46c
SHA1: f88a712ae085ac67f49cb0a8fa16a47e82e780cf

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --