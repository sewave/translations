The Jetsons - Invasion of the Planet Pirates (Super Nintendo)
Traducción al Español v1.0 (12/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jetsons, The - Invasion of the Planet Pirates (USA).sfc
MD5: 76d93ffebb00ddaf4cf23222ab28b962
SHA1: b3a08e927fe4eac5f4e47e1361cb80cc392fb06f
CRC32: 3e3073ce
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --