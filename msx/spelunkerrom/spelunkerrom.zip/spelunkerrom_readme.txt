Spelunker (MSX)
Traducción al Español v1.0 (01/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spelunker (1986) (Irem) (J).rom
MD5: 29293a0887a32a2aaab79369efaebe0b
SHA1: 49e14b0248c649e7b5754357597695abef70c17d
CRC32: dc948a3a
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --