Rendering Ranger R2 (Super Nintendo)
Traducción al Español v1.0 (11/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rendering Ranger R2 (Japan) (En).sfc
MD5: 057f03c63b9cdb4b1e7dd340982f2640
SHA1: f40ac25a6cdff1e8384723cad0290ba42fd50bda
CRC32: 8fb5ac86
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --