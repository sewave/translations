Dick Tracy (Game Boy)
Traducci�n al Espa�ol v1.0 (03/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dick Tracy (U).gb
131.072	bytes
MD5: ab5f50d0e31a07e19739453bb9a2d328
SHA1: 906361b2066c2b48500b9b709f7b4ed1018309c0
CRC32: a308b86b

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --