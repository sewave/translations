Clay Fighter - Tournament Edition
Traducci�n al Espa�ol v1.0 (03/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Clay Fighter - Tournament Edition
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Clay Fighter - Tournament Edition
-----------------
Juego de lucha con animaciones hechas con plastilina.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Clay Fighter - Tournament Edition (U).smc
3.145.728 bytes
CRC32: b360f7af
MD5: a6637ccb145e42bbce94fbce3a1bb5e7
SHA1: a7d9a90f792c90d3d51f62db6279e9533dab5ca8

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --