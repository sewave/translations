{GAME} ({SYSTEM})
Traducción al Español v1.0 ({DATE})
(C) {YEAR} Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
{HASHES}

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --