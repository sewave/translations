VR Troopers (Mega Drive)
Traducción al Español v1.1 (04/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:Arreglado continuar y fin de juego, arreglada introducción.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
VR Troopers (USA, Europe).md
MD5: 674216dccb221b14c3df1007bd2e4388
SHA1: e4c5271ef2034532841fde323f59d728365d7f6a
CRC32: 2f35516e
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --