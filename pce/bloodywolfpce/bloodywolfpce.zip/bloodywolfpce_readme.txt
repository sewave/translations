Bloody Wolf (PC Engine)
Traducción al Español v2.0 (09/11/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Guion retraducido
-Añadidos caracteres españoles

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bloody Wolf (USA).pce
MD5: f19869d1823a28e8472452baf697cf56
SHA1: 45f8762414fb6b581b6159908cc35b2607ecf237
CRC32: 37baf6bc
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --