The Simpsons - Bartman Meets Radioactive Man (NES)
Traducción al Español v1.0 (27/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Simpsons, The - Bartman Meets Radioactive Man (USA).nes
MD5: 8b537b843ef29af2b6e986a786441088
SHA1: d238eaded5a32018e215be465763a134eb8f79cf
CRC32: 7c86930e
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --