Jumpin' Kid - Jack to Mame no Ki Monogatari (NES)
Traducción al Español v1.0 (26/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jumpin' Kid - Jack to Mame no Ki Monogatari (Japan).nes
MD5: c3a222b810675b27ae2c17c2cfe49cd3
SHA1: ff4124d7293b31e0b38341fa37407a5d81eb24fb
CRC32: 93e52908
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --