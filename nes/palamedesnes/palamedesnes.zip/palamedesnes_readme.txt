Palamedes (NES)
Traducción al Español v1.0 (19/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Palamedes (U) [!].nes
MD5: e843ccdd40ee2c7369e40bea72ae3ce4
SHA1: b0279f1ea509bf57fe641d33e071330d0794075f
CRC32: c3cd6c66
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --