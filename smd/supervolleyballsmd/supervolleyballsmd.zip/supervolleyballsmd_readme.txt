Super Volley Ball (Mega Drive)
Traducción al Español v1.1 (02/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1.: Arregladas un par de erratas con la palabra "EQPO"

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Volley Ball (USA).md
MD5: b2007f23346c87e12f54e04aebd55f52
SHA1: 3f00e7f8de50e73346cba06dd44b6dd9461d5c9c
CRC32: 85102799
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --