World Championship Soccer II (Mega Drive)
Traducción al Español v1.0 (05/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
World Championship Soccer II (USA).md
MD5: d0686cf7c1851ebc960c08c9f9908a31
SHA1: f6ce0b826e028599942957729d72c7a8955c5e35
CRC32: c1dd1c8e
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --