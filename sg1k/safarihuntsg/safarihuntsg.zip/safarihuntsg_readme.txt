Safari Hunt (SG-1000)
Traducci�n al Espa�ol v1.0 (27/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Safari Hunt (SG-1000) [!].sg
16.384 bytes
MD5: f77826f62d943c4a24f7fb9c3bb4a5f9
SHA1: 902dbabbfa98d71299adda0638b87152188e1cf1
CRC32: 49e9718b

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --