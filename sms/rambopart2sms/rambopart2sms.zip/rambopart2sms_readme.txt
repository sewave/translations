Rambo - First Blood Part 2
Traducci�n al Espa�ol v1.0 (16/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Rambo - First Blood Part 2
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Rambo - First Blood Part 2
-----------------
Shooter segunda parte de Rambo para Master System.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Rambo - First Blood Part 2 (U) [!].sms
131.072 bytes
CRC32: bbda65f0
MD5: 7a080a155ad6a806da88aa1d3576d78c
SHA1: dc44b090a01d6a4d9b5700ada764b00c62c00e91

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --