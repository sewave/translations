Mega Turrican (Mega Drive)
Traducci�n al Espa�ol v1.0 (03/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mega Turrican (U) [!].bin
MD5: 8d73db292f0f4c838e72086fb3d5896b
SHA1: 180285dbfc1613489f1c20e9fd6c2b154dec7fe2
CRC32: fe898cc9
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --