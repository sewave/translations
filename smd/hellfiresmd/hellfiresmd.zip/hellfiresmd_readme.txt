Hellfire (Mega Drive)
Traducci�n al Espa�ol v1.0 (07/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hellfire (U) [!].bin
MD5: dbdc25c40b85e488a1e817557e3e375c
SHA1: 9a91bef8a07f709e1f79f8519da79eac34d1796d
CRC32: 184018f9
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --