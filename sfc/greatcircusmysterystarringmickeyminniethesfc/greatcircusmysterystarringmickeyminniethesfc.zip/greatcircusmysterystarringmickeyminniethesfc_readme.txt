Great Circus Mystery Starring Mickey & Minnie, The
Traducci�n al Espa�ol v1.1 (22/01/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Great Circus Mystery Starring Mickey & Minnie, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Great Circus Mystery Starring Mickey & Minnie, The
-----------------
Segunda parte de la saga de plataformas de Mickey de la trilog�a Disney's Magical Quest.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1: Arreglos menores.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Great Circus Mystery Starring Mickey & Minnie, The (U).smc
1.572.864 bytes
CRC32: 1903ea89
MD5: a4d68c20ac1567834403cde9d590357f
SHA1: d90d6cdcaa108738c7d41e1e9d79da5c8ddc8853

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --