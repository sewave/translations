Double Dribble (NES)
Traducción al Español v1.0 (17/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Dribble (USA) (Rev 1).nes
MD5: e1b768a0f5bb9c31572bf61b1c84dc67
SHA1: 8ebaa4e726eabb4cd7b64fcb6d012e21f24a26ee
CRC32: e3e0bc5f
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --