Space Harrier (Master System)
Traducción al Español v1.0 (20/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Space Harrier (Japan, USA).sms
MD5: b2e5047df186af7c02da17f1b285ae4f
SHA1: 51ba2185a2b93957c1c51b0a2e2b80394463bed8
CRC32: beddf80e
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --