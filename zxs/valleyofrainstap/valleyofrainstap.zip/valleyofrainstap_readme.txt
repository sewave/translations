Valley_of_Rains (ZX Spectrum)
Traducción al Español v1.0 (11/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Valley_of_Rains.tap
MD5: f11d3e4db6a00df2ea2fd2ab4535f3c1
SHA1: 84c0481f72ea81c822d7a6f3ab5606494ff91ade
CRC32: 3c706ba4
53712 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --