Terminator 2 - Judgment Day (NES)
Traducción al Español v2.1 (02/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducido subtítulo en pantalla de título
-Traducción de gráficos varios
-Guion retraducido
-Mejoradas instrucciones en pantalla
-Traducidos HOLDING, DEPOSIT, TIMER
V2.1:
-Arreglada la segunda adquisición de arma

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Terminator 2 - Judgment Day (USA).nes
MD5: 7e7edbc2801aefb931f4cefc638383a7
SHA1: 26a9230f97fffd39d8d43538dfb0195bfd38377b
CRC32: c0b4bce5
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --