Babel no Tou (NES)
Traducción al Español v1.0 (14/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Babel no Tou (J) [!].nes
MD5: 6c0cd447297e95e45db35a4373dbeae1
SHA1: 5d5fe8424394eb8449819552e309aea0e6326955
CRC32: 154a31b6
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --