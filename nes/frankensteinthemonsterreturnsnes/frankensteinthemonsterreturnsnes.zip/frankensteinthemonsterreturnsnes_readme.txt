Frankenstein - The Monster Returns (NES)
Traducción al Español v1.0 (08/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Frankenstein - The Monster Returns (USA).nes
MD5: 4bd587b71381dcc20e01b97d2ca1ef32
SHA1: 49445b48a47a579ba35551c2298f0032cd59c57f
CRC32: 84f0cd63
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --