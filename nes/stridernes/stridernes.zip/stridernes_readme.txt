Strider (NES)
Traducción al Español v1.0 (02/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Strider (U) [!].nes
MD5: 67773120c4b8b6836cbe669dad6df46c
SHA1: a91cf3ff63dd7a45c8c83bc0e192c1011d217609
CRC32: 5307702a
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --