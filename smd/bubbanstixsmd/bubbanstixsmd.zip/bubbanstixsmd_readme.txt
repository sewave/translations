Bubba N Stix (Mega Drive)
Traducción al Español v1.0 (18/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bubba N Stix (U) [!].bin
MD5: 7f6f2774da5fb57435c31708a52d8738
SHA1: 907c875794b8e3836e5811c1f28aa90cc2c8ffed
CRC32: d45cb46f
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --