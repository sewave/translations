Rollerblade Racer (NES)
Traducción al Español v1.0 (02/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rollerblade Racer (USA).nes
MD5: f66e44cc74ca408bf6a655a6879a2b22
SHA1: 182deb3b4f8933c780cca16291605bcf1c3024fd
CRC32: 09e3c83b
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --