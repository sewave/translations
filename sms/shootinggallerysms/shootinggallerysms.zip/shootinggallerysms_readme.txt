Shooting Gallery (Master System)
Traducción al Español v1.0 (01/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shooting Gallery (USA, Europe, Brazil).sms
MD5: f8ea8b8e641cabff32210ea6583f9f94
SHA1: 6c22e3fa928c2aed468e925af65ea7f7c6292905
CRC32: 4b051022
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --