Alcazar - The Forgotten Fortress (MSX)
Traducción al Español v1.0 (08/06/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alcazar - The Forgotten Fortress (Japan).rom
MD5: 4448ff0e82651aaf079621584aeac9df
SHA1: 807676038cbba043b8099eba9c5840a4811a7e59
CRC32: 3ee454b0
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --