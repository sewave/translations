Cannon Fodder (Super Nintendo)
Traducci�n al Espa�ol v1.0 (08/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cannon Fodder (E).smc
MD5: 8a61ea1d3b53375aae00cc69367dec7e
SHA1: e091a94e465078cb5bb554ea03cd8cf6ee5b87d0
CRC32: f3b5cbb1
1.572.864 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --