Lot Lot (NES)
Traducción al Español v1.0 (01/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lot Lot (Japan).nes
MD5: 112406d15da9c31fe9fb54ed008f42c4
SHA1: fc85c2e19a019746fe9865f2bcfd25c04a2717bc
CRC32: 8b7ac605
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --