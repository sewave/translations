World Cup Italia '90 (Mega Drive)
Traducción al Español v1.0 (12/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
World Cup Italia '90 (Europe).md
MD5: 11e4635d58198b873fdafc65fb6d1229
SHA1: c233313214418300a39afc446e8426cc11f99c6c
CRC32: dd95f829
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --