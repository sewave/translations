Power Moves (Super Nintendo)
Traducción al Español v1.1 (24/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:Mejorado título y arreglado continuar.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Power Moves (USA).sfc
MD5: dc20901fcbbeaceb539208ebe7bba48c
SHA1: 93d8eca8612adae232931d11c718cea588ec3716
CRC32: c2e094b5
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --