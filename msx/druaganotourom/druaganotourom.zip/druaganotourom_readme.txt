Druaga no Tou (MSX)
Traducción al Español v1.0 (02/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Druaga no Tou (Japan).rom
MD5: 8da49cfb7782c6f6391b61cf66105d69
SHA1: 9b815efaa927c11827acfdb0f9b9197b5ac97572
CRC32: 47bef309
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --