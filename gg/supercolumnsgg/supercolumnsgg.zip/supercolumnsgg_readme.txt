Super Columns (Game Gear)
Traducci�n al Espa�ol v1.0 (12/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Columns (U) [!].gg
MD5: 8f1de0caa864beed2a61f391795b0a10
SHA1: ce59845e973b7fb7b3b2121b35a95fba5727df62
CRC32: 8ba43af3
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --