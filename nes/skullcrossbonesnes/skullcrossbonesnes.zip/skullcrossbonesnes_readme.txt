Skull & Crossbones (NES)
Traducción al Español v1.0 (18/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Skull & Crossbones (USA) (Unl).nes
MD5: ca624fd4e622ad54c24103c83def9240
SHA1: b191e5d30e31e1f8613c4b3fb40b770f97ae92ed
CRC32: a8b93a4b
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --