Dennis the Menace (Game Boy)
Traducción al Español v1.0 (05/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dennis the Menace (USA).gb
MD5: f064bd662fdcb40a9f6926cc3baee116
SHA1: 4695b50738add92926dc5d4b48568b037df7cdb9
CRC32: 7eb0cd32
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --