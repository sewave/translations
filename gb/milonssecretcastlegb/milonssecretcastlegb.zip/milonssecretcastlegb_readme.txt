Milon's Secret Castle (Game Boy)
Traducción al Español v1.0 (03/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Milon's Secret Castle (U) [!].gb
MD5: 1f93249c298f3ecdc4099602d9dedbb5
SHA1: 40ff7865b543c9b6a3c2dde542819018e7f06fa8
CRC32: 62b4cc8c
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --