Thunder Force II
Traducci�n al Espa�ol v1.0 (05/01/2018)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Thunder Force II
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Thunder Force II
-----------------
Segunda parte del gran shoot em up de mega drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Thunder Force II (U) [!].gen
524.288	bytes
CRC32: 9b1561b3
MD5: 2cd56a01eef20b74ab7ea532f9b25a94
SHA1: b81e7ebc4ceb6c1ae2975d27e0a78ba1e8546b5f

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --