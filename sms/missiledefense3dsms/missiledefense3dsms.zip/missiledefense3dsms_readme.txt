Missile Defense 3-D (Master System)
Traducción al Español v1.0 (29/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Missile Defense 3-D (UEB) [!].sms
MD5: b17ca24555cc79c5f7d89f156b99e452
SHA1: 86242fcc8b9f93cdad2241f40c3eebbf4c9ff213
CRC32: fbe5cfbb
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --