Takahasi Meijin no Boukenjima (MSX)
Traducción al Español v1.0 (01/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Takahasi Meijin no Boukenjima. Wonder Boy (1986)(Hudson Soft).rom
MD5: f995dc16607cd2ff9254890fca522288
SHA1: 1672af5bc1740480e8302f7690589ea5b5391bcb
CRC32: 5130c27b
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --