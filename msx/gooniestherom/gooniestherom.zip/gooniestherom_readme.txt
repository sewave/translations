The Goonies (MSX)
Traducción al Español v1.0 (05/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Goonies, The (1986) (Konami) (J).rom
MD5: 24a6d9cfa9e38e120678a538663e8ad2
SHA1: b1248f7b9d4e16a894555c51c533d3fd9a90802e
CRC32: db327847
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --