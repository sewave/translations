Sabrina - The Animated Series - Spooked! (Game Boy Color)
Traducción al Español v1.0 (25/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sabrina - The Animated Series - Spooked! (USA, Europe).gbc
MD5: 3073432455a395835de6147399b36cfc
SHA1: 7a219159ef46c5ef88eb6b478667c2ec80194edc
CRC32: 2cf48188
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --