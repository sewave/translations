3 Ninjas Kick Back
Traducci�n al Espa�ol v1.0 (08/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre 3 Ninjas Kick Back
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre 3 Ninjas Kick Back
-----------------
Adaptacion de la pelicula a plataformas/accion.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
3 Ninjas Kick Back (U).smc
2.097.152 bytes
CRC32: f2ee11f9
MD5: c638c1175840c6640d897951daa73637
SHA1: b619576a51a3968e243028a830a455d40cf92e78

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --