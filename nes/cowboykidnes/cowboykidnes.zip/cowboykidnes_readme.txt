Cowboy Kid (NES)
Traducción al Español v2.1 (17/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
Cambios versión 2.0:
-Título
-Pantalla continuar
-Carta nivel 4
-Gráficos varios
-Tiempo
-Nombres de objetos
-Selección de buscados
-Traducidos créditos
-Minijuegos
-Mapa
2.1:
-Arreglado GAME OVER/CONTINUE

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cowboy Kid (USA).nes
MD5: 2ac82902cbd1bcb2526508822a290550
SHA1: 3f12e2ac5e074e7970735d896331bb7e5ef5bb73
CRC32: b150ae9a
524304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --