Death Duel (Mega Drive)
Traducci�n al Espa�ol v1.0 (22/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Death Duel (U) [!].bin
MD5: 2bd0bcddda80b6dac8be82dc7e3a3d76
SHA1: 21390cc3036047f3de4a58c5f41f588079b0e56f
CRC32: a9804dcc
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --