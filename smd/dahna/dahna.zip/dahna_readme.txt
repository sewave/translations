Dahna - Megami Tanjou
Traducci�n al Espa�ol v1.2 (10/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Dahna - Megami Tanjou
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Dahna - Megami Tanjou
-----------------
Accion/plataformas medieval/fantastico con buenas animaciones y sprites muy trabajados.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basado en el de cccmar.
V1.1: Correcciones en la intro y al continuar.
V1.2: Correcciones en la intro.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Dahna - Megami Tanjou (J) [!].bin
1.048.576 bytes
CRC32: 4602584f
MD5: 731b77ec3acab4aaf3b76cd3c8d82a41
SHA1: da0246a063e6f70933e251b9ae84587fe620d4f0

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al Espa�ol

Original:
Contributor	Type of contribution
celcion	Hacking	
cccmar	Translation	

-- END OF README --