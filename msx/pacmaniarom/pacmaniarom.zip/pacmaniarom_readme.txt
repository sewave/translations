Pac-Mania (MSX 2)
Traducción al Español v1.0 (12/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pac-Mania (1989) (Namcot) (J).rom
MD5: 45f9b96088f36697f779af7de373f8fe
SHA1: d5902afbd8dfb1ea96fc8cf4d62cf6e4fa40d4f7
CRC32: 7df16fc8
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --