Big Nose the Caveman (NES)
Traducción al Español v1.0 (22/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Big Nose the Caveman (USA) (Unl).nes
MD5: 2075e182698bee9b0d056d213da82040
SHA1: 07bf688a127900aa0c2cc878099134c3f4063d8a
CRC32: dcdf053f
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --