Predator (NES)
Traducci�n al Espa�ol v1.0 (18/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Predator (U) [!].nes
MD5: 225caaf558830748d3ae8d8735c0c013
SHA1: 48e6610a4a3db096aa9b5d386eab7f359318086d
CRC32: ca6d44ca
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --