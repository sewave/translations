Karnov (NES)
Traducción al Español v1.1 (29/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Restaurado mapper correcto en la cabecera iNES, ahora debería ser compatible con cualquier emulador actual.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Karnov (USA).nes
MD5: 36810c924688fee01659968d7e582bdd
SHA1: 5e593b72121a9e8edd186a3e21e54ffaffe82736
CRC32: 103f0755
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --