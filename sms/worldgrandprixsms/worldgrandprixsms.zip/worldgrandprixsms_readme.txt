World Grand Prix
Traducci�n al Espa�ol v1.0 (11/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre World Grand Prix
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre World Grand Prix
-----------------
Arcade de conducci�n para Master System con editor de circuitos.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
World Grand Prix (U) [!].sms
131.072	bytes
CRC32: 7b369892
MD5: 75550fca836414ce7286c294d03c1b04
SHA1: feff411732ca2dc17dab6d7868749d79326993d7

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --