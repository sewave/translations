Virtua Fighter 2 (Mega Drive)
Traducción al Español v1.0 (29/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Virtua Fighter 2 (UE) [!].gen
MD5: 61b922208e0518a2e127939d374a43cb
SHA1: c283bf31b646489c2341f8325c52fb8b788a3702
CRC32: 937380f3
4194304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --