Field Combat (NES)
Traducci�n al Espa�ol v1.0 (05/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Field Combat (J).nes
MD5: 1407f35d0206eec13536b548391be83f
SHA1: 1a3a57484dcd53c1d6de56c0fa5ac4e6f3413ae7
CRC32: 90d93924
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --