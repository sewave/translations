Dinobasher Starring Bignose the Caveman (Master System)
Traducción al Español v1.0 (21/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dinobasher Starring Bignose the Caveman (E) (Prototype) [!].sms
MD5: bb448ca5ce1ec7d86636c6571d6e94cb
SHA1: 05b4f23e33ada08e0a8b1fc6feccd8a97c690a21
CRC32: ea5c3a6f
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --