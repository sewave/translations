Master of Monsters (Mega Drive)
Traducción al Español v1.0 (24/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Master of Monsters (U) [!].bin
MD5: 6fd2ba6b00c102debe3dcbe6257656c1
SHA1: 28f38617911a99504542b30f70c0d9c81996ef65
CRC32: 91354820
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --