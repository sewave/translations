Mafat Conspiracy - Golgo 13
Traducci�n al Espa�ol v1.1 (25/02/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Mafat Conspiracy - Golgo 13
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mafat Conspiracy - Golgo 13
-----------------
Juego de acci�n basado en el manga Golgo 13.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1: Arreglado MAFATS en intro.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mafat Conspiracy - Golgo 13 (U) [!].nes
262.160	bytes
CRC32: a0973444
MD5: 6c3b5383adff5bd9d09a82eb5cb8da6c
SHA1: 5a8f0a99dc1dab26909bd08b949d849c108c25e8

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
Danilo1652 - Testing

-- END OF README --