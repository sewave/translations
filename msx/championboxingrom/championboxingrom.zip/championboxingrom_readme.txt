Champion Boxing (MSX)
Traducción al Español v1.0 (08/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Champion Boxing (1985) (Pony Cannon) (J).rom
MD5: 7164b72a06b210804174630131b718a8
SHA1: 39cb046a9b6b6ef4e769cdc6fdf36b274cd44039
CRC32: c4b7a5b9
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --