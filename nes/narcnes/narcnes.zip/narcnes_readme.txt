NARC (NES)
Traducción al Español v1.1 (16/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arregladas dos "A" que no se borraban.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
NARC (USA).nes
MD5: cf8f1ac43de1256f7742a0c005de4864
SHA1: 748fcca3d704f88ee923095b08d950a8564703c5
CRC32: f5985a75
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --