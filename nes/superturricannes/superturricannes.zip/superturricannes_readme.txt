Super Turrican (NES)
Traducción al Español v1.0 (04/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Turrican (Europe).nes
MD5: 460656799b0cda992a3cbfbd944f6fc5
SHA1: 19002258dd263115930528dcd42eb0d63fc9a5d5
CRC32: a2500748
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --