Robo Warrior (NES)
Traducci�n al Espa�ol v1.0 (21/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Robo Warrior (U) [!].nes
MD5: 8e47eac40ec8ca94a583cafcb9a8ba69
SHA1: b5686d7a66804ba0eb0220a6ee90b754ddd83053
CRC32: b202a98d
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --