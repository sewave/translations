Atlantean (PC Engine)
Traducción al Español v1.0 (14/09/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Atlantean.pce
MD5: b407192527c9472a489fea0aeac00f8d
SHA1: d76f867256c3ff192b0cde8a1c685d558c2066c2
CRC32: ef596649
524800 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --