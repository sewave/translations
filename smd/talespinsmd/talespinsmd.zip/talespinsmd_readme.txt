Tale Spin (Mega Drive)
Traducci�n al Espa�ol v1.0 (01/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tale Spin (UE) [!].bin
MD5: 2ac0d4208641095358d663b3eb17b397
SHA1: 9b6ab86fea23adb3cfba38b893278d856540c8b8
CRC32: f5c0c8d0
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --