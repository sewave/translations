Castlevania II - Belmont's Revenge
Traducci�n al Espa�ol v1.0 (04/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Castlevania II - Belmont's Revenge
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Castlevania II - Belmont's Revenge
-----------------
Otra entrega de castlevania para la game boy.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Castlevania II - Belmont's Revenge (U) [!].gb
131.072	bytes
CRC32: 8875c8fe
MD5: 7c65e9da405d2225d079f75e56276822
SHA1: 696b9ad1e9cfb7112977c9a7c05cf64fe8423d8a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --