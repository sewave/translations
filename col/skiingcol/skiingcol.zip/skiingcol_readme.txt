Skiing (Colecovision)
Traducción al Español v1.0 (25/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Skiing (1986) (Telegames).col
MD5: a9e17aac9858dcc504879e45f50bd3ac
SHA1: 2cfd62a4b403fc2f5344d0e095d1028cc11e4ecc
CRC32: b37d48bd
8192 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --