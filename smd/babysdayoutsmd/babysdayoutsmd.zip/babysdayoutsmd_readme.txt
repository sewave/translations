Baby's Day Out (Mega Drive)
Traducción al Español v1.0 (13/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Baby's Day Out (USA) (Proto) (February, 1995).md
MD5: 1412b2ee0dcc0cd191edf1cc3c3631f6
SHA1: 99983282e75e1cf01a47d00f0be15e20eaae0907
CRC32: 459b891c
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --