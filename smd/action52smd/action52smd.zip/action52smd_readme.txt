Action 52
Traducci�n al Espa�ol v1.0 (18/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Action 52
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Action 52
-----------------
Infame agrupaci�n de juegos cutres, aunque alguno se salva de la crema.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Action 52 (Unl) [b3].bin
2.097.152 bytes
CRC32: 8809d666
MD5: 7db63c82f6840bc7f89c0e8f538b6858
SHA1: fe9936517f45bd0262613ce4422ace873112210a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --