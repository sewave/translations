Raiden Trad (Super Nintendo)
Traducci�n al Espa�ol v1.0 (08/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Raiden Trad (USA).sfc
MD5: 4e3a04e52dddc4e8a676386bea87d3ad
SHA1: b80ab440635c149f86b7cb8ab39d19fce2ea934c
CRC32: 02ce6c96
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --