Aerial Assault
Traducci�n al Espa�ol v1.0 (12/06/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Aerial Assault
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Aerial Assault
-----------------
Shoot em up para game gear.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Aerial Assault (JU) (V1.1) [!].gg
131.072 bytes
CRC32: 04fe6dde
MD5: f1dee7875668c536f0434217a67ba2f4
SHA1: 2a91ab5817938dddf2724df2dfd95a3bc6f5156d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --