Tiny Toon Adventures - Buster's Hidden Treasure (Mega Drive)
Traducción al Español v2.0 (21/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Cambiado PASSWORD por CLAVE
-Cambiado PUNTO por MARCA y traducido mientras se juega
-Cambiado STAFF por EQUIPO
-Traducidos menús principales
-Traducido PAUSE
-Pequeños ajustes del guion

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tiny Toon Adventures - Buster's Hidden Treasure (USA).md
MD5: 4831cb1b067887a086467ec51653af48
SHA1: d8d159c7c5a365242f989cc3aad2352fb27e3af3
CRC32: a26d3ae0
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --