Castlevania - The Adventure (Game Boy)
Traducción al Español v1.0 (17/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Castlevania - The Adventure (USA).gb
MD5: 0b4410c6b94d6359dba5609ae9a32909
SHA1: fd9116efcd8eb9698f483cc5745f83b3674d7d13
CRC32: 216e6aa1
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --