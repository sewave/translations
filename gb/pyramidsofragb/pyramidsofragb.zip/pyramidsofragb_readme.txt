Pyramids of Ra (Game Boy)
Traducción al Español v1.0 (31/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pyramids of Ra (U).gb
MD5: 1c1619f1caef49132e87160aa20a0a4d
SHA1: 8b75bc3127862c8b38b7992d2560966982bbe2e0
CRC32: abef175b
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --