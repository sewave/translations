Shadow Dancer - The Secret of Shinobi (Mega Drive)
Traducción al Español v2.0 (29/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres españoles
-Intro reescrita
-Algunas cadenas extendidas
-Traducidos gráficos de la barra de estado
-Traducido PAUSE
-Traducidas letras grandes
-Traducidos gráficos POWER UP! y EXIT

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shadow Dancer - The Secret of Shinobi (World).md
MD5: 1f2a9f322e770be0a3cc2aabdf8bc575
SHA1: c5f096b08470a564a737140b71247748608c32b6
CRC32: ebe9ad10
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --