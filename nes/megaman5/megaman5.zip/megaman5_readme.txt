Mega Man V
Traducci�n al Espa�ol v1.0 (30/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Mega Man V
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mega Man V
-----------------
Quinta parte del clasico de capcom.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
En el menu de armas, pone S.Choque en vez de E.Choque, esto es porque repite letras de otros lados, no se puede corregir.
Tambi�n pone R.Coil, es por el mismo tema, coge la letra de otro lado.
Lo mismo con la S.Arrow.
Si encuentras alguno puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Megaman V (U) [!].nes
524.304	bytes
CRC32: 5e023291
MD5: d7d22bf9edfb16469975f7f4d8da518f
SHA1: 1748e9b6ecff0c01dd14ecc7a48575e74f88b778

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --