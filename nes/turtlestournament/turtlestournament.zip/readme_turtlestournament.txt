Teenage Mutant Ninja Turtles - Tournament Fighters
Traducci�n al Espa�ol v1.0 (20/12/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Teenage Mutant Ninja Turtles - Tournament Fighters
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Teenage Mutant Ninja Turtles - Tournament Fighters
-----------------
Juego de lucha con las tortugas, una version mucho mas sencilla que las de 16 bits.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles - Tournament Fighters (U) [!].nes
262.160	bytes
CRC32: ac05464f
MD5: 2029e6af90f987fa2ac7aa5d19edfdb4
SHA1: 182f901142530a509a7c9f5831b5a7f7f4c923a8

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --