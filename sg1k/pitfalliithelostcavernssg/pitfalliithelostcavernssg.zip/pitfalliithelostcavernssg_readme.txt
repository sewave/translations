Pitfall II - The Lost Caverns (SG-1000)
Traducción al Español v1.0 (21/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pitfall II - The Lost Caverns (Japan).sg
MD5: c34260b61c6a45bbdd074df3f3e72c46
SHA1: 356db6edcd337a06063957bd8cb27edeb7160f6c
CRC32: 37fca2eb
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --