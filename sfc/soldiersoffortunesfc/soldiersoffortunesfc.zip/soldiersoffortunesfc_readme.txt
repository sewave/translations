Soldiers of Fortune (Super Nintendo)
Traducción al Español v1.0 (11/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Soldiers of Fortune (U) [!].smc
MD5: f6afe62ee85f004b35c36b8f92944cae
SHA1: 90440d74aa01c4ae8a86c56d092263f6c9fa0d42
CRC32: cf719a93
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --