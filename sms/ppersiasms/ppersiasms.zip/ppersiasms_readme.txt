Prince of Persia
Traducci�n al Espa�ol v1.0 (01/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Prince of Persia
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Prince of Persia
-----------------
Version para master system de prince of persia.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Prince of Persia (E).sms
262.144	bytes
CRC32: 7704287d
MD5: 70e9b330dd6a91e7310f3c8d9a934ecc
SHA1: 7ef7b4e2fcec69946844c186c62836c0ae34665f

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --