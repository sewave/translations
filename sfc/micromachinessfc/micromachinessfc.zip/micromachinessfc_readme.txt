Micro Machines (Super Nintendo)
Traducci�n al Espa�ol v1.0 (21/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Micro Machines (U) [!].smc
MD5: b447b20f378bff1342338c5c1acc0e53
SHA1: 282c4f27d08a9def36dc4e7fe71deaaf0a5f2b43
CRC32: 364e68bb
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --