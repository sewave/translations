Sonic Blast Man II (Super Nintendo)
Traducción al Español v1.0 (25/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sonic Blast Man II (U).smc
MD5: c955c2388aff8d1b888aaff9567b8d04
SHA1: 35f07d2fa80ce6f7d11c0cf2e41c768b3e94caf7
CRC32: 24229a34
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --