Rollergames (NES)
Traducción al Español v2.0 (26/10/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos acentos
-Textos mejorados

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rollergames (USA).nes
MD5: b15ab11d5f8a5b4f76f47e252d05fb3c
SHA1: e2db0b04b75f19226c9d524d422143318141710a
CRC32: 80da9f53
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --