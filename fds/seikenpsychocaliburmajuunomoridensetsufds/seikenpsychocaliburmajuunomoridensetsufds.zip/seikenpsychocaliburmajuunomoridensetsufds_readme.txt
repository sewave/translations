Seiken Psychocalibur - Majuu no Mori Densetsu (Famicom Disk System)
Traducción al Español v1.0 (27/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basada en la de The Spoony Bard.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Seiken Psychocalibur - Majuu no Mori Densetsu (Japan).fds
MD5: b0650faacdb24ccf48d2dc1986d7128d
SHA1: 359a02325660092c5c2b6d13aa43b20f178901ca
CRC32: c41be40d
131000 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --