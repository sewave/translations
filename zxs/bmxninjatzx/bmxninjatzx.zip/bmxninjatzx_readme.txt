BMX Ninja (ZX Spectrum)
Traducción al Español v1.0 (14/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
BMX Ninja (Alternative).tzx
MD5: 9134379f3389c0c999c2b67161497a51
SHA1: 3cedf1f0d6aa0fbc63fd1f426e653111750ab940
CRC32: 6c6c75d7
57443 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --