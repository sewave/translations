Cliffhanger (Mega Drive)
Traducción al Español v1.0 (07/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cliffhanger (U) [c][!].gen
MD5: 7deb4b6859c115e0c9ad816476237465
SHA1: bed365b6b7a1ef96cbdf64b35ad42b54d7d3fb1c
CRC32: 9cbf44d3
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --