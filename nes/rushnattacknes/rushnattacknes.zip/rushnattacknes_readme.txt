Rush'n Attack (NES)
Traducción al Español v1.1 (09/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Mejoras de script y añadidos acentos.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rush'n Attack (USA).nes
MD5: 332c8c5202d4195a567d831f1197c563
SHA1: 0ad3979ba3c7696166fb60b0461f4409da653303
CRC32: ed2c6a3b
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --