Cool Spot (Game Gear)
Traducci�n al Espa�ol v1.0 (16/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cool Spot (U) [!].gg
MD5: 7f55c7e4696a9ad316e57c3f14a77f39
SHA1: c5f39a81c33327dc86b41d6f416efe09b131e14d
CRC32: 2c758fc8
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --