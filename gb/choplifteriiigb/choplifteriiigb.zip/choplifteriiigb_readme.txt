Choplifter III (Game Boy)
Traducción al Español v1.0 (22/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Choplifter III (Europe).gb
MD5: 04a6e77d1fabcbe325882e4bd79d6d4b
SHA1: fb1c83ee69fa32c26cdc7031733f17b90cdb0570
CRC32: 1b3b46ef
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --