Snow Brothers (NES)
Traducci�n al Espa�ol v1.0 (29/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Snow Brothers (U) [!].nes
MD5: 493df46ac731036292d606ae2aaf76bf
SHA1: 352b295953f5dc817f9a1daf4f5a6d781971cab8
CRC32: 701f4326
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --