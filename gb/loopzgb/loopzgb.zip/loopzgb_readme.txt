Loopz (Game Boy)
Traducción al Español v1.0 (03/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Loopz (U).gb
MD5: 7e68c061d77a2e8925442a9b6fa0a0ed
SHA1: dd2ddac2310409287299c287f1959196e0b4d14e
CRC32: 531a3e16
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --