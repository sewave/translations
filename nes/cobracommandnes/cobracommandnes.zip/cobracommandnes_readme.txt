Cobra Command (NES)
Traducci�n al Espa�ol v1.0 (17/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cobra Command (U) [!].nes
MD5: 16fc376d9130acdac01fe1598ad32c83
SHA1: b17031a2294fc8b1b3d54b7bde7963370627b496
CRC32: 40c6e687
262160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --