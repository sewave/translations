Teenage Mutant Ninja Turtles II - The Arcade Game (NES)
Traducción al Español v2.0 (10/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducida pantalla de licencia
-Ampliadas opciones en título
-Traducido Selector 1P-1J
-Guion ampliado y retraducido
-Mejorada la traducción de los créditos

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles II - The Arcade Game (USA).nes
MD5: 63d85db88f52e9a1c3da2e7813e5b0e1
SHA1: 40ff068d2a7be1202d843c2a9dc1220f087a094a
CRC32: c9ffbbdb
524304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --