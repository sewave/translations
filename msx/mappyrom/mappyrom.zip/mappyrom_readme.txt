Mappy (MSX)
Traducción al Español v1.0 (12/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mappy (1984) (Namcot) (J).rom
MD5: 134f8a060bb879a343afcae975e45adf
SHA1: e7d06c0a5c7f256c061e5b8173fdcc145d2fc4d6
CRC32: 3b702e9a
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --