Clue (Super Nintendo)
Traducción al Español v1.1 (27/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Pequeños arreglos.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Clue (USA).sfc
MD5: 061fb90e60bc8ec8128ae4bb8f5884c8
SHA1: 956b48f602a24dd3d5d64195f6366fa0b68f0738
CRC32: a4fbe827
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --