Stevedore (MSX)
Traducción al Español v1.0 (27/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Stevedore (2020) (theNestruo & Wonder) [v1.2].rom
MD5: feb5749515eb248fe212120523aa18db
SHA1: ec17403587abf2e0bd88f77d62864f52e3087136
CRC32: 859c04ad
49152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --