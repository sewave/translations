Dropzone (Game Gear)
Traducción al Español v1.0 (19/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dropzone (Europe).gg
MD5: 65df09530f9c8f02ab11982228d7d18e
SHA1: b78bc3fe6bfbc7d6f5e85d59d79be19bf7372bcc
CRC32: 152f0dcc
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --