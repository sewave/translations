Mortal Kombat (Game Boy)
Traducci�n al Espa�ol v1.0 (21/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mortal Kombat (U) [!].gb
MD5: b3474bab3eda25bdb1508ed53765fb30
SHA1: 59752879efaf2f271ce4b8a9d4a455056a2985d0
CRC32: 90eb0929
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --