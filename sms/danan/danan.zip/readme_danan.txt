Danan the Jungle Fighter
Traducci�n al Espa�ol v1.0 (06/10/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Danan the Jungle Fighter
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Danan the Jungle Fighter
-----------------
Un interesante arcade/plataformas con historia, muy entretenido.
Este parche lo traduce completamente al espa�ol y a�ade la letra �.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Danan the Jungle Fighter (E) [!].sms
262.144	bytes
CRC32: ae4a28d7
MD5: 6b0fc60aa886c060bf1a16ea97b4f441
SHA1: c99f2562117a2bf7100a3992608e9a2bcb50df35

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --