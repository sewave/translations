Taz-Mania (Mega Drive)
Traducción al Español v2.0 (11/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Guion reescrito

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Taz-Mania (World).md
MD5: 659550d4c9588ff594a927eb173877d2
SHA1: 01875bb6484d44a844f3d3e1ae141864664b73b8
CRC32: 0e901f45
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --