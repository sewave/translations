The Lion King (NES)
Traducción al Español v1.0 (16/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
No está traducida la frase final:
"EVERYTHING THE LIGHT TOUCHES IS YOUR KINGDOM" 
"TODO LO QUE TOCA LA LUZ ES TU REINO"
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lion King, The (Europe).nes
MD5: 50e8f47d0287048e25f1d8efe57f17b0
SHA1: 7841c458014849207bb63b60e1da7d5c6884c5dd
CRC32: 149e367f
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --