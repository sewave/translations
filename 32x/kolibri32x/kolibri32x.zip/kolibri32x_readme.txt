Kolibri (Mega Drive 32X)
Traducción al Español v1.0 (16/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kolibri (USA, Europe).32x
MD5: 6af6207b1e67072a9104178130c61712
SHA1: 191ae0b525ecf32664086d8d748e0b35f776ddfe
CRC32: 20ca53ef
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --