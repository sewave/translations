Mysterium (Game Boy)
Traducción al Español v1.0 (21/12/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mysterium (USA).gb
MD5: 12e9e43481d38003a4f1e2c2ce596aee
SHA1: 382c346af83e3cb9f95192378843d4e15ef93716
CRC32: eb225e96
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --