Spartan X 2
Traducci�n al Espa�ol v1.0 (27/01/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Spartan X 2
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Spartan X 2
-----------------
Segunda parte de Spartan X o Kung Fu, un beat em up lateral.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basado en la traducci�n al ingl�s de: Abstract Crouton Productions
Adem�s utiliza sus herramientas:
https://www.romhacking.net/utilities/68/

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Spartan X 2 (J).nes
262.160	bytes
CRC32: 09825979
MD5: e8051bec80c0f1a38b64200431cd77ec
SHA1: 4aee1b4ba1037c9fa8139d4f620cb3c4daa473bd

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Original:
Contributor	Type of contribution	Listed credit
occluded hairdo	Hacking	Translation
Parasyte	Hacking	

-- END OF README --