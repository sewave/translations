Golden Axe II
Traducci�n al Espa�ol v1.0 (04/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Golden Axe II
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Golden Axe II
-----------------
Segunda parte del clasico beat em up de sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Golden Axe II (W) [!].bin
524.288	bytes
CRC32: 725e0a18
MD5: 2cd3573172961fa52f622f14ccff4e1a
SHA1: 31f12a21af018cdf88b3f2170af5389b84fba7e7

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --