Vampire - Master of Darkness
Traducci�n al Espa�ol v1.1 (26/10/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Vampire - Master of Darkness
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Vampire - Master of Darkness
-----------------
Plataformas/accion clonico de castlevania, pero con algunos toques originales.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
1.1: Correcciones traduccion

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Vampire (E) [!].sms
262.144	bytes
CRC32: 20f40cae
MD5: 6ccf82ff6296fa9365b919de424dd3d9
SHA1: d03fb8fb31d6c49ce92e0a4c952768896f798dd5

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --