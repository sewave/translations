Simpsons, The - Bart vs. The Space Mutants (MEGA DRIVE)
Traducci�n al Espa�ol v1.0 (13/07/2018)
(C) 2018 Wave Translations

---------
Contenido
---------

1. Notas y Fallos Conocidos
2. Instrucciones de Parcheo
3. Cr�ditos del Parche

---------------------------
1. Notas y Fallos Conocidos
---------------------------
Esta traducci�n y hacking es completamente original.
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
2. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Simpsons, The - Bart vs The Space Mutants (UE) (REV01) [!].gen
524.288	bytes
CRC32: db70e8ca
MD5: b87cb990d9238f252a4dd89077aa180e
SHA1: 2d42143c83ec3b4167860520ee0a9030ef563333

----------------------
3. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --