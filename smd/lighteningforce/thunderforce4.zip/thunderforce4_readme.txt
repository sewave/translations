Lightening Force - Quest for the Darkstar
Traducci�n al Espa�ol v1.1 (09/01/2018)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Lightening Force - Quest for the Darkstar
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Lightening Force - Quest for the Darkstar
-----------------
Versi�n americana del gran shoot em up de megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Arreglada frase final

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Lightening Force - Quest for the Darkstar (U) [c][!].gen
1.048.576 bytes
CRC32: c8f8c0e0
MD5: bb6b10927e6238206e9a7ba8c7d91a14
SHA1: ab5bd9ddbfc07d860f44b9c72d098aef2581d1d8

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --