Soldiers of Fortune (Mega Drive)
Traducción al Español v1.0 (11/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
Las bios de los personajes no están traducidas al ser imágenes.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Soldiers of Fortune (U) [c][!].gen
MD5: b90ff517cba6492377e02d23fcda4b80
SHA1: 619faee3d78532478aad405db335d00fb93e6850
CRC32: a84d28a1
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --