Kid Dracula
Traducci�n al Espa�ol v1.0 (12/04/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Kid Dracula
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Kid Dracula
-----------------
Genial plataformas de konami parodia de castlevania.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Kid Dracula (U) [!].gb
262.144	bytes
CRC32: f27294b7
MD5: 24a6b4457a511cc667e9ac25417401ab
SHA1: f186833a2ccec808210eb4ba669f08401f950e23

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --