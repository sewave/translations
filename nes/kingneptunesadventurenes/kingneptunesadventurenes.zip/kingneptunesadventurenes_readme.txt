King Neptune's Adventure (NES)
Traducción al Español v1.1 (28/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado texto de los billetes.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
King Neptune's Adventure (Color Dreams) [!].nes
MD5: 712e6a0c7bb8f27205c1af83e94d055d
SHA1: b75fecca7954ee7094474bd2a25b5e1f97e88064
CRC32: ae4b13df
98320 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --