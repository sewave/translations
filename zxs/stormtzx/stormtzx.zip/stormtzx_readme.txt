Storm (ZX Spectrum)
Traducción al Español v1.0 (24/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Storm.tzx
MD5: 575138ed719f650b935b733e02e9d47b
SHA1: b380bc01b3a574214433f0ca6575ff896a069c97
CRC32: 8de26a4d
42893 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --