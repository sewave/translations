Dancing Blocks (NES)
Traducción al Español v1.0 (29/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Este juego es algo difícil de emular, el emulador debe soportar el mapper 143 y la ram debe estar inicializada como aleatoria, en FCEUX esto es en "Config->Ram Init->Random", en Bizhawk, eligiendo el core Neshawk, "Nes->Advanced Settings->Initial Ram pattern override" introducimos "00FFAA" sin comillas.

El juego se identifica como PAL, pero creo que funciona igual en modo NTSC.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dancing Blocks (Asia) (PAL) (Unl).nes
MD5: d7505e4c80fa09bdbad47874c83107a6
SHA1: 4449f8ae931c91d12a2663f7c7250fe6662a5f1a
CRC32: 5a7395d1
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --