Pang (Game Boy)
Traducción al Español v1.0 (26/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pang (Europe).gb
MD5: 031e78c5067b88abe2870841d1125a29
SHA1: ae97143e51b6f031efb83b245b1b2558e6cb9026
CRC32: 9ae199df
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --