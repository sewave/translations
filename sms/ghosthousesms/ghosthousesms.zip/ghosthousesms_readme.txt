Ghost House (Master System)
Traducción al Español v1.0 (06/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ghost House (UE) [!].sms
MD5: 580adb73aecd35348862fb6ed43ae956
SHA1: cbce4c5d819be524f874ec9b60ca9442047a6681
CRC32: f1f8ff2d
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --