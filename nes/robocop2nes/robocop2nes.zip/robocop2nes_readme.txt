RoboCop 2 (NES)
Traducción al Español v2.0 (14/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

-V2.0:
-Pantalla de licencias
-Guion reescrito con Ó e Í
-Nombre de las ubicaciones
-Mejorada pantalla de título
-Mejorada pantalla de GAME OVER
-Gráficos varios traducidos (CENTRUM, FLOOR, ROOF, W)
-Modificado PRESS START PLAYER X
-Mejorada pantalla de final

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
RoboCop 2 (USA) (Rev A).nes
MD5: d7904d82e8c57377ec0ec70e2fb7b89b
SHA1: 3bb345d9801c60f0d14656f52ee1b593244b6767
CRC32: f4baa4ee
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --