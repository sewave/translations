Tiny Toon Adventures 6
Traducci�n al Espa�ol v1.0 (29/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Tiny Toon Adventures 6
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Tiny Toon Adventures 6
-----------------
Juego sin licencia de plataformas de los tiny toons.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Tiny Toon Adventures 6 (Unl) [!].nes
524.304	bytes
CRC32: 476cb108
MD5: ef54e6c462c095c8a5c835026aa9407a
SHA1: c1648e8855f6947af28ab75a96104702a0f9b123

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
Danilo1652 - Testing

-- END OF README --