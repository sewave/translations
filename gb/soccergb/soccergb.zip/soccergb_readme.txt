Soccer (Game Boy)
Traducción al Español v1.0 (03/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Soccer (E) (M3) [S][!].gb
MD5: effbaf8c4b83edfebbe6451df0d44fd1
SHA1: 355fb7f220a0ba470011220282a59e707f168e1a
CRC32: c36b199b
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --