Judge Dredd (ZX Spectrum)
Traducción al Español v1.0 (22/03/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Judge Dredd.tzx
MD5: 5b6ae6a1d9a21169f723766aa38bd5b9
SHA1: 9763d8fd220236c0975c71a9543e91d4493ed1f7
CRC32: 835fc84e
47929 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --