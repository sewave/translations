Pendragon (ZX Spectrum)
Traducción al Español v1.0 (23/03/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pendragon.tzx
MD5: 86387b2161876890cac441a8dc05718f
SHA1: db1b9b4070d95b578dd36666ef5a0a7c351b9d04
CRC32: fb8be8ec
47085 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --