Back to the Future Part III (Mega Drive)
Traducci�n al Espa�ol v1.0 (27/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Back to the Future Part III (U) [!].gen
524.288	bytes
MD5: 165288c22589ef8c1a41e31215b52c34
SHA1: a704a1538fb4392e4631e96dce11eeff99d9b04a
CRC32: 66a388c3

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --