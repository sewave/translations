Altered Beast
Traducci�n al Espa�ol v1.0 (27/08/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Altered Beast
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Altered Beast
-----------------
Adaptacion de la recreativa a pc engine.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Juuouki (J).pce
524.800	bytes
CRC32: 0e163240
MD5: cdcc727a18ef2405e88db959ba94c7ed
SHA1: 624e253da44787f963dc35f586cd274714be6aab

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --