Parasol Stars - Rainbow Islands II (Game Boy)
Traducción al Español v1.0 (07/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Parasol Stars - Rainbow Islands II (Europe).gb
MD5: ab5e4c728a5b62f7985c22c61551469c
SHA1: 4970bbf5456305f2bfdb27e3a0dc14be4a0e10b7
CRC32: c35ad128
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --