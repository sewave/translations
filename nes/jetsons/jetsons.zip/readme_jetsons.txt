Jetsons, The - Cogswell's Caper!
Traducci�n al Espa�ol v1.1 (12/03/2017)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Jetsons, The - Cogswell's Caper!
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche
6. Parche del titulo

-----------------
1. Sobre Jetsons, The - Cogswell's Caper!
-----------------
Curioso plataformas basado en la serie de tv.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: A�adida pantalla de titulo de sics en parche a parte.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Jetsons, The - Cogswell's Caper! (U) [!].nes
393.232	bytes
CRC32: 0f945df6
MD5: b380cd9366bc9df6ca3f33bab6f4cd1d
SHA1: 72fcd4a5aaa14b426ac8abb8db97e42bedbbbe1d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
Sics - Parche del t�tulo

----------------------
6. Parche del titulo
----------------------

 Se distribuye por separado para que pueda se reutilizado, modificado y distribuido en otros proyectos, el mismo no requiere cr�ditos.

-- END OF README --