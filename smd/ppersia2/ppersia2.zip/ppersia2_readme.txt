Prince of Persia 2 - The Shadow and The Flame
Traducci�n al Espa�ol v1.0 (10/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Prince of Persia 2 - The Shadow and The Flame
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Prince of Persia 2 - The Shadow and The Flame
-----------------
Adaptaci�n no liberada para Mega Drive del juego de accion/plataformas de PC.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Incluye el parche para el nivel del caballo de Tony Hedstrom.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Prince of Persia 2 - The Shadow and The Flame (Beta).bin
2.097.152 bytes
CRC32: 3ab44d46
MD5: dc580653e3edc6c6b01cb1bfacc947b4
SHA1: ba63dc1e521bee68b4121b626061ebb203ac63c6

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Nivel Caballo:
Contributor	Type of contribution
Tony Hedstrom	Hacking

-- END OF README --