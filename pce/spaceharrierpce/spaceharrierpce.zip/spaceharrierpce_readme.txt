Space Harrier (PC Engine)
Traducción al Español v1.0 (19/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Space Harrier (U).pce
MD5: b87aba8faae39f238a8b2176daec96f4
SHA1: 948e6a5c30dcf945ab8332009ae4fa3ab231255a
CRC32: 43b05eb8
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --