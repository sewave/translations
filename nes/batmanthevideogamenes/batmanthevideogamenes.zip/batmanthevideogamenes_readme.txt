Batman - The Video Game (NES)
Traducción al Español v1.0 (27/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batman - The Video Game (USA).nes
MD5: 2e9f52556273aa735d0e75649541d812
SHA1: 73b33e67e3c9e1116f9fcb021b10bb1171b8696a
CRC32: 395569ec
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --