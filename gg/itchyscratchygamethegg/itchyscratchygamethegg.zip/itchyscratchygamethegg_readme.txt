The Itchy & Scratchy Game (Game Gear)
Traducción al Español v1.0 (19/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Itchy & Scratchy Game, The (U) [!].gg
MD5: 63bb5a1a959cdc79bfbe05b022f64ebf
SHA1: 2d0c2be09b977cc68a7e8f0fc415d8783ad7f8ae
CRC32: 44e7e2da
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --