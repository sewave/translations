Alien 3
Traducci�n al Espa�ol v1.0 (10/02/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Alien 3
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alien 3
-----------------
Juego de la pel�cula para la 16 bits de sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alien 3 (UE) (REV01) [!].gen
524.288	bytes
CRC32: b327fd1b
MD5: 793b92cd4a66921db6ca4f582a690db5
SHA1: 26959752d0683298146c2a89599fa598d009651b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --