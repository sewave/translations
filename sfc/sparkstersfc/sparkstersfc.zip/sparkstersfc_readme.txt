Sparkster
Traducci�n al Espa�ol v1.0 (08/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Sparkster
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Sparkster
-----------------
Primera parte de Super Nintendo de la zarig�eya con cohete.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Sparkster (U).smc
1.048.576 bytes
CRC32: 40d11c94
MD5: e00ef4c1b9e17d5fa2d8367402d28a08
SHA1: 0ac5326401903212c6565a7a982f60a56017c1ef

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --