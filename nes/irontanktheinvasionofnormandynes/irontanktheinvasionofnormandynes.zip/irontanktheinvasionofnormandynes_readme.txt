Iron Tank - The Invasion of Normandy (NES)
Traducción al Español v1.0 (16/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Iron Tank - The Invasion of Normandy (USA).nes
MD5: 31572d4d08a39292770461d4a78a5f5e
SHA1: 7d86532b323ca75d827da5ea5f67d2f10fd39690
CRC32: dcfd85fc
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --