Mappy-Land (NES)
Traducción al Español v1.0 (02/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mappy-Land (U) [!].nes
MD5: d80c89a478dfd14ffce44fa02a670055
SHA1: 68168cd5ae72adc614858a0b03a62934e47481b3
CRC32: 4e8ebcfe
163856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --