Rolling Thunder 3
Traducci�n al Espa�ol v1.1 (16/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Rolling Thunder 3
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Rolling Thunder 3
-----------------
Tercera parte de Rolling Thunder exclusiva para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Revisi�n script

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Algunos textos sueltos no los he encontrado (as� como men�s), si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Rolling Thunder 3 (U) [c][!].bin
1.572.864 bytes
CRC32: 64fb13aa
MD5: a1e062e71e091793ebb09edd4511da77
SHA1: 34c2b5df456a1f8ff35963ca737372e221e89ef6

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --