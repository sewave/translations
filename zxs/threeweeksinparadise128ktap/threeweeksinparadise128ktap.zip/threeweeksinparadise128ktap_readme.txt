Three Weeks In Paradise - 128k (ZX Spectrum)
Traducción al Español v1.0 (14/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Three Weeks In Paradise - 128k.tap
MD5: 8b42482bc7bbd775cef0830d9ea33258
SHA1: f83090dac11fe4b1cd62a3964ebad54fd4462453
CRC32: 49dc0b72
87879 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --