Journey From Darkness - Strider Returns
Traducci�n al Espa�ol v1.1 (17/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Journey From Darkness - Strider Returns
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Journey From Darkness - Strider Returns
-----------------
Segunda parte de strider para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1:Arreglado nombre del nivel 4.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Journey From Darkness - Strider Returns (U) [c][!].bin
1.048.576 bytes
CRC32: 42589b79
MD5: 62ccc620d3a721c9040d85aa5d540f86
SHA1: 8febb4aff32f40148f572d54e158f4b791736f55

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --