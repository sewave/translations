Solomon no Kagi - Oujo Rihita no Namida (Master System)
Traducci�n al Espa�ol v1.0 (27/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Solomon no Kagi - Oujo Rihita no Namida (J) [!].sms
MD5: cfa84806075e017e29ffcdd0127fe647
SHA1: 875f35d0775609776ec75ea2a8fa2297643e906c
CRC32: 11645549
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --