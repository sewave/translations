Bill's Tomato Game (Mega Drive)
Traducción al Español v1.0 (28/09/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bill's Tomato Game (USA) (Proto).md
MD5: 8e1f13ad0742e7b4309ac785f951fb93
SHA1: bd7abe4b2019f9aac53e8e124433f9f753390f8c
CRC32: 0e1f263f
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --