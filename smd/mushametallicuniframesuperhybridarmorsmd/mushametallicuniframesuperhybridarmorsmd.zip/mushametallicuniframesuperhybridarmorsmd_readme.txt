MUSHA - Metallic Uniframe Super Hybrid Armor (Mega Drive)
Traducción al Español v2.0 (30/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales a la intro
-Guion revisado
-Ampliadas cadenas de menús

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
MUSHA - Metallic Uniframe Super Hybrid Armor (USA).md
MD5: d5ced66ba18ec2b8eb69b8b1a6baf0d0
SHA1: 821eea5d357f26710a4e2430a2f349a80df5f2f6
CRC32: 58a7f7b4
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --