Hyper Sports (SG-1000)
Traducci�n al Espa�ol v1.0 (07/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hyper Sports (SG-1000) [!].sg
32.768 bytes
MD5: d8e6d89d520c91a9ea219291b55284bb
SHA1: 8a13ee297f861f436b9529a5e2193cb697baa56f
CRC32: ba09a0fd

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --