F1 Race (NES)
Traducción al Español v1.0 (07/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
F1 Race (Japan).nes
MD5: 5c7641c1adc213454c9962eb7f307626
SHA1: c456b19b74e661bd44dd39cd04af0d7f68d958a4
CRC32: 827dc0b9
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --