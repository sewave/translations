Mega Man Soccer (Super Nintendo)
Traducción al Español v1.0 (23/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mega Man Soccer (USA).sfc
MD5: 9e886f686da276b00c4671967d396a79
SHA1: 7e59c9457829ed3f0fbd9cd0ceeb3432a4739e98
CRC32: fa9ee2ce
1310720 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --