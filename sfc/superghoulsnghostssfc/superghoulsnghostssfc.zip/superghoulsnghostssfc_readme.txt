Super Ghouls'n Ghosts (Super Nintendo)
Traducción al Español v1.2 (27/01/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Arregla cadena al derrotar a un jefe.

V1.2:
-Arreglada frase al salir llave de final de nivel
-Cambiado JUGADO por JUGADR en estado
-Cambiado STEREO por ESTEREO
-Traducidas iniciales de las medidas de la princesa
-Mejorados los créditos finales

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Ghouls'n Ghosts (USA).sfc
MD5: 19b2d7a555ecef4c453a819e67e61574
SHA1: f12280b13eea88ca03d700b75cf3c13a0e13f3bc
CRC32: 6aaba901
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --