Logical (Game Boy Color)
Traducción al Español v1.0 (02/08/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Logical (USA).gbc
MD5: eac27e6d4cd1d38d07f2a18ad8169af1
SHA1: 3163071800753f29f2ce6142931356d8d6dfbe68
CRC32: d67275f7
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --