Arkanoid (ZX Spectrum)
Traducción al Español v1.0 (17/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Arkanoid (Erbe).tzx
MD5: 993e810b9962acebf8c9d144ac1a3c0c
SHA1: 3e5f1ad1b2db2ce1c6230265c5a9982bec9a07e1
CRC32: 71617f7a
46635 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --