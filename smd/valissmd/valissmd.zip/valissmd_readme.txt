Valis (Mega Drive)
Traducción al Español v2.0 (30/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0: Añadidos caracteres especiales, traducción de menús excepto magias, reescritura del texto.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Valis (USA).md
MD5: da1638baec999b2203ac5e5fec31c744
SHA1: fed29e779aa0d75645a59608f9f3a13f39d43888
CRC32: 13bc5b72
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --