Total Recall (NES)
Traducción al Español v1.0 (22/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Total Recall (U) [!].nes
MD5: 67f20f04ec0abe40215b557c1ff2c924
SHA1: 27ed96dd9e208bf0ed06ead0f6347ed9deb6799e
CRC32: 178cb593
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --