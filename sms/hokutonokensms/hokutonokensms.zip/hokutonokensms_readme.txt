Hokuto no Ken
Traducci�n al Espa�ol v1.0 (13/01/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Hokuto no Ken
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Hokuto no Ken
-----------------
Adaptaci�n del manga/anime del mismo nombre, conocido en espa�a como "El Pu�o de la Estrella del Norte".

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basado en el de phalanX.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Hokuto no Ken (J) [!].sms
131.072	bytes
CRC32: 24f5fe8c
MD5: ddd6b56e864a7dfd74a9e04bc4407f41
SHA1: 26c5da3ee48bc0f8fd3d20f9408e584242edcd9d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Original:
phalanX	Hacking	
Hiei-	Translation	
Midna	Translation	

-- END OF README --