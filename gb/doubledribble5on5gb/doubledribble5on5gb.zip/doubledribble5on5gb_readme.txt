Double Dribble - 5 on 5 (Game Boy)
Traducción al Español v1.0 (22/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Dribble - 5 on 5 (USA).gb
MD5: ff3e6d70d42987dd7f6214067dc83afe
SHA1: d0f18c97b48dd8b355d195d2ddaeee910c5fc2b1
CRC32: ee28749d
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --