Pac-Man (Game Gear)
Traducci�n al Espa�ol v1.0 (27/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pac-Man (USA, Europe).gg
MD5: e6985998d25d6c4fe36c2b8041244bb4
SHA1: d78b6aac927692f1b67e6a4b7494e2c7e709ae17
CRC32: a16c5e58
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --