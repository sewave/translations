Veigues Tactical Gladiator (PC Engine)
Traducción al Español v1.0 (03/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Veigues Tactical Gladiator (U).pce
MD5: 757754c27f380ce3f574bb861d641247
SHA1: 88a858feeba77031e7d2fb85e563aafcbd9b0b39
CRC32: 99d14fb7
393216 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --