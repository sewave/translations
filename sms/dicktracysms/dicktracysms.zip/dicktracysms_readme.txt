Dick Tracy (Master System)
Traducci�n al Espa�ol v1.0 (03/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dick Tracy (UE) [!].sms
262.144	bytes
MD5: 1dcaf7d1ea7caaaa716f0ec43c3f828a
SHA1: b788f0394aafbc213e6fa6dcfae40ebb7659f533
CRC32: f6fab48d

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --