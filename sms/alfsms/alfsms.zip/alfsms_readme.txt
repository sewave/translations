ALF
Traducci�n al Espa�ol v1.0 (23/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre ALF
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre ALF
-----------------
Juego de aventuras basado en la serie de televisi�n.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
ALF (U) [!].sms
131.072	bytes
CRC32: 82038ad4
MD5: bc1360afa99cd89fbab4ea55bef08aae
SHA1: 7706485b735f5d7f7a59c7d626b13b23e8696087

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --