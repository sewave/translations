Mega Man (NES)
Traducción al Español v2.0 (18/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Guion revisado

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mega Man (USA).nes
MD5: 4d4ffdfe7979b5f06dec2cf3563440ad
SHA1: 2f88381557339a14c20428455f6991c1eb902c99
CRC32: 5ded683e
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --