Panther (ZX Spectrum)
Traducción al Español v1.0 (12/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Panther.tzx
MD5: 1d8ce22f19af46e2a29fb109d6281a0e
SHA1: a2026da45b92aecca368c1d0e75a4dc3cfbdca6b
CRC32: de7fec5a
34663 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --