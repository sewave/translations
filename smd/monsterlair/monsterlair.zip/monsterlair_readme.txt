Wonder Boy III - Monster Lair
Traducci�n al Espa�ol v1.0 (26/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Wonder Boy III - Monster Lair
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Wonder Boy III - Monster Lair
-----------------
Curioso plataformas/shooter en el mundo de wonder boy.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Wonder Boy III - Monster Lair (JE) [c][!].bin
524.288	bytes
CRC32: c24bc5e4
MD5: 17f53791945ce7ccd83a4e812e3705e4
SHA1: 1fd3f77a2223ebeda547b81e49f3dfc9d0197439

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --