Zenji (Colecovision)
Traducción al Español v1.0 (29/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zenji (1984) (Activision).col
MD5: 5595dc8acc25f51aaed0d72bbb96e68b
SHA1: 9119f3a485eb4215e7d41c7cf0e412d903458647
CRC32: 6e523e50
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --