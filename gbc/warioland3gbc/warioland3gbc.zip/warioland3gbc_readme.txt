Wario Land 3 (Game Boy Color)
Traducción al Español v1.0 (04/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wario Land 3 (World) (En,Ja).gbc
MD5: 16bb3fb83e8cbbf2c4c510b9f50cf4ee
SHA1: bb7877309834441fd03adb7fa65738e5d5b2d7ba
CRC32: 480d0259
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --