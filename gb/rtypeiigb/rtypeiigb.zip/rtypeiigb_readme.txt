R-Type II (Game Boy)
Traducci�n al Espa�ol v1.0 (23/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
R-Type II (U).gb
MD5: 967030223fa85f7ba4ac71f26837f831
SHA1: f19436dfed41b9c2e94e070a76c5bdbcc7f993c3
CRC32: 2fe2a72d
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --