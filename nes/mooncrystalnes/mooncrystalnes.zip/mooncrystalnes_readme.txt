Moon Crystal (NES)
Traducción al Español v1.0 (19/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basada en el de Alex W. Jackson.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Moon Crystal (Japan).nes
MD5: 2920fef29c5c68b1ef2dc41b25b0591f
SHA1: 495e41feb430c4db5f1452aaf7b828adc3caa881
CRC32: 463d5c4c
524304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --