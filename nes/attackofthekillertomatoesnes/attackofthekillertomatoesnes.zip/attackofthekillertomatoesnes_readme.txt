Attack of the Killer Tomatoes (NES)
Traducción al Español v1.0 (19/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Attack of the Killer Tomatoes (USA).nes
MD5: b557edc2ca60df335e3e0d31cb3ae84c
SHA1: da40fae301047e33c7be5c3e87c2c0265c1f0751
CRC32: 11dc4071
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --