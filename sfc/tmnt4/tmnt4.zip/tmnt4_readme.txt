Teenage Mutant Ninja Turtles IV - Turtles in Time
Traducci�n al Espa�ol v1.0 (17/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Teenage Mutant Ninja Turtles IV - Turtles in Time
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Teenage Mutant Ninja Turtles IV - Turtles in Time
-----------------
Clasico beat em up de konami para snes.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
La pantalla de opciones y time attack se traducen al pasar por encima.
La pantalla de neon riders tiene algunas letras sin traducir.
Tampoco est� traducida la peque�a intro donde salen las tortugas.
Ni algunos mensajes como PRESS START.
Si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles IV - Turtles in Time (U) [!].smc
1.048.576 bytes
CRC32: 5940bd99
MD5: 807009d25eb31559974daa3e39eeccd7
SHA1: 4f8fc0f45023e0339e501054b253c33f479a001a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --