Heavy Unit (PC Engine)
Traducci�n al Espa�ol v1.0 (07/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Heavy Unit (Japan).pce
MD5: fc73cb01460d932319dd3eeff3032951
SHA1: d55b3f1bf4f26e37be745e8bfade4384912eb647
CRC32: eb923de5
393.216 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --