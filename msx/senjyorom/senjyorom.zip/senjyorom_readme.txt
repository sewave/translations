Senjyo (MSX)
Traducción al Español v1.0 (18/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Senjyo (1984) (Sony) (J).rom
MD5: c129fbaa8caabb21cc28e3fe35304576
SHA1: e373e3e9be4f6d30d5db84b699082c00b2021ba3
CRC32: 126bc4cd
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --