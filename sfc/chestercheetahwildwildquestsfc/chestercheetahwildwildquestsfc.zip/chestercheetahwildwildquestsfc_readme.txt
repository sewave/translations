Chester Cheetah - Wild Wild Quest (Super Nintendo)
Traducci�n al Espa�ol v1.0 (14/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chester Cheetah - Wild Wild Quest (U) (59734).smc
MD5: 4cd2bc92082a33ca686052ea3ea1c8d4
SHA1: bb162d28d631fc327ebc9bf87e22dc7e718cb52a
CRC32: bc27bca6
1.310.720 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --