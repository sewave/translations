Hammerin' Harry (NES)
Traducci�n al Espa�ol v1.0 (16/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hammerin' Harry (E) [!].nes
MD5: 10935d03a033e558b04e5515d460fa8e
SHA1: b017bd17b5a9e07003cfc3c498b3549bdb49cb1a
CRC32: 4d58c832
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --