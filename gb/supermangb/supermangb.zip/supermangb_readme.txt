Superman (Game Boy)
Traducción al Español v1.0 (10/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Superman (U) [S][!].gb
MD5: a55e4143925f5cbe2b929cc5f598bbe9
SHA1: 3a987cb4ba6f33717ea70d7388ec1dfe6ab934e8
CRC32: 358e0091
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --