Taito Chase H.Q. (Master System)
Traducción al Español v1.0 (16/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Taito Chase H.Q. (Europe).sms
MD5: 08511c5cf0df0941b10ebf28050afe51
SHA1: 495e3ced83ccd938b549bc76905097dba0aaf32b
CRC32: 85cfc9c9
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --