The Simpsons - Escape from Camp Deadly (Game Boy)
Traducci�n al Espa�ol v1.0 (07/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Simpsons, The - Escape from Camp Deadly (U) [!].gb
131.072 bytes
MD5: e731fa23d9cd0c3d4dec7d5565beef61
SHA1: 89b7b2d4684d703ea5d323e3aaf4910dcdbc47d3
CRC32: 5546a382

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --