3D Deathchase (ZX Spectrum)
Traducción al Español v1.0 (25/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
3D Deathchase.tzx
MD5: fe364c0806838107a6dc12b5faddcab2
SHA1: 0c35ecae020b7662775d19569301d4c737ed9471
CRC32: cca317b6
16515 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --