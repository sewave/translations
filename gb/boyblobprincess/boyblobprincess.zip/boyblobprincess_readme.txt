Boy and His Blob, A - The Rescue of Princess Blobette
Traducci�n al Espa�ol v1.0 (20/08/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Boy and His Blob, A - The Rescue of Princess Blobette
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Boy and His Blob, A - The Rescue of Princess Blobette
-----------------
Version portatil del clasico a boy and his blob.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Boy and His Blob, A - The Rescue of Princess Blobette (U) [!].gb
65.536 bytes
CRC32: 8210a03f
MD5: 81f7dee7546e630de075a3397349efb8
SHA1: 0a45d1b98646fd7832b5119b04bc8d6d6d0f657a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --