Deadly Moves (Mega Drive)
Traducción al Español v1.0 (18/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Deadly Moves (U) [!].bin
MD5: 208652cf1e1f77405cf3e854f009d2b8
SHA1: 8733d179292d4dc5c3513459539d96484b6d018f
CRC32: 35cbd237
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --