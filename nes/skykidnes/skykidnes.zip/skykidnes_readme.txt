Sky Kid (NES)
Traducción al Español v1.0 (11/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sky Kid (USA).nes
MD5: 83d03598ed42f9d1c7ff08cd8e532224
SHA1: 2b19a755dbdf96c5857a5b772137785b906480b3
CRC32: 8b190ddc
163856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --