MotorCity Patrol (NES)
Traducción al Español v1.0 (10/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
MotorCity Patrol (USA).nes
MD5: 3c71083fecad736c8a97f8e950b619e7
SHA1: 8f3babf76eebbd523877105fb74514c2f4169693
CRC32: 67ba0793
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --