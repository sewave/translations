Bonkers Wax Up! (Master System)
Traducci�n al Espa�ol v1.0 (05/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bonkers Wax Up! (UE) [!].sms
MD5: 044b79a5e4cf58fb92b60fc09cf4f316
SHA1: e1f8da3897f0756c8764ece6605f940ce79e81ca
CRC32: b3768a7a
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --