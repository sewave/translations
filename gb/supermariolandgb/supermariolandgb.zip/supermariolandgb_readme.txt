Super Mario Land
Traducci�n al Espa�ol v1.0 (30/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Super Mario Land
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Super Mario Land
-----------------
Adaptaci�n del cl�sico a Game Boy.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Super Mario Land (W) (V1.1) [!].gb
65.536 bytes
CRC32: 2c27ec70
MD5: b259feb41811c7e4e1dc200167985c84
SHA1: 418203621b887caa090215d97e3f509b79affd3e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --