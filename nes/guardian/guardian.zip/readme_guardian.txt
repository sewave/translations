Guardian Legend, The
Traducci�n al Espa�ol v1.0 (04/09/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Guardian Legend, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Guardian Legend, The
-----------------
Guardian Legend, The es un shooter vertical con escenas estilo zelda.
Este parche lo traduce completamente al espa�ol excepto la palabra KEY del menu, porque es muy corta.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Guardian Legend, The (U) [!].nes
131.088	bytes
CRC32: c94ac75f
MD5: 5acfc9d45b94f82f97e04c4434adbf36
SHA1: d00d73c7764a4c3513892b97afb939f30e522245

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --