Vigilante (ZX Spectrum)
Traducción al Español v1.0 (20/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Vigilante (Erbe).tzx
MD5: a120558a7fee4d4586593edcdf865fac
SHA1: 5e78e4436cfb64051bb134a9b8ae29d675862520
CRC32: 1b9a4915
110778 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --