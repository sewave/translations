Double Dragon
Traducci�n al Espa�ol v1.0 (03/02/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Double Dragon
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Double Dragon
-----------------
Versi�n de Master System del beat em up de technos.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Double Dragon (UE) [!].sms
262.656	bytes
CRC32: b8cffa0f
MD5: e95fc0b0123a58056a9059c7f19d8298
SHA1: 7a7e5290b80e04e01a5e6cff9095d0cc9f88f25e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --