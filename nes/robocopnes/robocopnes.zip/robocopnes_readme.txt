RoboCop (NES)
Traducción al Español v2.0 (23/12/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducida pantalla de licencia
-Traducido GAME OVER
-Añadido ¡ a "OH NO!"
-Guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
RoboCop (USA).nes
MD5: ad20426b20942679c12794f3f7c6a681
SHA1: 9103a9355fe00769bef3fe74f8dfef29fedebabf
CRC32: 33be5cfd
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --