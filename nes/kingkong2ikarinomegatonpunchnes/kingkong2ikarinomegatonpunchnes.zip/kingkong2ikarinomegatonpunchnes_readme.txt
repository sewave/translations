King Kong 2 - Ikari no Megaton Punch (NES)
Traducción al Español v1.0 (19/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basada en la de DvD Translations.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
King Kong 2 - Ikari no Megaton Punch (Japan).nes
MD5: ba2cbbebcc0adaca687598b0a00b29d3
SHA1: 75822c00abc9d8174178e5b160ba6afb0b2982a4
CRC32: af534918
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --