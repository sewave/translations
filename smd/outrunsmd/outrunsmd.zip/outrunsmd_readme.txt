OutRun (Mega Drive)
Traducci�n al Espa�ol v1.0 (07/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
OutRun (W) [!].gen
1.048.576 bytes
MD5: 2c93e520772d4cdc1cf4ad54d2fcb406
SHA1: 95d2055ffd679ab19f0d4ca0af62a0d565bc258e
CRC32: fdd9a8d2

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --