Bomb Disposer (Game Boy)
Traducción al Español v1.0 (01/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bomb Disposer (Sachen 4-in-1 Vol. 6) (Unl) [!].gb
MD5: 39c56e18dda32b4e5fcb5f14c59774e3
SHA1: f39beb0cddceab0067cb468edca60cacd5ee5a37
CRC32: c2a85d91
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --