Pyramid (NES)
Traducción al Español v1.0 (19/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pyramid (AVE) (PRG1) [!].nes
MD5: 1d7bd8f167cb54f4fce762ce97a26865
SHA1: 9652fc81d332e08ddbd8bab6fe5387205cdb4019
CRC32: afee5df1
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --