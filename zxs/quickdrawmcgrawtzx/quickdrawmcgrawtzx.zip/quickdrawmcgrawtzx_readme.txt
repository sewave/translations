Quick Draw McGraw (ZX Spectrum)
Traducción al Español v1.0 (06/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Quick Draw McGraw.tzx
MD5: 33e11a089ccc93ed6b3d5b07cfe11162
SHA1: 99fa37f2d75e631756e907d10cd7f504cb29808a
CRC32: f26edf6b
53496 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --