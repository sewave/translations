Indiana Jones and the Last Crusade (NES)
Traducción al Español v1.1 (16/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglada carta de Sallah.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Indiana Jones and the Last Crusade (U) (Taito) [!].nes
MD5: c65e7a05787f5b2a7c3d5988a9dac062
SHA1: 78bc318d19f0c7d1d429890c65ee083ecdab2d5c
CRC32: da23166a
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --