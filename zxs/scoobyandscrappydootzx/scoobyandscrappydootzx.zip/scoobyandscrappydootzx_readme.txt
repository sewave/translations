Scooby And Scrappy Doo (ZX Spectrum)
Traducción al Español v1.0 (20/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Scooby And Scrappy Doo.tzx
MD5: da2f4aecb0dbb65e44dafeb315e3501e
SHA1: 71c906a5355d3e67d6a1a5461dfc8307da28fa6b
CRC32: 15d8300f
48454 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --