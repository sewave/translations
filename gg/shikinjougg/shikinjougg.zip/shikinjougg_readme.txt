Shikinjou (Game Gear)
Traducción al Español v1.0 (24/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shikinjou (J).gg
MD5: a952a843a123092aafbeb37b428ef6ff
SHA1: bf36130b1be4bce6c6eb7b87db00d420797c3611
CRC32: 9c5c7f53
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --