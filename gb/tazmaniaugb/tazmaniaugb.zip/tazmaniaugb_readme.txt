Taz-Mania (USA) (Game Boy)
Traducci�n al Espa�ol v1.0 (12/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Taz-Mania (U) [!].gb
MD5: 9db0e1e39aa5a40471911a40e12ba739
SHA1: d36d731bd2644ee84c7cf77a2c1d319851e4d6bb
CRC32: 22d07cf6
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --