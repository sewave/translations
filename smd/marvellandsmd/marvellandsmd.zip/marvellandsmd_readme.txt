Marvel Land (Mega Drive)
Traducción al Español v1.1 (24/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado doble "el".

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Marvel Land (U) [!].bin
MD5: ac2b187f80174678c8e9941d75f55b52
SHA1: 29f290c80f992542e73c9ea95190403cb262b6ad
CRC32: cd7eeeb7
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --