Elevator Action (MSX)
Traducción al Español v1.0 (12/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Elevator Action (1985) (Taito) (J).rom
MD5: 4ececca3e5358198c39747d08d3e5f66
SHA1: 6cbddd118afe63e79cb8a40f8aa879df1c7590e1
CRC32: 39886593
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --