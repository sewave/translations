Krusty's Super Funhouse (Mega Drive)
Traducción al Español v1.0 (10/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Krusty's Super Funhouse (UE) (REV01) [!].gen
MD5: 8bd4d2f51f08380a1ba9ac6cd2070585
SHA1: 6aa026e394dba0e5584c4cf99ad1c166d91f3923
CRC32: 56976261
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --