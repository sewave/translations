Alter_Ego (NES)
Traducción al Español v1.0 (13/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alter_Ego.nes
MD5: 1f21f648af663fbd3c864b7283d994c7
SHA1: d92d14ae576365eee1b3afda9e7b03230a0b4032
CRC32: 5f322f79
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --