Pipe Dream (NES)
Traducción al Español v1.0 (04/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pipe Dream (USA).nes
MD5: 3c1c35ddd2acb3f2f500afc925a21ef9
SHA1: 4929c3cd3d69239a16fae52b2570e099cc6f4bc8
CRC32: f3cc626d
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --