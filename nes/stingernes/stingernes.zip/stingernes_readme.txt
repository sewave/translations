Stinger (NES)
Traducción al Español v1.0 (08/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Stinger (U) [!].nes
MD5: a8bc764aabc1812f016d300baeccd4ff
SHA1: 70d8088dce879710ee2c685cb7f5bc98edd5e5da
CRC32: f6b9629f
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --