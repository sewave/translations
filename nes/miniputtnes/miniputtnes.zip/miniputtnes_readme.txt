Mini-Putt (NES)
Traducción al Español v1.0 (19/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mini-Putt (Japan).nes
MD5: abe65de54a2c2270e8937cf8d81ea11e
SHA1: befd1b209b54521c637d0e5a1e33ced7ccddef89
CRC32: 098ad414
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --