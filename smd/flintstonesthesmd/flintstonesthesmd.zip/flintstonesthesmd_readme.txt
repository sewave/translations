Flintstones, The
Traducci�n al Espa�ol v1.2 (16/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Flintstones, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Flintstones, The
-----------------
Plataformas sobre los picapiedra para megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Arreglada frase sin traducir y cambios menores.
v1.2: Arreglos menores.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Flintstones, The (U) [c][!].bin
524.288	bytes
CRC32: 7c982c59
MD5: 60ea3535c8a939d26ded83bde0f4809d
SHA1: 5541579ffaee1570da8bdd6b2c20da2e395065b0

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --