Terminator 2 - Judgment Day (Super Nintendo)
Traducción al Español v1.0 (25/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Terminator 2 - Judgment Day (U) [!].smc
MD5: 64e0fdfc5dd759018924791faa77c2f9
SHA1: c95c46bf2c77e7233792fc1212e90d8fc267c1a3
CRC32: f729b19e
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --