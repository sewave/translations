Dead Angle (Master System)
Traducción al Español v1.0 (19/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dead Angle (UE) [!].sms
MD5: 8d5e93715bad32ba8bbcac9d21e87d89
SHA1: 0236c5239c924b425a99367260b9ebfa8b8e0bca
CRC32: e2f7193e
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --