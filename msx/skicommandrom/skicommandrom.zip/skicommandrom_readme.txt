Ski Command (MSX)
Traducción al Español v1.0 (19/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ski Command (1984)(Casio).rom
MD5: ff7221aa4a2a0a81b3801d5a538fae51
SHA1: fe53d85adb758103097fd56132e71c7f4cb32313
CRC32: edb91850
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --