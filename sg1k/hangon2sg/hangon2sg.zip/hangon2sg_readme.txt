Hang-On 2 (SG-1000)
Traducci�n al Espa�ol v1.0 (12/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hang-On 2 (SG-1000).sg
MD5: 314c865decbe6f578d9bfa23f27a08e6
SHA1: e636e889d4e81c024ee7dae8943c2b8d9d4a5414
CRC32: 9be3c6bd
32.768 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --