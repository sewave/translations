Jang Pung 3 (Master System)
Traducción al Español v1.0 (03/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Incluye un parche para funcionar en emuladores que no soportaran el mapper koreano.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jang Pung 3 (K) (Unl).sms
MD5: f355ec9d0171a4d01356165d2baba6a1
SHA1: 1b2b525ef2ab2d7ea3f934f0c229dab33af56d90
CRC32: 18fb98a3
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --