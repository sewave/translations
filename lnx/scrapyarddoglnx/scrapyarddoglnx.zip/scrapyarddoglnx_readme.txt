Scrapyard Dog (Atari Lynx)
Traducción al Español v1.0 (12/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking contiene el cargador de Harry Dodgson.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Scrapyard Dog (USA, Europe).lnx
MD5: 0cf228912d2f8eeb29aa215abf416f6d
SHA1: df57cd7f119fa6af8f9b24942f0f12314b301075
CRC32: be166f3b
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --