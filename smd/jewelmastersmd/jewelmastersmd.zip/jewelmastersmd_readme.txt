Jewel Master (Mega Drive)
Traducción al Español v2.0 (14/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres especiales
-Traducido "PUSH START BUTTON"
-Alargadas algunas cadenas
-Guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jewel Master (USA, Europe) (Rev A).md
MD5: 42ec7e0894625345be8021f9d5f5d52f
SHA1: 9a6e4ca71546e798e1c98e78c4ab72aba46374c5
CRC32: cee98813
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --