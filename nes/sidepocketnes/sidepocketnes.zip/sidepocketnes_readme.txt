Side Pocket (NES)
Traducción al Español v1.0 (25/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Side Pocket (U) [!].nes
MD5: 4548ccbe18d8631734a08d57d32b44fe
SHA1: 32946fc54618078b163d88a48e535197ae149be5
CRC32: 1fbacf06
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --