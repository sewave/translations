Mamono Hunter Youko - Dai 7 no Keishou (Mega Drive)
Traducción al Español v1.0 (23/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mamono Hunter Youko - Dai 7 no Keishou (Japan).md
MD5: e5df696dcfbc46e2b664dedf1dc0be52
SHA1: 5c8c600ca7468871b0ef301fd82a1909aa8b3b10
CRC32: 10bb359b
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --