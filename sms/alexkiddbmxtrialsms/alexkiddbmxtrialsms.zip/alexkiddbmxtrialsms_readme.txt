Alex Kidd - BMX Trial (Master System)
Traducci�n al Espa�ol v1.0 (27/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alex Kidd - BMX Trial (J) [!].sms
MD5: 571f18f49e679a128b4a237001760d6c
SHA1: 77cc767bfae01e9cc81612c780c939ed954a6312
CRC32: f9dbb533
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --