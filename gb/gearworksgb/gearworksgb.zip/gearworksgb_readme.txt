Gear Works (Game Boy)
Traducción al Español v1.0 (08/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gear Works (U) [!].gb
MD5: 16af858484041d572299b501ead2b788
SHA1: f064c897da11945287ed793fe041d75c1b536709
CRC32: b2b72056
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --