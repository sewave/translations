RoboCop 3 (NES)
Traducción al Español v2.0 (09/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducido menú del título
-Añadidos caracteres especiales
-Guion retraducido
-Más gráficos traducidos

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
RoboCop 3 (USA).nes
MD5: 09643d3d3a5d2eb830fa9902f950dbf2
SHA1: 77bab039b13a974a46686a7647c0affd00b4a9ad
CRC32: fbbb58a6
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --