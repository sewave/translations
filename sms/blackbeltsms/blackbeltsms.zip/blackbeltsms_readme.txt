Black Belt
Traducci�n al Espa�ol v1.0 (25/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Black Belt
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Black Belt
-----------------
Adaptaci�n americana de Hokuto No Ken para Master System.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Black Belt (UE) [!].sms
131.072	bytes
CRC32: da3a2f57
MD5: 16e6b4a1d71960d64bd20aaf7024e8ac
SHA1: 7c5524cff2de9b694e925297e8e74c7c8d292e46

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --