QIX (Game Boy)
Traducción al Español v1.0 (24/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
QIX (World).gb
MD5: 1c94dccdfaaa0c3e1d6bda5969704885
SHA1: fb9935ca821562966eafa8f60ec2f489ad33940a
CRC32: 9185e89e
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --