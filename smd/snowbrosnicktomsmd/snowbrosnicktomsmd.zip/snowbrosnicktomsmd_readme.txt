Snow Bros. - Nick & Tom (Mega Drive)
Traducción al Español v2.0 (07/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Alargadas cadenas
-Retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Snow Bros. - Nick & Tom (Japan).md
MD5: bc5d2dadfa64e26d851af8c294c38436
SHA1: 27caf554f48d2e3c9c6745f32dbff231eca66744
CRC32: 11b56228
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --