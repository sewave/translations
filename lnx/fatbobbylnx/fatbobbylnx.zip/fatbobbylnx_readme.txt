Fat Bobby (Atari Lynx)
Traducción al Español v1.0 (23/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking contiene el cargador de Harry Dodgson.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fat Bobby (USA, Europe).lnx
MD5: 69abd21c83390dae54630919c3c150d0
SHA1: 766ed1a28528535338e176559a145afaffacf3ef
CRC32: 9034ee27
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --