Terminator 2 - Judgment Day
Traducci�n al Espa�ol v1.0 (07/11/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Terminator 2 - Judgment Day
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Terminator 2 - Judgment Day
-----------------
Juego de la pelicula, parecido al de nes, pero peor.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Terminator 2 - Judgment Day (USA, Europe).gg
262.144	bytes
CRC32: 1bd15773
MD5: 67388b1c9758e7f0c0957eb9a788611a
SHA1: 833c94ea65a7c36349b2bb0b2b637116f54a6762

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --