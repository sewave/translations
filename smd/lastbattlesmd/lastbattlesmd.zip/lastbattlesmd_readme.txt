Last Battle (Mega Drive)
Traducción al Español v1.0 (19/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Last Battle (UE) [!].bin
MD5: 1164d4b9e1c69c914f68a3f0e126039b
SHA1: 6ebef9c86779040bd2996564caa8631f4c41cf03
CRC32: bbfaad77
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
Jackic - Revisión y pruebas.

-- FIN --