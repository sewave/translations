Double Strike (NES)
Traducción al Español v1.0 (15/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Strike (AVE) (V1.1) [!].nes
MD5: d05fd9c964161979e3b0cdd08956acd0
SHA1: f74743d24b877183d735de08397f34215fb2493f
CRC32: dcbcc7a2
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --