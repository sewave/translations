Shinobi II - The Silent Fury
Traducci�n al Espa�ol v1.0 (15/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Shinobi II - The Silent Fury
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Shinobi II - The Silent Fury
-----------------
Segunda parte de shinobi para Game Gear.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Shinobi II - The Silent Fury (U) [!].gg
262.144	bytes
CRC32: 6201c694
MD5: 48d741774004eab9c19c1dd43758bf2b
SHA1: cd57301d16202ea02d9f97bd8b17d71772782c94

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --