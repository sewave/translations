Montezuma's Revenge (Master System)
Traducción al Español v1.0 (05/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Montezuma's Revenge (U) [!].sms
MD5: fe20d983d1b18ff1986c376489843f32
SHA1: a2665093b8588d5d6f24c6b329080fb3ebee896e
CRC32: 82fda895
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --