Fantasy Zone (NES)
Traducción al Español v1.0 (02/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fantasy Zone (Tengen) [!].nes
MD5: 8e5628c5c7ac7242207e2e125b867c01
SHA1: a3d852930db34bb76c1ac1531311dd5552b8e7be
CRC32: 9c546b0b
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --