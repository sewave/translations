Wonder Boy III - The Dragon's Trap
Traducci�n al Espa�ol v1.0 (05/06/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Wonder Boy III - The Dragon's Trap
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Wonder Boy III - The Dragon's Trap
-----------------
Clasico plataformas/aventura de la 8 bits de sobremesa de sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Wonder Boy III - The Dragon's Trap (UE) [!].sms
262.144 bytes
CRC32: 679e1676
MD5: e7f86c049e4bd8b26844ff62bd067d57
SHA1: 99e73de2ffe5ea5d40998faec16504c226f4c1ba

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --