Galactic Crusader (NES)
Traducción al Español v1.0 (11/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Galactic Crusader (Bunch) [!].nes
MD5: 38f2c01e1b944541b76afdc8fad63400
SHA1: 2647d4f6b7346fa399ed79e1c19dabc1c045889c
CRC32: ce3f8820
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --