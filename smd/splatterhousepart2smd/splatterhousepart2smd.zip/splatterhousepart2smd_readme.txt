Splatterhouse Part 2 (Mega Drive)
Traducción al Español v1.0 (29/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Splatterhouse Part 2 (Japan).md
MD5: ef2dc6223949eaf84f14e270874a5fff
SHA1: 0c33bb0cf3de11f52aec8d90283b831d9d7d37af
CRC32: 9fb70301
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --