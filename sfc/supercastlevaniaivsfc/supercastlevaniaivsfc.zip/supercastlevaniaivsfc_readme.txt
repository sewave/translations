Super Castlevania IV (Super Nintendo)
Traducción al Español v1.0 (13/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Castlevania IV (USA).sfc
MD5: 094f035993e9724647b61ddcba1e9a7a
SHA1: 684c1dfaff8e5999422c24d48054d96bb12da2f4
CRC32: b64ffb12
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --