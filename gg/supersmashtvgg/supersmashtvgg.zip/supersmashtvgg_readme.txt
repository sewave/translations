Super Smash T (Game Gear)
Traducción al Español v1.0 (29/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Smash T.V. (U) [!].gg
MD5: d378d5784b82154bdc7b36976a7c7737
SHA1: 85189e29f3f6b94f95723bc75571e9424df119f9
CRC32: 1006e4e3
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --