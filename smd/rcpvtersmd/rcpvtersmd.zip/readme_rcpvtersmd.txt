Robocop Versus The Terminator
Traducci�n al Espa�ol v1.0 (27/03/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Robocop Versus The Terminator
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Robocop Versus The Terminator
-----------------
Buen run and gun para la 16 bits de sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Se han a�adido acentos y caracteres especiales.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Robocop Versus The Terminator (U) [!].bin
2.097.152 bytes
CRC32: bbad77a4
MD5: cfc3568cc985f7b73dd5afa69c9f28a4
SHA1: b67b708006145406f2a8dacb237517ededec359a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --