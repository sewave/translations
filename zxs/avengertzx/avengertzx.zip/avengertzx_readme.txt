Avenger (ZX Spectrum)
Traducción al Español v1.0 (22/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Avenger.tzx
MD5: 2aff448e0f1311f7d9cca9c7044faf5b
SHA1: bd8998dc09055a372144f0f693c6e6265d8fab40
CRC32: 44c509bf
54326 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --