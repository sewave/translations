Alien 3
Traducci�n al Espa�ol v1.0 (12/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Alien 3
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alien 3
-----------------
Shooter inspirado en la pelicula, las versiones de master system y game gear son identicas.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alien 3 (E) [!].sms
262.144	bytes
CRC32: b618b144
MD5: 7d6b3351e820b6afa7cf80713dc139e3
SHA1: be40ffc72ee19620a8bac89d5d96bbafcefc74e7

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --