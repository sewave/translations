Go! Go! Tank (Game Boy)
Traducción al Español v1.0 (29/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Go! Go! Tank (U) [!].gb
MD5: 23824d72928a05e9fcf052d42f3c91c6
SHA1: 7f3408c951a161f93394812d34f6d2534658b7d3
CRC32: 65dfabcb
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --