Captain Skyhawk (NES)
Traducci�n al Espa�ol v1.0 (06/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Captain Skyhawk (U) (PRG1) [!].nes
MD5: 95cce48687a53272df719d905b1c36c4
SHA1: c14c59b4509612d4b44c832934f6bcb0c30687b5
CRC32: 1f7d0668
131088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --