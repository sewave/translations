Battle Cars (Super Nintendo)
Traducción al Español v1.0 (11/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battle Cars (USA).sfc
MD5: 0b14bd63104ab1e7c59e18b1e18b2002
SHA1: 9135ddb50d303cb08b8d6ed5d2533eada4b09f20
CRC32: 46043454
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --