Blaster Master Boy (Game Boy)
Traducción al Español v1.0 (07/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blaster Master Boy (U).gb
MD5: c4868bf46a993b4c33a9a8af5341282a
SHA1: 21b1e574a6f4543651e96de65994e7b0b7a6a0f6
CRC32: 3b2c7118
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --