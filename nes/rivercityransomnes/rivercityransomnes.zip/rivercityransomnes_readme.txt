River City Ransom (NES)
Traducción al Español v1.0 (26/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
River City Ransom (USA).nes
MD5: 294e4fa092db8e29d83f71e137d1f99f
SHA1: a8612a36d9d2739d2b321b6ebb97c2757ccca410
CRC32: c3508f7e
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --