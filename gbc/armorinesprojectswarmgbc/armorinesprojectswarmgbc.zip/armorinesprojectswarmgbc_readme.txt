Armorines - Project S.W.A.R.M. (Game Boy Color)
Traducción al Español v1.0 (21/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Armorines - Project S.W.A.R.M. (USA, Europe) (En,De).gbc
MD5: 0b2ab6c8ee77d7dc6856ebffcfeb9c43
SHA1: 2be58ee1a3a76d1259a044c6c7c9dcd6dacf8405
CRC32: ea3b9c73
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --