World Court Tennis (PC Engine)
Traducción al Español v1.0 (03/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
World Court Tennis (USA).pce
MD5: 994d61834e2ee91313b75618ce213971
SHA1: d302676c409a59628935298b95c7ba43359b29bb
CRC32: a4457df0
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --