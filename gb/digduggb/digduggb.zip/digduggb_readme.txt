Dig Dug (Game Boy)
Traducción al Español v1.0 (07/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dig Dug (U) [!].gb
MD5: 9719eaada417782a236a9d84805a512a
SHA1: 951753904389332412d4b0a80b48d7ac61a494fc
CRC32: 6c742478
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --