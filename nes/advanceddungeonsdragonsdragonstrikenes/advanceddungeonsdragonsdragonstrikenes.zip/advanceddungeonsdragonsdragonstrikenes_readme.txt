Advanced Dungeons & Dragons - Dragon Strike (NES)
Traducción al Español v1.0 (17/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Advanced Dungeons & Dragons - Dragon Strike (U) [!].nes
MD5: 75869f905c1f78544c65946bba32aa40
SHA1: 273f99684dbdfcf27cfca58136132898217bfbc5
CRC32: 4c87cdde
524304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --