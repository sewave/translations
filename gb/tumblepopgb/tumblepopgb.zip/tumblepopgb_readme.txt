Tumble Pop (Game Boy)
Traducción al Español v1.0 (14/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tumble Pop (U) [!].gb
MD5: 9038a85be1595de2a4f16b6f6db0f3fd
SHA1: 1b5a9b71bc14f9725b37fa0a166253f1047943b1
CRC32: 8a3aab31
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --