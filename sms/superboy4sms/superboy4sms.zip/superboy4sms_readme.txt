Super Boy 4 (Master System)
Traducción al Español v1.0 (28/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Boy 4 (Korea) (Unl).sms
MD5: eb7d7db5ab98b0b7812552644fb95fe8
SHA1: 9b4be448b81f96391ef9667b1923abc53a9c59d9
CRC32: b995b4f0
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --