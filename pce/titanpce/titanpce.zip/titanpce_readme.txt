Titan (PC Engine)
Traducción al Español v1.0 (03/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Titan (Japan).pce
MD5: a9f182b617533d24200b4e39b2b311ad
SHA1: 7d12a65453c8d3d539104904a9a1eb9e429f9ab4
CRC32: d20f382f
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --