Duck Tales 2
Traducci�n al Espa�ol v1.0 (16/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Duck Tales 2
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Duck Tales 2
-----------------
Segunda parte de las Patoaventuras para la portatil de 8 bits de nintendo.
Port de la versi�n de NES, pero con varios cambios.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Duck Tales 2 (U) [!].gb
131.072	bytes
CRC32: b151509d
MD5: b4e5876c5acedd12b62e25a12973a4ae
SHA1: c9d5b7a71badcc7b198897b4888482f663f03504

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --