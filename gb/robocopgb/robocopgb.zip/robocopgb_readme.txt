Robocop
Traducci�n al Espa�ol v1.0 (XX/XX/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Robocop
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Robocop
-----------------
Version basada en la pelicula, port de las versiones de microordenador.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Robocop (U) (V1.0) [M][!].gb
131.072	bytes
CRC32: 6088b426
MD5: 421a923ba483f65a967b8455500b8880
SHA1: 39b92e019134dfd4480b957509c3eb64920cecb3

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --