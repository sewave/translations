Ristar the Shooting Star
Traducci�n al Espa�ol v1.0 (29/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Ristar the Shooting Star
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Ristar the Shooting Star
-----------------
Version portatil 8 bits del plataformas de mega drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Ristar the Shooting Star (U) [!].gg
524.288	bytes
CRC32: efe65b3b
MD5: 06f0a495fbb70fad50246da715f8add7
SHA1: d0d950097471553b6a96dc9cf0fb14ddb3a7dda2

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --