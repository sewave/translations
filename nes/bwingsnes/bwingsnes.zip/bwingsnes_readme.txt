B-Wings (NES)
Traducción al Español v1.0 (16/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
B-Wings (J) [!].nes
MD5: 1b24f09725092a2526fde24426eb6bc8
SHA1: c0ba99ec176c2082609f4f9705432feb7fc0921c
CRC32: 15a4facb
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --