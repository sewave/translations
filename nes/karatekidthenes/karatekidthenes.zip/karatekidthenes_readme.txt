The Karate Kid (NES)
Traducción al Español v1.0 (22/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Karate Kid, The (U) [!].nes
MD5: ecd9129338544fac5a5451e4d5ff103b
SHA1: 4bf8a8670145e130a1e5dfb1e9b10c035bfc7a6f
CRC32: d71252b9
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --