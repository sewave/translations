The Curse Of Sherwood (ZX Spectrum)
Traducción al Español v1.0 (14/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
The Curse Of Sherwood.tzx
MD5: 1c41a2dd975dd83f3dcd7a30718bb359
SHA1: 2c8f0c56bf1e83dcc9b1913080d22f5aef8602e6
CRC32: 14017404
41682 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --