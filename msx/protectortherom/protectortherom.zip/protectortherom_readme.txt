The Protector (MSX)
Traducción al Español v1.0 (01/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Protector, The (1985) (Pony Cannon) (J).rom
MD5: 5bde548d26288b4c7c7cd05159f5a493
SHA1: d03fdca57b55bdb7e6b5481615b8ad0c8a71f77d
CRC32: 5747e69d
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --