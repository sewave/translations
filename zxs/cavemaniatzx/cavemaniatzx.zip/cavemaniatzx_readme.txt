Cavemania (ZX Spectrum)
Traducción al Español v1.0 (12/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cavemania.tzx
MD5: aaaa2c37e630136a28559d400411d17b
SHA1: 302ac578640838e8877c94bfbac95262b2b760be
CRC32: bee84353
48351 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --