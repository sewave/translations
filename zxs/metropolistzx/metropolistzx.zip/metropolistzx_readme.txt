Metropolis (ZX Spectrum)
Traducción al Español v1.0 (18/05/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Metropolis - Loading Screen Fix.tzx
MD5: a2b18a861ded4bbe54df90b5e5a7dfab
SHA1: 9ee2cc56e30337201a027c55106f402a0cc28574
CRC32: aea1d4e3
48738 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --