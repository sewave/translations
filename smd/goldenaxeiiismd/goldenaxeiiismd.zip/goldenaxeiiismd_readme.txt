Golden Axe III
Traducci�n al Espa�ol v1.0 (04/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Golden Axe III
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Golden Axe III
-----------------
Tercera parte del clasico de sega, solo para jap�n.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Golden Axe III (J) [!].bin
1.048.576 bytes
CRC32: c7862ea3
MD5: 7d9f963c9c2e22b542516edd03ada6f6
SHA1: cd9ecc1df4e01d69af9bebcf45bbd944f1b17f9f

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --