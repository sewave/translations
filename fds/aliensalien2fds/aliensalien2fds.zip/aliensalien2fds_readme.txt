Aliens - Alien 2 (Famicom Disk System)
Traducción al Español v1.0 (19/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Aliens - Alien 2 (Japan) (Proto) [b].fds
MD5: 7363b374069926cca64bb952759cfdf9
SHA1: b2cae6809c682a5ac0040905047c1b2ccdc89d76
CRC32: 9be84191
131016 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --