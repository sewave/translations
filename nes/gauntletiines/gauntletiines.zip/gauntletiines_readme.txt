Gauntlet II (NES)
Traducción al Español v1.0 (01/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gauntlet II (USA).nes
MD5: bdc58d67a341949fa42542204ec47aca
SHA1: b70634806b6503b181415af4bf92d5cce4eb2c22
CRC32: 31e2c449
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --