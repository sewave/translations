Cyborg Hunter (Master System)
Traducción al Español v2.0 (16/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Guion reescrito
-Traducida barra de estado
-Traducidos gráficos del ascensor

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cyborg Hunter (USA, Europe).sms
MD5: ac90d79743cac1afcd7049f7b4e73bc4
SHA1: b6131585cb944d7fae69ad609802a1b5d51b442f
CRC32: 908e7524
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --