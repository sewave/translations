Tiny Toon Adventures (NES)
Traducción al Español v1.0 (08/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tiny Toon Adventures (U) [!].nes
MD5: 0ebcb18c1ce6dba52dc44b57dd809986
SHA1: 110796622e50c2e8c20b1430acadc5bae5f36586
CRC32: b34ed396
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --