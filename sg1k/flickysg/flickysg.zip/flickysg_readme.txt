Flicky
Traducci�n al Espa�ol v1.0 (08/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Flicky
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Flicky
-----------------
Port del arcade para SG-1000.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Flicky (SG-1000).sg
32.768 bytes
CRC32: bd24d27b
MD5: b52e308e1c0005bc1dba2ba900ad44d0
SHA1: 39a91b5ad6b139ca5d8ac60b78520210e84944bd

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --