Pinball Dreams (Game Gear)
Traducción al Español v1.0 (26/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pinball Dreams (U) [!].gg
MD5: d3e43d2779b93393d7d1d4485a1907aa
SHA1: 1734288c1ca2d83b28b5e266998fbbba76f665f6
CRC32: 635c483a
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --