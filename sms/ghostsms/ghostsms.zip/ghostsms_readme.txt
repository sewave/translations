Ghostbusters
Traducci�n al Espa�ol v1.0 (26/06/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Ghostbusters
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Ghostbusters
-----------------
Original simulador de cazafantasmas par ala 8 bits de sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Ghostbusters (UE) [!].sms
131.072	bytes
CRC32: 1ddc3059
MD5: dbae1ad6d3917a95b96d28bfc6f3f90a
SHA1: 8945a9dfc99a2081a6fb74bbabf8feaac83a7e1a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --