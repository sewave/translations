Zippy Race (SG-1000)
Traducción al Español v1.0 (08/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zippy Race (SG-1000) [!].sg
MD5: 0eda34ba313d3bb34558fd5939b19794
SHA1: 8c48dbe187ff4b26d6244d38075565f284536d0c
CRC32: bc5d20df
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --