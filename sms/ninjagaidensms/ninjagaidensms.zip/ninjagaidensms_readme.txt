Ninja Gaiden (Master System)
Traducci�n al Espa�ol v1.0 (20/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Gaiden (E) [!].sms
262.144	bytes
MD5: 2cd25b3d9a1ced329a551d7fc3c0f01e
SHA1: 4c65db563e8407444020ab7fd93fc45193ae923a
CRC32: 1b1d8cc2

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --