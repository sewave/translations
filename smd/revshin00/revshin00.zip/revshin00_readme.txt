Revenge of Shinobi, The
Traducci�n al Espa�ol v1.0 (10/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Revenge of Shinobi, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Revenge of Shinobi, The
-----------------
Primera version de revenge of shinobi, el clasico plataformas ninja, con personaes como spiderman o godzilla :p

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Revenge of Shinobi, The (W) (REV00) [!].gen
524.288	bytes
CRC32: 5c7e5ea6
MD5: c296021f74ab1192ed7e1865cdebc972
SHA1: d5807a44d2059aa4ff27ecb7bdc749fbb0382550

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --