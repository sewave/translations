The Pagemaster (Game Boy)
Traducción al Español v1.0 (19/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pagemaster, The (USA) (SGB Enhanced).gb
MD5: 0040b5bd11a936063a0dc9a30b9a8727
SHA1: 1d1dfdab693fdb1a3a1388cae34af017f79c41ab
CRC32: cdfa71e5
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --