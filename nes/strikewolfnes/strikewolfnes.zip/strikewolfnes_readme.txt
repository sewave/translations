Strike Wolf (NES)
Traducción al Español v1.0 (03/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Strike Wolf (MGC-014) [!].nes
MD5: ec88c197ccdfeffdd964f1d4a09466eb
SHA1: a25bfd8f0cf77ee96f6b07deebe6313eb3787ea3
CRC32: 21264238
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --