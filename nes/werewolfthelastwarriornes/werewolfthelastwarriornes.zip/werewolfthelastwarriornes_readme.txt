Werewolf - The Last Warrior (NES)
Traducción al Español v2.0 (16/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Script retraducido
-Traducido Subtitulo
-Traducidos gráficos varios
-Traducido "THE END"

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Werewolf - The Last Warrior (USA).nes
MD5: 19ad8f9c1e6ac449e3ac82e33bda7b2f
SHA1: 8580b3deeddfa75c12dfe2f6cab8d062e52fdb34
CRC32: 19af4032
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --