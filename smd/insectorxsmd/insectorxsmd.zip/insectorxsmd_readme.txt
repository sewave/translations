Insector X (Mega Drive)
Traducci�n al Espa�ol v1.0 (03/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Insector X (U) [!].bin
MD5: 77574085187602bf50dd1167da389f60
SHA1: 4f4ecff167d5ada699b0b1d4b0e547b5ed9964d5
CRC32: 70626304
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --