Flappy (NES)
Traducción al Español v1.0 (01/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Flappy (Japan).nes
MD5: e82ef1763b81bfcab9c95c0258347512
SHA1: 4e7af113b95299e5e0e6020486498fd7f55a9694
CRC32: 31ad3838
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --