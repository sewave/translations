Ronald in the Magical World (Game Gear)
Traducción al Español v1.0 (24/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ronald in the Magical World (JU).gg
MD5: 34e9b284e61fb9a2cad4878451579295
SHA1: 5f9afdd5720f88f7cc18715f8e50fc5635b15323
CRC32: 87b8b612
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --