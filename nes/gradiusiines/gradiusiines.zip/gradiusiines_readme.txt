Gradius II (NES)
Traducci�n al Espa�ol v1.0 (13/07/2018)
(C) 2018 Wave Translations

---------
Contenido
---------

1. Notas y Fallos Conocidos
2. Instrucciones de Parcheo
3. Cr�ditos del Parche

---------------------------
1. Notas y Fallos Conocidos
---------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
2. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Gradius II (J) [!].nes
262.160	bytes
CRC32: d213aa0d
MD5: 6dd42d8da20a20aa0760745bc9207f3f
SHA1: b5a8e30d20a52d0f9bfb35def76b8733dfa705e9

----------------------
3. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --