Eliminate Down (Mega Drive)
Traducci�n al Espa�ol v1.0 (03/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Eliminate Down (J) [!].bin
MD5: 06aa841b8773de52cd7ccc9d4f907468
SHA1: 53b418bde065011e161e703dd7c175aa48a04fe5
CRC32: 48467542
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --