Hook
Traducci�n al Espa�ol v1.0 (02/11/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Hook
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Hook
-----------------
Curioso plataformas basado en la pelicula.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Hook (Prototype) [!].sms
262.144 bytes
CRC32: 9ced34a7
MD5: 7a07e3e59f51b620d8c51bef468d4df5
SHA1: b7bbd78b301244d7ce83f79d72fd28c56a870905

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --