Earthworm Jim (Game Gear)
Traducci�n al Espa�ol v1.0 (24/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Earthworm Jim (U) [!].gg
524.288 bytes
MD5: c25af3925fd6973af62bdd6d0c5f61ca
SHA1: dbb149da0b0373f23750ed954dbb5e08bc634615
CRC32: dbb149da0b0373f23750ed954dbb5e08bc634615

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --