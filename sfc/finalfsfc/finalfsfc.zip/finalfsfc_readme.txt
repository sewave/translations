Final Fight
Traducci�n al Espa�ol v1.0 (04/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Final Fight
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Final Fight
-----------------
Adaptaci�n de la recreativa de capcom, con haggar y cody jugables.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Final Fight (U).smc
1.048.576 bytes
CRC32: 4cab21db
MD5: f638224ce95e2101c2948edf7569ac73
SHA1: 6ca2ac5916b3201d90f88612d28006cffedde03d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --