Mortal Kombat
Traducci�n al Espa�ol v1.0 (08/05/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Mortal Kombat
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mortal Kombat
-----------------
Port del clasico juego de lucha para la portatil, muy parecido a la version de master system.
Algunas cadenas no traducidas, como start o similar.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mortal Kombat (U) [!].gg
524.288	bytes
CRC32: 07494f2a
MD5: f9971dc9d78214f94856f6e886b1c8c2
SHA1: ef634649b846b3f49d2c68739b36019e4fae0464

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --