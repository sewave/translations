Tom & Jerry (Game Boy Color)
Traducción al Español v1.0 (19/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tom & Jerry (USA, Europe).gbc
MD5: fac13870841c0f570fff95b0c53a6e24
SHA1: 86d841e84c68e4d15f4bbf72f1aa0fddc86dcd34
CRC32: b97c0bd9
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --