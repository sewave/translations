X-Men 2 - Clone Wars
Traducci�n al Espa�ol v1.0 (05/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre X-Men 2 - Clone Wars
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre X-Men 2 - Clone Wars
-----------------
Accion/plataformas de los xmen para megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
X-Men 2 - Clone Wars (UE) [!].bin
2.097.152 bytes
CRC32: 710bc628
MD5: b687660446f6e49dfd465cd0ef9f0bc3
SHA1: 61409e6cf6065ab67d8952b891d8edcf47777193

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --