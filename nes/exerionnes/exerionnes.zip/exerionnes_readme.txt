Exerion (NES)
Traducción al Español v1.0 (27/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Exerion (J) [!].nes
MD5: d602de6f90c301f2deea26d41ff8ad1c
SHA1: 1f51e431d8febc917b9ca2835fdb0fa37bf668fa
CRC32: 352f9a62
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --