Bare Knuckle - Ikari no Tetsuken ~ Streets of Rage (Mega Drive)
Traducción al Español v2.0 (23/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres especiales en la fuente principal
-Guion retraducido
-Mejorada traducción de personajes
-Traducidos gráficos THE END/PLAYER

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bare Knuckle - Ikari no Tetsuken ~ Streets of Rage (World) (Rev A).md
MD5: 59a3b22a1899461dceba50d1ade88d3a
SHA1: 731cdf182fe647e4977477ba4dd2e2b46b9b878a
CRC32: 4052e845
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --