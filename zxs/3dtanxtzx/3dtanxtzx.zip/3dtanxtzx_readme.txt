3D Tanx (ZX Spectrum)
Traducción al Español v1.0 (05/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
3D Tanx.tzx
MD5: 7970bc46c2c51f0c5eb5867505c13ba2
SHA1: 697c9dc7733f984636a605cf44f0bbb91d6f1657
CRC32: 61200c81
16173 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --