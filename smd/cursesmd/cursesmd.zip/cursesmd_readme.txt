Curse (Mega Drive)
Traducción al Español v1.0 (07/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Curse (J) [!].bin
MD5: 513c1a3f2ddd5b8bf705215f820ada72
SHA1: 978780d9575022450d415591f32e1118c7fac5ad
CRC32: a4fbf9a9
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --