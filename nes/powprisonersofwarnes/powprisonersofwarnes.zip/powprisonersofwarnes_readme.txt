P.O.W. - Prisoners of War (NES)
Traducción al Español v2.0 (19/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres españoles
-Script reescrito
-Traducido subtítulo
-Traducidos gráficos de ARMA y ALTA

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
P.O.W. - Prisoners of War (USA).nes
MD5: 2d6179d9ba584be64f37271903cf8cbb
SHA1: a942f478ac91b4288d7682e7fe15c3d60b82bff3
CRC32: 18967ea6
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --