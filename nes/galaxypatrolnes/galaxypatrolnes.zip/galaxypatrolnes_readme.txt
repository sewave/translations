Galaxy Patrol (NES)
Traducción al Español v1.0 (13/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
galaxy_patrol.nes
MD5: 408e627b8a806b42642ab4a696114ef4
SHA1: b8041076213c70f7e697bca1b3d21601292fa1d3
CRC32: 66100a28
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --