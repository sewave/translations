Toki - Going Ape Spit
Traducci�n al Espa�ol v1.1 (29/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Toki - Going Ape Spit
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Toki - Going Ape Spit
-----------------
Adaptaci�n libre de la recreativa para megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Arreglada T en opciones
v1.2: Arreglado pausa sin cr�ditos

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Toki - Going Ape Spit (UE) [c][!].bin
524.288	bytes
CRC32: 7362c3f4
MD5: 56ba94382fe6f06d05baf77261644ad4	
SHA1: 77270a6ded838d0263284dcc075aa4b2b2aef234

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --