Bump'n'Jump (NES)
Traducci�n al Espa�ol v1.0 (19/05/2018)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bump'n'Jump (U) [!].nes
MD5: 9a2c449679737cd3297e9f268b3a0986
SHA1: ad557aa7da55236f71a517ef09fe1a74fa353462
CRC32: 79bfe095
65552 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --