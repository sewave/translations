The 3-D Battles of World Runner (NES)
Traducción al Español v1.1 (27/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:Arreglado título.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
3-D Battles of World Runner, The (U) [!].nes
MD5: 5a5ace7fa14af00433c4a40e90442762
SHA1: 75b6cc94a952875c936dabfbb6157f9a11c5ac49
CRC32: d5ada486
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --