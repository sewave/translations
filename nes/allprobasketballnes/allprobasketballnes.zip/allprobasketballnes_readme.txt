All-Pro Basketball (NES)
Traducción al Español v1.1 (13/04/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
-Arreglada pantalla de título

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
All-Pro Basketball (USA).nes
MD5: dcf7b3220ddcece3a04c4f6f6b8db45e
SHA1: 832944a78e94851d7c8520c3eabe58d53b22ec01
CRC32: fefe9064
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --