Defender II (NES)
Traducci�n al Espa�ol v1.0 (12/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Defender II (U) [!].nes
MD5: d6e43c366c73c2ad7dac0e632b3d8943
SHA1: a9228fec33620c1ed2f55269ebe022e1bc0ca3e4
CRC32: c0b2aa1f
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --