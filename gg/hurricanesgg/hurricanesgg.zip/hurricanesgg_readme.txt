Hurricanes (Game Gear)
Traducción al Español v1.0 (24/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hurricanes (Europe).gg
MD5: 2f36c3cea09a1d394273b9607ccd8c60
SHA1: d4f0a691f11de7d91ede6ff95d26343a50840eb1
CRC32: 0a25eec5
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --