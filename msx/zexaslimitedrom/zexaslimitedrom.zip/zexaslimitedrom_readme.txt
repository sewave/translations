Zexas Limited (MSX)
Traducción al Español v1.0 (12/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zexas Limited (1985) (dB-Soft) (J).rom
MD5: 23f4722a2359120c3ca93cffe3d1da18
SHA1: a87971b9df0de44644c2188f5f475aef7ae85304
CRC32: efefa02a
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --