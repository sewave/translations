Superkid (ZX Spectrum)
Traducción al Español v1.0 (19/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Superkid.tzx
MD5: 216a000f360e930a7c29b29aee653483
SHA1: 25be3b3895d1ca33905d01e550e8dd5aeccf310f
CRC32: cbb7652f
48512 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --