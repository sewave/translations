X-Men (Game Gear)
Traducción al Español v1.0 (24/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
X-Men (U) [!].gg
MD5: 21d75ed09b6f73037544894580933a0b
SHA1: 215e5f761475ca17a091371e39f636718f213403
CRC32: 567a5ee6
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --