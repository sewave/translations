Daedalian Opus (Game Boy)
Traducción al Español v1.0 (05/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Daedalian Opus (USA).gb
MD5: 34b3d0f0843b83e5b0e00bc3d0669793
SHA1: 7a9294de582f7d3ffd8d14a786774c56af7ce7bc
CRC32: b6b51fce
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --