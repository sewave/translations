Robin The Outlaw (ZX Spectrum)
Traducción al Español v1.0 (09/03/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Robin The Outlaw.tzx
MD5: 81b9ceb4ea004efd487c03d07b64b869
SHA1: c7f541d252b284db545aef980fd66cb8fbc79ab1
CRC32: 447c34ea
47679 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --