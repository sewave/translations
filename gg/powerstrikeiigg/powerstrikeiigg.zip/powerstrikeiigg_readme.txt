Power Strike II (Game Gear)
Traducción al Español v1.0 (29/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Power Strike II (U).gg
MD5: d5836ec389ec2c81bd54728b96b87152
SHA1: e4db2140761b43426024bd08c4372bb9b8979d3d
CRC32: 09de1528
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --