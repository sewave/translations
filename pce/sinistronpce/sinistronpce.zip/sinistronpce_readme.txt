Sinistron (PC Engine)
Traducci�n al Espa�ol v1.0 (30/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sinistron (U).pce
MD5: 1c5eb68a65115abaccd9479503fd3a2b
SHA1: 65defeeecfe60564a214b6572f94243fcfea78e0
CRC32: 4f6e2dbd
393.216 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --