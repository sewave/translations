Bubsy II (Super Nintendo)
Traducción al Español v1.0 (25/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bubsy II (USA).sfc
MD5: cf5c2ca9af502a0f12cf9504fb0e748a
SHA1: c501d8779891a501ca4674cc39fc9d82cc05eb8c
CRC32: d0d172fa
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --