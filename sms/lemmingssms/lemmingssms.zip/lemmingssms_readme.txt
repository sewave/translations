Lemmings (Master System)
Traducción al Español v1.0 (25/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lemmings (E) [!].sms
MD5: b190f17a46ba9cc66676e7174209c24e
SHA1: f3a853cce1249a0848bfc0344f3ee2db6efa4c01
CRC32: f369b2d8
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --