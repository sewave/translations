Ring King (NES)
Traducción al Español v1.0 (16/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ring King (USA).nes
MD5: caa1c9b31bfeea6c89adbe76b9f46705
SHA1: 0d38ea51ac34a21caf2103650cb5cc07ea979bf3
CRC32: 38e1163d
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --