Bomb Fusion (ZX Spectrum)
Traducción al Español v1.0 (08/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bomb Fusion.tzx
MD5: 7d8d9db1fe7b32139b64219e528c6750
SHA1: 5fc0e337e79f52a391257397925ccd04fa5a7689
CRC32: 02290e7e
49433 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --