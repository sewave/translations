Gekitotsu Dangan Jidousha Kessen - Battle Mobile (Super Nintendo)
Traducción al Español v1.0 (29/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gekitotsu Dangan Jidousha Kessen - Battle Mobile (J).smc
MD5: f03545b1932d26a755b9dcef3adeef59
SHA1: 220a463789e245e2b970f8d45f5e9fe540b26144
CRC32: 3e88e883
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --