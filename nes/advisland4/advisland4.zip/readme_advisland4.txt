Takahashi Meijin no Bouken Shima IV
Traducci�n al Espa�ol v1.0 (18/12/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Takahashi Meijin no Bouken Shima IV
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Takahashi Meijin no Bouken Shima IV
-----------------
Cuarta parte de la aventura que se pasa a un estilo "metroidvania".

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking esta basado en la de demiforce.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Takahashi Meijin no Bouken Shima IV (J).nes
393.232	bytes
CRC32: 5ecfd3dc
MD5: dd53d022bb0b8d5a8d464690b14a0b30
SHA1: e73efd3e932b9e3501ce9c77418bdbf0d59d75cd

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --