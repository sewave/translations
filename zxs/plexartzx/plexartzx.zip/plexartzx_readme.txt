Plexar (ZX Spectrum)
Traducción al Español v1.0 (12/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Plexar.tzx
MD5: bdb178f819831b22f1191d7d8949ae80
SHA1: 72dfaaef421245c362d19c5fcdef75f97966b208
CRC32: 0f7c8230
46498 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --