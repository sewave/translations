Teenage Mutant Ninja Turtles - Tournament Fighters
Traducci�n al Espa�ol v1.0 (29/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Teenage Mutant Ninja Turtles - Tournament Fighters
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Teenage Mutant Ninja Turtles - Tournament Fighters
-----------------
Beat em up de las tortugas ninja, con modo historia y torneo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Todo traducido excepto la pantalla de seleccion de planetas y personajes y los bonus de fin de batalla.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles - Tournament Fighters (U) [T+ESP].bin
2.097.152 bytes
CRC32: 95b5484d
MD5: 4cabf79a9e4783ff4e5c1294bcb6129c
SHA1: 1a27be1e7f8f47eb539b874eaa48586fe2dab9c0

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --