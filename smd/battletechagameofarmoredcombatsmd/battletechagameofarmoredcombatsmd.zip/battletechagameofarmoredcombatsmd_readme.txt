BattleTech - A Game of Armored Combat (Mega Drive)
Traducción al Español v1.0 (22/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
BattleTech - A Game of Armored Combat (USA).md
MD5: 0e086b6f7a4e98ba909c2c7e6ae8fa80
SHA1: ee22ae12053928b652f9b9f513499181b01c8429
CRC32: 409e5d14
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --