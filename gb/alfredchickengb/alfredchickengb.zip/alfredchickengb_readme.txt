Alfred Chicken (Game Boy)
Traducci�n al Espa�ol v1.0 (08/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alfred Chicken (USA).gb
MD5: cac921f8eec70d5ccd8a2db8f473a084
SHA1: 80c39d93ca58d0d6144fe7f7bdd47c3a4fcf0438
CRC32: 3b9c3bc6
131072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --