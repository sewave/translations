Final Fight 3
Traducci�n al Espa�ol v1.0 (21/05/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Final Fight 3
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Final Fight 3
-----------------
Beat em up sin licencia para la NES, bastante bien realizado, pese a sus parpadeos a 2 jugadores pro los grandes sprites.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
En los dialogos a veces hay 2 espacios seguidos, esto es debido a que internamente algunos caracteres est�n mapeados pero no tienen gr�ficos, he preferido dejarlo as� porque es como era el original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Final Fight 3 (Unl) [!].nes
786.448	bytes
CRC32: 97f05116
MD5: a7d7d3e08c226f8c9be9a8e4f72e3e24
SHA1: 9c09601acd7a93a3c92600549223e3b72c6576b4

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --