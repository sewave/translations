Indiana Jones and the Last Crusade (Mega Drive)
Traducci�n al Espa�ol v1.0 (27/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Indiana Jones and the Last Crusade (U) [c][!].gen
1.048.576 bytes
MD5: e927417e67f1ff3170cc027ff1e96726
SHA1: 82758a8a47c4f1f0e990bd50b773b2c4300f616e
CRC32: 3599a3fd

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --