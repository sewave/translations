Target Earth (Mega Drive)
Traducci�n al Espa�ol v1.0 (25/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Target Earth (U) [!].bin
MD5: ae816c5017578267060fd4733586cba7
SHA1: e19f7a02f140882e0364f11cd096aec712e56f83
CRC32: cddf62d3
524288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --