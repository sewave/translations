Super Star Wars - Return of the Jedi (Game Boy)
Traducción al Español v1.0 (10/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Star Wars - Return of the Jedi (USA, Europe) (SGB Enhanced).gb
MD5: 55945a517d1e89003003d51c7ec938be
SHA1: 4947f04548ddcf22a6f064601de48925099d1e1d
CRC32: 6cb73dc7
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --