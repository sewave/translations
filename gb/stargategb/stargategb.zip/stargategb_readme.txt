Stargate (Game Boy)
Traducción al Español v1.0 (04/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
-Faltan algunos textos comprimidos

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Stargate (USA, Europe).gb
MD5: 04bde16beda3f9d7cec4509a04a75946
SHA1: 3d2d65252fd57dc1d96c234a436fa377a769c708
CRC32: 4789295c
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --