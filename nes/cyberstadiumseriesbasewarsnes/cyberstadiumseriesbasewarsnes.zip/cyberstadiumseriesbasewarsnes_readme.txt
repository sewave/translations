Cyber Stadium Series - Base Wars (NES)
Traducción al Español v1.0 (13/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cyber Stadium Series - Base Wars (USA).nes
MD5: 0afbffd00b470021ed80e56687900971
SHA1: e1bb4e681cab4a86586ad8c94a811694496d47c8
CRC32: eed00ddf
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --