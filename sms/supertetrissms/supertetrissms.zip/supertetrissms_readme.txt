Super Tetris (Master System)
Traducci�n al Espa�ol v1.0 (10/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Tetris (Korea) (Pirate).sms
MD5: 3aab83a641bf3a26d68ed44f49c28714
SHA1: 3772e9dc07b15de62326ee78981ec0b6f4387590
CRC32: bd1cc7df
65536 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --