Operation Secret Storm (NES)
Traducción al Español v1.0 (01/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Operation Secret Storm (Color Dreams) [!].nes
MD5: 0c48863d30e94ff82bd7a885871fc6f0
SHA1: 8408f0801b1e6e62112d3d4b3c632f7b7f6ec7f3
CRC32: dcae060a
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --