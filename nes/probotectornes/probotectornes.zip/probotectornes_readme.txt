Probotector (NES)
Traducción al Español v1.0 (25/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Probotector (Europe).nes
MD5: 7127f616c13b58087481dd9e93aeb2ff
SHA1: 6531ff3a062c2a83fa9683bf8a859a3500e8d9af
CRC32: 8236d3e0
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --