World Ice Hockey (Game Boy)
Traducción al Español v1.0 (20/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
World Ice Hockey (Japan).gb
MD5: 98e7d7fe08be476b3e8d5989fb8b301c
SHA1: a4ed60dd7354de12c4af04f874ac1fd648f6684b
CRC32: 4e345023
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --