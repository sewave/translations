Motocross Maniacs (Game Boy)
Traducción al Español v1.0 (08/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Motocross Maniacs (U) [!].gb
MD5: de1572d4d181b265e2cb7d517c0ba04a
SHA1: 80575304ccedbd26c0366d8f6f0f0faae09a4f13
CRC32: 318dbde1
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --