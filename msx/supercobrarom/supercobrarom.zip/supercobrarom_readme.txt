Super Cobra (MSX)
Traducción al Español v1.0 (20/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Cobra (1983) (Konami) (J).rom
MD5: 94620318823a2aeb024a8db03e96d823
SHA1: a84608f1c2fe1aea1a8a586f2e335cb64bb951fc
CRC32: 97425d70
8192 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --