Double Dragon V - The Shadow Falls
Traducci�n al Espa�ol v1.0 (26/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Double Dragon V - The Shadow Falls
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Double Dragon V - The Shadow Falls
-----------------
Versi�n de Super Nintendo del juego de pelea de Double Dragon.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Double Dragon V - The Shadow Falls (U).smc
3.145.728 bytes
CRC32: 98a96ae8
MD5: 306fe638317aee4843fdc8ede55f1c6f
SHA1: db7514bee2236e8d0339d00d51a5baf392ccbeff

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --