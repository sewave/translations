Technocop (Mega Drive)
Traducción al Español v1.0 (05/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Technocop (USA).md
MD5: 863f39866dde86d1ee5cc5ce743ffc7c
SHA1: 739421dd98d8073030d43cf8f50e411acb82f7d6
CRC32: 7459ad06
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --