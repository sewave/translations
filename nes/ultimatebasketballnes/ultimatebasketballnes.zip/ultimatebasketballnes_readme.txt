Ultimate Basketball (NES)
Traducción al Español v1.0 (20/04/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ultimate Basketball (USA).nes
MD5: 2eebc74638501c46940eaa303c8d5523
SHA1: 47cc469d15cfa86ab3e0cb8c8515dc7eb173e2c2
CRC32: b5ffe9e3
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --