Kawasaki Superbike Challenge (Mega Drive)
Traducción al Español v1.1 (06/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglada posición en el marcador.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kawasaki Superbike Challenge (USA, Europe).md
MD5: 159dd6bef1cf7df913fd4ac98138d9e7
SHA1: fa7e07bbab70a7b5c32a0f2713494b2c10ce8e1e
CRC32: 631cc8e9
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --