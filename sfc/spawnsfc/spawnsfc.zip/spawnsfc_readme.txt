Spawn (SNES)
Traducci�n al Espa�ol v1.0 (01/12/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spawn (U) [!].smc
MD5: fa499b552c4c9cccd089802147b5dcd5
SHA1: f3d8b7ff4127899131fc9253be8b30f7a8bab717
CRC32: 4e1dafd0
3.145.728 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --