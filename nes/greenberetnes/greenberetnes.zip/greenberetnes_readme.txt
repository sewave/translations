Green Beret (NES)
Traducción al Español v1.0 (09/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Green Beret (FDS Conversion, Whirlwind Manu)(Unl)[U][!].nes
MD5: c75ed5efb14d7c49d1a0e79bffb44877
SHA1: 0537a4e9dd42a4ef86c9c231a2edc9dd25ac69b0
CRC32: f3c8edec
163960 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --