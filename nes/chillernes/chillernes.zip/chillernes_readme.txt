Chiller (NES)
Traducción al Español v1.0 (25/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chiller (USA) (Unl).nes
MD5: c4ff5512f46e483d781ef04bd13609c4
SHA1: 48d6cb1eae242d74496a9eb2de59424cfcadc642
CRC32: 5cda5a68
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --