Ghoul School (NES)
Traducción al Español v1.0 (20/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ghoul School (U) [!].nes
MD5: 46df5a824f2bc69c6fc3e1ec825d4ade
SHA1: 3774bba926b79382f413ed911e985baea4160de9
CRC32: 46717c74
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --