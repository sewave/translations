Darwin 4081 (Mega Drive)
Traducción al Español v1.1 (08/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado Duro y Super Duro

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Darwin 4081 (J) [!].bin
MD5: 70b6289a3857f411361ef8cfd4bba4bf
SHA1: e9decc48451aba62d949a7710e466e1d041a2210
CRC32: 7a33b0cb
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --