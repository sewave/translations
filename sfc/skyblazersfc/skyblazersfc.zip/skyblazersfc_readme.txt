Sky Blazer (Super Nintendo)
Traducci�n al Espa�ol v1.0 (28/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sky Blazer (U) [!].smc
MD5: 5dd2c9f0a933e6a43b7e38e6ef0769ba
SHA1: 8426a16f7d8656c8d2ce4ac3151ec96b433f938d
CRC32: f13b00b0
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --