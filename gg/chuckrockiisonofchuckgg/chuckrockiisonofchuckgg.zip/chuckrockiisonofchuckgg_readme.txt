Chuck Rock II - Son of Chuck (Game Gear)
Traducci�n al Espa�ol v1.0 (06/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chuck Rock II - Son of Chuck (U) [!].gg
MD5: bb6558532d5eda87c93d7fe8eb8ee24c
SHA1: f6aa6a9a641b3a588a8091cf44e8b0a55ebbd613
CRC32: 3fcc28c9
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --