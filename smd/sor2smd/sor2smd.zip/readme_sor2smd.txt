Streets of Rage 2
Traducci�n al Espa�ol v1.0 (29/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Streets of Rage 2
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Streets of Rage 2
-----------------
Clasico beat em up de sega, imprescindible.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Todo traducido menos el la frase de inicio y final de escena.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Streets of Rage 2 (U) [!].bin
2.097.152 bytes
CRC32: e01fa526
MD5: cb75d5a6919b61efe917bea5762c1cb7
SHA1: 8b656eec9692d88bbbb84787142aa732b44ce0be

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --