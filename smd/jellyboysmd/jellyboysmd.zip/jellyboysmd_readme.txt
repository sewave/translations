Jelly Boy (Mega Drive)
Traducción al Español v1.0 (10/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jelly Boy (Beta).bin
MD5: 82d43fe67f4beae110ec3e9b90ea1957
SHA1: 75be8d5b305e669848b4a5a48cdcfa43b951dc20
CRC32: 7cfadc16
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --