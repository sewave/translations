Seven Years War (PC)
Traducción al Español v1.0 (27/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Hay un parche para la versión 1.35 y otro para la 1.40, la versión 1.40 es la española y la que añade acentos, la otra no lleva.

El parche NOCD es para la versión española.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
language.gtf
MD5: c1c57e63fab13f0ee4111d1b62d3396e
SHA1: 67909081c57f892a794de2c9f459096131261dec
CRC32: 4412b4c4
35952 bytes

syw.exe
MD5: 11520ed1dab00a8c7f6ee57c6c2facf2
SHA1: fea79cab396599625477ababcd9eab016526e826
CRC32: 5baa7149
441856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
xblastoise99 - Revisión de textos.

-- FIN --