Magic Carpet (ZX Spectrum)
Traducción al Español v1.0 (05/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Magic Carpet.tzx
MD5: 47f15fa1e19df1d572d187392a647895
SHA1: 2c2664fe9cb17ed62b77a8c70fe5cb20593028c1
CRC32: 6a9af9f0
14799 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --