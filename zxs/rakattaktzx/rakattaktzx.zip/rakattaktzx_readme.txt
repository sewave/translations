Rakattak (ZX Spectrum)
Traducción al Español v1.0 (06/04/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rakattak.tzx
MD5: 0a28cb14ae4761a40aed55b3c2320643
SHA1: da0abc53099b4b86a10aaf5c12e9049916772632
CRC32: 463165fd
47776 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --