Cyborg Hunter
Traducci�n al Espa�ol v1.0 (11/01/2017)
(C) 20167Wave Translations

---
TdC
---

1. Sobre Cyborg Hunter
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Cyborg Hunter
-----------------
Curioso juego de accion/aventura de robots.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Cyborg Hunter (UE) [!].sms
131.072	bytes
CRC32: 908e7524
MD5: ac90d79743cac1afcd7049f7b4e73bc4
SHA1: b6131585cb944d7fae69ad609802a1b5d51b442f

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --