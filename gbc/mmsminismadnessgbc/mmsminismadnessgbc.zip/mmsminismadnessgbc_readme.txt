M&M's Minis Madness (Game Boy Color)
Traducción al Español v1.0 (27/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

El texto de la introducción a veces no se dibuja bien, este es un error de la rom original.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
M&M's Minis Madness (USA).gbc
MD5: c7bcdd8ace2dfac5fdce889880472f80
SHA1: 7cc20e133a66163c6dec140e960b5be3848ccd44
CRC32: 8649d7a0
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --