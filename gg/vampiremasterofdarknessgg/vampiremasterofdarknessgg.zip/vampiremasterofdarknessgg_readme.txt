Vampire - Master of Darkness (Game Gear)
Traducci�n al Espa�ol v1.3 (17/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
V1.2: Correcci�n pantalla CONTINUAR.
V1.3: Correcci�n final 3a pantalla.
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Vampire - Master of Darkness (U) [!].gg
262.144	bytes
CRC32: 7ec64025
MD5: 1e068538747f6d4d99888221a50b7e06
SHA1: 14e6b1e886355d902b34acdf503eced8df88afe4

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --