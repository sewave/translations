Spacegulls (NES)
Traducción al Español v1.0 (10/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spacegulls-1.0.nes
MD5: d6aacf1a11e030a31d4055a0f8e5537a
SHA1: 7e57b34d391be30cb59abc0955830715159c66fe
CRC32: 35fdd434
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --