From Below (2020_09_16_v_1_0_0) (NES)
Traducción al Español v1.0 (19/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
from_below_2020_09_16_v_1_0_0.nes
MD5: 15945fe933188072397cdfb0ad0cdfdb
SHA1: fe718046353eaf8972848372a7fbb12c79b7522f
CRC32: 8ce49adb
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --