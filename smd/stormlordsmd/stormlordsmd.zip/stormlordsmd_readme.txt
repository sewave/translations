Stormlord (Mega Drive)
Traducción al Español v1.0 (22/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Stormlord (U) [!].bin
MD5: 73070170122193915b7f8af945ef426c
SHA1: 1bf4b58d50fdc0fdc173ce3dcadcc5d9b58f0723
CRC32: 39ab50a5
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --