McDonald's Treasure Land Adventure (Mega Drive)
Traducción al Español v2.0 (01/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales al guion principal
-Retraducción del guion
-Traducidos PAUSE y NEXT en el minijuego
-Añadidos Á-Ñ a los créditos

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
McDonald's Treasure Land Adventure (USA).md
MD5: 2346c99595a4f341e39e6ec75fe19908
SHA1: bcb77c10bc8f3322599269214e0f8dde32b01a5c
CRC32: 04ef4899
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --