Teenage Mutant Ninja Turtles - Tournament Fighters (Super Nintendo)
Traducción al Español v1.2 (01/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Sin traducir, comprimido:
-Opciones
-Licencia
-Nombre escenarios
-Perfiles
-Carta inicial
-Puntuación final

V1.1: Arreglados algunos diálogos que no se borraban correctamente.

V1.2: Arreglados algunos diálogos que no se borraban correctamente.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles - Tournament Fighters (USA).sfc
MD5: 878e95bca6b94b3fa0e72fef1867434c
SHA1: c2460ce4aeda68f6170bdf9cfa52467b56e15ebf
CRC32: e2fe5dbf
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --