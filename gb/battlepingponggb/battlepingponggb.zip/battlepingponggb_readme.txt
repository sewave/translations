Battle Pingpong (Game Boy)
Traducción al Español v1.0 (13/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battle Pingpong (J).gb
MD5: f24ccb89c3ff60f54600d7b063d5a6c2
SHA1: 5008699f7a31a1a0722114f83e94591e99b22cc0
CRC32: 7c787bc4
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --