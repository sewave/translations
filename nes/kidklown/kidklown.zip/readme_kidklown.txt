Kid Klown
Traducci�n al Espa�ol v1.2 (04/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Kid Klown
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Kid Klown
-----------------
Un plataformas que en su versi�n original era un juego de mickey mouse, se pueden ver varias referencias a castle of illusion.
Este parche lo traduce completamente al espa�ol excepto la pantalla de final de juego "CONTINUE-END".

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es original y solo a�ade min�sculas y caracteres especiales.
V1.1: Corrige el texto final del juego.
v1.2: Correcci�n palabra repetida.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Kid Klown (U) [!].nes
262.160 bytes
CRC32: a474ccac
MD5: 220af5ab6c61a21582ffdb86690a72ec	
SHA1: b585aa4d3c226ee902e12010e3511360828e980e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al Espa�ol

-- END OF README --