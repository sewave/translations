Aladdin (Master System)
Traducción al Español v2.0 (18/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos ¡¿Ñ
-Guion retraducido
-Algunas cadenas alargadas
-Traducidas letras grandes
-Traducido PAUSE y READY!
-Traducidos créditos

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Aladdin (Europe, Brazil).sms
MD5: e3f60072028eb6f02c2b0558804aed83
SHA1: 585967f400473e289cda611e7686ae98ae43172e
CRC32: c8718d40
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --