Mario Bros. (NES)
Traducci�n al Espa�ol v1.0 (12/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mario Bros. (JU) [!].nes
MD5: 8d8e0b86dd870302bf4a994e76c55c83
SHA1: 9286a2db471d51713e9b75e68b47ffbf11e2d40b
CRC32: a6de1b55
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --