Puzznic (Game Boy)
Traducción al Español v1.0 (21/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Puzznic (Japan).gb
MD5: 9a777d82cd7a8913ba1aed2cc854fa50
SHA1: 74b26b502c5c728bc7b99f387f1aaf817d22b55a
CRC32: 916e638d
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --