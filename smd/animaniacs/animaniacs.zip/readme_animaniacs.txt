Animaniacs
Traducci�n al Espa�ol v1.1 (05/02/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Animaniacs
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Animaniacs
-----------------
Juego de plataformas/puzzle de la serie de animaci�n.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1: Peque�a correcci�n gramatical.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Animaniacs (U) [!].bin
1.048.576 bytes
CRC32: 86224d86
MD5: ce0a42a75a9e374cf5092f34bf6927b7
SHA1: 7e9d70b5172b4ea9e1b3f5b6009325fa39315a7c

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --