Castle of Illusion Starring Mickey Mouse (Mega Drive)
Traducción al Español v1.0 (03/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Castle of Illusion Starring Mickey Mouse (USA, Europe).md
MD5: 24863151abd5baf28c9386d49ffe3c09
SHA1: 4ac3687634a5acc55ac7f156c6de9749158713e4
CRC32: ba4e9fd0
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --