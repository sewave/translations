Battletoads & Double Dragon - The Ultimate Team (Super Nintendo)
Traducción al Español v1.0 (27/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battletoads & Double Dragon - The Ultimate Team (U) [!].smc
MD5: 3c433a8aa73986e1361423303e92785b
SHA1: bf56f12bdde3e2233d7ffcaf4825b10d92632b77
CRC32: 8b18ac01
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --