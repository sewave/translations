Dezaemon (NES)
Traducción al Español v1.0 (25/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la versión de Aeon Genesis.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dezaemon (Japan).nes
MD5: cf366bcb5ec1c1a2f52538a96597c52c
SHA1: 298e5070f9ac3b7ce0e27011ae55535e03242cf6
CRC32: 032594cd
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --