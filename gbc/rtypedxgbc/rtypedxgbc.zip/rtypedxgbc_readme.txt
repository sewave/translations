R-Type DX (Game Boy Color)
Traducción al Español v1.0 (12/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
R-Type DX (U) [C][!].gbc
MD5: dae7b7625d41d8a06266b09924154bb2
SHA1: e6a5c632b616e520b10b8b7589207c87c0092047
CRC32: fc1d4089
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --