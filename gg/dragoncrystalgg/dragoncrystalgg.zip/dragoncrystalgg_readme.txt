Dragon Crystal (Game Gear)
Traducción al Español v1.0 (02/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon Crystal (U) [!].gg
MD5: 8431baccd169025f79c9cbc44e31622d
SHA1: 6d53f32001d419a5b5e9c16cb62e07e548d2f44a
CRC32: 0ef2ed93
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --