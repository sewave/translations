Combat Cars (Mega Drive)
Traducción al Español v1.0 (06/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Combat Cars (UE) [!].bin
MD5: d951bf2f27fcfd5641261f82dc3c7c47
SHA1: 0c7ca93b412c8ab5753ae047de49a3e41271cc3b
CRC32: e439b101
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --