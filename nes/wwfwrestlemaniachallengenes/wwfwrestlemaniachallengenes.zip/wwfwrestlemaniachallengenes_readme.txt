WWF Wrestlemania Challenge (NES)
Traducción al Español v1.0 (29/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
WWF Wrestlemania Challenge (USA).nes
MD5: fb825af3c38b209432c7439e1746dcce
SHA1: 8848dabf75b06560ffd743d83f2f081644a8ff7c
CRC32: 932ade41
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --