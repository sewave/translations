Mega Man VI
Traducci�n al Espa�ol v1.1 (31/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Megaman VI
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Megaman VI
-----------------
Sexta parte del clasico de capcom.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1: Corregidas letras de la eleccion de pantalla que no salian.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Megaman VI (U) [!].nes
524.304	bytes
CRC32: 1efcac48
MD5: 37bb1a39a69bc6d1bccae0dd5411330d
SHA1: 32774f6a0982534272679ac424c4191f1be5f689

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --