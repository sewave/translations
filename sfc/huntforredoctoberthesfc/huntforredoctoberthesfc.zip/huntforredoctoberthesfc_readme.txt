The Hunt for Red October (Super Nintendo)
Traducción al Español v1.0 (08/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hunt for Red October, The (USA).sfc
MD5: 47d7b7ba3419b894002b0402685a0960
SHA1: c8afadb64ba542e61d6e3b5b5101e782c262ddc0
CRC32: c796e830
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --