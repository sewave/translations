Jungle Warfare - Joystick (ZX Spectrum)
Traducción al Español v1.0 (03/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jungle Warfare - Joystick (1989)(Mastertronic).tzx
MD5: 6756536086f6e4e0e0714a751bf92d98
SHA1: 18a78f34b41bb24516355fe3be0b98f957a067f2
CRC32: 92bedfd8
43860 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --