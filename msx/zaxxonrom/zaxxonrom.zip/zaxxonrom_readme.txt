Zaxxon (MSX)
Traducción al Español v1.0 (18/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zaxxon (1985) (Pony Cannon) (J).rom
MD5: 8ad24cb1636b8cce01e1cb6f9fcd6fd6
SHA1: d88f33ee40839f87cdce6cc4820e1dd192a01776
CRC32: 0b3ba595
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --