NBA Jam (Game Gear)
Traducción al Español v1.0 (13/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
NBA Jam (U) (V1.1) [!].gg
MD5: 51ee14347b3f3633299511fa5e637164
SHA1: 30bdf6edfb1772054e15edefd69fbe16efd1797a
CRC32: 820fa4ab
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --