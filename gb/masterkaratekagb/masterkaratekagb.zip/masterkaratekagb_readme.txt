Master Karateka (Game Boy)
Traducción al Español v1.0 (22/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Master Karateka (Japan).gb
MD5: 8076db86c921743aedd82b12d139c3c3
SHA1: 1ffea01d8d91f026ce6677631bcb10991092ff13
CRC32: 4c0fb33e
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --