Great Circus Mystery, The - Starring Mickey & Minnie
Traducci�n al Espa�ol v1.2 (23/01/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Great Circus Mystery, The - Starring Mickey & Minnie
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Great Circus Mystery, The - Starring Mickey & Minnie
-----------------
Segunda parte de la saga de plataformas de Mickey de la trilog�a Disney's Magical Quest.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1: Arreglos varios.
V1.2: Arregladas opciones.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Great Circus Mystery, The - Starring Mickey & Minnie (U) [!].gen
2.097.152 bytes
CRC32: 14744883
MD5: b51204d15148b5856d41eb29d23d242c
SHA1: f2df9807fe2659e8f8e6ea43b2031a6abd980873

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --