Atomic Runner (Mega Drive)
Traducción al Español v2.0 (16/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Traducido PAUSE
-Guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Atomic Runner (USA).md
MD5: 6ddf32102f20c6f91b0d97bb5da5caad
SHA1: 8a6e868fe36f2e5ac01af2557d3798a892e34799
CRC32: 0677c210
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --