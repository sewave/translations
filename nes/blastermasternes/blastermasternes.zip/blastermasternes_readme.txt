Blaster Master (NES)
Traducci�n al Espa�ol v1.0 (16/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blaster Master (U) [!].nes
MD5: 9c96408f7a7aa0da2c3b723759699506
SHA1: adb89b4923bb34805a39c141baf227849a27ce41
CRC32: 52bcf64a
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --