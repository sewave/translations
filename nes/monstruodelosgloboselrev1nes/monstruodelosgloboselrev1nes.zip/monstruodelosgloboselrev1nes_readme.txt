Monstruo de los globos, El (NES)
Traducción al Español v1.0 (03/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Monstruo de los globos, El (Spain) (Rev 1) (Gluk Video) (Unl).nes
MD5: a10cf67948b49e6a95db795865e1dfe8
SHA1: 827a3778211cd0539281b87b0d75dcd8b2912739
CRC32: ec47097e
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --