Secret Commando (Master System)
Traducción al Español v1.0 (20/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Secret Commando (E) [!].sms
MD5: 3f6c5515a2e39826fbf816780298701c
SHA1: e7a952f8bd6dddbb365870e906801021b240a533
CRC32: 00529114
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --