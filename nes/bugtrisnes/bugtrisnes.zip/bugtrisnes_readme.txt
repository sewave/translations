BugTris (NES)
Traducción al Español v1.0 (07/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
BugTris (Korea) (Unl).nes
MD5: fb5276a4ec43e51ba5639d313a6ebca8
SHA1: b0691110baac1f93576b2646c85c1c89d380627f
CRC32: d0b23fe9
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --