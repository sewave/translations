GG Aleste 3 (Game Gear)
Traducción al Español v1.0 (17/09/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
GG Aleste 3 (Japan) (En) (Aleste Collection).gg
MD5: ba860afbf7b7eb2b1ba08c957d44b34c
SHA1: fbef21541adc445c92abf7c92e97088cb073aafa
CRC32: 5ae64731
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --