T2 - The Arcade Game (Game Gear)
Traducci�n al Espa�ol v1.0 (13/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
T2 - The Arcade Game (U) [!].gg
MD5: d459d14baddfa9f8a69e91f79be71b9b
SHA1: 12b6f5542b6cebfe872096eab2a885d297eefa2f
CRC32: 9479c83a
524288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --