Hit Marmot (NES)
Traducción al Español v1.0 (14/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hit Marmot (Asia) (Unl).nes
MD5: abbc30751bbedb057cf0e5b3e9d436f9
SHA1: 4a30cbeb750aaff86e9691a431e88e8872b03a9a
CRC32: db529e09
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --