Riddick Bowe Boxing (Super Nintendo)
Traducción al Español v1.0 (23/12/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Riddick Bowe Boxing (USA).sfc
MD5: 757a4f4bcb7fa4781ebd083e2e0cd71c
SHA1: 495fb0a8cf44eed9833ed6345e5c8b35ede01a23
CRC32: a967a041
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --