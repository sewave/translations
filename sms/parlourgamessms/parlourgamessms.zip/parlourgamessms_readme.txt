Parlour Games (Master System)
Traducción al Español v1.0 (16/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Parlour Games (USA, Europe).sms
MD5: 6bec795910c5a91ac146b905df7c17f5
SHA1: 06664daf208f07cb00b603b12eccfc3f01213a17
CRC32: e030e66c
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --