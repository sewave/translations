Home Improvement - Power Tool Pursuit! (Super Nintendo)
Traducción al Español v1.0 (02/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Home Improvement - Power Tool Pursuit! (USA).sfc
MD5: c9a7bdedd316eb187ef2154ec6c17126
SHA1: 6675e639623eb8add706d56d9733e8ca776b77d4
CRC32: fa698c31
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --