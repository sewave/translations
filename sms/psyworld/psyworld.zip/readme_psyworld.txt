Psychic World
Traducci�n al Espa�ol v1.0 (01/12/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Psychic World
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Psychic World
-----------------
Curioso plataformas con muchos poderes para ir pasando a traves de las pantallas, esta version de MASTER SYTEM, es diferente a la de GAME GEAR, no un port directo, pero sigue siendo el mismo juego.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
No esta traducido el peque�o dialogo con cecile al final del juego ni el titulo.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Psychic World (E) [!].sms
262.144	bytes
CRC32: 5c0b1f0f
MD5: 1076f6358527d1cec1e1e75143997293
SHA1: 5fa54329692e680a190291d0744580968aa8b3fe

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --