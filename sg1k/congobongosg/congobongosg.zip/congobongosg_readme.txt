Congo Bongo
Traducci�n al Espa�ol v1.0 (01/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Congo Bongo
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Congo Bongo
-----------------
Adaptaci�n del arcade para SG-1000.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Congo Bongo (SG-1000).sg
32.768 bytes
CRC32: dc4383cc
MD5: 74fc3c383b59ca0dc12bc299edf0bb22
SHA1: 96dd55a63bae0abc666fe317d50612116100d7b1

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --