Artillery Duel (Colecovision)
Traducción al Español v1.0 (17/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Artillery Duel (1983) (Xonox).col
MD5: 4c0a35ec646d092ffbca54b8dac1e364
SHA1: 2233e9099561bfd4ece10ff5884782f0e31d0ea1
CRC32: adfa09e2
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --