Spider-Man - X-Men - Arcade's Revenge (Super Nintendo)
Traducción al Español v1.0 (18/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Comic intro:
Sobre las calles de la ciudad
Spider-Man: ¡Solo espero no llegar demasiado TARDE!
Spider-Man: Primero Cíclope, luego Tormenta y ahora Lobezno...
Spider-Man: ¡¡Gambito!! ¡CUIDADO!
Spider-Man: Conozco ese CAMIÓN
Spider-Man: ...¡¡ARCADE!! TENGO que ir tras ellos
Spider-Man: ¡Las vidas de los X-MEN dependen de mi!

Comic final:
Lobezno: ¡CORRED! ..¡Todo este sitio va a EXPLOTAR!
Spider-Man: ¿Creéis que salió?
Gambito: Puedes contar con ello.
Cíclope: Venga... ¡Vamos a CASA!

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spider-Man - X-Men - Arcade's Revenge (USA).sfc
MD5: 9d59f3def2b1a8d87f7e97cef41a04c0
SHA1: 1365a9dc47e8150f171098691478d557be740c1a
CRC32: ae878ccb
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --