Wolverine (NES)
Traducción al Español v1.0 (21/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wolverine (U) [!].nes
MD5: f939c2e33326737c325eb2a3ecb6d3a0
SHA1: 72279226339938a684292bf17bbaeef78b67c788
CRC32: 1fd46615
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --