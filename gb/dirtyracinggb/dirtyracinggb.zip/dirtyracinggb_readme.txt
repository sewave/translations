Dirty Racing (Game Boy)
Traducción al Español v1.0 (10/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dirty Racing (Japan).gb
MD5: b2023017774d88ffe82a7d1b0af52c12
SHA1: 5b58b4d02987ce3a16774bc4a6707d12ac404c1c
CRC32: 43af45b1
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --