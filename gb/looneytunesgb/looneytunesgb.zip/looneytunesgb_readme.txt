Looney Tunes (Game Boy)
Traducción al Español v1.0 (31/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Looney Tunes (U) [!].gb
MD5: 6e9dd3c1fb169da79292a1962e95a884
SHA1: 97d96f8ec66acba996c7bec0a713c84075f22680
CRC32: a662a8ef
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --