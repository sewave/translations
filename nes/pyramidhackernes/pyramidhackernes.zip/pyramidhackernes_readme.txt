Pyramid (NES)
Traducción al Español v1.0 (19/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pyramid (Japan) (Hacker inc.) (Unl).nes
MD5: 1bb8ba8d37514540037741c6a80e490d
SHA1: f65726004e41798d6d52959124acb941626a9cf1
CRC32: be90adf4
98320 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --