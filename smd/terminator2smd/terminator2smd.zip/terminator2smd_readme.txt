Terminator 2 - Judgment Day (Mega Drive)
Traducción al Español v1.0 (25/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Terminator 2 - Judgment Day (UE) [!].bin
MD5: 32f931827159663d6bf27c12949b1875
SHA1: 6144fbb941c1bf0df285f6d13906432c23af2ba6
CRC32: 2f75e896
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --