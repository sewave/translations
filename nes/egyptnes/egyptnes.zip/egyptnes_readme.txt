Egypt (NES)
Traducción al Español v1.0 (23/11/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de BlackPaladin.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Egypt (Japan).nes
MD5: 5e7bf243e25d18feec6035aca444f187
SHA1: 605f62d4545e6a3b2aa4555728a6e6f5d5966389
CRC32: 38df4be7
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --