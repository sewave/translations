Flash Gordon (ZX Spectrum)
Traducción al Español v1.0 (01/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Flash Gordon.tzx
MD5: 3aa4b625af8d95b9a6f8f03cb56eadb4
SHA1: a343a7c3a5bac972eecd6dcb1f75b4767fecb0d1
CRC32: 15c66d16
76217 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --