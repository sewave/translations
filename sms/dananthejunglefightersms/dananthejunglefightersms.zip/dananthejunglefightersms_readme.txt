Danan - The Jungle Fighter (Master System)
Traducción al Español v2.0 (02/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducido "PRESS START BUTTON" del título
-Añadidos caracteres especiales
-Reescrito todo el guion
-Arreglado texto que indicaba "CUCHILLO DEL GATO MONTÉS" cuando en realidad es "CUCHILLO DE LA PANTERA"
-Arreglado texto atribuido a DANAN erróneamente restaurándolo a LINDA.
-Textos del menú ampliados

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Danan - The Jungle Fighter (Europe).sms
MD5: 6b0fc60aa886c060bf1a16ea97b4f441
SHA1: c99f2562117a2bf7100a3992608e9a2bcb50df35
CRC32: ae4a28d7
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --