Q-bert for Game Boy (Game Boy)
Traducción al Español v1.0 (21/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Q-bert for Game Boy (USA, Europe).gb
MD5: 514688df17c1f7bcf978a13c83d0c22c
SHA1: bd56a1e96c3d310b522e25d7b72ceef26af87f2e
CRC32: b0109545
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --