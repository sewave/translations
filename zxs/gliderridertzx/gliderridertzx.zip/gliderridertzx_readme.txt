Glider Rider (ZX Spectrum)
Traducción al Español v1.0 (11/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Glider Rider.tzx
MD5: 057332efcc32e123ad4021f124f46ade
SHA1: 6d8db4459e4226470f623a73002debf6d35ccc20
CRC32: d5ba7bad
73222 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --