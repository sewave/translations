Paperboy II (Mega Drive)
Traducci�n al Espa�ol v1.0 (10/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Paperboy II (U) [!].bin
MD5: 93a22de4e043056ead9f3bd4a7f659e0
SHA1: 6421c26000bec21d0c808252c5d9ce75b75cb8a4
CRC32: 1de28bb1
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --