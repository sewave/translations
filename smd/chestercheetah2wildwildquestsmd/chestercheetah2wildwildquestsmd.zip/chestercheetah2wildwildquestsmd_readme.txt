Chester Cheetah 2 - Wild Wild Quest (Mega Drive)
Traducci�n al Espa�ol v1.0 (14/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chester Cheetah 2 - Wild Wild Quest (U) [!].bin
MD5: e4a419078b558efedb838dc581365bf1
SHA1: 3a0a01338320a4326a365447dc8983727738a21e
CRC32: b97b735d
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --