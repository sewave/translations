Last Vampire (ZX Spectrum)
Traducción al Español v1.0 (05/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Last Vampire.tzx
MD5: 5fba299793a89353cc9cc2ea498f37aa
SHA1: 979506cce2d5586b0bc66f67ac80e64d3578a356
CRC32: 6e7748a8
50488 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --