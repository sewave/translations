Lone Ranger, The
Traducci�n al Espa�ol v1.0 (29/10/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Lone Ranger, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Lone Ranger, The
-----------------
Gran juego que tiene de todo, partes de accion, fps, plataformas, basado en la serie homonima.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Lone Ranger, The (U) [!].nes
393.232	bytes
CRC32: 06c65580
MD5: 270f04797f6d237c0a14c01f05a4f3d8
SHA1: 6b6dbfb4538ab3fca7d1bb4d89c6ca4cb32aedf9

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --