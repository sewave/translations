Castlevania (NES)
Traducción al Español v1.0 (26/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Castlevania (USA) (Rev 1).nes
MD5: 52eb3f7e2c5fc765aa71f21c85f0770e
SHA1: 7a20c44f302fb2f1b7adffa6b619e3e1cae7b546
CRC32: 856114c8
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --