Digger - The Legend of the Lost City (NES)
Traducción al Español v1.0 (09/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Digger - The Legend of the Lost City (USA).nes
MD5: f238710ab69ebf85c9b18d966508f164
SHA1: a3aa8100733d15f50c9166fab6533ba56577174a
CRC32: ec41647e
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --