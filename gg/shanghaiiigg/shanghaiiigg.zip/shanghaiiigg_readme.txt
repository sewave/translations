Shanghai II (Game Gear)
Traducción al Español v1.0 (22/03/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shanghai II (Japan) (Rev A).gg
MD5: c228d31cf77bd03ac457e2d22f5b2bd1
SHA1: 82210b387344aaebae8cf03029967cd0c906beff
CRC32: 81314249
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --