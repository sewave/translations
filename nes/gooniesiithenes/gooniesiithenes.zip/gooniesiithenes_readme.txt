The Goonies II (NES)
Traducción al Español v1.0 (05/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Goonies II, The (USA).nes
MD5: d38325cffb9ba2e6f57897c0e9564cc0
SHA1: 0a5b8fd5e46f56203f8bf12e888f4f2ea1616aa8
CRC32: aa9ca482
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --