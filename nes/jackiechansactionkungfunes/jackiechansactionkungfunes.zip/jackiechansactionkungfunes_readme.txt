Jackie Chan's Action Kung Fu (NES)
Traducci�n al Espa�ol v1.0 (21/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jackie Chan's Action Kung Fu (U) [!].nes
MD5: 3de761689d6d745f0d777bf7c86fb406
SHA1: 48308ad01ed49b928e38ee7de18feb9f917a6c1e
CRC32: 6f371f16
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --