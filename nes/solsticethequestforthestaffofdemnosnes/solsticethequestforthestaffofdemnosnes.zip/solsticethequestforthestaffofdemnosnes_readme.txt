Solstice - The Quest for the Staff of Demnos (NES)
Traducci�n al Espa�ol v1.1 (06/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglados �tems con acentos al no poderse mostrar correctamente.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Solstice - The Quest for the Staff of Demnos (U) [!].nes
MD5: a42e31d875d0573ba858de365628f608
SHA1: 992da7fac9248204cddcdf2e37412007359603ba
CRC32: 1d60732e
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --