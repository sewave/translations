Zen - Intergalactic Ninja
Traducci�n al Espa�ol v1.0 (16/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Zen - Intergalactic Ninja
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Zen - Intergalactic Ninja
-----------------
Curioso plataformas a lo Capit�n Planeta, con partes isom�tricas y otras laterales, corto, pero con trucos resultones.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Todo esta traducido menos la barra de estado y graficos con texto.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Zen - Intergalactic Ninja (U) [!].nes
262.160	bytes
CRC32: f2c4836f
MD5: 9ef264d1b0f6812ce60b9a6b78e365b9
SHA1: b230ffdd6fbe0180c48f181de792a7321b582273

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --