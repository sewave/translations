Amazing Spider-Man 3, The - Invasion of the Spider-Slayers
Traducci�n al Espa�ol v1.0 (27/04/2017)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Amazing Spider-Man 3, The - Invasion of the Spider-Slayers
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Amazing Spider-Man 3, The - Invasion of the Spider-Slayers
-----------------
Tercer juego de spider-man para game boy.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Amazing Spider-Man 3, The - Invasion of the Spider-Slayers (U) [!].gb
131.072	bytes
CRC32: cbb2f22c
MD5: 8833ae0fd3b4c47b8249a12708c98a98
SHA1: d9687896481316d873046daca43cc0e259c32929

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
juandex - Testing

-- END OF README --