Samurai Shodown (Super Nintendo)
Traducción al Español v1.0 (20/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Samurai Shodown (USA).sfc
MD5: f64e2b3eb9ee5b92f267bd420b294efc
SHA1: 3844a37927ae12d4077ee7188048b4cbb9958448
CRC32: 2e614a53
4194304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --