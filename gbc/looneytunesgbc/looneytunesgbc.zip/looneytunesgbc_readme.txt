Looney Tunes (Game Boy Color)
Traducción al Español v1.0 (14/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

-Traducido minijuegos
-Traducidos gráficos BOSS/TIME/SCORE repetidos
-Añadidas Ú y Ñ

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Looney Tunes (USA).gbc
MD5: f687b51a0fab72e03766356b62261a49
SHA1: 80a0e66754ce81a01385941459b9ea15a450b2b6
CRC32: 4ef3ddd7
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --