The Death and Return of Superman
Traducci�n al Espa�ol v1.0 (30/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre The Death and Return of Superman
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre The Death and Return of Superman
-----------------
Adaptaci�n del comic a beat em up para la MEGA DRIVE.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Las biograf�as de los personajes no est�n traducidas.
Si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Death and Return of Superman, The (U) [!].bin
2.097.152 bytes
CRC32: 982242d3
MD5: 960a409245913c8adf10c4b3ed23ab04
SHA1: 3534d17801bd5756b10a7f8d7d95f3a8d9b74844	

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --