Ice Climber (NES)
Traducci�n al Espa�ol v1.0 (27/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ice Climber (U) [!].nes
MD5: d35f9979f206897df94fb5425e23fc85
SHA1: 09d97003bf9d676f24a75cf3e1dced28cda3be59
CRC32: 70044a74
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --