Low G Man - The Low Gravity Man (NES)
Traducción al Español v2.0 (19/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Contiene el fix de la SRAM de RainWarrior.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres especiales
-Traducción de subtítulo
-Mejorada traducción del menú
-Guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Low G Man - The Low Gravity Man (USA).nes
MD5: 7e27442a832019524f81fed9fcc0979c
SHA1: f353e85c0f074ff5d77f1359e19bec660668b235
CRC32: 4e91df7c
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --