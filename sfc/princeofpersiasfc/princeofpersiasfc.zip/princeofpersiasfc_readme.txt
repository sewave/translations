Prince of Persia (Super Nintendo)
Traducción al Español v1.1 (28/12/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
-Cambiado Sultan por Sultán
-Cambiado password por clave
-Guion revisado
-Cambiada rom a no-intro

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Prince of Persia (USA).sfc
MD5: 8ffc8d34bc75bc049122894b4292eb85
SHA1: 29ce1e32cf57d8284d0670949045c0d9128c3e1b
CRC32: 891bb2bb
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --