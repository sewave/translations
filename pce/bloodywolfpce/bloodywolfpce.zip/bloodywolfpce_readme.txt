Bloody Wolf
Traducci�n al Espa�ol v1.0 (24/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Bloody Wolf
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Bloody Wolf
-----------------
Shooter para pc engine.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Bloody Wolf (U).pce
524.288	bytes
CRC32: 37baf6bc
MD5: f19869d1823a28e8472452baf697cf56
SHA1: 45f8762414fb6b581b6159908cc35b2607ecf237

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --