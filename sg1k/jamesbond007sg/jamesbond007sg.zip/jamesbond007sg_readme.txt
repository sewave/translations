James Bond 007 (SG-1000)
Traducci�n al Espa�ol v1.0 (23/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
James Bond 007 (SG-1000) [!].sg
MD5: b2ac0c7755e0d6ba0a737861ee190a53
SHA1: 88d8c1f56f06ec76be285c29f41322a748f7c4db
CRC32: 90160849
16.384 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --