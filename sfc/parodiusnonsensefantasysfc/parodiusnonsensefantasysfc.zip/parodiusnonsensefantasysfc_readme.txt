Parodius - Non-Sense Fantasy (Super Nintendo)
Traducción al Español v1.0 (09/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Parodius - Non-Sense Fantasy (E).smc
MD5: 59146e26b4fd75d74f953037868defa9
SHA1: c561db29eb48e814549aa6e967fde7de32e3f922
CRC32: 6ffa308c
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --