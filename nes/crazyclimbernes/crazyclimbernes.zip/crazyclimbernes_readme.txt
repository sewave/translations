Crazy Climber (NES)
Traducción al Español v1.0 (05/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Crazy Climber (Japan).nes
MD5: a7506be2f527bbe032d92469d36c4453
SHA1: cdaf5d5a8b1635c6e331781b249f9943931a65ff
CRC32: 738881a7
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --