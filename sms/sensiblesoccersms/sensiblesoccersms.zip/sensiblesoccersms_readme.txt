Sensible Soccer (Master System)
Traducción al Español v1.0 (08/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sensible Soccer (E) [!].sms
MD5: 5ca0a2b33db8eedcddb1d5aeaa8ea5a4
SHA1: 08b4f5b8096bc811bc9a7750deb21def67711a9f
CRC32: f8176918
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --