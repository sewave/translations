Superman
Traducci�n al Espa�ol v1.0 (06/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Superman
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Superman
-----------------
Arcade de superman para la 16 bits sobremesa de Sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Superman (U) [!].gen
1.048.576 bytes
CRC32: 543a5869
MD5: d7abe5e449f7fa966d0f6b158eea8ee9
SHA1: ca14653589fd36e6394ec99f223ed9b18f70fd6a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --