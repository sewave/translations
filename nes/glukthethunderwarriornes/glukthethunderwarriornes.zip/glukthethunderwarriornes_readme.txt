Gluk the Thunder Warrior (NES)
Traducción al Español v1.0 (30/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gluk the Thunder Warrior (Spain) (Gluk Video) (Unl).nes
MD5: f7337cf0cf731c1ba3687f49ff9298c2
SHA1: 283e8fbf7086f3a26064611c0dbacadefadcdb43
CRC32: 5d615d1d
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --