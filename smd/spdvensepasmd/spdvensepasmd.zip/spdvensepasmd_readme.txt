Spider-Man and Venom - Separation Anxiety (Mega Drive)
Traducci�n al Espa�ol v1.0 (09/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spider-Man and Venom - Separation Anxiety (U) [!].gen
MD5: 41d79267b01e983c0956151de10d9646
SHA1: 563b45254c168aa0de0bba8fadd75a2d1e8e094b
CRC32: 512ade32
3.145.728 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --