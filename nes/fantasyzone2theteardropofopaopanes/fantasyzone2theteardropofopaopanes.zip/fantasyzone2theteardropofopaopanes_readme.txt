Fantasy Zone 2 - The Teardrop of Opa-Opa (NES)
Traducción al Español v1.0 (10/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fantasy Zone 2 - The Teardrop of Opa-Opa (J) [!].nes
MD5: 7500a4abb48b288deff2dbe9dc2773d3
SHA1: 95aec2329a889754a11614c0cb0cfa12a966d941
CRC32: 6faf6db1
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --