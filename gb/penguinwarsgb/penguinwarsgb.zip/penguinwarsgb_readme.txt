Penguin Wars (Game Boy)
Traducción al Español v1.0 (19/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Penguin Wars (USA).gb
MD5: 9c17a77f10f8c8024addc299cfd74b8b
SHA1: 2c00f5678d55dcb865b596fcb1dbecd2c9213988
CRC32: eecff7f3
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --