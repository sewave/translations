Space Invaders (MSX)
Traducción al Español v1.0 (01/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Space Invaders (1985)(Taito).rom
MD5: cc67dc39f1c37ac5d2bdcaa9f9016756
SHA1: 4971bdd3db63d394fbc2186182c901ca4b32535b
CRC32: de02932d
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --