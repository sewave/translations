The Immortal (Mega Drive)
Traducción al Español v1.0 (29/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Immortal, The (UE) [!].gen
MD5: 469c2c852005972bbcd2b51fdf9d1220
SHA1: 71fc189fe2ba5687e9d45b68830baed27194f627
CRC32: f653c508
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --