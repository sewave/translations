Enduro Racer Jap
Traducci�n al Espa�ol v1.0 (15/03/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Enduro Racer
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Enduro Racer
-----------------
Curiosa adaptacion del clasico de sega, con un modo mas original, con ams pantallas y graficos que la version europea.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Enduro Racer (J).sms
262.144 bytes
CRC32: 5d5c50b3
MD5: a94de92b078911e71c246679c8992da1
SHA1: 7a0216af8d4a5aeda1d42e2703f140d08b3f92f6

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --