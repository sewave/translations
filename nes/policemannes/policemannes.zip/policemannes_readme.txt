Policeman (NES)
Traducción al Español v1.0 (03/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Policeman (Spain) (Gluk Video) (Unl).nes
MD5: c3e55225f7a2d9fc030f1910745db094
SHA1: 7684deb268b2bb2fe9e6e2208e1bacdb49370395
CRC32: 6b1ddc17
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --