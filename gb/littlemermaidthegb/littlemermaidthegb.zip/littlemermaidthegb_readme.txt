The Little Mermaid (Game Boy)
Traducción al Español v1.0 (20/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Little Mermaid, The (U) [!].gb
MD5: a4dee5de1b4c3d9083f307d910fa0c3f
SHA1: 9c7d7a82d0eeb4d7b4f4b7ae35e5ebd80c93d780
CRC32: d7c517e5
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --