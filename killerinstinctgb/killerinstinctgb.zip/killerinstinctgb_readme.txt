Killer Instinct (Game Boy)
Traducción al Español v1.0 (01/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Killer Instinct (USA, Europe) (SGB Enhanced).gb
MD5: ba8628a70339843c2ee8a294b840e8d6
SHA1: 65ae38588abc0e699b244b0854f698ddf72c7b46
CRC32: ac793b54
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --