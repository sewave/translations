Sylvan Tale (Game Gear)
Traducci�n al Espa�ol v1.0 (02/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking est� basada en la inglesa de Aeon Genesis.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sylvan Tale (J) [!].gg
MD5: 6657230e92f13ed98474523efc29d6b3
SHA1: bec44ab675bcd6b081590d4d52b6af4076c342e6
CRC32: 45ef2062
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

Contributor	Type of contribution	Listed credit
Gideon Zhi	Hacking	Project leader, lead ROM hacker
Shih Tzu	Script Editing/Revision	Scriptwriter, ROM hacker, script opinions
MO	Translation	
Akujin	Production	Script opinions
Jair	Production	Script opinions

-- FIN --