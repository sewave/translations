Greendog (Game Gear)
Traducción al Español v1.0 (06/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Greendog (U).gg
MD5: e6c364fce0f71a9eb9e5474cd84c2067
SHA1: b5bf962000636bb1cbdf134759baa1e25b25d097
CRC32: f27925b0
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --