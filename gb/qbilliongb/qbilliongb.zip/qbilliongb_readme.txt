Q Billion (Game Boy)
Traducción al Español v1.0 (13/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Q Billion (U) [!].gb
MD5: ab7a5f3d9e818a434cc64915c3dbd31f
SHA1: cfc54888f1ba368463009983f3cb3f6da66f3aec
CRC32: 7202e973
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --