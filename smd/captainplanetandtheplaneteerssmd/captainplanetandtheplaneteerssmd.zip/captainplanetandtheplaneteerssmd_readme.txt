Captain Planet and the Planeteers (Mega Drive)
Traducci�n al Espa�ol v1.0 (01/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Captain Planet and the Planeteers (E) [!].gen
MD5: 4f95573c08f905466e01cf8e1bc59a73
SHA1: b048f922db83802a4a78d1e8197a5ec52b73a89f
CRC32: 7672efa5
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --