Sonic 3D Blast Director’s Cut (Mega Drive)
Traducción al Español v1.0 (22/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Esta traducción está basada en la versión "Director’s Cut" de Sonic 3D Blast.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sonic 3D Blast (UE) [!].gen
MD5: 50acbea2461d179b2bf11460a1cc6409
SHA1: 89957568386a5023d198ac2251ded9dfb2ab65e7
CRC32: 44a2ca44
4194304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --