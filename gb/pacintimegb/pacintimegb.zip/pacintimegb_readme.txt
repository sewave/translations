Pac-In-Time (Game Boy)
Traducción al Español v1.0 (19/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pac-In-Time (USA) (SGB Enhanced).gb
MD5: 54ef4bb8c3d272af5bb78b4306f37248
SHA1: 282f9bbabd5a57d5e7755e5d00f4d65094f816d5
CRC32: 50a15dc8
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --