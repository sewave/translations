The Lord of King (NES)
Traducción al Español v1.0 (21/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de BlackPaladin.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lord of King, The (Japan).nes
MD5: 5fd2b7f64bb4a797bb79e1e99e9eda00
SHA1: b1cad2d3e38ccd7780437d2c83effa254576861b
CRC32: af267213
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --