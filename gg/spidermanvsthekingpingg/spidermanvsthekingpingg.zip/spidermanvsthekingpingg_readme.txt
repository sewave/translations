Spider-Man vs. The Kingpin
Traducci�n al Espa�ol v1.0 (09/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Spider-Man vs. The Kingpin
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Spider-Man vs. The Kingpin
-----------------
Versi�n de Game Gear del juego de acci�n/plataformas de Spider-Man.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------

Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Spider-Man vs. The Kingpin (U) [!].gg
262.144	bytes
CRC32: 2651024e
MD5: 13e2e27559b0ae898306506219dcc68b
SHA1: 46b064b4b5a6444ce0e64e16a7e5cec2087fb4d3

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --