Contra - Hard Corps (Mega Drive)
Traducción al Español v1.0 (08/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Contra - Hard Corps (USA, Korea).md
MD5: 2bd30479556da5c310d8f2a1fe66e8fa
SHA1: 68ea84146105bda91f6056932ff4fb42aa3eb4a7
CRC32: c579f45e
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --