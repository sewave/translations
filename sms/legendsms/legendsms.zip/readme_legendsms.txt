Legend of Illusion Starring Mickey Mouse
Traducci�n al Espa�ol v1.0 (11/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Legend of Illusion Starring Mickey Mouse
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Legend of Illusion Starring Mickey Mouse
-----------------
Otra aventura de mickey en los 8 bits, con muy buenos efectos y gameplay variado, identico en game gear y master system.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Legend of Illusion Starring Mickey Mouse (U) [!].sms
524.288	bytes
CRC32: 6350e649
MD5: 4a69a56a8efff7863feca11f1d6547e3
SHA1: 62adbd8e5a41d08c4745e9fbb1c51f0091c9dea6

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --