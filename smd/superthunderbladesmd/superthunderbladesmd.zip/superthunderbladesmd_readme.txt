Super Thunder Blade (Mega Drive)
Traducción al Español v1.0 (26/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Thunder Blade (World).md
MD5: 04da37f2a95340243bff72c82d4c7b73
SHA1: 21810b4a309a5b9a70965dd440e9aeed0b6ca4c5
CRC32: b13087ee
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --