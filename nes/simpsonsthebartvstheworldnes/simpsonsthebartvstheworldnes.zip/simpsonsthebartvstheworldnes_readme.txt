The Simpsons - Bart vs. the World  (NES)
Traducción al Español v1.0 (20/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Simpsons, The - Bart vs. the World (USA).nes
MD5: 7eebe195f48640c63050f6756d09adff
SHA1: a43d014a4706509c3f8093e61f9040b57d9bca4e
CRC32: 5101bae1
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --