Cooly Skunk (Super Nintendo)
Traducción al Español v1.0 (19/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Psyklax.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
coolyskunk_full.sfc
MD5: 2a25ab77111346caf7c760a04bcda218
SHA1: 135c5330be85ba72a7417c6773ca0c352446c216
CRC32: 90fd3134
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --