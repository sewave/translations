Road Rash II (Mega Drive)
Traducción al Español v1.1 (07/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Arreglada música en opciones que estaba del revés.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Road Rash II (USA, Europe).md
MD5: c04a309f607aaf59f55eb8dad6affa73
SHA1: 6fa6420a2abcf5c2c4620c19b1f2a831996af481
CRC32: 7b29c209
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --