Ms. Pac-Man (NES)
Traducci�n al Espa�ol v1.0 (05/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ms. Pac-Man (U) [!].nes
MD5: 7a47a5ff752c46409d8c1e4c8170426b
SHA1: 9bb7fc771a991ea036fbb0ae97f7af41aaae7826
CRC32: 51a0c9de
40.976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --