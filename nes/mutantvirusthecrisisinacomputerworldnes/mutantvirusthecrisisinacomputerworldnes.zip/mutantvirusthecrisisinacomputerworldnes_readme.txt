The Mutant Virus - Crisis in a Computer World (NES)
Traducción al Español v1.0 (07/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mutant Virus, The - Crisis in a Computer World (USA).nes
MD5: 4f83de81aa1b986a1961a8dc967fe0a2
SHA1: c301368ae8b92de2dca9ce707bbb150694a157df
CRC32: 10786d36
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --