MechWarrior 3050 (Super Nintendo)
Traducción al Español v1.0 (04/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
MechWarrior 3050 (USA).sfc
MD5: eacf64068aa69a47a82d110f074ff4c6
SHA1: 2e9ad76ef580813fa799bec5559474f3e881e11a
CRC32: c0acc92d
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --