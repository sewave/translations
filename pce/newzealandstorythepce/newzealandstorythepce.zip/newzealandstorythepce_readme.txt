The New Zealand Story (PC Engine)
Traducci�n al Espa�ol v1.0 (23/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
New Zealand Story, The (Japan).pce
MD5: 553dd0a65c0d060290f66c820ca94b1c
SHA1: cda9acea9cae4899af35b6c49b9ed449c240af16
CRC32: 8e4d75a8
393.216 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --