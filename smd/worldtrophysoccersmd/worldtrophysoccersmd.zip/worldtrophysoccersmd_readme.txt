World Trophy Soccer (Mega Drive)
Traducción al Español v1.0 (01/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
World Trophy Soccer (USA).md
MD5: dbf5f8e9346a4bd2eb84dc5dd2dd1ea8
SHA1: 0a0ac6d37d284ec29b9331776bbf6b78edcdbe81
CRC32: 6e3edc7c
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --