Star Wars (Game Gear)
Traducci�n al Espa�ol v1.0 (18/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Star Wars (U) [!].gg
MD5: 5330216b69cfd046abcc209cbc22d07e
SHA1: 48c14c0c2b4e38ac122d9ccdcdc8b194e15ef032
CRC32: 0228769c
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --