Terra Cresta (NES)
Traducci�n al Espa�ol v1.0 (31/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Terra Cresta (U) [!].nes
131.088 bytes
MD5: 346a24ff3466b2f9b0478146dbefa502
SHA1: 2c6f2d960dbefdfaead76fae795526a6c12cd1d1
CRC32: e9b1dfad

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.
Juandex - Testing

-- FIN --