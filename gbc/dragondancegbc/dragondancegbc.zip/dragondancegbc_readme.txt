Dragon Dance (Game Boy Color)
Traducción al Español v1.0 (01/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon Dance (USA) (SGB Enhanced).gbc
MD5: 0c6a0f2add131ca4afd24763fe3c3a04
SHA1: a28bfabc4db62ad5aa6bfe29114b0878429586cc
CRC32: 0602dbe1
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --