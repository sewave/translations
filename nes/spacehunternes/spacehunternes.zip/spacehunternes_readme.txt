Space Hunter (NES)
Traducción al Español v1.0 (29/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Zatos Hacks y Fyr.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Space Hunter (Japan).nes
MD5: b7b0473b60e259838d087849c408893e
SHA1: 6dfe0bcc89a78f39e56269da013c5a4dd2aeb6a0
CRC32: b155899c
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --