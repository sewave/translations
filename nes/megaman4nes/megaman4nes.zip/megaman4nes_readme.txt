Mega Man 4 (NES)
Traducción al Español v2.0 (19/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducido STAFF por GRUPO
-Traducido GAME OVER por FIN JUEGO
-Añadidos ¡ÁÉÍÑÓÚ al script principal
-Retraducción con modificación de punteros de la intro
-Añadidos acentos en CONTINÚA y CLAVE ERRÓNEA
-Mejorado menú de armas

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mega Man 4 (USA) (Rev A).nes
MD5: 1a4fdaece6ae32e5878029da63866d94
SHA1: 0fa8d2dadfb6e1dd9de737a02ce0bfa1cd5ff65d
CRC32: 9ed9d3af
524304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --