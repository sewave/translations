Monaco GP (SG-1000)
Traducci�n al Espa�ol v1.0 (19/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Monaco GP (SG-1000).sg
MD5: 236e3f1d2342bac175d68ecdb75234a2
SHA1: 6476bc0fc1608dd69a1ae62617ea4719bc7eaa50
CRC32: 72542786
40.960 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --