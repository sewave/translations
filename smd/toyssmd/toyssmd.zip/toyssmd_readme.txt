Toys (Mega Drive)
Traducción al Español v1.0 (17/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Toys (USA).md
MD5: 608e9d0f19b33749865f809bbe4b9f5c
SHA1: debc3a571c2c08a731758113550c040dfcda4782
CRC32: cbc9951b
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --