Castle of Illusion Starring Mickey Mouse (Master System)
Traducción al Español v2.0 (27/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducción del título
-Añadidos acentos y ñ¡¿
-Revisión de script

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Castle of Illusion Starring Mickey Mouse (USA, Brazil).sms
MD5: e9b4b92bc29ca8fbe9978da6720bd1eb
SHA1: c31d80429801e8c927cb0536d66a16d51788ff4f
CRC32: b9db4282
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --