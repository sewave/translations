Dough Boy (NES)
Traducción al Español v1.0 (28/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dough Boy (Japan).nes
MD5: 1534acfe4583e4b14af606b4737b8f0e
SHA1: 9ed81a29c83229b8706a5a2e443821f36bced18d
CRC32: 1012eb15
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --