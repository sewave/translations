Kung Fu (NES)
Traducci�n al Espa�ol v1.0 (09/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kung Fu (U) [!].nes
MD5: 27e5c62c6c169896bf80bafb6595ceb8
SHA1: c054a885fb9b00d3f6797a35ba5579f2896a254a
CRC32: 32b45889
40.976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --