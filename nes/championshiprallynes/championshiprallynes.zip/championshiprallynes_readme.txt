Championship Rally (NES)
Traducción al Español v1.0 (23/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Championship Rally (Europe).nes
MD5: fce050aaa563937d05e8563b10217702
SHA1: 64be2df1a37d73ca3798c01f77c76a26ee244858
CRC32: adc5f741
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --