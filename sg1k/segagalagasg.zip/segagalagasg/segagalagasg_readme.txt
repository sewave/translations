Sega Galaga (SG-1000)
Traducci�n al Espa�ol v1.0 (24/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sega Galaga (SG-1000) [!].sg
16.384 bytes
MD5: e2619cf7c307ac1916c534519f6043d9
SHA1: 32e776b3a17f7c0df0fa9eb49a3e451cfe702bfd
CRC32: 981e36c1

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --