Dragon's Revenge (Mega Drive)
Traducción al Español v1.0 (24/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon's Revenge (UE) [!].bin
MD5: f2b7d96aae4b5fdc6a1eac5a045e66c4
SHA1: 75854a732d4cf9a310c4359092cf5c2482df49a7
CRC32: 841edbc0
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --