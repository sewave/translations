Gods (Mega Drive)
Traducci�n al Espa�ol v1.0 (06/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gods (U) [!].bin
MD5: 7c3fcd8a86e01e5b542434fd37a49002
SHA1: bfc84beba074c7dc58b0b4fcac73fffcf0c6b585
CRC32: fd234ccd
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --