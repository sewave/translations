Simpsons, The - Bart vs. The Space Mutants (GAME GEAR)
Traducci�n al Espa�ol v1.0 (13/07/2018)
(C) 2018 Wave Translations

---------
Contenido
---------

1. Notas y Fallos Conocidos
2. Instrucciones de Parcheo
3. Cr�ditos del Parche

---------------------------
1. Notas y Fallos Conocidos
---------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
2. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Simpsons, The - Bart vs. The Space Mutants (U) [!].gg
262.144	bytes
CRC32: c0009274
MD5: a9dac5c7f2dc324232c3b5a3263b761a
SHA1: c8bbc1ea5b9b60ebcd15efc2dc850e0ffd20dae0

----------------------
3. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --