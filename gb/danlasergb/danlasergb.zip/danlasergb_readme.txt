Dan Laser (Game Boy)
Traducción al Español v1.0 (05/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dan Laser (Sachen) [!].gb
MD5: 1fca063770dda5cdfae166a4dcb3c6c5
SHA1: 54ac969c8c3e36d9a24e7862cd1f81b3f23772f9
CRC32: aabc00f6
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --