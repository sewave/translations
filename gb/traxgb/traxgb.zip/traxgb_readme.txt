Trax (Game Boy)
Traducción al Español v1.0 (05/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Trax (USA, Europe).gb
MD5: 89ecf5b28d5cc84208cfc39dc2d96598
SHA1: 3f3a31ed7e47319c5815dd6e31ca27a52377423c
CRC32: 4a38be7d
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --