Dig Dug II - Trouble in Paradise (NES)
Traducción al Español v1.0 (07/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dig Dug II - Trouble in Paradise (USA).nes
MD5: 7f4d3cea6c410538995e462e11b68871
SHA1: e21a7594cd07b478c4d823eabc367a833f9adb9e
CRC32: 3cc270fb
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --