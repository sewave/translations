Dick Tracy (Mega Drive)
Traducci�n al Espa�ol v1.0 (03/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dick Tracy (W) [c][!].gen
524.288	bytes
MD5: aed96d0a6c77759931d771ef0f6b0778
SHA1: 320e527847ebae79d2686c5a500c5100b080ff98
CRC32: ef887533

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --