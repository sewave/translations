Pocket Bomberman (Game Boy)
Traducción al Español v1.0 (26/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pocket Bomberman (U) [S].gb
MD5: 3050cdf055b1d036f85c9c629b03fbf2
SHA1: 34f377a6de2961fe16bfb854e0cebc7fdba7cf4b
CRC32: 0fd1ae54
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --