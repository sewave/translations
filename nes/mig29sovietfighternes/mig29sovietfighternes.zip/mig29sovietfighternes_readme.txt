MiG 29 - Soviet Fighter (NES)
Traducción al Español v1.0 (19/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
MiG 29 - Soviet Fighter (USA) (Unl).nes
MD5: 7deb323eb6238758755def863a3b990a
SHA1: add2ba1a4a4b6929ca4d0903c88dd32a51a2ed40
CRC32: af33971f
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --