Twin Eagle - Revenge Joe's Brother
Traducci�n al Espa�ol v1.0 (10/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Twin Eagle - Revenge Joe's Brother
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Twin Eagle - Revenge Joe's Brother
-----------------
Shooter para 2 jugadores bastante curioso.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Twin Eagle - Revenge Joe's Brother (U) [!].nes
131.088	bytes
CRC32: fc2f727d
MD5: 7d7b8aeb17fbe8613adde723a55c670b
SHA1: 2ddaeea37625601c626c65ad1bbb3f8502efd751

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --