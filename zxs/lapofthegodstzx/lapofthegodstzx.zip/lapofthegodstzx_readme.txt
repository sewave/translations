Lap Of The Gods (ZX Spectrum)
Traducción al Español v1.0 (15/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lap Of The Gods.tzx
MD5: b6f692722947b4ce89e3a65434bcf130
SHA1: 52bef96b7017174db648af1e0b96e293f8bf835e
CRC32: 40d000c8
30640 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --