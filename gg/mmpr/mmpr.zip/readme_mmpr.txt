Mighty Morphin Power Rangers
Traducci�n al Espa�ol v1.0 (23/10/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Mighty Morphin Power Rangers
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mighty Morphin Power Rangers
-----------------
Beat em up/lucha de los power rangers, muy buenos graficos.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mighty Morphin Power Rangers (U) [!].gg
524.288	bytes
CRC32: 9289dfcc
MD5: 7fcb774aa2b207cf16d2ddfe618351c0
SHA1: 86c4d12257faf355623f47f8fa22da23a3b36cd9

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --