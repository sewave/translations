Arcade Classics (Game Gear)
Traducción al Español v1.0 (02/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Arcade Classics (U) [!].gg
MD5: 647847fe498841762625ae9d604b9018
SHA1: fde19f418f4f13bbe43e6610f411065db9a6f550
CRC32: 3deca813
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --