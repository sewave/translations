Digger T (NES)
Traducción al Español v1.0 (09/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Digger T. Rock - The Legend of the Lost City (Europe).nes
MD5: 3a38b30af2261c29e6b40510bf7caf22
SHA1: b024e568ebfb7314460946990407fcf2225c1996
CRC32: 6660dc87
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --