Town & Country Surf Designs - Thrilla's Surfari (NES)
Traducción al Español v1.0 (22/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Town & Country Surf Designs - Thrilla's Surfari (USA).nes
MD5: e92ed6a8f0c9a4108525bbfd40f1ba79
SHA1: 592c8b6be5816ba771b4fc18ec6a72cfee06d2c7
CRC32: 54c4f37e
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --