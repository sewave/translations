Ariel - The Little Mermaid (Mega Drive)
Traducci�n al Espa�ol v1.0 (24/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ariel - The Little Mermaid (UE) [!].gen
MD5: 4916ade6b213b1f56864239db56fef0d
SHA1: 201105569535b7c8f11bd97b93cbee884c7845c4
CRC32: 58e297df
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --