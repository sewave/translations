Chuck II - Son of Chuck (Mega Drive)
Traducci�n al Espa�ol v1.0 (06/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chuck II - Son of Chuck (U) [!].gen
MD5: a9e607aed6b743ee42f9f9d25a49c881
SHA1: f5dc902a3d722842a4fb536644102de600e7dca3
CRC32: 408b1cdb
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --