Biker Mice from Mars (Super Nintendo)
Traducción al Español v1.1 (07/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglada introducción de personajes.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Biker Mice from Mars (USA).sfc
MD5: a1f47d45a9e5f93b3f10057d1d0e1469
SHA1: 3ea3d8b7cf36eba21a9b180a80b645ee0e221bc0
CRC32: 4e8b2ecb
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --