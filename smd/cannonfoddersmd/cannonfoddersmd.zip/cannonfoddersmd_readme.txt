Cannon Fodder (Mega Drive)
Traducci�n al Espa�ol v1.0 (08/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cannon Fodder (E) [!].bin
MD5: 8ae4b83a356da236f587e688955c23ab
SHA1: ced5f0967e30c3b4c4c2a81007a7db2910b1885d
CRC32: ad217654
1.572.864 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --