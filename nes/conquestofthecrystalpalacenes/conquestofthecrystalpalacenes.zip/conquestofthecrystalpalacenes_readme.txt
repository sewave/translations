Conquest of the Crystal Palace (NES)
Traducción al Español v1.1 (02/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:
-Revisión script
-Traducido título
-Traducidos créditos
-Traducido inicio de etapa y final

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Conquest of the Crystal Palace (USA).nes
MD5: edb710ff29cafdc131a6c26c952829d2
SHA1: 9369adbb9bdc25861877285773d14c747e48c500
CRC32: 0a362909
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --