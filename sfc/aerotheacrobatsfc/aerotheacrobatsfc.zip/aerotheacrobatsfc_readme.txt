Aero the Acro-Bat (Super Nintendo)
Traducci�n al Espa�ol v1.0 (09/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Aero the Acro-Bat (U) [!].smc
MD5: 055fb50b90ea0ef5946cbc191f3d2900
SHA1: 4d7dc1c4dc0c0756412a83eb5e5c1ac104c67831
CRC32: 919f23cb
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --