Spindizzy Worlds (Super Nintendo)
Traducción al Español v1.1 (30/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Corregida demo.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spindizzy Worlds (USA).sfc
MD5: 4c0fce9368b807e09df98f5bbbc047ce
SHA1: 58b4de4903156b24abb253b166082dd0d7212e22
CRC32: 52b68163
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --