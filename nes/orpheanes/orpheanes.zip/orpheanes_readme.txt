Orphea (NES)
Traducción al Español v1.0 (19/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
orphea.nes
MD5: 687b5d6352fc5c725e2010083c7c949f
SHA1: df16c556cfa478abf52d48eca94f47619411532a
CRC32: ff6290b7
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --