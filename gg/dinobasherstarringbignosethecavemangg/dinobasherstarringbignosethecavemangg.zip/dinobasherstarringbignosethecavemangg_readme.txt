Dinobasher - Starring Bignose the Caveman (Game Gear)
Traducción al Español v1.0 (31/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dinobasher - Starring Bignose the Caveman [Proto].gg
MD5: 7b03e5e3d8b5ccf8edbfa5bc1366b2c7
SHA1: 46d1689c09705341f593a18d4e9cfd7805ecff88
CRC32: 2306aaf4
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --