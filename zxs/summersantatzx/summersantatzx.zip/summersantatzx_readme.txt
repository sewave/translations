Summer Santa (ZX Spectrum)
Traducción al Español v1.0 (15/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Summer Santa.tzx
MD5: 944025cc262b8fe69a97ab197b0872f4
SHA1: b87c366953fd435ecb8a1c6c25025dc90f296dca
CRC32: 60887f39
46732 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --