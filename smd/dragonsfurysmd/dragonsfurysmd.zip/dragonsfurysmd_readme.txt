Dragon's Fury (Mega Drive)
Traducción al Español v1.1 (05/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:Arreglados algunos términos de las opciones.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon's Fury (UE) [!].bin
MD5: 5fabe199a9dbc28df33598944140e1db
SHA1: bcbafa6c4ab0b16ddb4f316a1ef8c0eecd0cd990
CRC32: 58037bc6
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --