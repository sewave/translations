Rock n' Roll Racing (Mega Drive)
Traducción al Español v1.0 (20/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rock n' Roll Racing (USA).md
MD5: 530c58317b5626fa15b77adab0aacc9d
SHA1: 9793572b6d64c85c1add0721c3be388ac18777d6
CRC32: 6abab577
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --