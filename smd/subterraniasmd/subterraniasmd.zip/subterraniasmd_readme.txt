Sub-Terrania (Mega Drive)
Traducción al Español v1.0 (04/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sub-Terrania (USA).md
MD5: d3bd3dc31b1903148c0ce92a98a6869a
SHA1: 70a5d4da311dd8a92492d01676bf9170fa4bd095
CRC32: dc3c6c45
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --