Asteroids (Game Boy Color)
Traducción al Español v1.0 (19/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Asteroids (USA, Europe).gbc
MD5: cfac8209d5119235f678303dfb3cc0f2
SHA1: 026f031e1bb787a4390e7873227dcb52a069a6e0
CRC32: 89d5d936
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --