The Tick (Super Nintendo)
Traducción al Español v1.0 (22/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tick, The (U) [!].smc
MD5: e2d1f8e997e1091a4465ba8a76d4357e
SHA1: 82cadb38f20e8610bd8c0c1763fdfa56528b8310
CRC32: 12ab22a7
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --