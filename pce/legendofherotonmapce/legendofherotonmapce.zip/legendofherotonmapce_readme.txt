Legend of Hero Tonma (PC Engine)
Traducción al Español v1.0 (05/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Legend of Hero Tonma (USA).pce
MD5: cfaa094419809446cabfe739995e22ee
SHA1: a87586ae18bd36f1c32e08b8b7a55afc6532fb3e
CRC32: 3c131486
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --