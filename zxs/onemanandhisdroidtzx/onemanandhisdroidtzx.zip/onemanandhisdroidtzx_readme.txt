One Man And His Droid (ZX Spectrum)
Traducción al Español v1.0 (01/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
One Man And His Droid.tzx
MD5: 72ddc8ffaf4d1db4bc15883f680ed721
SHA1: 1e2e074568da00cf2b604109592a604f0e355634
CRC32: 30a7998c
24896 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --