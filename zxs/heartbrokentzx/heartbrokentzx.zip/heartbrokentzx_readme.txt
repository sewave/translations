Heartbroken (ZX Spectrum)
Traducción al Español v1.0 (21/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Heartbroken.tzx
MD5: dc9efc4df1be24cfd5f9253cf30440ad
SHA1: 089b448cd605d1fc2aa67e0181c17afaf22c330c
CRC32: 75f20279
54896 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --