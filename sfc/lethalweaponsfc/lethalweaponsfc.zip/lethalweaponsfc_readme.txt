Lethal Weapon (Super Nintendo)
Traducción al Español v1.0 (15/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lethal Weapon (U) [!].smc
MD5: 29a70ecf317ede4ec1c19365a76e8201
SHA1: c02e8042a1a637c84d762152f8033e8adc7f0f2e
CRC32: a14c3dbc
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --