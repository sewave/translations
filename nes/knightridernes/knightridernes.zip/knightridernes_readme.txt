Knight Rider (NES)
Traducción al Español v1.0 (05/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Knight Rider (USA).nes
MD5: 303e1ba6ca9fd2e14dec8d399a5e942a
SHA1: c0958d55674c897401c0da15c238e1c03adaf756
CRC32: 604fa3fc
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --