Front Line (NES)
Traducción al Español v1.0 (31/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Front Line (Japan).nes
MD5: ab4e56cd24f931f526a06c22db43f1df
SHA1: 79c5f8d187b8fecc95ce5978f7bc7f6014341ecb
CRC32: 44d123a4
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --