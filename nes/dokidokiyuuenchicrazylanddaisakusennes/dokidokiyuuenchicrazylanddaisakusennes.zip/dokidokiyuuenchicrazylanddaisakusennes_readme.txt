Doki!Doki! Yuuenchi - Crazy Land Daisakusen (NES)
Traducción al Español v1.0 (19/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de pacnsacdave.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Doki!Doki! Yuuenchi - Crazy Land Daisakusen (Japan).nes
MD5: 48ed3f6f210e95fb3721221ba21ab7ad
SHA1: b11adc0a126702e09c7af5bf7df2258920029d97
CRC32: 97c3faa2
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --