Kid Niki - Radical Ninja (NES)
Traducción al Español v1.0 (14/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kid Niki - Radical Ninja (USA) (Rev 1).nes
MD5: 3c51ca8efd53149e5ff362091bf4d896
SHA1: 4676b6160368acf7ebf4f264dcc0d86a3bf08149
CRC32: f8a8124e
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --