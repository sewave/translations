Wave Race (Game Boy)
Traducción al Español v1.0 (09/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wave Race (USA, Europe).gb
MD5: 10fd41703b816fcb2a3d6766574b98f9
SHA1: 87ecdfe518f1707429fdbdc21d12bbfe1ff52252
CRC32: a6595506
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --