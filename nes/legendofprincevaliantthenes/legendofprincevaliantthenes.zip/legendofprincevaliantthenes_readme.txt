The Legend of Prince Valiant (NES)
Traducción al Español v2.0 (05/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
-V2.0:
-Añadidos caracteres especiales a ambas fuentes
-Cambiados gráficos para añadir "TIEMPO"
-Script retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Legend of Prince Valiant, The (Europe).nes
MD5: a3583a98ca40c2472085c8f1b8670529
SHA1: 1586d84972b46844d8665b931e34d155e11f3a02
CRC32: 90cdbb50
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --