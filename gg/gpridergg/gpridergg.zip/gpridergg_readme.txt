GP Rider (Game Gear)
Traducción al Español v1.0 (19/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
GP Rider (USA, Europe).gg
MD5: 6fa101fb69da89a922b1b99f36e515bc
SHA1: 7777f091c8b540d3248fd7c0fb21e742af6f0ede
CRC32: 876e9b72
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --