Supercooked! (Super Nintendo)
Traducción al Español v1.0 (24/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Supercooked! (J) (v1.2).sfc
MD5: 34c8e693445cde7ca1c39e8f7815c55e
SHA1: 015be7d6163e6af9d8666b00cb7e627f78851cd0
CRC32: 06df4264
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --