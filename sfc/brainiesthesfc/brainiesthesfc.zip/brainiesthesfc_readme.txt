The Brainies (Super Nintendo)
Traducción al Español v1.0 (21/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Brainies, The (USA).sfc
MD5: ef8f6f5d9f26f5af70b0892cc4fdea21
SHA1: ba2e624390925f0993b5ccf74072e168fbfe4606
CRC32: 718cb0df
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --