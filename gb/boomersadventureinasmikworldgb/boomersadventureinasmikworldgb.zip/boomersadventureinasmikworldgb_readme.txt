Boomer's Adventure in ASMIK World (Game Boy)
Traducción al Español v1.0 (06/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Boomer's Adventure in ASMIK World (USA).gb
MD5: 3b051df77605172195dcff97c2c935cc
SHA1: 3d8a6fcc644290c9d88fe2918bfa6007ee811de8
CRC32: 105bc1c0
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --