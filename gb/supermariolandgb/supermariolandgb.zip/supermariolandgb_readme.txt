Super Mario Land (Game Boy)
Traducción al Español v2.0 (18/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducido título
-Añadidos ¡, Ó, Ñ, TI
-Traducido BONUS GAME
-Traducido THE END
-Traducido 1UP

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Mario Land (World) (Rev A).gb
MD5: b259feb41811c7e4e1dc200167985c84
SHA1: 418203621b887caa090215d97e3f509b79affd3e
CRC32: 2c27ec70
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --