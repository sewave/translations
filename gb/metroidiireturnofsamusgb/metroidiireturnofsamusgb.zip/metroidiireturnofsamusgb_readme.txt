Metroid II - Return of Samus (Game Boy)
Traducción al Español v1.0 (12/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Metroid II - Return of Samus (World).gb
MD5: 9639948ad274fa15281f549e5f9c4d87
SHA1: 74a2fad86b9a4c013149b1e214bc4600efb1066d
CRC32: dee05370
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --