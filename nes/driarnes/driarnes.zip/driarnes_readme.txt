Driar (NES)
Traducción al Español v1.0 (06/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Driar.nes
MD5: 1276bd89a20f343ac230370acdd8d8a0
SHA1: 882a3686982874112af0d20875e3f7e9496a7392
CRC32: 2c31ce23
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --