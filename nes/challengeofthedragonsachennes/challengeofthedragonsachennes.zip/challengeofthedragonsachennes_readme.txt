Challenge of the Dragon (Sachen) (NES)
Traducción al Español v1.0 (13/07/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Los créditos están traducidos pero en la mayoría de emuladores el juego se
resetea antes de mostrarlos por un bug en el juego original.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Challenge of the Dragon (Asia) (En) (Sachen) (Unl).nes
MD5: 23c269975e2ccfa50e692fa4132bd77e
SHA1: 25d3e6f76e750b8e57d92b3c9c47a2813d7343c5
CRC32: bbc88010
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --