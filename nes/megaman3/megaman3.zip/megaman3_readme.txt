Megaman III
Traducci�n al Espa�ol v1.0 (06/08/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Megaman III
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Megaman III
-----------------
Tercera parte del mega clasico.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Megaman III (U) [!].nes
393.232	bytes
CRC32: 452d8089
MD5: 75b924155cafee335c9ea7a01bfc8efb
SHA1: 53197445e137e47a73fd4876b87e288ed0fed5c6

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --