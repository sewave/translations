Batman Returns (Atari Lynx)
Traducción al Español v1.0 (19/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking contiene el cargador de Harry Dodgson.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batman Returns (USA, Europe).lnx
MD5: 6e9bbff3c7b66d3ec0411ffbe0e41dfd
SHA1: 2e25b17a221d4d9598811fbf84ab0da3016f26e4
CRC32: 277f82c2
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --