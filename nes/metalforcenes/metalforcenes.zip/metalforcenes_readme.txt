Metal Force (NES)
Traducción al Español v1.0 (28/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Metal Force (Korea) (Unl).nes
MD5: 7f8ad0311b51776cffd59812ee77dfdb
SHA1: a83be1e67e9e4d27ca9f6bc55f6fada17535ccb6
CRC32: 7e3ba9fd
524304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --