Top Roller (MSX)
Traducción al Español v1.0 (08/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Top Roller (1984) (Jaleco) (J).rom
MD5: 1b840745ab51d80945bf9f95b49330ce
SHA1: 174437bfb20e2895f0f552602da823ca17b2fe93
CRC32: ca28cbb2
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --