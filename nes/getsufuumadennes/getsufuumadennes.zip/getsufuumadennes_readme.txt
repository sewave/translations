Getsufuu Maden (NES)
Traducci�n al Espa�ol v1.0 (05/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking est� basado en la inglesa de Nebulous Translations
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Getsufuu Maden (J) [!].nes
MD5: a3d90f1ab0a417e1819286c1d05efe7d
SHA1: b802f416d7e535289c4509d1768548ac703e40f1
CRC32: 71ff1e76
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

Contributor	Type of contribution	Listed credit
celcion	Hacking	Hacking, tools (coding)
Miralita	Hacking	Credits scene programming, title screen graphics
TheMajinZenki	Translation	Lead translator
cccmar	Translation	Testing/script editing

-- FIN --