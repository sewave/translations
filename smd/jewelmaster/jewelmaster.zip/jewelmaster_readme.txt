Jewel Master
Traducci�n al Espa�ol v1.0 (22/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Jewel Master
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Jewel Master
-----------------
Curioso plataformas en la que combinas poderes de anillos.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Jewel Master (UE) [!].bin
524.288	bytes
CRC32: cee98813
MD5: 42ec7e0894625345be8021f9d5f5d52f
SHA1: 9a6e4ca71546e798e1c98e78c4ab72aba46374c5

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --