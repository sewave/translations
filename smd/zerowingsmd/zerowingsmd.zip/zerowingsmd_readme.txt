Zero Wing (Mega Drive)
Traducción al Español v2.0 (06/04/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres españoles
-Alargadas cadenas
-Guion adaptado

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zero Wing (Europe).md
MD5: 5f4f2fb8c7b8c50efbc6eed57ce3dae3
SHA1: 98335b97c5e21f7f8c5436427621836660b91075
CRC32: 89b744a3
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --