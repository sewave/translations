Back to the Future Part II (Master System)
Traducci�n al Espa�ol v1.0 (27/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Back to the Future Part II (UE) [!].sms
262.144	bytes
MD5: f2535df9bdc3a84221303fa62d61ad6e
SHA1: 31af58e655e12728b01e7da64b46934979b82ecf
CRC32: e5ff50d8

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --