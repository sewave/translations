Super Space Invaders (Master System)
Traducci�n al Espa�ol v1.0 (06/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Space Invaders (E) [!].sms
MD5: f36e9758390ed2b781e9a8a7a958e7e3
SHA1: b28d2a9c0fe597892e21fb2611798765f5435885
CRC32: 1d6244ee
262144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --