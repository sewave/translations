The Jetsons (Game Boy)
Traducci�n al Espa�ol v1.0 (24/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jetsons, The (U).gb
131.072 bytes
MD5: 70cd582d3b1f15cb251620203d8b00c9
SHA1: 1790c7462907f803e9641a330df6f06aa5e4e985
CRC32: 6386c870

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --