After Burner II (PC Engine)
Traducci�n al Espa�ol v1.0 (11/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
After Burner II (J).pce
MD5: ac0cdee014e725e428fde5774751ff8d
SHA1: 50b9d22fe5179aee5cb95022472714ef8483841f
CRC32: ca72a828
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --