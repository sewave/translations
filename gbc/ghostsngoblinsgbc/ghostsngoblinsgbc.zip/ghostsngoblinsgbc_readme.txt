Ghosts 'N Goblins
Traducci�n al Espa�ol v1.0 (16/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Ghosts 'N Goblins
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Ghosts 'N Goblins
-----------------
Port del cl�sico de la versi�n de NES para Game Boy Color.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Ghosts 'N Goblins (U) [C][!].gbc
1.048.576 bytes
CRC32: ae024c23
MD5: 9b846e9a4eb6b80cdbc8e6c82f2b9e9e
SHA1: af9e69fc65fbe0d4fabe145472c1340e9f541a7b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --