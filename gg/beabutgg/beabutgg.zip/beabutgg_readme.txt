Beavis and Butt-head
Traducci�n al Espa�ol v1.0 (02/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Beavis and Butt-head
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Beavis and Butt-head
-----------------
Juego de plataformas de los famosos personajes de la MTV.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Beavis and Butt-head (U) [!].gg
524.288	bytes
CRC32: a6bf865e
MD5: 116ea358051e46f4829bad566e14b28b
SHA1: dd2ea76c05d933b91f1b03140f6a04bf02f746d1

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --