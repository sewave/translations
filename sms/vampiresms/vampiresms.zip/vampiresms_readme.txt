Vampire (Master System)
Traducci�n al Espa�ol v1.2 (16/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
v1.2: Corregida pantalla de CONTINUAR.
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Vampire (E) [!].sms
262.144	bytes
CRC32: 20f40cae
MD5: 6ccf82ff6296fa9365b919de424dd3d9
SHA1: d03fb8fb31d6c49ce92e0a4c952768896f798dd5

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --