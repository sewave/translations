Podder (ZX Spectrum)
Traducción al Español v1.0 (20/01/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Podder.tzx
MD5: b8513968d3d4d4aaac887d69dbc0dfd4
SHA1: 84a72039a3724af175bed136cf7fcd618454dbe9
CRC32: 08e2fa88
39518 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --