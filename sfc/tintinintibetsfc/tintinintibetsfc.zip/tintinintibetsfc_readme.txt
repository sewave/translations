Tintin in Tibet (Super Nintendo)
Traducción al Español v1.0 (09/03/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tintin in Tibet (Europe) (En,Fr,De,Nl).sfc
MD5: 5d6716d6793e9f9c456265d18cf763bc
SHA1: f93338abc37fcf77e68c4c8c1cbab9efca32b5b4
CRC32: f1dce2b7
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --