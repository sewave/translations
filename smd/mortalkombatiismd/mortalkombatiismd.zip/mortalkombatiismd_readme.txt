Mortal Kombat II (Mega Drive)
Traducción al Español v1.0 (04/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mortal Kombat II (World).md
MD5: c8e887ca9cdde7bde85f324f66d34b2d
SHA1: af6d2db16f2b76940ff5a9738f1e00c4e7ea485e
CRC32: a9e013d8
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --