Daze Before Christmas
Traducci�n al Espa�ol v1.0 (29/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Daze Before Christmas
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Daze Before Christmas
-----------------
Plataformas sobre papa noel y las navidades.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
El texto del final del juego en realidad es una imagen, as� que no est� traducido.
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Daze Before Christmas (E).smc
2.097.152 bytes
CRC32: 59909eb5
MD5: e1e3ce8a9d1b9ccaf059101add37314f
SHA1: 5e63cc5c05add8f1493485b5ce488f91e43a2553

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
juandex - Testing

-- END OF README --