Star Hawk (Game Boy)
Traducción al Español v1.1 (02/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Arreglado continuar

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Star Hawk (U) [!].gb
MD5: c284b8a9019020336c89b680fb6552e4
SHA1: 4c22e06cb98119923126f6500568ce9f136a33c5
CRC32: e032e502
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --