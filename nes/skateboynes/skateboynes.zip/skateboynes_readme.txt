Skate Boy (NES)
Traducción al Español v1.0 (03/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Skate Boy (Spain) (Gluk Video) (Unl).nes
MD5: 80e9890d8202ef6955769be81027f5e4
SHA1: 433b17ce54ddb7db926bd7b225def5367481d692
CRC32: 8ba3deff
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --