Bugs Bunny - Rabbit Rampage (Super Nintendo)
Traducción al Español v1.0 (09/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bugs Bunny - Rabbit Rampage (USA).sfc
MD5: 8c78204ddbc95caba8aa7ad0e81eb654
SHA1: 2e6d9f60dc50ef86f4f01c8825f01ffa0273b44f
CRC32: 832c0cb6
1572864 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --