Teenage Mutant Ninja Turtles III - Radical Rescue
Traducci�n al Espa�ol v1.0 (04/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Teenage Mutant Ninja Turtles III - Radical Rescue
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Teenage Mutant Ninja Turtles III - Radical Rescue
-----------------
Metroidvania con las tortugas ninja.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles III - Radical Rescue (U) [!].gb
131.072	bytes
CRC32: 58832bbc
MD5: e6104df1feb1318ff1764c791eb4ce0e
SHA1: 29f5de9e4c0f21bf8bffc721dacf1790446a5923

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --