Ki no Bouken - The Quest of Ki (NES)
Traducción al Español v1.0 (13/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking están basados en el de Zynk Oxhyde.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ki no Bouken - The Quest of Ki (Japan).nes
MD5: e9e7fe5152a94c92c71ddae23dab7605
SHA1: 8a5f3d42a90c39b6110f89b18937d2cb369fcd98
CRC32: a5e74941
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --