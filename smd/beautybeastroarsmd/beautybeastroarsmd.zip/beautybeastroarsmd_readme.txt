Beauty and the Beast - Roar of the Beast
Traducci�n al Espa�ol v1.0 (30/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Beauty and the Beast - Roar of the Beast
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Beauty and the Beast - Roar of the Beast
-----------------
Adaptaci�n de la pelicula para megadrive desde la perpectiva de bestia.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Beauty and the Beast - Roar of the Beast (U) [!].bin
1.048.576 bytes
CRC32: 13e7b519
MD5: a1ad9ddac033d6ea7d6ff1fe34aff627
SHA1: e98c7b232e213a71f79563cf0617caf0b3699cbf

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --