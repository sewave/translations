Tom & Jerry (NES)
Traducci�n al Espa�ol v1.0 (20/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tom & Jerry (U) [!].nes
262.160	bytes
MD5: c3670aa0b77a26279438944be48c3daa
SHA1: d6ebfe209995e8db14e82df952e8c5b10b025460
CRC32: fca83867

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --