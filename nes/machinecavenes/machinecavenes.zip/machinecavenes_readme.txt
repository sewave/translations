Machine Cave (NES)
Traducción al Español v1.0 (19/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Machine Cave(1.19).nes
MD5: 490c25ce0c647e92c0199c4a7e3acde5
SHA1: 825e3862aae9251624795b61c1e05bdb70b75625
CRC32: 2d904baf
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --