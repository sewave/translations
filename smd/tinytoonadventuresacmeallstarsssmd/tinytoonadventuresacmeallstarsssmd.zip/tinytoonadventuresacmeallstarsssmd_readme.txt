Tiny Toon Adventures - Acme All-Stars (Mega Drive)
Traducci�n al Espa�ol v1.1 (30/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1.: Arreglado modo f�cil.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tiny Toon Adventures - Acme All-Stars (U) [!].gen
MD5: 1def1d7dbe4ab6b9e1fc90093292de6a
SHA1: d64736a69fca430fc6a84a60335add0c765feb71
CRC32: 2f9faa1d
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --