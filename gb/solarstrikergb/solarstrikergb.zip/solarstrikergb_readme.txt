SolarStriker (Game Boy)
Traducción al Español v1.0 (03/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
SolarStriker (W) [!].gb
MD5: 83bed4ebefeece45748258fd2ef105b3
SHA1: a8d6acb026b0d0a8a2bcaea094951e915a3deb80
CRC32: 11817103
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --