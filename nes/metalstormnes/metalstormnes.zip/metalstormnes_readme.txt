Metal Storm (NES)
Traducción al Español v1.0 (22/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Metal Storm (U) [!].nes
MD5: 53a2866007c3fc346b1fc047cd415ccc
SHA1: f569f70dbbee96a348e053a958120f64f05b7d04
CRC32: 98cefa51
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --