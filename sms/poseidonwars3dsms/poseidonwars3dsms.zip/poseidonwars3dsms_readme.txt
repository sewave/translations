Poseidon Wars 3-D (Master System)
Traducción al Español v1.0 (05/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Poseidon Wars 3-D (USA, Europe, Brazil).sms
MD5: 3586416ac6f2aa1fa7dea351afb8ac1c
SHA1: c177effd5fd18a082393a2b4167c49bcc5db1f64
CRC32: abd48ad2
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --