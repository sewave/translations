Arena - Maze of Death (Game Gear)
Traducción al Español v1.0 (20/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Arena - Maze of Death (U) [!].gg
MD5: ce3e5094025b10c3885ff1da53a46d2f
SHA1: 91e411d979789f2e31dcfe94fb7f757815f60680
CRC32: 7cb3facf
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --