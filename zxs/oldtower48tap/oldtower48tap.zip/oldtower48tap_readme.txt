Old Tower 48K (ZX Spectrum)
Traducción al Español v1.0 (27/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
OldTower48.tap
MD5: ceece2a1e549c4e3abda213558b9c4b8
SHA1: 9e959725a6dc4f44d69c055520209c52763bd528
CRC32: 7152b0c9
48065 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --