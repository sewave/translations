Popeye 2 (Game Boy)
Traducción al Español v1.0 (15/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Popeye 2 (USA).gb
MD5: 30b579d82ae755bd37c1d4157a96129c
SHA1: dd673ee4dd847a3a217f5f5b6e76ff4d418f2d41
CRC32: 729c2e40
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --