Justice League Task Force (Mega Drive)
Traducción al Español v1.0 (15/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Justice League Task Force (W) [!].bin
MD5: 055d4c70f124963fcedc2eec47a28e38
SHA1: 1be166689726b98fc5924028e736fc8007f958ef
CRC32: 2a60ebe9
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --