Portal Runner (Game Boy Color)
Traducción al Español v1.0 (15/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Portal Runner (USA).gbc
MD5: 8765ee1fe94c16e934ea0d004291e8b0
SHA1: a8347366f15c0e454fa253bad5b4053d2a9613aa
CRC32: 913ac306
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --