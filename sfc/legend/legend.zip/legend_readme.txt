Legend
Traducci�n al Espa�ol v1.0 (15/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Legend
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Legend
-----------------
Beat em up medieval/fant�stico.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Legend (U) (718).smc
1.048.576 bytes
CRC32: 0a6dd870
MD5: 0c684458019a60b0e16acb408f1418ea
SHA1: 8d5595de49178294914d36ffc2b38f078cbd20a0

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --