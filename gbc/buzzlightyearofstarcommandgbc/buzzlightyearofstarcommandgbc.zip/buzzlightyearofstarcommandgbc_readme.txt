Buzz Lightyear of Star Command (Game Boy Color)
Traducción al Español v1.0 (11/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Buzz Lightyear of Star Command (USA, Europe).gbc
MD5: 560e27a4d80b88280d8ad7358467c301
SHA1: 314dacd9a5d60769105f2cde60a245074cb51c15
CRC32: 84e29b87
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --