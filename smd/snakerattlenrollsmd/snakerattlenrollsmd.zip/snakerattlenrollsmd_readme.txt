Snake Rattle 'n' Roll (Mega Drive)
Traducción al Español v1.1 (09/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Arreglado continuar y nombre de pantalla.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Snake Rattle 'n' Roll (E) [c][!].bin
MD5: 07c019dd98033e0402309f1f484f217c
SHA1: 0773ae487319b68695e9a6c3dcd0223695c02609
CRC32: 543bed30
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --