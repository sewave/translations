The Incredible Crash Dummies (Game Boy)
Traducción al Español v1.0 (16/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Incredible Crash Dummies, The (USA, Europe).gb
MD5: c21058af21efc29413797f0a2c532e16
SHA1: f62d369b576cfd2882f8e03a5a32238eb1599477
CRC32: d81c08fa
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --