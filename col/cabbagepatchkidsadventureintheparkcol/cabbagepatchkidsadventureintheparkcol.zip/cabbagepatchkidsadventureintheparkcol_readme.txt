Cabbage Patch Kids - Adventure in the Park (Colecovision)
Traducción al Español v1.0 (07/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cabbage Patch Kids - Adventure in the Park (1983).col
MD5: ade704f01e694fb539bd805d9e276c99
SHA1: 6dcf2f3acc4b221666defc6ebbc09286238e7a1b
CRC32: beacbff5
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --