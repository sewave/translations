Spider-Man
Traducci�n al Espa�ol v1.0 (16/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Spider-Man
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Spider-Man
-----------------
Primer plataformas de Spider-Man para Game Boy Color.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Spider-Man (U) [C][!].gbc
1.048.576 bytes
CRC32: 34e2b3ba
MD5: 9fde547bcb70b108895e259da4c4e100
SHA1: ea432c3f2b0d92b4cf03d762e273abc68f45f072

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
juandex - Testing

-- END OF README --