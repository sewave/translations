Pieces (Super Nintendo)
Traducción al Español v1.0 (13/07/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Menús y gráficos sin modificar.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pieces (USA).sfc
MD5: f0da10d1a7311ffdf1270dfb38ca3dbb
SHA1: 11141f46259fac85640ea17f1c1cc6279bf196d2
CRC32: bb6c3c54
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --