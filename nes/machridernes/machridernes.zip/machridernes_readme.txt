Mach Rider (NES)
Traducci�n al Espa�ol v1.0 (16/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mach Rider (JU) (PRG0) [!].nes
MD5: 3437293b6b88e5804fb49328bded4ad8
SHA1: a202684e317adacd50db0e6cb6902ecd4334fc06
CRC32: bee56098
40.976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --