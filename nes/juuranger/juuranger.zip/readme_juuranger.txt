Kyouryuu Sentai Juuranger
Traducci�n al Espa�ol v1.0 (31/12/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Kyouryuu Sentai Juuranger
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Kyouryuu Sentai Juuranger
-----------------
Un juego de plataformas basado en la serie "precuela" de los power rangers, bien ejecutado aunque bastante corto.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es basado en la traduccion de Dank-Trans.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Kyouryuu Sentai Juuranger (J).nes
262.160	bytes
CRC32: 7bf82c80
MD5: 8a626d6dd5555f1a53543e929b96fbc0
SHA1: 2c76856d6d2184140b2abb61f9efb127a5d706ee

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Original:
Contributor	Type of contribution	Listed credit
Eien Ni Hen	Original Translation	Translation.
RedComet	Original Hacking	    Line hack.
danke	    Original Work	        Original translation, editing, preliminary hacking, graphics editing.

-- END OF README --