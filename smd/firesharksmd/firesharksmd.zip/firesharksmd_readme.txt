Fire Shark (Mega Drive)
Traducci�n al Espa�ol v1.0 (03/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fire Shark (U) [!].bin
MD5: c00981929f3eca882d123809e81185df
SHA1: 020169eb2a4b3ad63fa2cbaa1927ab7c33b6add4
CRC32: 9c175146
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --