Penguin Land (Master System)
Traducci�n al Espa�ol v1.0 (09/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Penguin Land (UE) [!].sms
MD5: 8ddec589f72cdcf2cd4caafb075ec8e4
SHA1: 8762239c339a084dfb8443cc38515301476bde28
CRC32: f97e9875
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --