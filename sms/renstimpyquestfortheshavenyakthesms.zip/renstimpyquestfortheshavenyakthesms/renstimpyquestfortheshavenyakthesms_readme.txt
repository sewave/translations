Ren & Stimpy - Quest for the Shaven Yak, The (Master System)
Traducci�n al Espa�ol v1.0 (28/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ren & Stimpy - Quest for the Shaven Yak, The (B) [!].sms
MD5: 58b89d62438407f242bbe713f1d945ca
SHA1: 418ea57fdbd06aca4285447db2ecb2b0392a178d
CRC32: f42e145c
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --