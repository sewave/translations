The California Raisins - The Grape Escape (NES)
Traducción al Español v1.0 (24/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
California Raisins, The - The Grape Escape (U) (Prototype).nes
MD5: 1766757fe5915c2b1f086045762b6ac8
SHA1: 6bfc9e046ddc1be1f8b4b1e5372b4eabe04e3b87
CRC32: c100bea8
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --