Hook
Traducci�n al Espa�ol v1.0 (27/04/2017)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Hook
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Hook
-----------------
Adaptaci�n de la pel�cula.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
La pantalla de continuaci�n no est� traducida.
La frase inicial de la pantalla de objetos tampoco.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Hook (U).gb
131.072	bytes
CRC32: 6765b61b
MD5: c4e2de3be0bb5608ab903a885afc065d
SHA1: 570d7cc03e80e199e856160912431c21a6ca0f6c

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --