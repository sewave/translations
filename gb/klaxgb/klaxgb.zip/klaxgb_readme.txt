Klax (Game Boy)
Traducción al Español v1.0 (24/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Klax (USA).gb
MD5: 7d4f3bf92bbff701583eb74f36951bb9
SHA1: 85f6b02815e7131fdd96f3802eb0a17d93277e75
CRC32: 72660774
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --