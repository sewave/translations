Worms (Super Nintendo)
Traducción al Español v1.0 (17/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Worms (E).smc
MD5: 4d38bfc8893cdd7df999f118f6e56707
SHA1: 923e12fc1c59336c28be6bf5b677effb3b8faff9
CRC32: 90d0fac0
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --