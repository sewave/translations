Cross Fire (NES)
Traducción al Español v1.0 (28/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cross Fire (Japan).nes
MD5: f02dd5ec384a53edabdd2e61cf49b352
SHA1: 1ad7ab4cd12c28d2271f369537fdcb207c99321a
CRC32: c3c75c6e
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --