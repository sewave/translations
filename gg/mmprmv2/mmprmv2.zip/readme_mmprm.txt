Mighty Morphin Power Rangers - The Movie
Traducci�n al Espa�ol v1.1 (26/10/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Mighty Morphin Power Rangers - The Movie
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mighty Morphin Power Rangers - The Movie
-----------------
Segunda parte de los power rangers, beat em up/lucha, con mas detalles graficos pero menos historia.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
1.01 retoques de traduccion.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mighty Morphin Power Rangers - The Movie (U) [!].gg
524.288	bytes
CRC32: b47c19e5
MD5: f9acd8f01caa8d11150a53b37b435aa2
SHA1: dfe7dc7b2df143da4f4eeb32051a6d373dddba5d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --