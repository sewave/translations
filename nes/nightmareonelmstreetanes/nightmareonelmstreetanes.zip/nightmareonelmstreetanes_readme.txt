A Nightmare on Elm Street (NES)
Traducción al Español v1.0 (12/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nightmare on Elm Street, A (USA).nes
MD5: 2a13dab59e7545d39117439e738e48ba
SHA1: b2d2e8a85dcec7a4b7a9a6a24f59be3103f7d49c
CRC32: 2a83ddc5
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --