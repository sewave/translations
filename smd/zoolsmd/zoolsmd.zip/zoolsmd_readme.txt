Zool (Mega Drive)
Traducci�n al Espa�ol v1.0 (21/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zool (U) [!].gen
MD5: 2d28ddb5be02a3b3612ba73ca064edb5
SHA1: ee016f127b81f1ca25657e8fa47fac0c4ed15c97
CRC32: cb2939f1
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --