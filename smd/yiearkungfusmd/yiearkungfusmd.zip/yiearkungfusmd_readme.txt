Yie Ar Kung-Fu (Mega Drive)
Traducción al Español v1.0 (01/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Yie Ar Kung-Fu (PD) [!].gen
MD5: bb3ac114085882894a7ddd7f48301b48
SHA1: 568bdde7423ede74a505afac24751c4be365e25a
CRC32: a872dba3
206252 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --