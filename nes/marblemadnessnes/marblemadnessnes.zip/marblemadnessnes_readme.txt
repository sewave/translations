Marble Madness (NES)
Traducci�n al Espa�ol v1.0 (03/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Marble Madness (U) [!].nes
MD5: 37f843468277efc2c191d98e8ecb5b7f
SHA1: db009866ecf20cfdce93dca861f5be1f9dfaaf2b
CRC32: f9282f28
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --