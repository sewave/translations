Tomb Raider - Curse of the Sword (Game Boy Color)
Traducción al Español v1.0 (29/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tomb Raider - Curse of the Sword (U) [C][!].gbc
MD5: a0b4538f687fc61bc88f7ee111170355
SHA1: c84db1eaf7403ba292be020d410ab453342ab737
CRC32: 02c1035a
4194304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --