Buffalo Bill's Wild West Show (ZX Spectrum)
Traducción al Español v1.0 (21/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Buffalo Bill's Wild West Show (System 4).dsk
MD5: f37f30a020a5d6c9c75bcab293a4bbcc
SHA1: 6bb33ab8dfdc7b7c0081e6eb49abd68df760358a
CRC32: 98087bfb
194816 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --