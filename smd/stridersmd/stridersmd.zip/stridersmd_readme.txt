Strider (Mega Drive)
Traducción al Español v2.0 (08/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducida barra de estado y "PRESS START BUTTON"
-Traducido título
-Añadidos caracteres especiales
-Alargadas cadenas y guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Strider (USA, Europe).md
MD5: fcab622a6e56f7e9b1e0907ab5a630df
SHA1: 26fe42d13a01c8789bbad722ebac05b8a829eb37
CRC32: b9d099a4
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --