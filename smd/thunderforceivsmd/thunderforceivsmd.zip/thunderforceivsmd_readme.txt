Thunder Force IV
Traducci�n al Espa�ol v1.1 (09/01/2018)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Thunder Force IV
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Thunder Force IV
-----------------
Versi�n europea del gran shoot em up.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
v1.1: Arreglada frase final

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Thunder Force IV (E) [c][!].bin
1.048.576 bytes
CRC32: e7e3c05b
MD5: 66cac77bb663a6951c942b0722232a03
SHA1: ecbc2bfc4f3d8bbd46b398274ed2f5cc3db68454

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --