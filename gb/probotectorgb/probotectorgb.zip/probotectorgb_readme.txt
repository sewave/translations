Probotector (Game Boy)
Traducción al Español v1.0 (25/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Probotector (Europe).gb
MD5: 298c80fe568bb2ff8bb7e4dfe5862a9d
SHA1: 45482a44ce0cdfa33fc58a8a8afe2d7284dfa498
CRC32: c9acc4f4
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --