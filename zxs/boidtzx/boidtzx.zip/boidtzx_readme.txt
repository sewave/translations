Boid (ZX Spectrum)
Traducción al Español v1.0 (23/03/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Boid.tzx
MD5: 2b70a17bc101db512a8774dabe22800a
SHA1: 48ca469b8d4afde58637af0236391b9221e55fe6
CRC32: bcaea752
48033 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --