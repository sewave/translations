Marauder (ZX Spectrum)
Traducción al Español v1.0 (10/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Marauder.tzx
MD5: a4574b657b9ac81f90f67a46f1eb9e9b
SHA1: 6d1c24bd2674b6ac380d54c2f51788f8cb41728d
CRC32: 1d4fa119
54197 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --