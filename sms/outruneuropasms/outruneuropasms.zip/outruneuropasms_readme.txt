OutRun Europa (Master System)
Traducci�n al Espa�ol v1.0 (18/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
OutRun Europa (E) [!].sms
MD5: 458fc29765865fdaaf3f56808c94d8a6
SHA1: c8fbf18eabdcf90cd70fc77444cf309ff47f5827
CRC32: 3932adbc
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --