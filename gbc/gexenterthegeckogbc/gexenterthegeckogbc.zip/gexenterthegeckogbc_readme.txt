Gex - Enter the Gecko (Game Boy Color)
Traducción al Español v1.0 (31/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gex - Enter the Gecko (USA, Europe).gbc
MD5: f0462eba75d879c40668e20d1dbdb612
SHA1: a05a530b3272634c8d3fedb6fd6eaf8b00b5cf9c
CRC32: dccc7514
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --