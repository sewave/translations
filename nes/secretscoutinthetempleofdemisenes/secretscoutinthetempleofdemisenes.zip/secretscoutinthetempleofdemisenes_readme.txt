Secret Scout in the Temple of Demise (NES)
Traducción al Español v1.1 (03/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:Arreglado primer nivel.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Secret Scout in the Temple of Demise (Color Dreams) [!].nes
MD5: c6ffa868940765f13af71c1bbf8210a0
SHA1: e27a99cd4e242ab292fe409d24c5aadfd41e6305
CRC32: a1848857
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --