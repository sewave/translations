Terminator, The
Traducci�n al Espa�ol v1.0 (24/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Terminator, The
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Terminator, The
-----------------
Adaptacion de la pelicula para mega drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Terminator, The (U) [!].bin
1.048.576 bytes
CRC32: 31a629be
MD5: de0e4f5e3c45a42959defc1de97a79ff
SHA1: 2a1894e7f40b9001961f7bf1c70672351aa525f9

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --