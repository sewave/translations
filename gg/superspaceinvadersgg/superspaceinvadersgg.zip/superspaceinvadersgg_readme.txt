Super Space Invaders (Game Gear)
Traducci�n al Espa�ol v1.0 (06/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Space Invaders (U) [!].gg
MD5: 6367666402c51229d283ac0cf5bf3ffb
SHA1: 3864c399f76e67ae4ff40d32a60c36ad16578988
CRC32: dfe38e24
262144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --