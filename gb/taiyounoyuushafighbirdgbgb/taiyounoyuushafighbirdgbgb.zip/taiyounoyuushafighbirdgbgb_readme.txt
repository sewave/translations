Taiyou no Yuusha - Fighbird GB (Game Boy)
Traducción al Español v1.0 (25/09/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de Zynk Oxhyde.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Taiyou no Yuusha - Fighbird GB (Japan).gb
MD5: 5bd352e85f75a8314e4dce538cb956c6
SHA1: 7a2b9864bf2a93d271694d9bc7eedb55f0f15fad
CRC32: 723eb882
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --