Super Troll Islands (Super Nintendo)
Traducción al Español v1.0 (31/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Troll Islands (USA).sfc
MD5: c8e1660e62581092da3b2e85c62c7537
SHA1: 64c1d24cd88d11772d033a15d6505909d8aa6aa7
CRC32: f9690be9
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --