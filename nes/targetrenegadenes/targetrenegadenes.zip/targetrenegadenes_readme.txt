Target - Renegade
Traducci�n al Espa�ol v1.0 (21/05/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Target - Renegade
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Target - Renegade
-----------------
Beat em up para la NES.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Target - Renegade (U) [!].nes
262.160	bytes
CRC32: fe07b4ac
MD5: 039caec9b1db8056f954405e11b58b99
SHA1: 6614a12565041b7cf1923ebee3ae5e9715f84040

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --