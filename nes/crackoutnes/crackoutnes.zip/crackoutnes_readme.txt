Crackout (NES)
Traducción al Español v1.0 (10/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Crackout (U) (Prototype).nes
MD5: d308d6484acb235ec4ac9e050ef45850
SHA1: bc05cede199417f4f30758b2181cf60fec3cbdd3
CRC32: bd6ca0d7
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --