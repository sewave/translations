Super Pang (NES)
Traducción al Español v1.0 (01/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Pang (Asia) (Ja) (PAL) (Unl).nes
MD5: 9b8c4cc3538e04a36f09b6db9e35a4c2
SHA1: 366ee3bf00b04e5719245bdb3fda52229db4b772
CRC32: f7c73ecc
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --