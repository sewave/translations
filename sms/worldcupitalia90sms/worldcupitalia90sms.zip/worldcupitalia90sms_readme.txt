World Cup Italia '90 (Master System)
Traducción al Español v1.0 (12/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
World Cup Italia '90 (EB) [!].sms
MD5: a19d4a16be24106cd48b283b5bad5023
SHA1: dfa51a4f982d0bec61532e16a679edae605d0aea
CRC32: 6e1ad6fd
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --