Ninja Taro (Game Boy)
Traducción al Español v1.0 (11/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Taro (U) [!].gb
MD5: 1a52fb8f767e24dc75c3bb2d08679f6c
SHA1: bd472ed88042e032a57041eb0a889da6aa3d1598
CRC32: c53ebfbd
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --