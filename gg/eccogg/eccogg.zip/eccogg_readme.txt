Ecco the Dolphin (Game Gear)
Traducci�n al Espa�ol v1.0 (28/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ecco the Dolphin (U) [!].gg
MD5: ccd970b22303887734fafb8e45b1e43f
SHA1: 7c6c8f44d5aa799726adc3a9e21c9f35cacea87f
CRC32: 866c7113
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --