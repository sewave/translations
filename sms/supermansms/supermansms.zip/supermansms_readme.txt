Superman
Traducci�n al Espa�ol v1.0 (06/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Superman
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Superman
-----------------
Arcade de superman para la 8 bits sobremesa de Sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Superman (E) [!].sms
262.144	bytes
CRC32: 6f9ac98f
MD5: dc1541e54da2376781e3691784befaa9
SHA1: f12b0eddfc271888bbcb1de3df25072b96b024ec

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --