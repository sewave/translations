Super Return of the Jedi (Game Gear)
Traducción al Español v1.0 (10/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Return of the Jedi (U) [!].gg
MD5: fc8d04e6975267cdc6bd49a0dea33c41
SHA1: a37858100903ad1e0224c870fe12419c25df90e0
CRC32: 4a38b6b6
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --