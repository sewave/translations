AWS Pro Moves Soccer (Mega Drive)
Traducción al Español v1.0 (11/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
AWS Pro Moves Soccer (USA).md
MD5: 3aba3d30118d7ff24f7dc4041247efd6
SHA1: 59b47ce071b38eb740a916c42b256af77e2e7a61
CRC32: 707017e5
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --