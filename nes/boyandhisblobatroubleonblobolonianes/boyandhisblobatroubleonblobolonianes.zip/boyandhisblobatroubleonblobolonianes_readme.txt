Boy and His Blob, A - Trouble on Blobolonia
Traducci�n al Espa�ol v1.0 (18/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Boy and His Blob, A - Trouble on Blobolonia
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Boy and His Blob, A - Trouble on Blobolonia
-----------------
Original puzzle/plataformas donde ayudas a la plasta alien�gena a recuperar su planeta.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Boy and His Blob, A - Trouble on Blobolonia (U) [!].nes
262.160	bytes
CRC32: 20a9e4a2
MD5: 61d431d155b503c378778062bda9cf5d
SHA1: 74e43903d7b7a8d6b17e53f2774a4b2d26a2ea9a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --