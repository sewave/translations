Mary Shelley's Frankenstein (Mega Drive)
Traducción al Español v1.0 (04/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mary Shelley's Frankenstein (USA).md
MD5: 98f3846dc91ffda67929beeaf920f106
SHA1: 2dd34478495a2988fe5839ef7281499f08bf7294
CRC32: 48993dc3
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --