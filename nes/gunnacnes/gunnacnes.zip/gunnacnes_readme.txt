Gun-Nac (USA)
Traducci�n al Espa�ol v1.0 (20/01/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Gun-Nac (USA)
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Gun-Nac (USA)
-----------------
Interesante shoot em up de Compile.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Gun-Nac (U) [!].nes
262.160	bytes
CRC32: fb0ec3b9
MD5: 8998775634d50a48c83cb4d3e67d8420
SHA1: 8138ef3e28c0bdc1dbb8215c80d0fffd0c88379d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --