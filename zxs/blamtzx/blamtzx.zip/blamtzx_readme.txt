BLAM (ZX Spectrum)
Traducción al Español v1.0 (27/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
BLAM.tzx
MD5: 39de3f7ddc36b7d6e0ffb3af61be26b3
SHA1: ce7542e2675e8b5c13d09fe621b42530f08e4097
CRC32: 7d87b6af
41667 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --