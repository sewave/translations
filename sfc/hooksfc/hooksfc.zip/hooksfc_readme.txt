Hook (Super Nintendo)
Traducción al Español v2.0 (27/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Revisión de script
-Añadidos acentos
-Traducida barra de estado
-Traducido texto grande de final, game over y sin tiempo.
-Traducido "PRESS START"

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hook (USA).sfc
MD5: 1a0a3a079db7a848ee019161cbdb1788
SHA1: 24f628d669757b5c92d6c8788dbfcb1d1aeb0481
CRC32: 0c572ef0
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --