Surf Ninjas (Game Gear)
Traducción al Español v1.0 (08/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Surf Ninjas (U) [!].gg
MD5: 63f72877317fd3c17b0d867ea3169f56
SHA1: 23e493f7c19ffb17e67392289c5a72dc9d0d6d9e
CRC32: 284482a8
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --