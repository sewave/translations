Low G Man - The Low Gravity Man
Traducci�n al Espa�ol v1.0 (06/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Low G Man - The Low Gravity Man
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Low G Man - The Low Gravity Man
-----------------
Plataformas de grandes saltos para NES.

---------------------
2. Notas del Proyecto
---------------------
Con parche SRAM http://www.romhacking.net/hacks/2512/.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Low G Man - The Low Gravity Man (U) [!].nes
262.160	bytes
CRC32: b90a1ca1
MD5: 1dcc3f339cc030c9ebdd31744a9e7182
SHA1: a5d317f9565dfefd286bc50e828667c5801b606b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
rainwarrior - SRAM FIX

-- END OF README --