Airwolf (NES)
Traducción al Español v1.0 (29/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Airwolf (U) [!].nes
MD5: d0fa24d5784cca5cb96610a95db37538
SHA1: 377261e0ed050c1f363a778854a463112e02c567
CRC32: f0a5eb24
163856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --