Assault City - Pad Version
Traducci�n al Espa�ol v1.0 (15/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Assault City - Pad Version
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Assault City - Pad Version
-----------------
Shooter en primera persona para pad de Master System.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Assault City - Pad Version (E) [!].sms
262.144	bytes
CRC32: 0bd8da96
MD5: b13632f6e0e0b495aae726aec9ba66d0
SHA1: ea46350ce4827b282b73600a7f4feadbec7c0ed4

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --