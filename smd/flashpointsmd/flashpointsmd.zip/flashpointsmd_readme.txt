Flash Point (Mega Drive)
Traducci�n al Espa�ol v1.0 (19/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Flash Point (J) (Prototype).bin
MD5: 2f8eaa20117c78aec03fd63de3869dec
SHA1: 358e4dc17b4269b34273b7c4ce1d57c0c01ffd4e
CRC32: 0655074d
131072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --