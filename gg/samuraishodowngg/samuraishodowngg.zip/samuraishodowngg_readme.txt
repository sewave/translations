Samurai Shodown (Game Gear)
Traducci�n al Espa�ol v1.0 (31/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Samurai Shodown (U) [!].gg
MD5: 4898db4b63c7024842e748fb81c95a55
SHA1: d7330f5abcadb5c199299b24c22334be0072ec80
CRC32: 98171deb
524288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --