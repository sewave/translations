Choplifter (NES)
Traducción al Español v1.0 (06/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Choplifter (J) [!].nes
MD5: 4766d7224bb4e66c52bd67370a97fd2c
SHA1: aa4ebf1e4dfb6677d548d5e21254b6c74f76fa71
CRC32: 3b629df8
49168 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --