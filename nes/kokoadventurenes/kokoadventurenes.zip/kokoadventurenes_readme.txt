Koko Adventure (NES)
Traducción al Español v1.0 (01/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Koko Adventure (Korea) (Unl).nes
MD5: bed955a2b40dcf3bc20f8109f4c98a7a
SHA1: eabca2169115d2cef06eda6776b88ddc4eaf06a3
CRC32: a86e4d73
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --