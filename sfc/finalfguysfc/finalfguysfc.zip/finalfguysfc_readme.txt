Final Fight Guy
Traducci�n al Espa�ol v1.1 (31/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Final Fight Guy
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Final Fight Guy
-----------------
Adaptaci�n del arcade utilizando a Guy en lugar de a Cody.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1: Traducido "Sometime in the 1990's..."

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Final Fight Guy (U).smc
1.048.576 bytes
CRC32: bc1ae3c2
MD5: 067ad2453b32cb6fe595fc822b780700
SHA1: 67646b258d892d7ecbc660a01d4d19d525971801

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --