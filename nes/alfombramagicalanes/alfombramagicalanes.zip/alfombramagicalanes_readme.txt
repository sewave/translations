La Alfombra Magica (NES)
Traducción al Español v1.0 (30/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alfombra Magica, La (Spain) (Gluk Video) (Unl).nes
MD5: 18ace7cdcc653d611880720d36fdb976
SHA1: 013da3f235d32a7ea840e3ec9221434303708dc1
CRC32: 842f6871
65552 bytes
o
Alfombra Magica, La (Spain) (Rev 1) (Gluk Video) (Unl).nes
MD5: c42ca8ccc6d35b756f53f6953548f07a
SHA1: c7e2c6f29c6ff173747fc7608b2c1e791ae8d690
CRC32: 7f165221
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --