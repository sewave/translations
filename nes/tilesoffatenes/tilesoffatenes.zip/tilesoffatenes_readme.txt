Tiles of Fate (NES)
Traducción al Español v1.0 (28/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tiles of Fate (AVE) [!].nes
MD5: ed0790a939b6497db44f4b9302e8e747
SHA1: fc45759fd741661eb63917b1f253a16a9cc9f1f2
CRC32: fc1a1f57
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --