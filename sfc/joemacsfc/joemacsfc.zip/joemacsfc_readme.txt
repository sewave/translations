Joe & Mac (Super Nintendo)
Traducción al Español v1.0 (26/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Joe & Mac (U) [!].smc
MD5: cc902de2efa54df4d2c27acd7f4a6bf4
SHA1: be48f2193ad088b6ea395caeb2d03fa190480418
CRC32: 3a2b6167
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --