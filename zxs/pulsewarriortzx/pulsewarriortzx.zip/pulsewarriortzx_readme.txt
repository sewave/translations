Pulse Warrior (ZX Spectrum)
Traducción al Español v1.0 (08/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pulse Warrior.tzx
MD5: a861172baa83f4b596b4fda1d7f6d94e
SHA1: 94a78a2be8736a385b6fd006ebd9e498d32b19a6
CRC32: adec0100
41981 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --