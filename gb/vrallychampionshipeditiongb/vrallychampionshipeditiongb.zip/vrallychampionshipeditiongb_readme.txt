V-Rally - Championship Edition (Game Boy)
Traducción al Español v1.0 (26/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
V-Rally - Championship Edition (U) (M3) [M][!].gb
MD5: fb0adff5efe92c9d3a26be9313bcc236
SHA1: 67d2a6e41b6a1d8372808535ac8c8222d7c53480
CRC32: d149652b
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --