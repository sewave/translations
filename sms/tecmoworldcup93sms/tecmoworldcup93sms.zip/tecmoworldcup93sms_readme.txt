Tecmo World Cup '93 (Master System)
Traducci�n al Espa�ol v1.0 (27/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tecmo World Cup '93 (E) [!].sms
MD5: 81f530d169c5c04c8faf8db367bbcd63
SHA1: 43a30da241f57cf086ab9b2ed25fe018171f2908
CRC32: 5a1c3dde
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --