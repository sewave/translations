Heavyweight Champ (Master System)
Traducción al Español v1.0 (01/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Heavyweight Champ (E) [!].sms
MD5: 08431e57a5ecf6cbfb1fdb757d496541
SHA1: 7e2523061df0c08b7df7b446b5504c4eb0fea163
CRC32: fdab876a
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --