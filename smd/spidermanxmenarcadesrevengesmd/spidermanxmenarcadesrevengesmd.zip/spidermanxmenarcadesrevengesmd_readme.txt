Spider-Man X-Men - Arcade's Revenge (Mega Drive)
Traducción al Español v1.0 (18/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Comic intro:
Sobre las calles de la ciudad
Spider-Man: ¡Solo espero no llegar demasiado TARDE!
Spider-Man: Primero Cíclope, luego Tormenta y ahora Lobezno...
Spider-Man: ¡¡Gambito!! ¡CUIDADO!
Spider-Man: Conozco ese CAMIÓN
Spider-Man: ...¡¡ARCADE!! TENGO que ir tras ellos
Spider-Man: ¡Las vidas de los X-MEN dependen de mi!

Comic final:
Lobezno: ¡CORRED! ..¡Todo este sitio va a EXPLOTAR!
Spider-Man: ¿Creéis que salió?
Gambito: Puedes contar con ello.
Cíclope: Venga... ¡Vamos a CASA!

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spider-Man X-Men - Arcade's Revenge (USA, Europe).md
MD5: 16205f67804ec434085121f3c4a81bf5
SHA1: 978dabcc7d098edebc9d3f2fef04f27fd6aeab19
CRC32: 4a4414ea
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --