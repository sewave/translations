Splatterhouse - Wanpaku Graffiti (NES)
Traducción al Español v1.0 (10/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Spinner 8 and friends.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Splatterhouse - Wanpaku Graffiti (Japan).nes
MD5: 4fa13d2e51a3559d710ea3112e023dc7
SHA1: c5e4488c315c45b5a33ce2cd35b88d1ac4ddb061
CRC32: b7eeb48b
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --