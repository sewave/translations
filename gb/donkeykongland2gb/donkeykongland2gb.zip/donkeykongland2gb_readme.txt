Donkey Kong Land 2 (Game Boy)
Traducción al Español v1.0 (22/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Donkey Kong Land 2 (UE) [S][!].gb
MD5: 6e30394fd7ef4a4dc3fe1edd9fc69f72
SHA1: 89cc4f01653a6105ee5c00e10fc65aa1437fd320
CRC32: 2827e5d4
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --