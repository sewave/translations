Firehawk (NES)
Traducción al Español v1.0 (29/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Firehawk (USA) (Unl).nes
MD5: 45b9045a2c1578bc1736e83b9fa9e66e
SHA1: 9d7eeba87d4554e12c3c2e742281b722fc580aac
CRC32: a2259bd3
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --