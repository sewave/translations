Satellite 7 (Master System)
Traducción al Español v1.0 (29/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Satellite 7 (J) [!].sms
MD5: eac6a843975c50e39eb32f764da2a5ac
SHA1: 88fc5596773ea31eda8ae5a8baf6f0ce5c3f7e5e
CRC32: 16249e19
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --