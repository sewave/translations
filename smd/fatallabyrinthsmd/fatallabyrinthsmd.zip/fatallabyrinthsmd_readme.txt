Fatal Labyrinth (Mega Drive)
Traducción al Español v1.1 (03/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado Shuriken

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Fatal Labyrinth (JU) [!].bin
MD5: f4550e6ca0b6c8a9de2376f85bdc6a8a
SHA1: c136cb3fae1914a8fe079eb28c4533af5d8774e2
CRC32: 5f0bd984
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --