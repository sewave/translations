McDonaldland (Game Boy)
Traducción al Español v1.0 (25/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
McDonaldland (U) [!].gb
MD5: dcf79d785d5ce187f727f7dc2e00dc8c
SHA1: fd11d61f961a7e3c69e272ef19eb243b7df89833
CRC32: 81de6c13
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --