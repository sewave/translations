Cutthroat Island (Mega Drive)
Traducción al Español v1.0 (22/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cutthroat Island (UE) [!].bin
MD5: f1e6ec5e3bf9c04670d10fbc89fb549c
SHA1: 1b1648e02bb2e915286c35f01476358a8401608f
CRC32: ebabbc70
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --