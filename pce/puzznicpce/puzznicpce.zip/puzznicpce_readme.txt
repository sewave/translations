Puzznic (PC Engine)
Traducción al Español v1.0 (21/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Puzznic (Japan).pce
MD5: a8cdcc33207037a02868f366de6582ea
SHA1: 3906d644f5901e6d2e732cbd0a6dd0d38a29486b
CRC32: 965c95b3
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --