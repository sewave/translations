Toy Story (NES)
Traducción al Español v1.0 (14/01/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Toy Story (Unl) [hM219].nes
MD5: e99c116cdb5643e9f83ee548179041ae
SHA1: 7c748e5a83fb07905cadc427d1909a04af8c51ec
CRC32: d518d55d
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --