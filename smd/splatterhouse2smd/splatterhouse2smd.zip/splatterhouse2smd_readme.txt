Splatterhouse 2 (Mega Drive)
Traducción al Español v1.0 (29/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Splatterhouse 2 (USA).md
MD5: d0d14e031b6a62c733414e1039a51df3
SHA1: 59ec19ec442989d2738c055b9290661661d13f8f
CRC32: 2d1766e9
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --