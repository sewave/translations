An American Tail - Fievel Goes West (Super Nintendo)
Traducción al Español v1.0 (01/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
American Tail, An - Fievel Goes West (USA).sfc
MD5: a2aabe7064ff072de65450d50d50ba93
SHA1: 572254aebc4dcf3f65aa0c8f9b7cf6836bb9a294
CRC32: eea38aed
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --