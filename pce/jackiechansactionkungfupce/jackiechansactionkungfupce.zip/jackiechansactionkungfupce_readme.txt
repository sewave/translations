Jackie Chan's Action Kung Fu (PC Engine)
Traducci�n al Espa�ol v1.0 (21/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jackie Chan's Action Kung Fu (U).pce
MD5: 5a8c0f70f333ff03c8eb836eeb5f2ff9
SHA1: 33ee18e3cd6ba59ffca70fa7a1322d6e44a08682
CRC32: 9d2f6193
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --