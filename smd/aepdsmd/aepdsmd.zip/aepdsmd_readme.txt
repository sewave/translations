Alter Ego Remastered (Mega Drive)
Traducción al Español v1.0 (01/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
aepd.bin
MD5: 30c01f5a82b51fd7e23315dd070d5818
SHA1: 6f80b92b01aa35df3ea08d44225809f9d33c486b
CRC32: 3be95745
786432 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --