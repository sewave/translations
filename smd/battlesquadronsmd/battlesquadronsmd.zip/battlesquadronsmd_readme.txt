Battle Squadron (Mega Drive)
Traducción al Español v2.0 (16/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres españoles
-Traducido GAME OVER
-Guion revisado

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battle Squadron (USA, Europe).md
MD5: b5b815ef99b943fe0bad48dc13239b35
SHA1: f003f7af0f7edccc317c944b88e57f4c9b66935a
CRC32: 0feaa8bf
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --