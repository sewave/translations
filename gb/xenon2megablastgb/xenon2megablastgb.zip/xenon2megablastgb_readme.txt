Xenon 2 - Megablast (Game Boy)
Traducción al Español v1.0 (22/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Xenon 2 - Megablast (U).gb
MD5: 02d7df9a5ac5d859672b56be46343be1
SHA1: 00d76805e1ef3fe0eb5e8fc045cc22decfbe216b
CRC32: de398678
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --