Image Fight (PC Engine)
Traducción al Español v1.0 (30/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Image Fight (Japan).pce
MD5: baf6760fcd3b43540d55afc71f929697
SHA1: 4f2256e49cc71613a6b35d224be706ee95df17b9
CRC32: a80c565f
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --