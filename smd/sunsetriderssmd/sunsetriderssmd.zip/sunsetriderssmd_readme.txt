Sunset Riders (Mega Drive)
Traducci�n al Espa�ol v1.0 (27/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sunset Riders (U) [!].bin
MD5: 19cdf861c543f9c9cd9c8b6b70adeb1c
SHA1: b40ea5b00f477d7b7448447f15b4c571f5e8ff0d
CRC32: ac30c297
524288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --