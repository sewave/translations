Super Pang II (NES)
Traducción al Español v1.0 (01/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Pang II (Asia) (Ja) (Unl).nes
MD5: 4d26df8ea5b5ce2888e32901991dd65a
SHA1: fbb75ff55a08992f666b928586148fb6c428ff5b
CRC32: a5043905
98320 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --