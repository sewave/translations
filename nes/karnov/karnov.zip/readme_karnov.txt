Karnov
Traducci�n al Espa�ol v1.0 (29/11/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Karnov
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Karnov
-----------------
Un plataformas con toques de aventura.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking esta basado en la traduccion de Eien Ni Hen, Vice Translations.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Karnov (J).nes
196.624	bytes
CRC32: 63d71cda
MD5: 35fa43f7ac7d25a3a0c1813c14999b3b
SHA1: 4bf5cab72a36ac61c2138dbaabc31e32a6509b8c

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Original:
 Kitsune Sniper -
  Main hacker.
  Homepage: http://vice.parodius.com/
  Email: kitsune.sniper[AT]Gmail[DOT]com

 EienNiHen -
  Main script translation.
 
 RedComet
  Pointer help.

-- END OF README --