Asteroids (Game Boy)
Traducción al Español v1.0 (01/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Asteroids (U) [M][!].gb
MD5: 13749826df12da4574e34ccb6d9c780d
SHA1: 435dbdaa9b9d2e0d0bc7c1c010cdc5ec9bd9f359
CRC32: c1f88833
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --