Urban Strike (Mega Drive)
Traducción al Español v1.0 (13/07/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

No traducido: 
-Algunas partes de menú
-Mensaje de Malone al ser capturado:
¡PUEDE QUE GANARAS ESTA BATALLA!
¡PERO PRETENDO GANAR LA GUERRA!
¡EXPLOSIVAMENTE!

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Urban Strike (USA, Europe).md
MD5: 0f0be2db4084822d5514f8e34a0d1488
SHA1: 897a8f6a08d6d7d6e5316f8047532b3e4603e705
CRC32: cf690a75
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --