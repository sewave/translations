Wayne's World (Game Boy)
Traducción al Español v1.0 (11/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wayne's World (USA).gb
MD5: a2b68b9472bde2d2fee32c2ec87ff017
SHA1: 7165b8f31f1c5f783c8cad0399a3d71e87091ba2
CRC32: 829ea425
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --