Super Spike V'Ball
Traducci�n al Espa�ol v1.0 (13/08/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Super Spike V'Ball
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Super Spike V'Ball
-----------------
Versi�n americana del juego de voley playa, cambian algunas cosas como menus o las frases de los jugadores a elegir.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Super Spike V'Ball (U) [!].nes
262.160	bytes
CRC32: c2d3f5b3
MD5: 1a8a52a08dc9933e353ce0fed80c8dd3
SHA1: 5187384bd5694e38e96f2695e251b08717c63f81

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --