Super Mario All-Stars (Super Nintendo)
Traducción al Español v1.0 (11/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
Hay un menú del Super Mario Bros. 2 que no está traducido.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Mario All-Stars (U) [!].smc
MD5: 53c038150ba00d5f8d8574b4d36283f2
SHA1: c05817c5b7df2fbfe631563e0b37237156a8f6b6
CRC32: 925637c7
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --