World of Illusion Starring Mickey Mouse and Donald Duck (Mega Drive)
Traducción al Español v2.0 (09/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Revisión de guion
-Añadidos caracteres especiales a ambas fuentes
-Traducido "PRESS START BUTTON" del título

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
World of Illusion Starring Mickey Mouse and Donald Duck (USA, Korea).md
MD5: c2c5a4b990ce72f98b7b7f236e66c022
SHA1: adb0a2edebb6f978c3217075a2f29003a8b025c6
CRC32: 921ebd1c
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --