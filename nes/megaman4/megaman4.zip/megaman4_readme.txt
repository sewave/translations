Mega Man IV
Traducci�n al Espa�ol v1.0 (30/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Mega Man IV
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mega Man IV
-----------------
Cuarta parte del clasico de capcom.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Megaman IV (U) (PRG1) [!].nes
524.304	bytes
CRC32: 9ed9d3af
MD5: 1a4fdaece6ae32e5878029da63866d94
SHA1: 0fa8d2dadfb6e1dd9de737a02ce0bfa1cd5ff65d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --