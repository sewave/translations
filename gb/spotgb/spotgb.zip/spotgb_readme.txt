Spot (Game Boy)
Traducción al Español v1.0 (22/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spot (U) [!].gb
MD5: 2524230d0300f46ebf423ae1b37747eb
SHA1: 1a1ae34a3ec668d9a69c9c851c0291752dc63238
CRC32: fcd61b98
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --