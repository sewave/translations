George Foreman's KO Boxing (Master System)
Traducción al Español v1.0 (01/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
George Foreman's KO Boxing (EB) [!].sms
MD5: 31cf051d130a64e211d3ccb37c5653f7
SHA1: d0ddb71c6ca823c53d7e927a0de7de4b56745331
CRC32: a64898ce
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --