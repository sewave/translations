Ninja Gaiden Shadow (Game Boy)
Traducción al Español v1.0 (13/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Gaiden Shadow (U).gb
MD5: e12c5c2897ed095f8d26c7578afddfda
SHA1: 8aadd7dfb4add75d5ac5351658762e5f56e78c66
CRC32: d3741a3a
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --