3 Ninjas Kick Back
Traducci�n al Espa�ol v1.1 (18/02/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre 3 Ninjas Kick Back
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre 3 Ninjas Kick Back
-----------------
Juego basado en la pel�cula de los 3 peque�os ninjas, tecnicamente muy bueno, pero dif�cil como el solo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original, no traduce la pantalla de final de escena.
V1.1: Correcciones menores.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
3 Ninjas Kick Back (U) [!].bin
2.097.152	bytes
CRC32: e5a24999
MD5: df666774c0b73e112739b68c8841658b
SHA1: d634e3f04672b8a01c3a6e13f8722d5cbbc6b900

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --