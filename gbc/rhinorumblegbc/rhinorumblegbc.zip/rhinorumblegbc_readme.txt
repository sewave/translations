Rhino Rumble (Game Boy Color)
Traducción al Español v1.0 (28/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rhino Rumble (U) [C][!].gbc
MD5: ced299d2952ae83c7bbfbb64767e4634
SHA1: 2caf47c20d8632e47c4426dd3564e76415139973
CRC32: 73160e05
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --