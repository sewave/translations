Swords and Serpents (NES)
Traducción al Español v1.0 (21/12/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Swords and Serpents (USA).nes
MD5: 924c0e7f1abc1c141d0e72388bf1d6b2
SHA1: cd7c6fe5a198412cb1b9762778c28ddb63c1ef3b
CRC32: 071e3f72
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --