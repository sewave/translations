The Great Circus Mystery Starring Mickey & Minnie (Mega Drive)
Traducción al Español v2.0 (21/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres especiales
-Guion reescrito

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Great Circus Mystery Starring Mickey & Minnie, The (USA).md
MD5: b51204d15148b5856d41eb29d23d242c
SHA1: f2df9807fe2659e8f8e6ea43b2031a6abd980873
CRC32: 14744883
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --