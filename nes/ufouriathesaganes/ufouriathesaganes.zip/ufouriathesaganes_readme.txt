U-four-ia - The Saga (NES)
Traducción al Español v1.0 (14/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
U-four-ia - The Saga (E) [!].nes
MD5: 2386571285995137ab5b2044818d8a80
SHA1: ad6f93b83bcc0454f0dcdd68b364ae3001e76c15
CRC32: 6453f65e
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --