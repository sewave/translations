Aladdin (Game Gear)
Traducción al Español v2.0 (18/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos ¡¿Ñ
-Guion retraducido
-Algunas cadenas alargadas
-Traducidas letras grandes
-Traducido PAUSE y READY!
-Traducidos créditos

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Aladdin (USA, Europe).gg
MD5: 1ab3a94109af90a333a68479a02a5643
SHA1: 20ba7f5e5c801fbe48a537d2551a3d4525eb63e7
CRC32: 7a41c1dc
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --