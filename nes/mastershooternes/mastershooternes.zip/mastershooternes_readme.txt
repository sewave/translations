Master Shooter (NES)
Traducción al Español v1.0 (21/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Master Shooter (Asia) (Unl).nes
MD5: 03dfb0f60348b568fbcb673189349764
SHA1: 9d13a63eda096facfa4a92b645d05394bb1114b3
CRC32: d2dcae89
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --