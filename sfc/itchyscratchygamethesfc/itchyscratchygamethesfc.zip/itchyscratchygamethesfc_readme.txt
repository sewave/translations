The Itchy & Scratchy Game (Super Nintendo)
Traducción al Español v1.1 (20/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado DIFÍCIL en las opciones.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Itchy & Scratchy Game, The (USA).sfc
MD5: fa3c211a2f115ccf90518ed91097b395
SHA1: f44ba05908cb36462505ef431a68d11bad301dbc
CRC32: 95b65dfe
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --