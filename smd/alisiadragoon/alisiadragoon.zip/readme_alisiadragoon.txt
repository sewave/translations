Alisia Dragoon
Traducci�n al Espa�ol v1.0 (30/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Alisia Dragoon
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alisia Dragoon
-----------------
Curioso plataformas de Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
No est� traducida la intro de letras grandes.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Palabra OF en ranking.
Si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alisia Dragoon (U) [!].bin
1.048.576 bytes
CRC32: d28d5c40
MD5: 77be06102101759f30b416d80872c8da
SHA1: 69bf7a9ebcb851e0d571f93b26d785ca87621b01

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --