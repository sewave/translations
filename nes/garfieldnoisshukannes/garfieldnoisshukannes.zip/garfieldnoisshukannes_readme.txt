Garfield no Isshukan (NES)
Traducción al Español v1.0 (26/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Garfield no Isshukan (Japan).nes
MD5: a8816f534afee0901f0b3f078b9438ad
SHA1: a0edea35e6dca38c8fd6b2437ed0856c226b52cd
CRC32: 39c68f84
163856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --