Spy Hunter (NES)
Traducción al Español v1.0 (09/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spy Hunter (USA).nes
MD5: 9eb7ded08c29c6933d5bec7a185feefa
SHA1: 18365fe8e037a50d2127129f81ce291cab4c1a3e
CRC32: 1e060ae0
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --