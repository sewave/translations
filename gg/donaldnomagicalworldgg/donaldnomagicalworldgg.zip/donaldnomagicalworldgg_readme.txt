Donald no Magical World (Game Gear)
Traducción al Español v2.0 (24/02/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres españoles en todos los textos
-Forzada versión internacional
-Traducida frase de selección de minijuego

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Donald no Magical World (Japan) (En,Ja).gg
MD5: 34e9b284e61fb9a2cad4878451579295
SHA1: 5f9afdd5720f88f7cc18715f8e50fc5635b15323
CRC32: 87b8b612
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --