Home Alone (NES)
Traducción al Español v1.0 (27/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Home Alone (U) (REVA) [!].nes
MD5: 7d128a68a09d852cb9da9dff1c466070
SHA1: e9eafc223336e93665571158ad8f2dd8a229248a
CRC32: d98e3e31
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --