Pizza Bar (ZX Spectrum)
Traducción al Español v1.0 (06/04/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pizza Bar.tzx
MD5: dd9155a53557161c8d43f7ad7b6fef0f
SHA1: 796c9a8bf6187872712308d21f434a6754097b8b
CRC32: cd587f02
47820 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --