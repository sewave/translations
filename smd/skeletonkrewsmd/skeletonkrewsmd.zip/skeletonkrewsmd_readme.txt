Skeleton Krew
Traducci�n al Espa�ol v1.1 (17/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Skeleton Krew
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Skeleton Krew
-----------------
Shooter multijugador para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

v1.1:Arreglada palabra "KAVDAVER" del script original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Skeleton Krew (U) [!].gen
2.097.152 bytes
CRC32: c2e05acb
MD5: 7e9a79a887c4edf56574d7a1cd72c5fd
SHA1: 2a6f6ea7d2fc1f3a396269f9455011ef95266ffc

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --