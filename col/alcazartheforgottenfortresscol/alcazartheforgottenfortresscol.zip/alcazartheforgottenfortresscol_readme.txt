Alcazar - The Forgotten Fortress (Colecovision)
Traducción al Español v1.0 (21/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alcazar - The Forgotten Fortress (1985) (Activision).col
MD5: 48cf5b1ebbad828467eda47f2c5c5046
SHA1: 1582cbb23eb5464bd6b9dfdbeb0b161ec90af60a
CRC32: 9cc3fabc
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --