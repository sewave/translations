Spider-Man (Mega Drive)
Traducción al Español v1.0 (09/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spider-Man (USA, Europe) (Acclaim).md
MD5: af2a9fdd4a378593e47289eb8068164d
SHA1: a38d5ad7d503999b7fea3ebf59f3dda9d667758b
CRC32: 11b5b590
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --