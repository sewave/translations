Izzy's Quest for the Olympic Rings (Mega Drive)
Traducción al Español v1.0 (30/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Izzy's Quest for the Olympic Rings (USA, Europe).md
MD5: 012e2512633c6c1b5ca8dcfbf0e878f7
SHA1: 0f05e0c333d6ee58a254ee420a70d6020488ac54
CRC32: 77b416e4
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --