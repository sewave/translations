Dr. Mario (NES)
Traducci�n al Espa�ol v1.0 (23/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dr. Mario (JU) (PRG1) [!].nes
MD5: 8181d696756578fc92e6c4c86da01904
SHA1: cbed8bb73ccc3224f87d787e065b61ecf94e2c0c
CRC32: 7623dffd
65.552 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --