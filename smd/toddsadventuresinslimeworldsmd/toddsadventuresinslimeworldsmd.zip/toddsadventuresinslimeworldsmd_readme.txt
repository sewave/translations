Todd's Adventures in Slime World (Mega Drive)
Traducción al Español v1.0 (29/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Todd's Adventures in Slime World (U) [!].bin
MD5: 0ff81c6ec1c1c92a4bce8e29c5db2291
SHA1: e558e39e3e556d20c789bf2823af64e1a5c78784
CRC32: 652e8b7d
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --