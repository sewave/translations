Buster Fight (Game Gear)
Traducción al Español v1.0 (21/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Buster Fight (J).gg
MD5: a729ed9b55fd8496b807d39c3bb9299e
SHA1: 5c87048082a95acd6bc27b98f85bda731617c739
CRC32: a72a1753
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --