Totsuzen! Macchoman (NES)
Traducción al Español v1.0 (12/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Totsuzen! Macchoman (Japan).nes
MD5: 8ba3aaa07af2b313a6a14d64dc469c8a
SHA1: 7106b220c2e4e944a0d6c2b2446d8caf563f96d1
CRC32: d1442067
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --