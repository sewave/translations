Dragon's Lair (Mega Drive)
Traducción al Español v1.0 (16/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dragon's Lair (USA) (Proto) (June, 1994).md
MD5: 8edba746c8a5881714ce3c6dad6c3bc9
SHA1: d29ec9588dcbc27a4ef3f838191b767235a6ff17
CRC32: a33eb522
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --