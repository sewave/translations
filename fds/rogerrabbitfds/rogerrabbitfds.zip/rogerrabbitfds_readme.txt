Roger Rabbit (Famicom Disk System)
Traducción al Español v1.0 (22/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Roger Rabbit (Japan) [b].fds
MD5: 0e1188b3860b6d7fc748e4efda3408cf
SHA1: 0d34576bc5c14fb0edb6f8fa8e2daca0438912ea
CRC32: 8350559a
131000 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --