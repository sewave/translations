The Hunt for Red October (Game Boy)
Traducción al Español v1.0 (15/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hunt for Red October, The (USA, Europe).gb
MD5: cca5288a7a9e0270592bf75c0431bbb5
SHA1: 7c9ccfd9e98b30c33ff71b3ab3098c2afeb9037c
CRC32: 5a61ee00
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --