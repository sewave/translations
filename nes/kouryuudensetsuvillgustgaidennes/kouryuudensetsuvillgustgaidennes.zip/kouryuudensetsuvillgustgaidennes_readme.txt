Kouryuu Densetsu Villgust Gaiden (NES)
Traducción al Español v1.2 (31/08/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking esta basado en el de LIPEMCO! Translations.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
- Corregido "Anitmal" por "Antimal"
- Expandida "HachaMano"
- Expandida "EspinillerasAntimal"

V1.2:
- Aplicadas correcciones informadas por signatux

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kouryuu Densetsu Villgust Gaiden (Japan).nes
MD5: 6973aeec39afd834ed287722bfae2425
SHA1: 2b485675298722c4c0eaed0f3c705ff5c1b8a73d
CRC32: 5a8bfdf5
393232 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.
signatux - Pruebas.

-- FIN --