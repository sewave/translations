Bubsy II (Game Boy)
Traducción al Español v1.0 (13/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bubsy II (USA).gb
MD5: c80413993cb4a5b79c9cdd04235010dd
SHA1: 1ac9bf5043caf428994bca3e80158ca697e94c58
CRC32: 600a6ad5
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --