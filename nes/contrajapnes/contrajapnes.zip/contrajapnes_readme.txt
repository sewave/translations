Contra (Japón) (NES)
Traducción al Español v1.0 (26/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Stardust Crusaders.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Contra (Japan).nes
MD5: 0e40bc1b049c16c5d7246cc28399cb5d
SHA1: 376836361f404c815d404e1d5903d5d11f4eff0e
CRC32: 8a96a3c4
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --