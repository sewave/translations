Bubble Bobble (Game Boy)
Traducción al Español v1.0 (24/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bubble Bobble (USA, Europe).gb
MD5: 11c49d405eef2174d9c14682204bb458
SHA1: 569881bea21cf5fd542ff3dfc40e1626c6748ceb
CRC32: d516841d
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --