Battletoads and Double Dragon (Mega Drive)
Traducción al Español v1.0 (27/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battletoads and Double Dragon (U) [c][!].bin
MD5: 78f3ea32bcb4f627e4f9bc9711e017b8
SHA1: 5b79623e90806206e575b3f15499cab823065783
CRC32: 8239dd17
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --