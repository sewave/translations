Yogi Bear's Gold Rush (Game Boy)
Traducción al Español v1.0 (29/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Yogi Bear's Gold Rush (USA).gb
MD5: 1337510dc9de85723ff1778524c5007f
SHA1: d701b98b34c61ea230df1ca9561e1c9474928ebf
CRC32: a86bd81b
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --