James Pond - Underwater Agent (Mega Drive)
Traducci�n al Espa�ol v1.0 (10/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
James Pond - Underwater Agent (UE) [!].bin
524.288 bytes
MD5: aacf7533fd8e45b95321a57b01fb3ac8
SHA1: b4e1c945c3ccea2e76b296d6694c0931a1ec1310
CRC32: d0e7b466

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --