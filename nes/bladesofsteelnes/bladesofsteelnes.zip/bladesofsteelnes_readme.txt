Blades of Steel (NES)
Traducci�n al Espa�ol v1.0 (05/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blades of Steel (U) [!].nes
MD5: 46ee7db0d4c3d4b77512ee1db6f10ae1
SHA1: 1aa1e36483d766ece1e8a72409bf12397ff262d6
CRC32: b9bcf910
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --