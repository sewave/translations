Batty (ZX Spectrum)
Traducción al Español v1.0 (15/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
BATTY.TZX
MD5: b5bc4500b7a9c729cd9dea0dedccae07
SHA1: dedb7c97429a78c5596e6629e07cacec814847e4
CRC32: 97de1163
32370 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --