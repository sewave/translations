Rollerball (NES)
Traducción al Español v1.0 (18/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rollerball (USA).nes
MD5: d0e0ac88022edbbda455ea29146e2042
SHA1: bf47ae90d69f0914e4251419d090e04af952fe59
CRC32: e45a440d
163856 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --