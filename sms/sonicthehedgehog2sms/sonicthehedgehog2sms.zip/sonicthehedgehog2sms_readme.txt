Sonic The Hedgehog 2 (Master System)
Traducci�n al Espa�ol v1.0 (19/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sonic The Hedgehog 2 (UE) (V2.2).sms
MD5: 0ac157b6b7e839953fc8eba7538fb74a
SHA1: 689339bac11c3565dd774f8cd4d8ea1b27831118
CRC32: d6f2bfca
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --