Super Arabian (NES)
Traducción al Español v1.0 (28/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Arabian (J).nes
MD5: 4f468a50ef3e23807e74c9770868d08c
SHA1: 95a1dedb3f23ff4f1e71b5f518fd7622163ec8cd
CRC32: f2988a21
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --