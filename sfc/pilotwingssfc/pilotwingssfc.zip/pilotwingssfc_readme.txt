Pilotwings (Super Nintendo)
Traducción al Español v1.2 (06/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
v1.1:Arreglado texto erróneo al reintentar etapa.
v1.2:Arreglados mensajes de aterrizaje de doble línea.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pilotwings (USA).sfc
MD5: 8dcb216beed58c798b25df55f62218d0
SHA1: fe941ba251acf329f028a1603a43562db2c75e51
CRC32: 266c44ed
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --