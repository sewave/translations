Rastan
Traducci�n al Espa�ol v1.0 (11/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Rastan
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Rastan
-----------------
Plataformas/accion en el que llevas a un barbaro.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Rastan (UE) [!].sms
262.144	bytes
CRC32: c547eb1b
MD5: 5b3a785de403c311db7f17eae27caae6
SHA1: 90f9ccf516db2a1cf20e199cfd5d31d4cfce0f1f

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --