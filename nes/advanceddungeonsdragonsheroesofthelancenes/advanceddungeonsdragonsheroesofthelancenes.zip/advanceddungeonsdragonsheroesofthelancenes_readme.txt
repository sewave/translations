Advanced Dungeons & Dragons - Heroes of the Lance (NES)
Traducción al Español v1.0 (11/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Advanced Dungeons & Dragons - Heroes of the Lance (U) [!].nes
MD5: 01d8a23d55fdd23b0f5c97b8dfb1e81a
SHA1: d9328b02916d365c97ed21074333257968e55f91
CRC32: e880d426
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --