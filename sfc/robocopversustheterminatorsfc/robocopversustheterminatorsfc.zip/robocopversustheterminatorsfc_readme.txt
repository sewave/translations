Robocop Versus The Terminator (Super Nintendo)
Traducción al Español v1.0 (11/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Robocop Versus The Terminator (U).smc
MD5: 3683319beeba73ad6deb851ef72bf3d3
SHA1: f6b6cd466d1a50a4f8608f4af1b773f317aaf964
CRC32: f5ab5d91
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --