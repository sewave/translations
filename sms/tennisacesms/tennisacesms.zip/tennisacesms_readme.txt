Tennis Ace (Master System)
Traducción al Español v1.0 (17/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tennis Ace (Europe).sms
MD5: 89146053b1474833e921835c907aa2d3
SHA1: 0d202166d4a3bdfcf90514c711c77e4f20764552
CRC32: 1a390b93
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --