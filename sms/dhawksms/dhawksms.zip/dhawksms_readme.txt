Double Hawk
Traducci�n al Espa�ol v1.0 (28/04/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Double Hawk
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Double Hawk
-----------------
Curioso shooter estilo Cabal para la Master System.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Est� todo traducido excepto la pantalla continue/end.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Double Hawk (E) [!].sms
262.144	bytes
CRC32: 8370f6cd
MD5: 3e6e6cb8729965fdfdbb422f066ad706
SHA1: d2428baf22da8a70a08ff35389d59030ce764372

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --