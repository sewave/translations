Duke Nukem 3D (Mega Drive)
Traducci�n al Espa�ol v1.0 (08/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Duke Nukem 3D (B) [!].bin
MD5: 5093ad6641abb0c3757d24da094a51e6
SHA1: a4663f2b96787a92db604a92491fa27e2b5ced9e
CRC32: 6bd2accb
4.194.304 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --