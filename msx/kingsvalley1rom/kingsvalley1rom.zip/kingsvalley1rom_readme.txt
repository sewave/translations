King's Valley 1 (MSX)
Traducción al Español v1.0 (07/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
King's Valley 1 (1985) (Konami) (J).rom
MD5: dcd8d9508be4fd38fdb4c8f50b16dbe3
SHA1: 07448ffb20f260df159a19df2cae1ee5545a0aef
CRC32: dfac2125
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --