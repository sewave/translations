Dynamite Headdy (Mega Drive)
Traducción al Español v1.0 (12/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dynamite Headdy (USA, Europe).md
MD5: d11ec9b230e88403cd75ef186a884c97
SHA1: e843decdff262791b1237f1545f5b17c56712d5f
CRC32: 3dfeeb77
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --