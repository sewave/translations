Mortal Kombat (Super Nintendo)
Traducción al Español v1.0 (20/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mortal Kombat (USA).sfc
MD5: 0934878bb5ef33f25c1fcaba18a1105b
SHA1: c6ded5b8bca1716a2dddfdc697b31f085aaa05d0
CRC32: def42945
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --