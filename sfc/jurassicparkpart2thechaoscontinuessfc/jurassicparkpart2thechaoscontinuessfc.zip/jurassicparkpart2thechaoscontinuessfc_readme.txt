Jurassic Park Part 2 - The Chaos Continues (Super Nintendo)
Traducción al Español v1.0 (23/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jurassic Park Part 2 - The Chaos Continues (USA) (En,Fr,De,It).sfc
MD5: 64d367e1406fc39281443da9cfd9f015
SHA1: 23967b9dd586c01a8b6e89bb3774c3b3f7bdf3ba
CRC32: 836ee990
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --