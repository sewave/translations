Aero Blasters
Traducci�n al Espa�ol v1.0 (04/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Aero Blasters
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Aero Blasters
-----------------
Shooter para pc engine.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Aero Blasters (U).pce
524.288	bytes
CRC32: b03e0b32
MD5: b2b62baab5fefafc5db6538720b503c3
SHA1: 23b7da6a6067563af5fdf303d83adeae818cdcdf

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --