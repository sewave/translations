After Burner II (Mega Drive)
Traducci�n al Espa�ol v1.0 (11/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
After Burner II (UE) [!].bin
MD5: 75458e38c278f61c06dabacc744b5fe1
SHA1: 523e4abdf19794a167a347b7eeca79907416e084
CRC32: ccafe00e
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --