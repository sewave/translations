Legacy of the Wizard (NES)
Traducción al Español v1.0 (01/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Legacy of the Wizard (USA).nes
MD5: dc2075de098c136d6b8ee43477164045
SHA1: 512a6a3dd1cc822f468003ac2c21f3e082432232
CRC32: b534eb48
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --