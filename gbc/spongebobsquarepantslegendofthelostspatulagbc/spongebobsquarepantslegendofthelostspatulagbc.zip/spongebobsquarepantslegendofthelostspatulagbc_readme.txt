SpongeBob SquarePants - Legend of the Lost Spatula (Game Boy Color)
Traducción al Español v1.1 (30/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1
-Arreglado "una" por "un"

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
SpongeBob SquarePants - Legend of the Lost Spatula (USA, Europe).gbc
MD5: 4272d192cf2b14db93f1e2d1bc07aa74
SHA1: d3bea58987c9904056587242bf3ad26f91b4ef34
CRC32: 81230564
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --