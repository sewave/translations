T2 - The Arcade Game (Super Nintendo)
Traducci�n al Espa�ol v1.0 (13/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
T2 - The Arcade Game (U).smc
MD5: 49a4cf748b491f6e7bdbfc86f2cf4d16
SHA1: 29597788b9240be9fd1f800ce61a54298986ce73
CRC32: 5dc6b9fe
1048576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --