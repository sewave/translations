Pico Pico (MSX)
Traducción al Español v1.0 (12/04/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Existen dos versiones del parche:
picopicoromNonExtended.ips si tienes una bios de MSX original.
picopicorom.ips si tienes una bios con caracteres latinos como C-BIOS, así se aprovechan.

Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pico Pico (Japan).rom
MD5: 17b55fb340f89abf313a099c15c58fca
SHA1: 683478868f6c6423cc3e9c6aabe1868b30b1e47d
CRC32: ba3e62d3
8192 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --