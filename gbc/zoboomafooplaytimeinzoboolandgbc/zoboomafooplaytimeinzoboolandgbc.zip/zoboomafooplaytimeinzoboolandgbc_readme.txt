Zoboomafoo - Playtime in Zobooland (Game Boy Color)
Traducción al Español v1.0 (17/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zoboomafoo - Playtime in Zobooland (USA).gbc
MD5: 63f1430338d4f8053a34587429fb6b96
SHA1: a85a113bc266325f807f110daaf30feeea4b2738
CRC32: 38d91885
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --