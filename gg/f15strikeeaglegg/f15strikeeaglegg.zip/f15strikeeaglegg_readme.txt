F-15 Strike Eagle (Game Gear)
Traducción al Español v1.0 (14/10/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
F-15 Strike Eagle (USA, Europe).gg
MD5: 69cc38014650bdd0af0a2b7d7e9c46ec
SHA1: 4bfdafa848223598ca16699ad44fe4a19a1c2ba2
CRC32: 8bdb0806
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --