Operation Wolf (Master System)
Traducción al Español v1.0 (18/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Operation Wolf (U) [!].sms
MD5: 2ca2064302f51f724e1f2593369a0696
SHA1: 064040452b6bacc75443dae7916a0fd573f1600d
CRC32: 205caae8
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --