Frogger (Mega Drive)
Traducción al Español v1.0 (14/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Frogger (U) [!].bin
MD5: a5ef16bf634e12cb959da662858bae94
SHA1: c0ccfec43ea859ab1e83293a38cfb302c0191719
CRC32: ea2e48c0
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --