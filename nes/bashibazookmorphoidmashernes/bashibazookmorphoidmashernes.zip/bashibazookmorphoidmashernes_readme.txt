Bashi Bazook - Morphoid Masher (NES)
Traducción al Español v1.1 (30/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:
-Eliminadas letras "ZON" en el título

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bashi Bazook - Morphoid Masher (USA) (Proto).nes
MD5: 8f5745f5dacaa1a0c4016423e6f179ff
SHA1: 5c6a64d300a3125d1333ec358f715d0f5c267b35
CRC32: 11c92b5d
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --