Metal Masters (Game Boy)
Traducción al Español v1.0 (24/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Metal Masters (U).gb
MD5: 680c8fbb0bc15c850121ef2c929df177
SHA1: caae5811b2d2b884b691ea7d940ecb86647cd250
CRC32: bf6866dc
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --