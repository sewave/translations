Kishin Douji Zenki - Batoru Raiden 
Traducci�n al Espa�ol v1.0 (26/09/2016)
(C) 2016 Wave Translations
	
---
TdC
---

1. Sobre Kishin Douji Zenki - Batoru Raiden 
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Kishin Douji Zenki - Batoru Raiden 
-----------------
Kishin Douji Zenki - Batoru Raiden es un plataformas/accion con algunos dialogos de por medio.
Este parche traduce los dialogos al espa�ol.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es basada en la de Dynamic-Designs.
No a�ade caracteres especiales.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Kishin Douji Zenki - Batoru Raiden (J)
2.097.152 bytes
CRC32: 0becfc92
MD5: 2152cca035b8e3080d9eddb5bea8d94d
SHA1: 7706caf2c6b6f36ff7cad5cbdde0a1b6ec03cae0

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al espa�ol

Dynamic-Designs Production Credits:
	Project Coordination:			Bongo`
	Hacking/Tools/Bug Fixing:		Bongo`
    Assembly: 						Bongo`
	Translation:					Kakushiken
	Translation Check:				Filler
	Editors/Writers:				Taskforce, Draken
	Beta Testing:					Taskforce, Draken
	Anime Consistency Check:		Filler, Taskforce
	Splash:						    Taskforce

-- END OF README --