Gun-Dec
Traducci�n al Espa�ol v1.0 (15/09/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Gun-Dec
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Gun-Dec
-----------------
Un juego de plataformas con unos efectos graficcos muy avanzados y una historia un poco adulta.
Este parche lo traduce completamente al espa�ol excepto los menus del juego.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es derivada de la de Pennywise.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato BPS, recomiendo usar Floating IPS v1.31.
Archivo utilizado:
Gun-Dec (J).nes
262.160 bytes
CRC32: 4b08e280
MD5: 500fb76166df6cca24a2b0c65c605262
SHA1: dbf0b269578fc9125503181f50815aa35290e7ae

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al Espa�ol

Orignal
Pennywise - hacking, text editing
aishsha - translation
Ryusui - text editing/translation
Lord Oddeye - testing

-- END OF README --