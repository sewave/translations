Maru's Mission (Game Boy)
Traducción al Español v1.0 (27/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Maru's Mission (U) [!].gb
MD5: 7f26dd90f8e80b52ead8fc0e3609d4f2
SHA1: 91446b1cc6dbf3b98b81f13e35ffe7bfaaa027aa
CRC32: 6e4f1eb3
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --