Gain Ground (Mega Drive)
Traducci�n al Espa�ol v1.0 (20/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gain Ground (UE) [c][!].gen
524.288	bytes
MD5: fa43881a792fadf1ab737294fff1bcc3
SHA1: 3cc501086f794ac663aad14d5c5a75b648041151
CRC32: 83e7b8ae

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --