Teenage Mutant Ninja Turtles - The Hyperstone Heist
Traducci�n al Espa�ol v1.0 (05/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Teenage Mutant Ninja Turtles - The Hyperstone Heist
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Teenage Mutant Ninja Turtles - The Hyperstone Heist
-----------------
Adaptacion para megadrive del clasico beat em up de konami.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Todo traducido excepto los menus y las frases ingame con letras grandes.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles - The Hyperstone Heist (U) [!].bin
1.048.576 bytes
CRC32: 679c41de
MD5: 30ede62c8efe3e046e5409758b091eb6
SHA1: f440dfa689f65e782a150c1686ab90d7e5cc6355

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --