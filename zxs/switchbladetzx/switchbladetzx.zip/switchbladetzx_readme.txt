Switch Blade (ZX Spectrum)
Traducción al Español v1.0 (24/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Switch Blade.tzx
MD5: 8e752fb706580cee0be855f9d58cafb6
SHA1: f2f90e9604d3c69472034ecc4d310755a61c1eb0
CRC32: cae096c8
52995 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --