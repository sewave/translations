WWF King of the Ring (Game Boy)
Traducción al Español v1.0 (07/12/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
WWF King of the Ring (USA, Europe).gb
MD5: 8ffab7c16a215d3e2cce01fa24fbdf4f
SHA1: fd17015d8f85f407427c8aa3e68fb0a32dc072a8
CRC32: 7f0cd87c
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --