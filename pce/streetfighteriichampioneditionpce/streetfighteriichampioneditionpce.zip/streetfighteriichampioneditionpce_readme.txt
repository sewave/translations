Street Fighter II' - Champion Edition (PC Engine)
Traducción al Español v1.0 (28/09/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basada en la de Cabbage.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Street Fighter II' - Champion Edition (Japan).pce
MD5: 0d9135be3267876bfec7f588abeda5bb
SHA1: e757ecdf857803cb46cdf37ecf4596f6eaccdd76
CRC32: d15cb6bb
2621440 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --