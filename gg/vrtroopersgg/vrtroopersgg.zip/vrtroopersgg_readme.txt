VR Troopers (Game Gear)
Traducci�n al Espa�ol v1.0 (19/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
VR Troopers (U) [!].gg
MD5: 1093dbdc69a36330973cfb76c292c0ef
SHA1: 0986935cee44541c1e24bcd4dc3d9f87f324bbbe
CRC32: b0f22745
524288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --