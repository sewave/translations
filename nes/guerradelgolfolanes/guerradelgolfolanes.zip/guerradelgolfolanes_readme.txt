Guerra del golfo, La (NES)
Traducción al Español v1.0 (03/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Guerra del golfo, La (Spain) (Gluk Video) (Unl).nes
MD5: f2e8182c230cf0e1d0ac2d14caf74423
SHA1: 903787b48140ca618c3ffb4e551225081c3fbc72
CRC32: e45d5d88
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --