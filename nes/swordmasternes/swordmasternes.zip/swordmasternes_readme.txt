Sword Master (NES)
Traducci�n al Espa�ol v1.0 (25/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sword Master (U) [!].nes
MD5: 6aeec579039e1cc3fc284d1cc3d713f8
SHA1: 8145e4c6520e84ee8be1be883cb07f9c4f25350c
CRC32: 6ccd5c11
262160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --