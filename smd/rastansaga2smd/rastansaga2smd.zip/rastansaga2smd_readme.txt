Rastan Saga II
Traducci�n al Espa�ol v1.0 (03/05/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Rastan Saga II
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Rastan Saga II
-----------------
Segunda parte de rastan, sencillo plataformas/accion.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Rastan Saga II (U) [!].gen
524.288	bytes
CRC32: c7ee8965
MD5: c96b3cdf4525f7fba802d2804fed6a33
SHA1: adec2cb70344ffc720ecdfeb68712bb3d1d0fd9c

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --