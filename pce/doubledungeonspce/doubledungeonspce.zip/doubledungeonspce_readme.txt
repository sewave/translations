Double Dungeons - W (PC Engine)
Traducción al Español v1.0 (13/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Dungeons - W (USA).pce
MD5: 5ba010cd617c6f2b0f6e926fd4ef8a42
SHA1: 4e81f6cfa47ed941922492889be432041ff99e25
CRC32: 4a1a8c60
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --