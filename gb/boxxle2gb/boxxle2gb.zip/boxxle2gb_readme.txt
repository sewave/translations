Boxxle 2 (Game Boy)
Traducción al Español v1.0 (05/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Boxxle 2 (U) [!].gb
MD5: 308abd707a48ee9d69c287d818469fd6
SHA1: 36315dab12915d2d2fad7a37fcb5ce6809118c8a
CRC32: c08e9756
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --