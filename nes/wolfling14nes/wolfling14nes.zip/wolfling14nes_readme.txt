Wolfling (NES)
Traducción al Español v1.0 (06/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
wolfling14.nes
MD5: 78e9b671404a8d2aa68296e4bf46f92e
SHA1: 7a0437dff746ac5c779833edb1fc89fc8156dc83
CRC32: f22ae9b8
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --