Warriors of Might and Magic (Game Boy Color)
Traducción al Español v1.0 (11/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Warriors of Might and Magic (USA) (En,Fr,De).gbc
MD5: f0656cf3aa3d6b539fb1b7da0fd27617
SHA1: 06163acad95d6ab87ffcd56f18b37c8c9e37a6ec
CRC32: ef9f5bea
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --