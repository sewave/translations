Wriggler (ZX Spectrum)
Traducción al Español v1.0 (11/10/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wriggler.tzx
MD5: 73438914e28a1afc2e3f288d3e971004
SHA1: 023803894d8a09cfca4fe84fae7311b4ef9e99ac
CRC32: 6c65a021
51239 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --