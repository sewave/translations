Druaga no Tou (Game Boy)
Traducción al Español v1.0 (02/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Druaga no Tou (Japan).gb
MD5: c8611861afe5d9b47043150ee2c94389
SHA1: 7701f8c535f612943d736fef342973e9c77011df
CRC32: f924bdb1
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --