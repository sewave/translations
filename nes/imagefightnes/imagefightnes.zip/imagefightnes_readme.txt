Image Fight (NES)
Traducción al Español v1.0 (24/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Image Fight (USA).nes
MD5: adecb3390059b28b60ae019d30354137
SHA1: 508ae922ada0082bb48a265baa7dbb52df04af1d
CRC32: 2f1c2b30
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --