Snow Bros. - Nick & Tom (Mega Drive)
Traducci�n al Espa�ol v1.0 (03/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Snow Bros. - Nick & Tom (J) [c][!].gen
1.048.576 bytes
MD5: bc5d2dadfa64e26d851af8c294c38436
SHA1: 27caf554f48d2e3c9c6745f32dbff231eca66744
CRC32: 11b56228

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --