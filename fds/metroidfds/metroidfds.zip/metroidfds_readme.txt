Metroid (Famicom Disk System)
Traducción al Español v1.0 (11/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de AlanMidas.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Metroid (Japan) (v1.2).fds
MD5: d68f36d25a3474663bb1decfe0fcb395
SHA1: d902169f4db2a5127d808cca8539c3ca924f4039
CRC32: 1ad64b0f
131000 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --