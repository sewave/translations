Swordbird Song - Iron Owl Tower (Game Boy)
Traducción al Español v1.0 (15/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Swordbird Song - Iron Owl Tower 3.1.gb
MD5: 57611d2939ee579349f2221c78339bb1
SHA1: b36ec89e0299c19767cc5c6467fa3664abbc3017
CRC32: 64921bb1
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --