Bank Panic (MSX)
Traducción al Español v1.0 (24/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bank Panic (1985) (Pony Cannon) (J).rom
MD5: 0242d2ebf0f2e7b8d4d840c13f426c73
SHA1: b0956b97c9087aabab333c271c7afd9754ae84cd
CRC32: d5e18df0
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --