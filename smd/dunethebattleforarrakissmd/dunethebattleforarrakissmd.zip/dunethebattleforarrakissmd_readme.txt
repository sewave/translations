Dune - The Battle for Arrakis (Mega Drive)
Traducción al Español v1.0 (14/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

El tutorial, parte de las opciones y los resúmenes de misión no están traducidos al ser gráficos o pantallas comprimidas.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dune - The Battle for Arrakis (USA).md
MD5: d4df66f77d52718798ec07d350d3a3cd
SHA1: 0f7c1c130cb39abc97f57545933e1ef6c481783d
CRC32: 4dea40ba
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --