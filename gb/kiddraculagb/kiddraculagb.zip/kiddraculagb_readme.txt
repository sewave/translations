Kid Dracula (Game Boy)
Traducción al Español v2.0 (23/11/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Guion retraducido
-Añadidos caracteres españoles

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kid Dracula (USA, Europe).gb
MD5: 24a6b4457a511cc667e9ac25417401ab
SHA1: f186833a2ccec808210eb4ba669f08401f950e23
CRC32: f27294b7
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --