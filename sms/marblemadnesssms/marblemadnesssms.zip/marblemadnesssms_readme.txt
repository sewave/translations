Marble Madness (Master System)
Traducci�n al Espa�ol v1.0 (03/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Marble Madness (UE) [!].sms
MD5: 97832999dd6d2ba467b5625006b018a0
SHA1: f5efe0635e283a08f98272a9ff1bc7d37c35692c
CRC32: bf6f3e5f
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --