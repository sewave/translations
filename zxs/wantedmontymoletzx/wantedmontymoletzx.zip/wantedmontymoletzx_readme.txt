Wanted - Monty Mole (ZX Spectrum)
Traducción al Español v1.0 (16/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wanted - Monty Mole.tzx
MD5: 3e8eb3d8f7d0d208d7eb65ae25f89ee5
SHA1: 14b47218e2c1d42c7396ee46e04b08075833e551
CRC32: 6eff8637
49476 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --