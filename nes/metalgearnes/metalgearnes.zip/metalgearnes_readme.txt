Metal Gear (NES)
Traducción al Español v1.0 (11/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Metal Gear (USA).nes
MD5: 347f6b957cff910cd058d7bfd3cee588
SHA1: 9aaa7c001465311ae79d84644aa5fce1f9766860
CRC32: b27de2d8
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --