Mystic Defender (Mega Drive)
Traducción al Español v2.0 (04/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mystic Defender (USA, Europe) (Rev A).md
MD5: 780baa7dd2f030f0b1c64897b5d4cc10
SHA1: aec8aefa11233699eacefdf2cf17d62f68cbdd98
CRC32: 50fd5d93
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --