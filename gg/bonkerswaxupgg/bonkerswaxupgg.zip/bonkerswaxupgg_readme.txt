Bonkers Wax Up! (Game Gear)
Traducci�n al Espa�ol v1.0 (05/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bonkers Wax Up! (U) [!].gg
MD5: 3608e04a697b3c6b5857b5d3f3a58cca
SHA1: b98bd9467fe8bf782989172b576c7844f3666ae9
CRC32: bfceba5f
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --