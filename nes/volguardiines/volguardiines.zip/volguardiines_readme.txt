Volguard II (NES)
Traducción al Español v1.0 (18/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Volguard II (Japan).nes
MD5: b5e8b758841a3c78a2fefb773315e6e4
SHA1: 008bc60ba2b47874afde50abb155806a8facd888
CRC32: 1a935610
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --