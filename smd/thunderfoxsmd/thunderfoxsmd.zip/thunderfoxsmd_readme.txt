Thunder Fox (Mega Drive)
Traducción al Español v1.0 (05/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Thunder Fox (U) [c][!].bin
MD5: ca6f52b094db8bb2c5a4deaebe6b56ce
SHA1: c1699ccabb89c2877dd616471e80d175434bffe3
CRC32: 5463f50f
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --