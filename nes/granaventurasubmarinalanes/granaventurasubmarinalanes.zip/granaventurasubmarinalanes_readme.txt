Gran Aventura Submarina, La (NES)
Traducción al Español v1.0 (03/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gran Aventura Submarina, La (Spain) (Gluk Video) (Unl).nes
MD5: 224295159430761669ab9e50253dc250
SHA1: ef79bce4bcf36285a2d17f45a3f3da3addecc5a4
CRC32: 6483756a
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --