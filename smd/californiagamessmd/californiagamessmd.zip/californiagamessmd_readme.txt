California Games (Mega Drive)
Traducción al Español v1.0 (05/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
California Games (USA, Europe).md
MD5: 6cb2871511f53a30996963f30839de75
SHA1: 0417ff05bb8bd696cfae8f795c09786665cb60ef
CRC32: 43b1b672
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --