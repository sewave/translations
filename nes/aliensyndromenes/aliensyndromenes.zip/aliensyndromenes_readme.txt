Alien Syndrome
Traducci�n al Espa�ol v1.1 (12/02/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Alien Syndrome
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Alien Syndrome
-----------------
Versi�n para la 8 bits de nintendo del arcade.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
V1.1:Arreglada intro.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Alien Syndrome (Tengen) [!].nes
262.160	bytes
CRC32: 9e8351af
MD5: 5b87e0a19b65de73d41cf0a6df88b47b
SHA1: 23e03135514d88297444438a490d222f2f54be4f

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --