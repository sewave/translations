Mega Qbert (Mega Drive)
Traducción al Español v1.1 (05/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglados fallos de game over

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mega Qbert.bin
MD5: 50a8a3e41b42df0a42d9eb6e471dfd03
SHA1: 0cc93c58ccb8837ebe6305437dac209ff2b9fac2
CRC32: 8e48002d
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --