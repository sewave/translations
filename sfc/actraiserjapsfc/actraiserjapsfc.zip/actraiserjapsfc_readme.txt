Actraiser (Super Nintendo)
Traducción al Español v2.0 (14/10/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la traducción de Aeon Genesis.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Reajustado todo el guion
-Correcciones gramaticales
-Cambios en expresiones y opciones de menú

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Actraiser (Japan).sfc
MD5: 3cb1a7ae9fd34a56015f752fd138070e
SHA1: f031fc983a2eed4d69e223b256ece5f037fb5d5d
CRC32: bee9b30c
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --