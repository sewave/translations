Level 5 (ZX Spectrum)
Traducción al Español v1.0 (30/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Level 5.tzx
MD5: 8549451f6a88e0b4121b85409af9c05a
SHA1: 66f19965d5ad89c854ef2077d51f1c5a5efea58e
CRC32: 930cac98
31972 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --