Double Dragon (Game Gear)
Traducción al Español v1.0 (06/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Double Dragon (U) [!].gg
MD5: b45d73e40ce8f6e76dced24ee921871a
SHA1: baebe28fc7549cbb06c94fcb36a3c40231933c01
CRC32: 1307a290
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --