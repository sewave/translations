RoboCop Vs (Game Boy)
Traducción al Español v1.0 (11/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
RoboCop Vs. The Terminator (U) [!].gb
MD5: 0e82b5210966e9eb53d5b7ef906a0f40
SHA1: ca0484363d1d427474de028f037c7d566e9c1fea
CRC32: f82d7223
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --