Castlevania - Legends
Traducci�n al Espa�ol v1.0 (04/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Castlevania - Legends
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Castlevania - Legends
-----------------
Traducci�n de este tard�o juego de game boy de la saga castlevania.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
La traducci�n est� completa excepto el final con todos los tesoros, 
eso son imagenes aunque parezca texto, la traducci�n ser�a as�:
Tras un tiempo, la joven chica de nuestra leyenda fue madre,
cuyo ni�o llevar�a el destino y la tragedia de la familia
Belmont, y el linaje de las maneras oscuras.
Un ni�o cargado con un destino maldito.
Y a�n y as� este ni�o, antes contento en el amor de su madre,
tambi�n se alzar� para luchar valientemente contra el
Pr�ncipe de la Oscuridad, que volver� una vez m�s.
Este ni�o quien, un d�a ser� alabado por todo el mundo como
h�roe...

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Castlevania - Legends (UE) [S][!].gb
262.144	bytes
CRC32: ad9c17fb
MD5: 1475824e7262c0d6359f43c287e034a5
SHA1: 91a8e49bf6eac5fe62ec2cc5e6decbd08ce9b515

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --