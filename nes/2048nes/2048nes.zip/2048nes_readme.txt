2048 (NES)
Traducción al Español v1.0 (20/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
2048.nes
MD5: 8544a91dafff6b0a268fe67c3655104c
SHA1: b9b6e11f4834e51b81993653e65c266aaea3ceb8
CRC32: 73e0d658
16400 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --