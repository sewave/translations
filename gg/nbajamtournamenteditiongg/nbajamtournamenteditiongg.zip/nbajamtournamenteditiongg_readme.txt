NBA Jam - Tournament Edition (Game Gear)
Traducción al Español v1.0 (16/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
NBA Jam - Tournament Edition (World).gg
MD5: cfb2427a59cf67223e25ab2c46abca3e
SHA1: c34e318852ca6f52e980c7a63721a145cd167843
CRC32: 86c32e5b
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --