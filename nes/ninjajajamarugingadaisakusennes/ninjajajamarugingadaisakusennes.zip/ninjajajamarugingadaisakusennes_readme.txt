Ninja Jajamaru - Ginga Daisakusen (NES)
Traducción al Español v1.0 (24/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la traducción de HTI.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Jajamaru - Ginga Daisakusen (Japan).nes
MD5: 80444bfdbcfe2973418500a99693af5d
SHA1: 42d8c7f151b1fbb6f9d5df0d1b000e9c726ce051
CRC32: 7934c198
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --