Amazing Penguin (Game Boy)
Traducción al Español v1.0 (25/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Amazing Penguin (UE) [!].gb
MD5: d8326bfee457ccb2c0afb8dd6ac11db2
SHA1: 84cc6452823eb05ee38679aec86e3cc6e4a50e6f
CRC32: 3011d5ca
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --