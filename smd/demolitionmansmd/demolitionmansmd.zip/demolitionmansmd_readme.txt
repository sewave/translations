Demolition Man (Mega Drive)
Traducción al Español v1.0 (23/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Demolition Man (USA, Europe).md
MD5: a7d8154ebc55d4d680d35c359ec1e0bc
SHA1: 40d71f6bd6cd44f8003bfaff8c953b0693ec1b01
CRC32: 5ff71877
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --