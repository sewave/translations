Hobgoblin (ZX Spectrum)
Traducción al Español v1.0 (09/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hobgoblin.tzx
MD5: 03a2a5dc8508b82601f98ac0b7d993a1
SHA1: b0c38f3109453bf3aa8aeab6a382301c66994b5f
CRC32: 0808cf69
31604 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --