Wonder Boy (Game Gear)
Traducci�n al Espa�ol v1.0 (19/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wonder Boy (E) [!].gg
MD5: 03adbea26158137de3f18d82e119c520
SHA1: f2c546bc87c5e89719fe01a59142bb3250861b83
CRC32: ea2dd3a7
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --