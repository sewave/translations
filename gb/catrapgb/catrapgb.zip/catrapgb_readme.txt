Catrap (Game Boy)
Traducción al Español v1.0 (26/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Catrap (U) [!].gb
MD5: 5a75fe8de54e4cbd09cae23f050f6965
SHA1: 171e4d54f22f8dc137d12828fcc2da9874c56970
CRC32: adb96150
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --