Kid Chameleon (Mega Drive)
Traducción al Español v2.0 (18/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Retraducidos y alargados textos de los niveles
-Script revisado
-Acentos en la introducción
-Traducido menú de pausa

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kid Chameleon (USA, Europe).md
MD5: 756e603b6cf9b3ebbb1b0f79d9447e43
SHA1: 28b904000b2863b6760531807760b571f1a5fc1d
CRC32: ce36e6cc
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --