Teenage Mutant Hero Turtles (ZX Spectrum)
Traducción al Español v1.0 (25/02/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Teenage Mutant Hero Turtles.tzx
MD5: 85ce0181f447a7028b2fa5c13a314b6f
SHA1: 56427d76809b559f649aa0d81d60978cdcc913c2
CRC32: 63f160a5
54644 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --