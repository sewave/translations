Daffy Duck (Game Boy)
Traducción al Español v1.0 (13/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Daffy Duck (USA, Europe) (SGB Enhanced).gb
MD5: 7c9cef32db758d3f6b8a8a23b6902e2d
SHA1: 75b384222d07947baed2213c288385c4b91e1911
CRC32: c47671f3
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --