Rolo to the Rescue (Mega Drive)
Traducción al Español v1.0 (11/09/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rolo to the Rescue (UE) [!].bin
MD5: 46f0c65ea34800bd53c14712ad57eeff
SHA1: 8f27907df777124311b7415cd52775641276cf0d
CRC32: 306861a2
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --