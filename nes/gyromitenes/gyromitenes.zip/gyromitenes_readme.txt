Gyromite (NES)
Traducci�n al Espa�ol v1.0 (25/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gyromite (W) [!].nes
MD5: 8f8f7d4615b0fef23c0754b7641ec03b
SHA1: 77b3a27b07cf7625227478ada2d42006cad3f7d6
CRC32: e54840ec
40976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --