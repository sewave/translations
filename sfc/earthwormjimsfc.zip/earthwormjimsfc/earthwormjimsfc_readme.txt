Earthworm Jim (Super Nintendo)
Traducci�n al Espa�ol v1.0 (24/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Earthworm Jim (U) [!].smc
3.145.728 bytes
MD5: 25fdebdec0e83132d8f24e9ac5bfc45f
SHA1: 3b666f44ea7574caafb9d64cd4d4c74dd3f81a61
CRC32: 3a4a47eb

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --