Rolling Thunder (NES)
Traducción al Español v1.0 (03/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rolling Thunder (USA) (Unl).nes
MD5: 3457fc34e9ccfb43854353d5db3052ca
SHA1: 9a65a1190f9a6fe136856bd2a7696604de241ea8
CRC32: e68a35bc
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --