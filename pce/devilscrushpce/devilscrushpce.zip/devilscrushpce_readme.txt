Devil's Crush (PC Engine)
Traducción al Español v1.0 (08/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Devil's Crush (USA).pce
MD5: 92fbe89d4c87bf283dbfbeac69a64e6e
SHA1: 1c54fb80e5acf82d7346dd7f2e8db8c74c58f4ba
CRC32: 157b4492
393216 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --