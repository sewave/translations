The Pirates of Dark Water (Mega Drive)
Traducci�n al Espa�ol v1.0 (05/10/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pirates of Dark Water, The (UE).bin
MD5: eb0eda9027dd52008594b2755066df86
SHA1: 55496714f32eb7f57335201f90b3f437a1500c49
CRC32: 0a62de34
2.097.152 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --