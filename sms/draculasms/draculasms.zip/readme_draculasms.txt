Bram Stoker's Dracula (Master System)
Traducci�n al Espa�ol v1.0 (24/12/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Bram Stoker's Dracula
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Bram Stoker's Dracula
-----------------
Plataformas basado en la pelicula, bastante logrado identico a la version de NES (excepto el colorido).

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Bram Stoker's Dracula (E) [!].sms
262.144	bytes
CRC32: 1b10a951
MD5: 4b3c934b3daa99a6b341da57388a7543
SHA1: 6c9f52cdae96541020eaaa543ca6f729763f3ada

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --