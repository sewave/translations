Wizards & Warriors (NES)
Traducción al Español v1.0 (29/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wizards & Warriors (U) (PRG1) [!].nes
MD5: 8769d413aa2fddabeac54a0ac2c6b3c0
SHA1: f1e061a739ed0a1963a357c8df3f19fffd9b77c3
CRC32: d6fc36aa
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --