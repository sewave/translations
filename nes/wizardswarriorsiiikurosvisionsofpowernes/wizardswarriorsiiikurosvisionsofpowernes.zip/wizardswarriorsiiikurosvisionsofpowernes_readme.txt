Wizards & Warriors III - Kuros...Visions of Power (NES)
Traducción al Español v1.1 (05/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglados textos con números no válidos y pequeña revisión de script.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wizards & Warriors III - Kuros...Visions of Power (USA).nes
MD5: 36a820680b83c3a5efbc46f43e36cca9
SHA1: 9c04e7357e5b39cfd9d0a119c52102197b4a1be0
CRC32: 4f505449
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --