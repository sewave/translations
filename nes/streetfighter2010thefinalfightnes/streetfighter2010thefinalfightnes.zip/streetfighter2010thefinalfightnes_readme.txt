Street Fighter 2010 - The Final Fight (NES)
Traducción al Español v2.0 (14/10/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducido menú de estado en juego
-Traducido PRESS START y The Final Fight en el título
-Traducido TARGET
-Traducido FADEIN!
-Guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Street Fighter 2010 - The Final Fight (USA).nes
MD5: 33205e81e0e6a50156f2f0b0fbbb427d
SHA1: 442445bd955e3228b4f94dff9ccddc30bcec8253
CRC32: 50ae9a9b
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --