Chuck Rock II - Son of Chuck (Master System)
Traducci�n al Espa�ol v1.0 (06/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chuck Rock II - Son of Chuck (E) [!].sms
MD5: ad6c6ffe26d93298ae56bdea8eafc879
SHA1: 46c326d7eb73b0393de7fc40bf2ee094ebab482d
CRC32: c30e690a
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --