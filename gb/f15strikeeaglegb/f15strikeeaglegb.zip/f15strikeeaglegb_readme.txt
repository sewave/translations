F-15 Strike Eagle (Game Boy)
Traducción al Español v1.0 (14/10/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
F-15 Strike Eagle (USA, Europe).gb
MD5: a8b74d14e66f7a3049e79ca147141d52
SHA1: 237a08abe860bce316f1ce337afb11ee0e566037
CRC32: 045dee8c
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --