S.C.A.T. - Special Cybernetic Attack Team (NES)
Traducción al Español v1.0 (17/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
S.C.A.T. - Special Cybernetic Attack Team (U) [!].nes
MD5: d8cbc5f2dbf44fae5239a170ad6a092d
SHA1: 74a15693eebc2c01c7982c0c9a3f294bc26f53a7
CRC32: 19abbf3c
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --