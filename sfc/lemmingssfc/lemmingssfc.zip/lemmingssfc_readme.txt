Lemmings (Super Nintendo)
Traducción al Español v1.0 (19/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lemmings (USA) (Rev 1).sfc
MD5: ecf0db12f88db32c4a129ff11af7f73d
SHA1: 10fcf1268cf9bc53e7815c843ea506a77d5e1a9e
CRC32: 51e3d566
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --