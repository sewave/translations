Friday the 13th (NES)
Traducción al Español v1.0 (19/06/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Friday the 13th (USA).nes
MD5: 823d631e20fe6239207965be6a453141
SHA1: f7897f46a4dcfef1e484d80b10f0810f986f9e25
CRC32: f19a4249
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --