Godzilla - Monster of Monsters! (NES)
Traducción al Español v1.0 (25/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Godzilla - Monster of Monsters! (USA).nes
MD5: edc3b87c475c40d9b341f653c6b9da18
SHA1: 9471686d4c29ce460a20fa64406dcb532a1c7e32
CRC32: 198b4e3b
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --