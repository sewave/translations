Hollywood Pinball (Game Boy Color)
Traducción al Español v1.0 (10/05/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hollywood Pinball (Europe) (En,Fr,De,It) (GB Compatible).gbc
MD5: 9889afc5b4e72c9f96db8e6b4260f6b7
SHA1: 2d179e034dbd19e48aee31ffdc504305444cc84a
CRC32: 8bd1f635
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --