Psycho Hopper (ZX Spectrum)
Traducción al Español v1.0 (27/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Psycho Hopper.tzx
MD5: 96ef2b334c8a0b55912eeb4c652d20b5
SHA1: cb5d1bd9d4657b4debd85c226d3a6a919938f5cf
CRC32: 77a86b6e
50233 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --