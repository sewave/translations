Lightgun Game 2 in 1 - Tough Cop + Super Tough Cop (NES)
Traducción al Español v1.0 (01/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lightgun Game 2 in 1 - Tough Cop + Super Tough Cop (Asia) (Unl).nes
MD5: ee2fa6fdd114e5d5a38386c1a049634b
SHA1: c7cb10e71894e0162cbaece4db0cecb2ea2661d2
CRC32: 7ec004cb
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --