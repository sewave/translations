Puzznic (NES)
Traducci�n al Espa�ol v1.0 (20/07/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Puzznic (U) [!].nes
65.552 bytes
MD5: 5c26f435f26459ef431fa11c0ec1b4d4
SHA1: 2c35fe417679713f9925f1dba0ba8e3bd319f5cd
CRC32: 327e666a

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.
juandex - Testing

-- FIN --