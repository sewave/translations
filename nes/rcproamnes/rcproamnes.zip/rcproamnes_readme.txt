R.C. Pro-Am (NES)
Traducción al Español v1.1 (02/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado ranking.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
R.C. Pro-Am (USA) (Rev 1).nes
MD5: 500b1dff51abc465b26c069e9b730dd4
SHA1: fc133e4eda2ce05e163782d494aedace543a9ed2
CRC32: 0296e5f4
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --