Solomon's Key (NES)
Traducción al Español v1.0 (14/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Solomon's Key (U) [!].nes
MD5: 097f3eb5211e106a5ea6ec43e0c439de
SHA1: 18102689fd35c7d531a5e6241b06b748accab2f6
CRC32: 99773bc4
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --