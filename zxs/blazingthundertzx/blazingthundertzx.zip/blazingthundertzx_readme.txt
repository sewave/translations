Blazing Thunder (ZX Spectrum)
Traducción al Español v1.0 (20/01/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blazing Thunder.tzx
MD5: 7ab1990aba0e5f3b3443088e0bfa89dc
SHA1: 696d5ce2d4ad4068abac10b6713bde9f4354f220
CRC32: b61515dc
46602 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --