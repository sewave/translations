The Incredible Crash Dummies (Master System)
Traducción al Español v1.0 (10/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Incredible Crash Dummies, The (E) [!].sms
MD5: 429738d19911881f443582a303ecd7f5
SHA1: 94a4ba183de82fc0066a0edab2acaee5e8bdd0e7
CRC32: b4584dde
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --