Pizza Pop! (NES)
Traducción al Español v1.0 (30/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de pacnsacdave.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pizza Pop! (Japan).nes
MD5: ad1a3c0b4f598ff55f9df5e8e212a97b
SHA1: 181921a0b34bef08c3c0a6880d3b7e03ac850152
CRC32: 361729fa
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas al español.

-- FIN --