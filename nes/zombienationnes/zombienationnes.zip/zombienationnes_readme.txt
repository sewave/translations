Zombie Nation (NES)
Traducción al Español v1.0 (28/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zombie Nation (USA).nes
MD5: 41a7f3aa196031a0ebac9f249cd78ab3
SHA1: f0c1172205c7cce9ae42676a287d9c65b5c3597e
CRC32: 29685f24
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --