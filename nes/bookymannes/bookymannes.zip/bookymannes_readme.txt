Booky Man (NES)
Traducción al Español v1.0 (30/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Booky Man (Spain) (Gluk Video) (Unl).nes
MD5: 84d0098e3718885d479072cc2218756f
SHA1: fca4651e01f3282e890b481774b237ec41708fd3
CRC32: de1bdbf3
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --