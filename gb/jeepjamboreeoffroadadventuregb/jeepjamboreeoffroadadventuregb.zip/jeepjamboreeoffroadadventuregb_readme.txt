Jeep Jamboree - Off-Road Adventure (Game Boy)
Traducción al Español v1.0 (13/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jeep Jamboree - Off-Road Adventure (USA).gb
MD5: 47b2627e14592a8c5b53c84c5f06400b
SHA1: 988a40823f7db661bc91ffff8fc1bcd80e64f18d
CRC32: a1e76a33
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --