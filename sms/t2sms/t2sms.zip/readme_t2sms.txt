Terminator 2 - Judgment Day (SMS)
Traducci�n al Espa�ol v1.0 (19/11/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Terminator 2 - Judgment Day
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Terminator 2 - Judgment Day
-----------------
Version sms del juego basado en la pelicula, identico al de game gear.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Terminator 2 - Judgment Day (E) [!].sms
262.144	bytes
CRC32: ac56104f
MD5: cc2454eebbbfab7ba99851a923dfdaaf
SHA1: a8fe50e27fa9d44f3bd05d249a964352a32d1799

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --