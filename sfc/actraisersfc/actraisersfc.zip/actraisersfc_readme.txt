ActRaiser
Traducci�n al Espa�ol v1.1 (15/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre ActRaiser
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre ActRaiser
-----------------
Gran simulador/arcade de Enix, muy original.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basado en la traducci�n al ingles de Aeon Genesis.
v1.1: Arreglada frase al morir.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
La velocidad de texto m�xima descuadra los textos, pasa en el parche al ingles original.
Si usas el arroz fuera de un campo con plantas, da un texto incorrecto, pasa en el parche al ingles original.
Si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
ActRaiser (J).smc
1.048.576 bytes
CRC32: bee9b30c
MD5: 3cb1a7ae9fd34a56015f752fd138070e
SHA1: f031fc983a2eed4d69e223b256ece5f037fb5d5d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Original:
Contributor	Type of contribution	Listed credit
Gideon Zhi	Hacking					Project leader, ROM hacker, translator
Ian Kelley	Translation	

-- END OF README --