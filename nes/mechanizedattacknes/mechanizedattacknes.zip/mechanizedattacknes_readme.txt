Mechanized Attack (NES)
Traducción al Español v1.0 (06/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mechanized Attack (U) [!].nes
MD5: 325873b147c7e6887913c5d3b5f4525a
SHA1: 7ac704367a42ee41eee838a2cc0a520cbaed77aa
CRC32: d56644b7
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --