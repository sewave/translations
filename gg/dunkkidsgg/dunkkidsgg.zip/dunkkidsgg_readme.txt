Dunk Kids (Game Gear)
Traducción al Español v1.0 (31/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dunk Kids (Japan).gg
MD5: 1d1c50cdbfe605a37d5dcf1250a951df
SHA1: 7525923ba2531d5079d66b2b1156cb5e7d44c66a
CRC32: 77ed48f5
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --