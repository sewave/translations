Gunrunner (ZX Spectrum)
Traducción al Español v1.0 (25/02/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gunrunner.tzx
MD5: df520a117e84a989d3f558a942b6b113
SHA1: bbf5cdb1a46a504007e52379fe01edbd06c02d0c
CRC32: 9b47871f
47174 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --