Tiny Toon Adventures 2 - Trouble in Wackyland (NES)
Traducción al Español v1.0 (12/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tiny Toon Adventures 2 - Trouble in Wackyland (USA).nes
MD5: 130dd157d6148f2be3ef60e0ddc968c8
SHA1: 3c17a0bd435eee8e93a7a700ce2a082a66f8b62a
CRC32: ab36e3f7
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --