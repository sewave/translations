Front Line (MSX)
Traducción al Español v1.0 (16/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Front Line (1984) (Taito) (J).rom
MD5: 5ea44c3480d577de238eddcd7b2c6b91
SHA1: ec54e05a6f784f9c616c94ab8d57e5d2647abc66
CRC32: b9d03f7b
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --