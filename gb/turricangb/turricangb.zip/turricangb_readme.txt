Turrican (Game Boy)
Traducci�n al Espa�ol v1.0 (08/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Turrican (UE) [!].gb
MD5: 6534eff4dff0000f66a0059f0b84e71e
SHA1: 3023b2b831be9fe7db62857f1b353700a1c31c75
CRC32: 2359bf0c
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --