Tennis (Game Boy)
Traducción al Español v1.0 (15/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tennis (W) [!].gb
MD5: 7d621dcbbce12b73574c42f40deec275
SHA1: ec45a932fb3fc21394fef5e27e7fe9eccd0c7f70
CRC32: 5009215f
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --