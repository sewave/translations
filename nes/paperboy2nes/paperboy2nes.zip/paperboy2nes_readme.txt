Paperboy 2 (NES)
Traducción al Español v1.0 (02/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Paperboy 2 (USA).nes
MD5: d0f5ec23ed0bb2d6d7ea75c783ca473e
SHA1: ca66bbd5607d96d72045c96a17f0d03967a7f260
CRC32: e02f3836
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --