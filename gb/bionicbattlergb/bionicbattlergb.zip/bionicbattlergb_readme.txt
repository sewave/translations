Bionic Battler (Game Boy)
Traducción al Español v1.0 (25/03/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bionic Battler (U).gb
MD5: b5a6254b1711edfaf89830bcfff09d38
SHA1: 9eca6a5fd1e537085598e8b2903ad75fe9c0b785
CRC32: a1e55dc2
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --