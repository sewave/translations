Warpman (NES)
Traducción al Español v1.0 (25/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Warpman (Japan).nes
MD5: 267e2c93d9b84a9f3502b72e537a9b8c
SHA1: 088c73d4e121dd21d369d4d1c7d2aafeeee0d238
CRC32: ef27556d
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --