Guerrilla War (NES)
Traducción al Español v1.0 (27/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Guerrilla War (USA).nes
MD5: a0912faabef533293b8b490392c9f8b2
SHA1: 77411a2f3a70fd415b2753710e0580dd2d9602f8
CRC32: 005ff9a8
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --