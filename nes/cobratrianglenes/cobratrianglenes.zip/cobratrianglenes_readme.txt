Cobra Triangle (NES)
Traducción al Español v1.0 (17/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cobra Triangle (U) [!].nes
MD5: c23bcf1cb353bc3a7d19b88df01eee59
SHA1: 36636860236c9b83bd6fc92085eba010d1c514da
CRC32: 3802276d
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --