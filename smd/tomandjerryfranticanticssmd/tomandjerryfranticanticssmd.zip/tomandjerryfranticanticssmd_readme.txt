Tom and Jerry - Frantic Antics! (Mega Drive)
Traducción al Español v1.0 (28/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tom and Jerry - Frantic Antics! (USA).md
MD5: 61246a57e46da52d32d934edea7b628f
SHA1: 09dd23ab18dcaf4e21754992a898504188bd76f2
CRC32: 3044460c
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --