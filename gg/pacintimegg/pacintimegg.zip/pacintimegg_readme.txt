Pac-In-Time (Game Gear)
Traducción al Español v1.0 (05/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pac-In-Time (Prototype) [!].gg
MD5: 64109fe1d3d3e34b2963b80685a3f28a
SHA1: bc956615da23f13bddc491377b29631f9c0a4d5a
CRC32: 64c28e20
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --