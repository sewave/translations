DuckTales (Game Boy)
Traducción al Español v1.0 (11/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
DuckTales (USA).gb
MD5: 785441d3d75913393807b10b3194dc48
SHA1: 93460364e33e8fb09a0659738044d0297cd4df69
CRC32: 2bbbb54d
65536 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --