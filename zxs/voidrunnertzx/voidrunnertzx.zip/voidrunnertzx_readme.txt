Voidrunner (ZX Spectrum)
Traducción al Español v1.0 (19/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Voidrunner.tzx
MD5: 3de263e2e4072a24379692e20d1d46c2
SHA1: e8e11b7c3aac78739b218a917258475b6238dc79
CRC32: 30a2ccb5
19760 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --