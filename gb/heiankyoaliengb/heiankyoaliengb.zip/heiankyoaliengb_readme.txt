Heiankyo Alien (Game Boy)
Traducción al Español v1.0 (05/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Heiankyo Alien (U) [!].gb
MD5: b236e81e9f5c19148c24c4984d8ef90f
SHA1: 7372e49dbe5cbb25b8201f52ca544737d06e0fb6
CRC32: 1495bbe5
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --