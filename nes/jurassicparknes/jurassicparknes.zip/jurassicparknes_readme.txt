Jurassic Park (NES)
Traducción al Español v1.0 (14/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jurassic Park (USA).nes
MD5: 02b9809bf7f0c982a32572e480406717
SHA1: 3429cd3d0af90ef2315d63c641826dbf35e3c4b8
CRC32: 11ec53a9
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --