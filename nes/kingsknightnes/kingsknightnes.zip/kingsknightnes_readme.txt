King's Knight (NES)
Traducción al Español v1.0 (24/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
King's Knight (U) [!].nes
MD5: 26d75dc4ff4b3b6ec239db6f516dc19a
SHA1: b43816495eb567d88fb2f25cdd9950384fa5c905
CRC32: d8abbfd8
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --