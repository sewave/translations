Power Blade (NES)
Traducción al Español v2.0 (27/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Alargadas cadenas de texto a 30 caracteres (antes 28)
-Textos retraducidos, movidos y alargados
-Traducidos gráficos GO
-Mejorados gráficos THANKS YOU! del final

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Power Blade (USA).nes
MD5: 316f5b34bb7affd2b5d45ebaa3fd076f
SHA1: 5d2ab4af581d6b81b9a97a505798ae3b2f494d8a
CRC32: 76663e66
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --