Castlevania - Bloodlines
Traducci�n al Espa�ol v1.0 (04/09/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Castlevania - Bloodlines
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Castlevania - Bloodlines
-----------------
Entrega de castlevania para megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Los textos que son sprites, la pantalla de seleccion de personaje y alguna parte de la barra de estado no estan traducidos.
Si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Castlevania - Bloodlines (U) [!].gen
1.048.576 bytes
CRC32: fb1ea6df
MD5: 0f04fc1b5bf8c9a887abcf14ce96b0cd
SHA1: 4809cf80ced70e77bc7479bb652a9d9fe22ce7e6

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --