Shaq-Fu (Mega Drive)
Traducción al Español v1.2 (09/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
-Eliminada palabra doble "ciudad" y reescrito el texto.
V1.2:
-Arreglado bug gráfico al perder y mostrar movimiento especial

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Shaq-Fu (USA, Europe).md
MD5: 72b5848612f80d14bc51807f8c7e239e
SHA1: 1ad8cd54f8fe474da01d1baba98491411c4cedaf
CRC32: 499955f2
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --