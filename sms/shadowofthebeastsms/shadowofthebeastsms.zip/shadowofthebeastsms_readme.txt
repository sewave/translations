Shadow of the Beast
Traducci�n al Espa�ol v1.0 (15/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Shadow of the Beast
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Shadow of the Beast
-----------------
Versi�n de Shadow of the Beast para Master System.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Shadow of the Beast (E) [!].sms
262.144	bytes
CRC32: 1575581d
MD5: abc8a9e43c588c7d0535cc8305bdbf94
SHA1: 45943b021cbaee80a149b80ddb6f3fb5eb8b9e43

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --