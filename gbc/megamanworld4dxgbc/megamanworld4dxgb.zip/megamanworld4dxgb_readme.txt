Mega Man World 4 DX (Game Boy)
Traducción al Español v1.0 (15/02/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de marc_max.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mega Man IV (USA).gb
MD5: 8a00f627b8902c92327435901c249e19
SHA1: 6f0901db2b5dcaace0215c0abdc21a914fa21b65
CRC32: abcea00d
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --