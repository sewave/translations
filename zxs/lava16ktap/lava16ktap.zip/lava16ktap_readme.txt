Lava16K (ZX Spectrum)
Traducción al Español v1.0 (23/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lava16K.tap
MD5: 713498217dad9f1973b32a02126f127a
SHA1: 3623862d764c184bc2e61bb9265cebbaf0294d1f
CRC32: a307f634
8366 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --