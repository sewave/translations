Slap Fight (Mega Drive)
Traducción al Español v1.0 (15/11/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Slap Fight (J) [c][!].bin
MD5: 989f8effd6fbbd93dcabd0be8fd41f8a
SHA1: 3cb992c70b4a5880a3e5f89211f29fe90486c0e0
CRC32: d6695695
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --