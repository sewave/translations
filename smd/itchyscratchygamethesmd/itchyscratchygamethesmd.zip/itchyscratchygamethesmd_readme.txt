The Itchy & Scratchy Game (Mega Drive)
Traducción al Español v1.0 (19/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Itchy & Scratchy Game, The (USA) (Proto).md
MD5: 64f51f149825ee44aa36bcbaea55e961
SHA1: 860d9bd7501d59da8304ab284b385afa4def13a0
CRC32: 81b7725d
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --