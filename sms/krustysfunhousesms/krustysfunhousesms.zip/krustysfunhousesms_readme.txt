Krusty's Fun House (Master System)
Traducción al Español v1.0 (10/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Krusty's Fun House (E) [!].sms
MD5: 86deebacc6413f23fe11ee54011cf4bf
SHA1: 54714a19c2d24260b117ebc5ae391d9b24ca9166
CRC32: 64a585eb
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --