Tintin in Tibet (Game Boy)
Traducción al Español v1.0 (09/03/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tintin in Tibet (Europe) (En,Fr,De,Nl) (SGB Enhanced).gb
MD5: eef71c64f1a51f5e32ab4e6e5e2cc5e8
SHA1: 8d8978fbd5a5634e2cce940122039d575e7b3646
CRC32: 5d2bd778
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --