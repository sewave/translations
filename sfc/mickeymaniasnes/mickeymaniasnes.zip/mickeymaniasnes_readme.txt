Mickey Mania
Traducci�n al Espa�ol v1.0 (03/07/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Mickey Mania
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mickey Mania
-----------------
Gran plataformas de mickey para la 16 bits de nintendo.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mickey Mania (U) [!].smc
2.097.152 bytes
CRC32: 08806b5b
MD5: e3f9cc6d8321fa661a30cabe5dce141a
SHA1: 34b11763d672df886789c428f7cf8a567876a57e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --