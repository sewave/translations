Ace of Aces (Master System)
Traducción al Español v1.0 (02/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ace of Aces (E) [!].sms
MD5: ce26b4372655f35f1b7c9d0c3b700f93
SHA1: 08a79905767b8e5af8a9c9c232342e6c47588093
CRC32: 887d9f6b
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --