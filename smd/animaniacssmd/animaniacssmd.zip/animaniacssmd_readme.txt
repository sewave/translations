Animaniacs (Mega Drive)
Traducción al Español v2.1 (10/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Reescritura de guion
V2.1:
-Arreglados "ves" por "ve"

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Animaniacs (USA).md
MD5: ce0a42a75a9e374cf5092f34bf6927b7
SHA1: 7e9d70b5172b4ea9e1b3f5b6009325fa39315a7c
CRC32: 86224d86
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --