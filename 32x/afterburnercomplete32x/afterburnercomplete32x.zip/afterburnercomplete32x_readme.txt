After Burner Complete (32X)
Traducci�n al Espa�ol v1.0 (11/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
After Burner Complete (JU) (32X) [!].32x
MD5: ec9529858cc7961b39f5382b2f657b8f 
SHA1: 9cf575feb036e2f26e78350154d5eb2fd3825325
CRC32: 204044c4
2.097.152 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --