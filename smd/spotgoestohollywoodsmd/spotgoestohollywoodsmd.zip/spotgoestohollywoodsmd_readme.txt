Spot Goes to Hollywood (Mega Drive)
Traducción al Español v1.0 (29/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spot Goes to Hollywood (U) (REV01) [!].bin
MD5: f3c5a2a9eae5cffbdc9f87c20fb492fc
SHA1: 064a384f745eeffee3621d55a0278c133abdbc11
CRC32: bdad1cbc
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --