Monster Truck Rally (NES)
Traducción al Español v1.0 (19/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Monster Truck Rally (USA).nes
MD5: 69376bb48ee7bdf79671cf0e7cce0ba7
SHA1: 8e44581df8fc310ba15b0cffb177246c5fd5656b
CRC32: 60429651
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --