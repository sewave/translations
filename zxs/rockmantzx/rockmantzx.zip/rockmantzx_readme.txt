Rockman (ZX Spectrum)
Traducción al Español v1.0 (03/12/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rockman.tzx
MD5: 988b476fb94552732d9caecb665f6752
SHA1: ac750b4c1e3ce5e173f29a16851c70abb9e1f722
CRC32: fc910d49
48149 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --