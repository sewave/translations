Athletic Land (MSX)
Traducción al Español v1.0 (24/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Athletic Land (1984) (Konami) (J).rom
MD5: 2ad5cea9a2f22cb66b95317bb864e176
SHA1: 90bdd12d632d2e909ac5d69235ad0366f430b734
CRC32: 7b1acdea
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --