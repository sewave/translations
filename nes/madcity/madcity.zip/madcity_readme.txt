Mad City
Traducci�n al Espa�ol v1.2 (01/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Mad City
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mad City
-----------------
Versi�n japonesa de "Adventures of Bayou Billy", mucho m�s jugable.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basado en la de Stardust Crusaders.
v1.1: parche para la version japonesa, anteriormente era el parche para la inglesa.
V1.2: Arreglos menores en cr�ditos y ending bueno.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mad City (J) [!].nes
262.160	bytes
CRC32: b28d64fc
MD5: ceae892a71b63cbf7534c04cd09f2819
SHA1: fcad4b5bc48e2f6e46f081e01d6cefa33a3a7e0c

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al espa�ol

--Versi�n Inglesa--
Contributor	Type of contribution	Listed credit
Pennywise	Hacking	
Jonny2x4	Translation	Translation Review + Additional Translation
DvD	Graphics	Title Screen Design & Hacking

-- END OF README --