Ninja Kid (NES)
Traducción al Español v1.0 (28/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ninja Kid (USA).nes
MD5: ebfa12fbcd9125fd30441bba240152d1
SHA1: fbc7b428c7156216ffd31796874a05baf824f5ec
CRC32: 4de7236f
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --