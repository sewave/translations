The Addams Family - Pugsley's Scavenger Hunt (Super Nintendo)
Traducción al Español v1.0 (08/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Addams Family, The - Pugsley's Scavenger Hunt (USA).sfc
MD5: 2dc248f730b474e24452eba7971dfbd9
SHA1: 3419e8a5fef813bc0234169f9e8055444dc2049b
CRC32: 153a00a7
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --