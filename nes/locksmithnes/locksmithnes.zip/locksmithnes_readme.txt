Locksmith (NES)
Traducción al Español v1.0 (12/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Locksmith (Asia) (Ja) (PAL) (Unl).nes
MD5: 3e75a9f5a1b09d331b21898f4dfc7e8b
SHA1: 30b10c08aced054768a49a5f2024229dddaa4aac
CRC32: 9b84a9d4
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --