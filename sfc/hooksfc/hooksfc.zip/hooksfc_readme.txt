Hook
Traducci�n al Espa�ol v1.0 (22/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Hook
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Hook
-----------------
Adaptaci�n de la pel�cula.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Hook (U) (29252).smc
1.048.576 bytes
CRC32: 82ff23bc
MD5: 77742b53c27ac1db25af2ea8ace3d63f
SHA1: b2ebb39efcf8a09450fb3c4731812a7c2541d336

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --