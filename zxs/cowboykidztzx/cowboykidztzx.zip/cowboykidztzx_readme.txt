Cowboy Kidz (ZX Spectrum)
Traducción al Español v1.0 (24/02/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cowboy Kidz.tzx
MD5: cc3f3ac1fd4b946df24353af32d67a2d
SHA1: 5bfebc0dc86158beea56e58b07ef3b1bffb36833
CRC32: 5c99181e
47832 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --