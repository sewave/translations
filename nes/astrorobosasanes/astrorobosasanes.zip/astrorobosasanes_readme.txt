Astro Robo Sasa (NES)
Traducción al Español v1.0 (07/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Astro Robo Sasa (Japan).nes
MD5: 00228c95eddba9a604b6e8e3760a57b3
SHA1: d7a35f5ad1f68284e64330eda80a85335995c00a
CRC32: cab240b1
40976 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --