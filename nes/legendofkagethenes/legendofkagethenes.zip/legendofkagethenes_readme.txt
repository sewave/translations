The Legend of Kage (NES)
Traducci�n al Espa�ol v1.0 (12/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Legend of Kage, The (U) [!].nes
MD5: 31b79fea43089a702ae6ad1c6835a58b
SHA1: ba1541b80f6789a07c6016de1f5325261aea527b
CRC32: 6785c961
49.168 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --