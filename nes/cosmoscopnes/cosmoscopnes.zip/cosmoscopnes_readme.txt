Cosmos Cop (NES)
Traducción al Español v1.0 (30/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cosmos Cop (Spain) (Gluk Video) (Unl).nes
MD5: fce7d809e44d489aea8e54780dc2eae6
SHA1: 72f1ecb004377348d94f1fdd36b6da42e9ad0601
CRC32: 30b25432
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --