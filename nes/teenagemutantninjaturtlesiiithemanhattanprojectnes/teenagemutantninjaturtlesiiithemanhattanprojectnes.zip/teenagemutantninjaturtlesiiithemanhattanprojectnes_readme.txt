Teenage Mutant Ninja Turtles III - The Manhattan Project (NES)
Traducción al Español v2.3 (16/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Alargadas opciones en título
-Añadidos ¡¿Ñ
-Guion revisado
-Traducido GAME OVER pequeño y grande
-Traducido globo de texto
V2.1:
-Arreglado bug que hace invencible a Shredder por omitir "KONAMI" del título, para que haga efecto hay que iniciar la partida de cero.
V2.2:
-Arreglado espaciado del texto introductorio de la segunda fase.
V2.3:
-Arreglado texto de ETAPA 6 que mostraba ETAPA 4 incorrectamente.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles III - The Manhattan Project (USA).nes
MD5: 483695de094f4dd49652c5bc78bdba19
SHA1: 30b6afb694ab5045b88f723a1ade44575c33fb69
CRC32: dbb3bc30
524304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --