Kabuki - Quantum Fighter (NES)
Traducción al Español v2.0 (23/11/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Guion retraducido
-Cambiada fuente por una más estilizada
-Traducida pantalla de licencia
-Traducida pantalla de título
-Mejorada barra de estado
-Traducida ficha de SCOTT
-Traducido gráfico 1UP
-Traducido gráfico THE END

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kabuki - Quantum Fighter (USA).nes
MD5: d5b486e9fcac1376bf18f71af9dd999e
SHA1: 7b07791f9aea7170a43f54390b45f2904f78ff0f
CRC32: 5ee7a400
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --