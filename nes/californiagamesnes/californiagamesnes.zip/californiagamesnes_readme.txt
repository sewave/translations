California Games (NES)
Traducción al Español v1.0 (05/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
California Games (USA).nes
MD5: 4ccd88010450fe71165351a0152cb619
SHA1: ed0ec77caf7ae0ace254266af054ec3cedd0c81c
CRC32: 1c6f3036
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --