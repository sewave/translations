Power Blade 2 (NES)
Traducción al Español v2.0 (14/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducida pantalla PASSWORD
-Mejorada pantalla de título
-Mejorada barra de estado
-Traducidos gráficos CHANGE
-Guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Power Blade 2 (USA).nes
MD5: 7c48ad4d6b511f7ce6530c46f8179d9c
SHA1: cbd35c583d99d2181f0e482666adff3fb8456d74
CRC32: f8e0bc9b
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --