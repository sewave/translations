Silent Assault (NES)
Traducción al Español v1.0 (13/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Silent Assault (USA) (Unl).nes
MD5: 5728699d313c3426ff8d8c871c0acbad
SHA1: 2bdfaa5d4482557211a3debae5569b5fe5bc3f8f
CRC32: fcb5b1bc
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --