Tank Command (ZX Spectrum)
Traducción al Español v1.0 (23/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tank Command.tzx
MD5: 13667ac05a7bce794fbd37ece21b483a
SHA1: e7f21ea33a68e8c59956b8e0ceb729df26bfe78c
CRC32: c971a06c
48337 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --