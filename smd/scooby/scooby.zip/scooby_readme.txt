Scooby Doo Mystery
Traducción al Español v0.9 (03/07/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Scooby Doo Mystery
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Créditos del Parche

-----------------
1. Sobre Scooby Doo Mystery
-----------------
Scooby Doo Mystery es una aventura al más puro estilo Lucas Arts que no salió de América
este parche lo traduce completamente al Inglés.

---------------------
2. Notas del Proyecto
---------------------
Esta traducción y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Al hablar con alguien el menú de acciones cambia de color
esto es así porque la MegaDrive carga las letras con el color
del actor que habla, es una limitación por tener que utilizar
los caracteres Ascii para el menú ya que no he podido
encontrar los gráficos del menú para cambiarlos.

Al haber añadido caracteres especiales para poder contraer
las acciones del menú, los passwords cambian un poco, aquí
la tabla de equivalencias para introducirlos:
+ = LA
# = MI
% = JA
* = BI

En caso de encontrar algún fallo, contactad conmigo en https://traduccioneswave.blogspot.com/

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche está en formato IPS, recomiendo usar LunarIPS.

Scooby Doo Mystery (USA).md or Scooby Doo Mystery (W) [!].bin
CRC32: 7bb9dd9b
MD5: f27ea503631e67c05860926099d97f7a
SHA1: ccc9542d964de5bdc1e9101620cae40dd98e7127

----------------------
5. Créditos del Parche
----------------------
Wave - Hacking y traducción

Gracias especiales al foro de GP32SPAIN por probar el parche.

-- END OF README --