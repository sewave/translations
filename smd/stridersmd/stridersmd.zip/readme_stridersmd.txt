Strider
Traducci�n al Espa�ol v1.0 (05/02/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Strider
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Strider
-----------------
Adaptacion de la recreativa para la megadrive, clasico plataformero.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Strider (UE) [!].bin
1.048.576 bytes
CRC32: b9d099a4
MD5: fcab622a6e56f7e9b1e0907ab5a630df
SHA1: b9d099a4

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --