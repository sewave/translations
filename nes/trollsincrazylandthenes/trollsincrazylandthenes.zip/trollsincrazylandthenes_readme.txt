The Trolls in Crazyland (NES)
Traducción al Español v1.0 (17/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Trolls in Crazyland, The (Europe).nes
MD5: ac384bdfa9187ce1672b89d11964f1cc
SHA1: 3cc31c98232cde912b69c017d6097f62dadf853c
CRC32: cc12bb92
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --