Phantom Fighter (NES)
Traducción al Español v1.0 (05/12/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Phantom Fighter (USA).nes
MD5: 857acdbe0c472615d4f75d9a7f1ecf34
SHA1: 373b6c4721e73142ea77be78439e741d6f86ad29
CRC32: 9dde4e60
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --