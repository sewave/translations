Super Mario Bros (NES)
Traducción al Español v1.0 (04/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Mario Bros. 2 (J) [hM04].nes
MD5: ad4674a3825228d444ff18a0543909d5
SHA1: 38d60b69899343c084db1a5ec067de30ce86458a
CRC32: 7eca8972
81936 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --