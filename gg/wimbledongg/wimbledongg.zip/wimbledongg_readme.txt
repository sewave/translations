Wimbledon (Game Gear)
Traducción al Español v1.0 (24/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wimbledon (World).gg
MD5: 05e39eb8dc19c023f4a4fed36c058675
SHA1: 6aa588e0aa93c5c74c80f7044de49933291af4e9
CRC32: ce1108fd
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --