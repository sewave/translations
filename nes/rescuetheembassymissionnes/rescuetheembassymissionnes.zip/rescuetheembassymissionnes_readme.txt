Rescue - The Embassy Mission (NES)
Traducci�n al Espa�ol v1.0 (19/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Rescue - The Embassy Mission (U) [!].nes
MD5: 40a59ad73d28047df21cec57d8bff399
SHA1: 8c3a5f1fff7470618111976cefaea6c41e3e4b31
CRC32: 0e4fe1f3
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --