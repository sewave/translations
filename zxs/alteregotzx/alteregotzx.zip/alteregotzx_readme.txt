Alter Ego (ZX Spectrum)
Traducción al Español v1.0 (13/02/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Alter Ego.tzx
MD5: 7e2986acd5d0c31879e69b25e0d9c62b
SHA1: 157280602be4db996000e6ab80e477f48a314dfc
CRC32: 9abd6dfb
38948 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --