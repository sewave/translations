Tale Spin (Game Gear)
Traducci�n al Espa�ol v1.0 (01/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Tale Spin (U) [!].gg
MD5: 0c03df9b73f191c27755c3816343827f
SHA1: 60e5c27a07a69969ea1ba830cc82df33a5fbf227
CRC32: f1732ffe
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --