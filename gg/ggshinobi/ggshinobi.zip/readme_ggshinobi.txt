GG Shinobi
Traducci�n al Espa�ol v1.0 (15/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre GG Shinobi
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre GG Shinobi
-----------------
Shinobi para la portatil de sega.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
GG Shinobi (E) [!].gg
262.144	bytes
CRC32: 30f1c984
MD5: 8fa7438dec1403f2e9d7b1ca60b29f1a
SHA1: 2e7303f82d885cb84fa557e211954808c8ebe779

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --