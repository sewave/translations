Bomb Jack
Traducci�n al Espa�ol v1.0 (18/05/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Bomb Jack
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Bomb Jack
-----------------
Adaptaci�n del cl�sico plataformero para la Sega SG-1000.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Bomb Jack (SG-1000).sg
32.768 bytes
CRC32: ea0f2691
MD5: 0bf5b6959fc1b58d8e37f9647f47a0b3
SHA1: 7859b9ee5614c595cb57a832ef7a8f1ab473b45b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --