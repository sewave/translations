Home Alone 2 - Lost in New York (Mega Drive)
Traducción al Español v1.0 (17/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Home Alone 2 - Lost in New York (U) [!].bin
MD5: 9ccafedaed5426819fefc3ae17a04fd2
SHA1: 24232a572b7eabc3e0ed5f483042a7085bd77c48
CRC32: cbf87c14
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --