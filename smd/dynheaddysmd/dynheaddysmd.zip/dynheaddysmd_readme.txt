Dynamite Headdy
Traducci�n al Espa�ol v1.1 (14/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Dynamite Headdy
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Dynamite Headdy
-----------------
Dynamite Headdy es un juego original de plataformas/accion para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basado en la traducci�n a ingl�s de M.I.J.E.T.
v1.1: Correcciones de texto.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Dynamite Headdy (J) [c][!].gen
2.097.152 bytes
CRC32: d03cdb53
MD5: cdb36911439289d3453060f58682057c
SHA1: 02727a217e654f3cdf5a3fcd33b2f38d404a467d

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Versi�n inglesa:
Contributor	Type of contribution	Listed credit
M.I.J.E.T.	Hacking	Full Hacking & Translation

-- END OF README --