Magic Maze (Game Boy)
Traducción al Español v1.0 (12/04/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Magic Maze (Sachen) [!].gb
MD5: 9420631b09c29dc05793c6b1afc6347a
SHA1: b44fd8a827dd3cffb4733c48d710d9a4e81b4314
CRC32: b1acbd28
32768 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --