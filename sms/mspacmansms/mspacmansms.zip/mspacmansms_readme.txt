Ms. Pac-man (Master System)
Traducci�n al Espa�ol v1.0 (12/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ms. Pac-man (E) [!].sms
MD5: e492a237f62ea6a5b7e71ff1a3fc0f33
SHA1: 4dd7cb303793792edd9a4c717a727f46db857dae
CRC32: 3cd816c6
131.072 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --