Golf Mania (Master System)
Traducción al Español v1.0 (29/02/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Golf Mania (UE) [!].sms
MD5: 5554f9f67103e0d5b1a4075a2d26d15b
SHA1: d0b964dd7cd8ccdd730de4d8e4bb2e87bea7686e
CRC32: 48651325
262144 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --