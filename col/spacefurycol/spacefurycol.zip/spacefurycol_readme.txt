Space Fury (Colecovision)
Traducción al Español v1.0 (23/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

Los textos de selección de modo de juego pertenecen a la bios y no pueden traducirse desde la rom del juego.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Space Fury (1983) (Sega).col
MD5: f821cf20b7faa5c2cb738cd8aa90dc95
SHA1: f400e1e368ae420a97015674a28db91b4bea15a6
CRC32: df8de30f
16384 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --