Nintendo World Cup (Game Boy)
Traducción al Español v1.0 (27/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nintendo World Cup (U) [!].gb
MD5: c9200b1be878f079cee6cbebbeaa27ea
SHA1: 9308dadfeb1becb81fe35015397df6e8e8ead06e
CRC32: 96c24e13
131072 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --