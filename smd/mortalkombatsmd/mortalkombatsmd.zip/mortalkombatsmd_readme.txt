Mortal Kombat (Mega Drive)
Traducción al Español v1.0 (17/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mortal Kombat (World) (v1.1).md
MD5: e0bb4d00ea95b75aac52851fb4d8ee47
SHA1: 2c4a0618cc93ef7be8329a82ca6d2d16f49b23e0
CRC32: 33f19ab6
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --